# HF_trimer_I.pml — HF Trimer | F-F distances | Config 2 (R = 2.0 Å)
# Atom order (from 2_2.0.xyz): H_A=1, F_A=2, H_B=3, F_B=4, H_C=5, F_C=6

load pymol_files_xyz/2_2.0.xyz, HF_trimer
preset.ball_and_stick(selection='all', mode=1)

# White background
bg_color white
set ray_opaque_background, 1

# Hide hydrogens — show F triangle only
hide everything, name H

# F-F connectivity — all three pairs
distance FF_AB, index 2, index 4
distance FF_AC, index 2, index 6
distance FF_BC, index 4, index 6

# Black dashes
color black, FF_AB
color black, FF_AC
color black, FF_BC

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
set label_distance_digits, 2

# A/B/C atom labels — BLACK on teal F spheres
set label_size, 24
set label_color, black
set label_font_id, 5

# Labels on fluorine atoms
label index 2, "A"
label index 4, "B"
label index 6, "C"

# Distance labels — black (must come AFTER global label_color)
set label_color, black, FF_AB
set label_color, black, FF_AC
set label_color, black, FF_BC
set label_size, 16, FF_AB
set label_size, 16, FF_AC
set label_size, 16, FF_BC

# Top-down view — F atoms all in z=0 plane
zoom all, 3

# Render
set ray_opaque_background, 1
png HF_trimer_I.png, width=800, height=800, dpi=300, ray=1
