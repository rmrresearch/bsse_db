# HF_trimer_II.pml — HF Trimer | H atoms visible, geometry only | Config 2 (R = 2.0 Å)
# Atom order (from 2_2.0.xyz): H_A=1, F_A=2, H_B=3, F_B=4, H_C=5, F_C=6
# H atoms at z=-0.924 Å — tilted view to show 3D geometry
# No interaction dashes — geometry picture only

load pymol_files_xyz/2_2.0.xyz, HF_trimer
preset.ball_and_stick(selection='all', mode=1)

# White background
bg_color white
set ray_opaque_background, 1

# H atoms: recolor grey so they show on white background
color grey60, name H

# A/B/C atom labels — BLACK on teal F spheres
set label_size, 24
set label_color, black
set label_font_id, 5

# Labels on fluorine atoms
label index 2, "A"
label index 4, "B"
label index 6, "C"

# Tilted view — positive x rotation puts H atoms above F in screen space
# (H at z=-0.924, negative rotation pushed them below — flip sign)
rotate x, 40

# Zoom with generous buffer
zoom all, 3

# Render
png HF_trimer_II.png, width=800, height=800, dpi=300, ray=1
