load pymol_files_xyz/0_1.5.xyz, 0_1.5
load pymol_files_xyz/1_1.75.xyz, 1_1.75
load pymol_files_xyz/2_2.0.xyz, 2_2.0
load pymol_files_xyz/3_2.25.xyz, 3_2.25
load pymol_files_xyz/4_2.5.xyz, 4_2.5
load pymol_files_xyz/5_2.75.xyz, 5_2.75
load pymol_files_xyz/6_3.0.xyz, 6_3.0
preset.ball_and_stick(selection='all', mode=1)
