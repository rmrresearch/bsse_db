# HF Trimer Data — `data/HF/3/`

## Overview
This directory contains NWChem CCSD(T)/aug-cc-pvdz calculations for the HF trimer
in an equilateral triangle arrangement. The F-F distance is varied systematically
from 1.5 to 3.0 Angstroms across 7 configurations.

## Monomer Geometry
HF monomer (fixed geometry for all configurations):
```
H  0  0  -0.924  (Angstroms)
F  0  0   0.000
```

## Configuration Table
| Config | F-F Distance (Å) |
|--------|-----------------|
| 0      | 1.5             |
| 1      | 1.75            |
| 2      | 2.0             |
| 3      | 2.25            |
| 4      | 2.5             |
| 5      | 2.75            |
| 6      | 3.0             |

Note: R=3.75 Å data was found misplaced in `data/Ne/` as `Ne_trimer_4` and has
been moved to `data/HF/Ne_trimer_4_misplaced/` pending PI guidance.

## Folder Structure
```
3/
├── n_R/CCSD_T/aug-cc-pvdz/   ← 19 .nw and 19 .out files per config
├── data_frames_plots/         ← CSVs and plots (populated by pipeline)
├── load_trimers.pml           ← PyMOL loader script
├── original_data/
│   └── HF_trimers.tar         ← backup of original raw data
├── pymol_files_xyz/           ← 7 clean .xyz files for visualization
├── README.md
└── scripts/                   ← reorganization and conversion scripts
```

## File Naming Convention
Files follow the `real_basis` convention:
- `real` = monomer(s) with real atoms
- `basis` = monomer(s) contributing basis functions
- `.nw` for NWChem input, `.out` for NWChem output

Examples: `A_A.out`, `AB_ABC.out`, `ABC_ABC.out`

## Scripts
| Script | Description |
|--------|-------------|
| `reorganizing_trimers_HF.py`  | Creates the `n_R/CCSD_T/aug-cc-pvdz/` folder skeleton |
| `copy_rename_files_HF.py`     | Copies and renames files from `HF_trimers/` (configs 0–5) |
| `copy_rename_files_HF_3_0.py` | Copies and renames files for config 6_3.0 |
| `verify_copy_HF.py`           | Verifies all copied files are identical to originals |
| `nwchem_to_pymol_HF.py`       | Converts NWChem input to clean `.xyz` format |
| `make_load_pml_HF.py`         | Generates `load_trimers.pml` PyMOL loader |

## Special Notes
- Config `6_3.0`: the `ABC_ABC` calculation (full trimer, all 3 monomers in
  trimer basis) was missing from the original tar. The `ABC_ABC.nw` input was
  reconstructed from the ghost-atom files and the calculation was run locally
  with NWChem. Total CCSD(T) energy: -300.789581798844495 Hartree.

## PyMOL Visualization
From `HF/3/`:
```bash
pymol load_trimers.pml
```