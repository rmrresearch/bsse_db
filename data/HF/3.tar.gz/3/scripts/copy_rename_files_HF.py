# copy_rename_files_HF.py
# Copies and renames NWChem files from HF_trimers/ into HF/3/ structure
# Rename convention: input_E_X_Y.txt → Y_X.nw, output_E_X_Y.txt → Y_X.out
# Skips R=3.0 ABC_ABC (missing files)

from pathlib import Path
import shutil

base = Path(__file__).resolve().parent.parent
source = base.parent / "HF_trimers"

r_values = ["1.5", "1.75", "2.0", "2.25", "2.5", "2.75", "3.0"]
method = "CCSD_T"
basis = "aug-cc-pvdz"

total_copied = 0
total_skipped = 0

for n, r in enumerate(r_values):
    src_folder = source / f"HF_trimer_{r}"
    dst_folder = base / f"{n}_{r}" / method / basis

    for src_file in sorted(src_folder.iterdir()):
        name = src_file.name

        if name.startswith("input_E_") and name.endswith(".txt"):
            parts = name[len("input_E_"):-len(".txt")].split("_", 1)
            new_name = f"{parts[1]}_{parts[0]}.nw"
        elif name.startswith("output_E_") and name.endswith(".txt"):
            parts = name[len("output_E_"):-len(".txt")].split("_", 1)
            new_name = f"{parts[1]}_{parts[0]}.out"
        else:
            print(f"  SKIP (unrecognized): {name}")
            total_skipped += 1
            continue

        dst_file = dst_folder / new_name
        shutil.copy2(src_file, dst_file)
        total_copied += 1

print(f"\nDone — {total_copied} files copied, {total_skipped} skipped.")