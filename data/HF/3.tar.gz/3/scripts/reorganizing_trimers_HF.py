# reorganizing_trimers_HF.py
# Creates the HF/3/ folder skeleton following PI convention (GitHub Issue #46)
# Config label: n_R  (e.g. 0_1.5, 1_1.75, ...)
# Method: CCSD_T, Basis: aug-cc-pvdz

from pathlib import Path

base  = Path(__file__).resolve().parent.parent
method = "CCSD_T"
basis = "aug-cc-pvdz"

r_values = ["1.5", "1.75", "2.0", "2.25", "2.5", "2.75", "3.0"]

for n, r in enumerate(r_values):
    config_label = f"{n}_{r}"
    target = base / config_label / method / basis
    target.mkdir(parents=True, exist_ok=True)
    print(f"Created: {target}")

# Create supporting directories
for d in ["data_frames_plots", "pymol_files_xyz", "original_data"]:
    (base / d).mkdir(parents=True, exist_ok=True)
    print(f"Created: {base / d}")

print("Done — HF/3/ skeleton created.")