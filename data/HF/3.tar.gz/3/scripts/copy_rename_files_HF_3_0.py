# copy_rename_files_HF_3_0.py
# Creates 6_3.0/CCSD_T/aug-cc-pvdz/ skeleton and copies/renames
# the 36 available files from HF_trimer_3.0/ (ABC_ABC missing)

from pathlib import Path
import shutil

base = Path(__file__).resolve().parent.parent  # HF/3/
source = base / "original_data" / "HF_trimers" / "HF_trimer_3.0"
method = "CCSD_T"
basis = "aug-cc-pvdz"

dst_folder = base / "6_3.0" / method / basis
dst_folder.mkdir(parents=True, exist_ok=True)
print(f"Created: {dst_folder}")

total_copied = 0
total_skipped = 0

for src_file in sorted(source.iterdir()):
    name = src_file.name

    if name.startswith("input_E_") and name.endswith(".txt"):
        parts = name[len("input_E_"):-len(".txt")].split("_", 1)
        new_name = f"{parts[1]}_{parts[0]}.nw"
    elif name.startswith("output_E_") and name.endswith(".txt"):
        parts = name[len("output_E_"):-len(".txt")].split("_", 1)
        new_name = f"{parts[1]}_{parts[0]}.out"
    else:
        print(f"  SKIP (unrecognized): {name}")
        total_skipped += 1
        continue

    dst_file = dst_folder / new_name
    shutil.copy2(src_file, dst_file)
    total_copied += 1
    print(f"  Copied: {new_name}")

print(f"\nDone — {total_copied} files copied, {total_skipped} skipped.")