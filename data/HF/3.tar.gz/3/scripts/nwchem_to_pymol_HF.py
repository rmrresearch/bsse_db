# nwchem_to_pymol_HF.py
# Extracts geometry from ABC_ABC.nw and writes .xyz files to pymol_files_xyz/

from pathlib import Path

base = Path(__file__).resolve().parent.parent
pymol_dir = base / "pymol_files_xyz"
method = "CCSD_T"
basis = "aug-cc-pvdz"

r_values = ["1.5", "1.75", "2.0", "2.25", "2.5", "2.75", "3.0"]

for n, r in enumerate(r_values):
    nw_file = base / f"{n}_{r}" / method / basis / "ABC_ABC.nw"
    xyz_file = pymol_dir / f"{n}_{r}.xyz"

    with open(nw_file) as f:
        lines = f.readlines()

    # Extract geometry block
    coord_lines = []
    in_geom = False
    for line in lines:
        if line.strip().startswith("geometry"):
            in_geom = True
            continue
        if line.strip() == "end" and in_geom:
            break
        if in_geom:
            coord_lines.append(line.strip())

    # Write .xyz file
    with open(xyz_file, "w") as f:
        f.write(f"{len(coord_lines)}\n")
        f.write(f"HF trimer R={r} Ang\n")
        for line in coord_lines:
            parts = line.split()
            element = parts[0]
            x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
            f.write(f"{element} {x:.8f} {y:.8f} {z:.8f}\n")

    print(f"Written: {xyz_file.name}")

print(f"\nDone — {len(r_values)} xyz files written to pymol_files_xyz/")