# make_load_pml_HF.py
# Generates load_trimers.pml for PyMOL visualization of HF trimer configs

from pathlib import Path

here     = Path(__file__).resolve().parent   # 3/scripts/
base_dir = here.parent                        # 3/
work_dir = base_dir / "pymol_files_xyz"
pml_name = "load_trimers.pml"

def make_loader_pml(work_dir, pml_name):
    xyz_files = sorted(work_dir.glob("*.xyz"),
                       key=lambda p: int(p.stem.split("_", 1)[0]))
    pml_path = work_dir.parent / pml_name

    with open(pml_path, "w") as f:
        for xyz in xyz_files:
            obj_name = xyz.stem
            rel_path = xyz.relative_to(work_dir.parent)
            f.write(f"load {rel_path}, {obj_name}\n")
        f.write("preset.ball_and_stick(selection='all', mode=1)\n")

    print(f"Wrote: {pml_path}")
    print(f"Objects loaded: {len(xyz_files)}")

make_loader_pml(work_dir, pml_name)