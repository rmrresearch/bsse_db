# verify_copy_HF.py
# Verifies copied files in HF/3/ are byte-identical to originals in HF_trimers/

from pathlib import Path
import filecmp

base = Path(__file__).resolve().parent.parent
source = base.parent / "HF_trimers"

r_values = ["1.5", "1.75", "2.0", "2.25", "2.5", "2.75", "3.0"]
method = "CCSD_T"
basis = "aug-cc-pvdz"

total_checked = 0
mismatches = 0

for n, r in enumerate(r_values):
    src_folder = source / f"HF_trimer_{r}"
    dst_folder = base / f"{n}_{r}" / method / basis

    for src_file in sorted(src_folder.iterdir()):
        name = src_file.name

        if name.startswith("input_E_") and name.endswith(".txt"):
            parts = name[len("input_E_"):-len(".txt")].split("_", 1)
            new_name = f"{parts[1]}_{parts[0]}.nw"
        elif name.startswith("output_E_") and name.endswith(".txt"):
            parts = name[len("output_E_"):-len(".txt")].split("_", 1)
            new_name = f"{parts[1]}_{parts[0]}.out"
        else:
            continue

        dst_file = dst_folder / new_name
        if not dst_file.exists():
            print(f"  MISSING: {dst_file}")
            mismatches += 1
        elif not filecmp.cmp(src_file, dst_file, shallow=False):
            print(f"  MISMATCH: {dst_file}")
            mismatches += 1
        total_checked += 1

print(f"\nDone — {total_checked} files checked, {mismatches} mismatches.")