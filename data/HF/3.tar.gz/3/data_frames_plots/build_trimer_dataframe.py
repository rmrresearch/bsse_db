"""
build_trimer_dataframe.py
==========================
Generalized trimer dataframe builder for Ne and HF trimers.
Adapted from H2O version in data/H2O/3/data_frames_plots/.

Reads:
    data/many_body_interactions_{mol}_3.pickle
    data/raw_data_{mol}_3.pickle
Computes BSSE quantities via three_body_bsse.py and writes one CSV
per method containing FORM(I) and FORM(II) quantities for all
configurations.

Usage
-----
    python3 build_trimer_dataframe.py --mol Ne
    python3 build_trimer_dataframe.py --mol HF

Place this script in:
    data/{mol}/3/data_frames_plots/build_trimer_dataframe.py

Path navigation
---------------
here      = data/{mol}/3/data_frames_plots/
data_dir  = data/                              (3 levels up)

Output CSVs
-----------
One file per method, saved in the same folder as this script:
    trimer_SCF_aug-cc-pvdz.csv
    trimer_MP2_aug-cc-pvdz.csv
    trimer_CCSD_T_aug-cc-pvdz.csv

CSV columns (30 total)
----------------------
FORM(I):
    config, distance, method, basis
    2b_no_vmfc_AB, 2b_vmfc_AB, 2b_bsse_AB
    2b_no_vmfc_AC, 2b_vmfc_AC, 2b_bsse_AC
    2b_no_vmfc_BC, 2b_vmfc_BC, 2b_bsse_BC
    3b_no_vmfc, 3b_vmfc, 3b_bsse
    total_bsse

FORM(II) delta terms (raw positive differences):
    A_in_AB, B_in_AB, A_in_AC, C_in_AC, B_in_BC, C_in_BC   (1b-in-2b, sign +)
    A_in_ABC, B_in_ABC, C_in_ABC                             (1b-in-3b, sign -)
    AB_in_ABC, AC_in_ABC, BC_in_ABC                          (2b-in-3b, sign +)
    total_bsse_form2  (must equal total_bsse to machine precision)
"""

import argparse
import sys
from pathlib import Path

import pandas as pd


def main():
    parser = argparse.ArgumentParser(
        description='Build trimer BSSE dataframe CSVs for Ne or HF.'
    )
    parser.add_argument('--mol', type=str, required=True,
                        choices=['Ne', 'HF'],
                        help='Molecule: Ne or HF')
    args = parser.parse_args()
    mol = args.mol

    # ---- path setup ----
    here     = Path(__file__).resolve().parent   # data/{mol}/3/data_frames_plots/
    data_dir = here.parent.parent.parent         # data/
    sys.path.insert(0, str(data_dir))

    from open_pickle_data import open_pickle
    from three_body_bsse import threebody_bsse

    # ---- pickle files ----
    many_body_pickle = data_dir / f'many_body_interactions_{mol}_3.pickle'
    raw_pickle       = data_dir / f'raw_data_{mol}_3.pickle'

    # ---- compute BSSE quantities ----
    three_b_bsse = threebody_bsse(many_body_pickle, mol)
    parameters   = open_pickle(raw_pickle)['parameters']

    # ---- shorthand ----
    trimer_bsse = three_b_bsse[mol]['3']
    trimer_pars = parameters[mol]['3']

    # ---- discover methods and basis dynamically ----
    first_cfg = next(iter(trimer_bsse))
    methods   = list(trimer_bsse[first_cfg].keys())
    basis     = list(trimer_bsse[first_cfg][methods[0]].keys())[0]

    print(f'Molecule  : {mol}')
    print(f'Configs   : {sorted(trimer_bsse.keys(), key=int)}')
    print(f'Methods   : {methods}')
    print(f'Basis     : {basis}')

    # ---- build one CSV per method ----
    for method in methods:
        rows = []

        for cfg in sorted(trimer_bsse.keys(), key=int):
            p = trimer_pars[cfg]['params']
            e = trimer_bsse[cfg][method][basis]

            row = {
                # geometry
                'config'          : cfg,
                'distance'        : p['distance'],
                'method'          : method,
                'basis'           : basis,

                # FORM(I) — two-body per pair
                '2b_no_vmfc_AB'   : e['2b']['AB']['no_vmfc'],
                '2b_vmfc_AB'      : e['2b']['AB']['vmfc'],
                '2b_bsse_AB'      : e['2b']['AB']['bsse'],
                '2b_no_vmfc_AC'   : e['2b']['AC']['no_vmfc'],
                '2b_vmfc_AC'      : e['2b']['AC']['vmfc'],
                '2b_bsse_AC'      : e['2b']['AC']['bsse'],
                '2b_no_vmfc_BC'   : e['2b']['BC']['no_vmfc'],
                '2b_vmfc_BC'      : e['2b']['BC']['vmfc'],
                '2b_bsse_BC'      : e['2b']['BC']['bsse'],

                # FORM(I) — three-body
                '3b_no_vmfc'      : e['3b']['no_vmfc'],
                '3b_vmfc'         : e['3b']['vmfc'],
                '3b_bsse'         : e['3b']['bsse'],

                # FORM(I) — total BSSE
                'total_bsse'      : e['total_bsse'],

                # FORM(II) — 12 individual delta terms
                'A_in_AB'         : e['delta_terms']['A_in_AB'],
                'B_in_AB'         : e['delta_terms']['B_in_AB'],
                'A_in_AC'         : e['delta_terms']['A_in_AC'],
                'C_in_AC'         : e['delta_terms']['C_in_AC'],
                'B_in_BC'         : e['delta_terms']['B_in_BC'],
                'C_in_BC'         : e['delta_terms']['C_in_BC'],
                'A_in_ABC'        : e['delta_terms']['A_in_ABC'],
                'B_in_ABC'        : e['delta_terms']['B_in_ABC'],
                'C_in_ABC'        : e['delta_terms']['C_in_ABC'],
                'AB_in_ABC'       : e['delta_terms']['AB_in_ABC'],
                'AC_in_ABC'       : e['delta_terms']['AC_in_ABC'],
                'BC_in_ABC'       : e['delta_terms']['BC_in_ABC'],

                # FORM(II) — total BSSE (must equal total_bsse)
                'total_bsse_form2': e['total_bsse_form2'],
            }
            rows.append(row)

        df = pd.DataFrame(rows)

        out_file = here / f'trimer_{method}_{basis}.csv'
        df.to_csv(out_file, index=False)
        print(f'{method}  {df.shape}  saved to: {out_file}')


if __name__ == '__main__':
    main()