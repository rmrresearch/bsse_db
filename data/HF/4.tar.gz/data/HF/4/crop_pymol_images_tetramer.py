"""
crop_pymol_images.py
Post-process PyMOL PNG outputs: auto-crop near-white borders with small padding.
Run from the folder where your PyMOL PNGs are saved.
"""
from PIL import Image, ImageChops
from pathlib import Path

PADDING   = 15
THRESHOLD = 245

FILES = [
    "Ne_tetramer.png",
    "HF_tetramer_I.png",
    "HF_tetramer_II.png",
]

for fname in FILES:
    p = Path(fname)
    if not p.exists():
        print(f"  SKIP  {fname} (not found)")
        continue

    img = Image.open(p).convert("RGB")
    w, h = img.size

    r, g, b = img.split()
    mask_r = r.point(lambda x: 255 if x > THRESHOLD else 0)
    mask_g = g.point(lambda x: 255 if x > THRESHOLD else 0)
    mask_b = b.point(lambda x: 255 if x > THRESHOLD else 0)

    bg_mask = ImageChops.darker(ImageChops.darker(mask_r, mask_g), mask_b)
    content = ImageChops.invert(bg_mask)

    bbox = content.getbbox()
    if bbox is None:
        print(f"  SKIP  {fname} (no content detected)")
        continue

    left   = max(bbox[0] - PADDING, 0)
    top    = max(bbox[1] - PADDING, 0)
    right  = min(bbox[2] + PADDING, w)
    bottom = min(bbox[3] + PADDING, h)

    cropped = img.crop((left, top, right, bottom))
    cropped.save(p, dpi=(300, 300))
    print(f"  OK    {fname}  {w}x{h}  ->  {cropped.width}x{cropped.height}")

print("Done.")
