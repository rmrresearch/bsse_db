# HF_tetramer_I.pml — HF Tetramer | F-F distances | H atoms hidden
# C4 cyclic ring, all atoms planar
# F_A=1, H_A=2, F_B=3, H_B=4, F_C=5, H_C=6, F_D=7, H_D=8
# Neighboring F-F: AB=BC=CD=DA=2.514 Å (~2.51 Å)
# Diagonal  F-F: AC=BD=3.555 Å (~3.56 Å)

load pymol_xyz_files/HF_abcd.xyz, HF_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white
set ray_opaque_background, 1

# Hide H atoms — show F skeleton only
hide everything, elem H

# F-F distances — neighboring (4 pairs)
distance FF_AB, index 1, index 3
distance FF_BC, index 3, index 5
distance FF_CD, index 5, index 7
distance FF_DA, index 7, index 1
# F-F distances — diagonal (2 pairs)
distance FF_AC, index 1, index 5
distance FF_BD, index 3, index 7

# Black dashes
color black, FF_AB
color black, FF_BC
color black, FF_CD
color black, FF_DA
color black, FF_AC
color black, FF_BD

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
set label_distance_digits, 2

# Global label settings BEFORE per-distance overrides
set label_size, 24
set label_color, black
set label_font_id, 5

# Labels on F atoms
label index 1, "A"
label index 3, "B"
label index 5, "C"
label index 7, "D"

# Distance labels — black
set label_color, black, FF_AB
set label_color, black, FF_BC
set label_color, black, FF_CD
set label_color, black, FF_DA
set label_color, black, FF_AC
set label_color, black, FF_BD
set label_size, 16, FF_AB
set label_size, 16, FF_BC
set label_size, 16, FF_CD
set label_size, 16, FF_DA
set label_size, 16, FF_AC
set label_size, 16, FF_BD

# Orient and fit — rotate z to level the BC edge horizontally
orient
rotate z, 2.5
zoom all, 0.8

# Render
png HF_tetramer_I.png, width=800, height=800, dpi=300, ray=1
