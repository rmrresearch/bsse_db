"""
build_tetramer_dataframe.py
Location: bsse_db/data/{molecule}/4/data_frames_plots/

Reads four_body_bsse_{molecule}_4.pickle and:
  1. Prints a formatted terminal summary with two clearly separated tables:
       Table 1 — FORM(I): 2b/3b/4b terms → total_bsse
       Table 2 — FORM(II): delta group subtotals compared to FORM(I) body terms
  2. Exports one CSV per method with INCREMENTAL correlation components.

CONVENTION (fixed):
  The pickle stores cumulative theory-level BSSE values built using
  total_energy() which reconstructs: MP2 = SCF + MP2_corr,
  CCSD_T = SCF + MP2_corr + CCSD_T_comp.
  The CSVs store incremental components (what the PI requires):
      SCF         -> unchanged  (SCF BSSE component)
      MP2_comp    -> cumulative_MP2    - cumulative_SCF
      CCSD_T_comp -> cumulative_CCSD_T - cumulative_MP2
  The method column still reads 'SCF', 'MP2', 'CCSD_T'; the labels
  'MP2_comp' and 'CCSD_T_comp' are applied by the plotter.

Table 1 — FORM(I)  [cumulative, from pickle — for verification]
------------------
  2b_IJ rows + Σ 2b
  3b_IJK rows + Σ 3b
  4b row
  total_bsse

Table 2 — FORM(II)  [cumulative, from pickle — for verification]
-------------------
  2b level:
    1b-in-2b terms (+) → Σ 1b-in-2b  vs  Σ 2b [FORM I]
  3b level:
    1b-in-3b terms (-) → Σ 1b-in-3b
    2b-in-3b terms (+) → Σ 2b-in-3b
    net 3b              vs  Σ 3b [FORM I]
  4b level:
    1b-in-4b terms (+) → Σ 1b-in-4b
    2b-in-4b terms (-) → Σ 2b-in-4b
    3b-in-4b terms (+) → Σ 3b-in-4b
    net 4b              vs  4b [FORM I]
  total_bsse_form2      vs  total_bsse [FORM I]
  |FORM I - FORM II|

Usage
-----
    python3 build_tetramer_dataframe.py --mol Ne
    python3 build_tetramer_dataframe.py --mol HF
    python3 build_tetramer_dataframe.py --mol H2O
"""

import pickle
import argparse
from pathlib import Path
import pandas as pd

# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------
CLUSTER = "4"
CONFIG  = "0"
BASIS   = "aug-cc-pvdz"
METHODS = ["SCF", "MP2", "CCSD_T"]
PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]
DELTA_1B_IN_4B = [
    "A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD",
]
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]
DELTA_3B_IN_4B = [
    "ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD",
]
ALL_DELTA_TERMS = (
    DELTA_1B_IN_2B + DELTA_1B_IN_3B + DELTA_2B_IN_3B
    + DELTA_1B_IN_4B + DELTA_2B_IN_4B + DELTA_3B_IN_4B
)
assert len(ALL_DELTA_TERMS) == 50, \
    f"Expected 50 delta terms, got {len(ALL_DELTA_TERMS)}"

# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------
SEP  = "-" * 76
SEP2 = "=" * 76
SEP3 = "·" * 76


def _match(val1, val2, tol=1e-10):
    diff = abs(val1 - val2)
    return f"{diff:.2e}  {'✅' if diff < tol else '⚠️  MISMATCH'}"


# ---------------------------------------------------------------------------
# Incremental subtraction helper  ← NEW
# ---------------------------------------------------------------------------

def _subtract_entry(e_curr, e_prev):
    """
    Compute incremental BSSE entry: e_curr minus e_prev for all fields.

    Converts cumulative theory-level values from the pickle into
    incremental correlation components:
        MP2_comp    = cumulative_MP2    - cumulative_SCF
        CCSD_T_comp = cumulative_CCSD_T - cumulative_MP2

    Parameters
    ----------
    e_curr : dict   entry at the higher theory level  (e.g. MP2)
    e_prev : dict   entry at the lower theory level   (e.g. SCF)

    Returns
    -------
    dict with same structure as e_curr, all values replaced by differences.
    """
    inc = {}

    # 2b per pair: no_vmfc, vmfc, bsse
    inc['2b'] = {}
    for pair in PAIRS:
        inc['2b'][pair] = {
            'no_vmfc': e_curr['2b'][pair]['no_vmfc'] - e_prev['2b'][pair]['no_vmfc'],
            'vmfc':    e_curr['2b'][pair]['vmfc']    - e_prev['2b'][pair]['vmfc'],
            'bsse':    e_curr['2b'][pair]['bsse']    - e_prev['2b'][pair]['bsse'],
        }

    # 3b per triple: no_vmfc, vmfc, bsse
    inc['3b'] = {}
    for triple in TRIPLES:
        inc['3b'][triple] = {
            'no_vmfc': e_curr['3b'][triple]['no_vmfc'] - e_prev['3b'][triple]['no_vmfc'],
            'vmfc':    e_curr['3b'][triple]['vmfc']    - e_prev['3b'][triple]['vmfc'],
            'bsse':    e_curr['3b'][triple]['bsse']    - e_prev['3b'][triple]['bsse'],
        }

    # 4b: no_vmfc, vmfc, bsse
    inc['4b'] = {
        'no_vmfc': e_curr['4b']['no_vmfc'] - e_prev['4b']['no_vmfc'],
        'vmfc':    e_curr['4b']['vmfc']    - e_prev['4b']['vmfc'],
        'bsse':    e_curr['4b']['bsse']    - e_prev['4b']['bsse'],
    }

    # total_bsse
    inc['total_bsse'] = e_curr['total_bsse'] - e_prev['total_bsse']

    # delta_terms — all 50 keys
    inc['delta_terms'] = {
        key: e_curr['delta_terms'][key] - e_prev['delta_terms'][key]
        for key in e_curr['delta_terms']
    }

    # total_bsse_form2
    inc['total_bsse_form2'] = e_curr['total_bsse_form2'] - e_prev['total_bsse_form2']

    return inc


# ---------------------------------------------------------------------------
# Terminal tables  — read from pickle (cumulative) — unchanged for verification
# ---------------------------------------------------------------------------

def print_form1_table(d, method):
    """Table 1 — FORM(I): 2b/3b/4b terms and total."""
    print(f"\n  ── TABLE 1: FORM(I)  |  {method}  [cumulative, from pickle] ──")
    print(SEP)
    print(f"  {'Term':<18}  {'no_vmfc (Ha)':>16}  {'vmfc (Ha)':>16}  {'bsse (Ha)':>16}")
    print(SEP)

    # 2b
    sum_2b = 0.0
    for pair in PAIRS:
        nv = d['2b'][pair]['no_vmfc']
        v  = d['2b'][pair]['vmfc']
        b  = d['2b'][pair]['bsse']
        sum_2b += b
        print(f"  2b_{pair:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 2b':<18}  {'':>16}  {'':>16}  {sum_2b:>+16.6e}")
    print(SEP)

    # 3b
    sum_3b = 0.0
    for triple in TRIPLES:
        nv = d['3b'][triple]['no_vmfc']
        v  = d['3b'][triple]['vmfc']
        b  = d['3b'][triple]['bsse']
        sum_3b += b
        print(f"  3b_{triple:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 3b':<18}  {'':>16}  {'':>16}  {sum_3b:>+16.6e}")
    print(SEP)

    # 4b
    nv = d['4b']['no_vmfc']
    v  = d['4b']['vmfc']
    b  = d['4b']['bsse']
    print(f"  {'4b':<18}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(SEP)

    # Total
    total = d['total_bsse']
    print(f"  {'total_bsse':<18}  {'':>16}  {'':>16}  {total:>+16.6e}")
    print(SEP)

    return sum_2b, sum_3b, b, total


def print_form2_table(d, method, sum_2b_f1, sum_3b_f1, b4_f1, total_f1):
    """Table 2 — FORM(II): delta groups, subtotals, comparison to FORM(I)."""
    deltas = d['delta_terms']

    print(f"\n  ── TABLE 2: FORM(II)  |  {method}  [cumulative, from pickle] ──")

    # ------------------------------------------------------------------
    # 2b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 2b level —':^72}")
    print(SEP3)
    print(f"  {'Group: 1b-in-2b  (sign +)'}")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_2b = 0.0
    for key in DELTA_1B_IN_2B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_2b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-2b':<20}  {'':>16}  {sum_1b_in_2b:>+16.6e}")
    print(f"    {'Σ 2b  [FORM I]':<20}  {'':>16}  {sum_2b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(sum_1b_in_2b, sum_2b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 3b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 3b level —':^72}")
    print(SEP3)
    print(f"  {'Group: 1b-in-3b  (sign −)'}")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_3b = 0.0
    for key in DELTA_1B_IN_3B:
        raw    = deltas[key]
        signed = -raw
        sum_1b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-3b':<20}  {'':>16}  {sum_1b_in_3b:>+16.6e}")
    print(SEP3)

    print(f"\n  {'Group: 2b-in-3b  (sign +)'}")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_3b = 0.0
    for key in DELTA_2B_IN_3B:
        raw    = deltas[key]
        signed = +raw
        sum_2b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-3b':<20}  {'':>16}  {sum_2b_in_3b:>+16.6e}")
    print(SEP3)

    net_3b = sum_1b_in_3b + sum_2b_in_3b
    print(f"\n    {'net 3b (FORM II)':<20}  {'':>16}  {net_3b:>+16.6e}")
    print(f"    {'Σ 3b  [FORM I]':<20}  {'':>16}  {sum_3b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_3b, sum_3b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 4b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 4b level —':^72}")
    print(SEP3)
    print(f"  {'Group: 1b-in-4b  (sign +)'}")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_4b = 0.0
    for key in DELTA_1B_IN_4B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-4b':<20}  {'':>16}  {sum_1b_in_4b:>+16.6e}")
    print(SEP3)

    print(f"\n  {'Group: 2b-in-4b  (sign −)'}")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_4b = 0.0
    for key in DELTA_2B_IN_4B:
        raw    = deltas[key]
        signed = -raw
        sum_2b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-4b':<20}  {'':>16}  {sum_2b_in_4b:>+16.6e}")
    print(SEP3)

    print(f"\n  {'Group: 3b-in-4b  (sign +)'}")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_3b_in_4b = 0.0
    for key in DELTA_3B_IN_4B:
        raw    = deltas[key]
        signed = +raw
        sum_3b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 3b-in-4b':<20}  {'':>16}  {sum_3b_in_4b:>+16.6e}")
    print(SEP3)

    net_4b = sum_1b_in_4b + sum_2b_in_4b + sum_3b_in_4b
    print(f"\n    {'net 4b (FORM II)':<20}  {'':>16}  {net_4b:>+16.6e}")
    print(f"    {'4b  [FORM I]':<20}  {'':>16}  {b4_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_4b, b4_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # Grand total comparison
    # ------------------------------------------------------------------
    form2_total = d['total_bsse_form2']
    diff        = abs(form2_total - total_f1)
    print(f"\n  {'─ Grand Total ─':^72}")
    print(SEP)
    print(f"  {'total (FORM I)':<22}  {total_f1:>+16.6e}")
    print(f"  {'total (FORM II)':<22}  {form2_total:>+16.6e}")
    print(f"  {'|FORM I - FORM II|':<22}  {diff:.2e}  "
          f"{'✅' if diff < 1e-10 else '⚠️  MISMATCH'}")
    print(SEP)


def print_scaling_table(bsse_data, molecule, basis=BASIS):
    """Compact body-order scaling across all methods. [cumulative, from pickle]"""
    print(f"\n  {'─ Body-order scaling summary  [cumulative, from pickle] ─':^72}")
    print(SEP)
    print(f"  {'Method':<10}  {'Σ 2b_bsse (Ha)':>18}  {'Σ 3b_bsse (Ha)':>18}"
          f"  {'4b_bsse (Ha)':>16}  {'total (Ha)':>16}")
    print(SEP)
    for method in METHODS:
        d      = bsse_data[molecule][CLUSTER][CONFIG][method][basis]
        sum_2b = sum(d['2b'][p]['bsse'] for p in PAIRS)
        sum_3b = sum(d['3b'][t]['bsse'] for t in TRIPLES)
        b4     = d['4b']['bsse']
        tot    = d['total_bsse']
        print(f"  {method:<10}  {sum_2b:>+18.6e}  {sum_3b:>+18.6e}"
              f"  {b4:>+16.6e}  {tot:>+16.6e}")
    print(SEP2)


def print_incremental_summary(bsse_data, molecule, basis=BASIS):
    """
    Print incremental correlation components (what goes into the CSVs).
    One row per component: SCF | MP2_comp | CCSD_T_comp.
    Plus sum verification: SCF + MP2_comp + CCSD_T_comp = full CCSD(T) BSSE.
    All values in Hartree.
    """
    d_scf = bsse_data[molecule][CLUSTER][CONFIG]['SCF'][basis]
    d_mp2 = bsse_data[molecule][CLUSTER][CONFIG]['MP2'][basis]
    d_cct = bsse_data[molecule][CLUSTER][CONFIG]['CCSD_T'][basis]

    inc = {
        'SCF':    d_scf,
        'MP2':    _subtract_entry(d_mp2, d_scf),
        'CCSD_T': _subtract_entry(d_cct, d_mp2),
    }

    METHOD_DISPLAY = {
        'SCF':    'SCF',
        'MP2':    'MP2_comp',
        'CCSD_T': 'CCSD_T_comp',
    }

    print(f"\n  {'─ Incremental components  [written to CSVs] ─':^72}")
    print(SEP2)
    print(f"  {'Method':<14}  {'Σ 2b_bsse (Ha)':>18}  {'Σ 3b_bsse (Ha)':>18}"
          f"  {'4b_bsse (Ha)':>16}  {'total (Ha)':>16}  {'|FI-FII|':>12}")
    print(SEP)

    totals = {}
    for method in METHODS:
        e      = inc[method]
        sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
        sum_3b = sum(e['3b'][t]['bsse'] for t in TRIPLES)
        b4     = e['4b']['bsse']
        total  = e['total_bsse']
        form2  = e['total_bsse_form2']
        diff   = abs(total - form2)
        flag   = "✅" if diff < 1e-10 else "⚠️"
        totals[method] = total
        label  = METHOD_DISPLAY[method]
        print(f"  {label:<14}  {sum_2b:>+18.6e}  {sum_3b:>+18.6e}"
              f"  {b4:>+16.6e}  {total:>+16.6e}  {diff:.2e} {flag}")

    # Sum verification
    inc_sum = sum(totals[m] for m in METHODS)
    cct_cum = d_cct['total_bsse']
    match   = abs(inc_sum - cct_cum) < 1e-12
    print(SEP)
    print(f"  {'Sum (SCF + MP2_comp + CCSD_T_comp)':<50}  {inc_sum:>+16.6e}")
    print(f"  {'Full CCSD(T) total  [from pickle]':<50}  {cct_cum:>+16.6e}")
    print(f"  {'Match':<50}  {'✅' if match else '⚠️  MISMATCH'}")
    print(SEP2)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build_dataframe(molecule):
    here        = Path(__file__).resolve().parent
    data_dir    = here.parent.parent.parent
    pickle_path = data_dir / f"four_body_bsse_{molecule}_{CLUSTER}.pickle"
    out_dir     = here

    with open(pickle_path, "rb") as f:
        bsse_data = pickle.load(f)
    print(f"Loaded: {pickle_path.name}")

    # --- Terminal tables (cumulative values from pickle — for verification) ---
    print(f"\n{SEP2}")
    print(f"  BSSE Analysis — {molecule} Tetramer  |  {BASIS}  [cumulative, from pickle]")
    print(SEP2)

    for method in METHODS:
        d = bsse_data[molecule][CLUSTER][CONFIG][method][BASIS]
        sum_2b, sum_3b, b4, total = print_form1_table(d, method)
        print_form2_table(d, method, sum_2b, sum_3b, b4, total)

    print_scaling_table(bsse_data, molecule)
    print_incremental_summary(bsse_data, molecule)

    # --- Pre-compute incremental entries  ← NEW ---
    e_scf = bsse_data[molecule][CLUSTER][CONFIG]['SCF'][BASIS]
    e_mp2 = bsse_data[molecule][CLUSTER][CONFIG]['MP2'][BASIS]
    e_cct = bsse_data[molecule][CLUSTER][CONFIG]['CCSD_T'][BASIS]

    incremental = {
        'SCF':    e_scf,                          # SCF: same as cumulative
        'MP2':    _subtract_entry(e_mp2, e_scf),  # MP2 correlation component
        'CCSD_T': _subtract_entry(e_cct, e_mp2),  # CCSD_T component
    }

    # --- CSVs (incremental components)  ← FIXED ---
    print(f"\nWriting CSVs to: {out_dir}  [INCREMENTAL components]")
    for method in METHODS:
        rows  = []
        entry = incremental[method]       # ← was: bsse_data[...][method][BASIS]

        row = {
            "config": CONFIG,
            "method": method,
            "basis" : BASIS,
        }
        for pair in PAIRS:
            for qty in ("no_vmfc", "vmfc", "bsse"):
                row[f"2b_{qty}_{pair}"] = entry["2b"][pair][qty]
        for triple in TRIPLES:
            for qty in ("no_vmfc", "vmfc", "bsse"):
                row[f"3b_{qty}_{triple}"] = entry["3b"][triple][qty]
        for qty in ("no_vmfc", "vmfc", "bsse"):
            row[f"4b_{qty}"] = entry["4b"][qty]
        row["total_bsse"] = entry["total_bsse"]
        for key in ALL_DELTA_TERMS:
            row[key] = entry["delta_terms"][key]
        row["total_bsse_form2"] = entry["total_bsse_form2"]

        rows.append(row)
        df       = pd.DataFrame(rows)
        out_file = out_dir / f"tetramer_{method}_{BASIS}.csv"
        df.to_csv(out_file, index=False)
        print(f"  Wrote: {out_file.name}  ({len(df.columns)} columns)")

    print("\nDone ✅")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build tetramer dataframes for Ne, HF or H2O"
    )
    parser.add_argument(
        "--mol", required=True, choices=["Ne", "HF", "H2O"],
        help="Molecule: Ne, HF or H2O"
    )
    args = parser.parse_args()
    build_dataframe(args.mol)