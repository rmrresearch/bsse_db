# HF_tetramer_II.pml — HF Tetramer | H-bond network | H atoms visible
# C4 cyclic ring: A→B→C→D→A (H of one monomer points to F of next)
# F_A=1, H_A=2, F_B=3, H_B=4, F_C=5, H_C=6, F_D=7, H_D=8
# H-bond contacts: H_A→F_B, H_B→F_C, H_C→F_D, H_D→F_A (~1.588 Å each)

load pymol_xyz_files/HF_abcd.xyz, HF_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white
set ray_opaque_background, 1

# H atoms visible — grey60 for contrast
color grey60, elem H

# H-bond network — cyclic A→B→C→D→A
distance HB_AB, index 2, index 3
distance HB_BC, index 4, index 5
distance HB_CD, index 6, index 7
distance HB_DA, index 8, index 1

# Black dashes
color black, HB_AB
color black, HB_BC
color black, HB_CD
color black, HB_DA

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
#set label_distance_digits, 2

# Global label settings BEFORE per-distance overrides
#set label_size, 24
#set label_color, black
#set label_font_id, 5

# Labels on F atoms only
label index 1, "A"
label index 3, "B"
label index 5, "C"
label index 7, "D"

# Hide H-bond distance labels — network topology shown by dashes only
hide labels, HB_AB
hide labels, HB_BC
hide labels, HB_CD
hide labels, HB_DA

# Orient and fit
orient
rotate z, 2.5
zoom all, 0.8

# Render
png HF_tetramer_II.png, width=800, height=800, dpi=300, ray=1
