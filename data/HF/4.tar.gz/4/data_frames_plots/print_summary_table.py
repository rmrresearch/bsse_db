"""
print_summary_table.py
Location: bsse_db/data/{molecule}/4/data_frames_plots/

Reads tetramer CSVs from the same folder and prints formatted terminal tables.
No files are written — use this for quick inspection and sharing with the PI.

Data source: tetramer_{SCF,MP2,CCSD_T}_{basis}.csv  (same folder as this script)

Table structure per method
--------------------------
  TABLE 1 — FORM(I)  : 2b/3b/4b terms → total_bsse  (Hartree)
  TABLE 2 — FORM(II) : delta group subtotals compared to FORM(I) body terms
                        net per body order vs FORM(I) → grand total check  (Hartree)

Scaling summary
---------------
  Σ 2b, Σ 3b, 4b, total per method (kcal/mol)
  + tail condition |Σ 3b + 4b| vs 1 kcal/mol chemical accuracy threshold

Usage
-----
    python3 print_summary_table.py --mol Ne
    python3 print_summary_table.py --mol Ne --method CCSD_T
    python3 print_summary_table.py --mol Ne --method all
    python3 print_summary_table.py --mol Ne --scaling-only
    python3 print_summary_table.py --mol HF --method MP2
    python3 print_summary_table.py --mol H2O --scaling-only
"""

import argparse
import pandas as pd
from pathlib import Path

# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------
BASIS   = "aug-cc-pvdz"
METHODS = ["SCF", "MP2", "CCSD_T"]
PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]
KCAL    = 627.509474    # Hartree -> kcal/mol

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]
DELTA_1B_IN_4B = [
    "A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD",
]
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]
DELTA_3B_IN_4B = [
    "ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD",
]

# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
SEP  = "-" * 76
SEP2 = "=" * 76
SEP3 = "·" * 76

here = Path(__file__).resolve().parent


def load_csv(method, basis):
    """Load tetramer CSV for the given method from the same folder."""
    path = here / f"tetramer_{method}_{basis}.csv"
    return pd.read_csv(path).iloc[0]   # single-row tetramer CSV


def sum_2b_bsse(row):
    return sum(row[f"2b_bsse_{p}"] for p in PAIRS)


def sum_3b_bsse(row):
    return sum(row[f"3b_bsse_{t}"] for t in TRIPLES)


def _match(val1, val2, tol=1e-10):
    diff = abs(val1 - val2)
    return f"{diff:.2e}  {'✅' if diff < tol else '⚠️  MISMATCH'}"


# ---------------------------------------------------------------------------
# TABLE 1 — FORM(I)
# ---------------------------------------------------------------------------

def print_form1_table(row, method):
    """Print FORM(I) table (Hartree). Returns (sum_2b, sum_3b, b4, total)."""
    print(f"\n  -- TABLE 1: FORM(I)  |  {method} --")
    print(SEP)
    print(f"  {'Term':<18}  {'no_vmfc (Ha)':>16}  {'vmfc (Ha)':>16}  {'bsse (Ha)':>16}")
    print(SEP)

    # 2b
    sum_2b = 0.0
    for pair in PAIRS:
        nv = row[f"2b_no_vmfc_{pair}"]
        v  = row[f"2b_vmfc_{pair}"]
        b  = row[f"2b_bsse_{pair}"]
        sum_2b += b
        print(f"  2b_{pair:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 2b':<18}  {'':>16}  {'':>16}  {sum_2b:>+16.6e}")
    print(SEP)

    # 3b
    sum_3b = 0.0
    for triple in TRIPLES:
        nv = row[f"3b_no_vmfc_{triple}"]
        v  = row[f"3b_vmfc_{triple}"]
        b  = row[f"3b_bsse_{triple}"]
        sum_3b += b
        print(f"  3b_{triple:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 3b':<18}  {'':>16}  {'':>16}  {sum_3b:>+16.6e}")
    print(SEP)

    # 4b
    nv = row["4b_no_vmfc"]
    v  = row["4b_vmfc"]
    b  = row["4b_bsse"]
    print(f"  {'4b':<18}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(SEP)

    # Total
    total = row["total_bsse"]
    print(f"  {'total_bsse':<18}  {'':>16}  {'':>16}  {total:>+16.6e}")
    print(SEP)

    return sum_2b, sum_3b, b, total


# ---------------------------------------------------------------------------
# TABLE 2 — FORM(II)
# ---------------------------------------------------------------------------

def print_form2_table(row, method, sum_2b_f1, sum_3b_f1, b4_f1, total_f1):
    """Print FORM(II) table (Hartree) with delta groups and FORM(I) comparisons."""
    print(f"\n  -- TABLE 2: FORM(II)  |  {method} --")

    # ------------------------------------------------------------------
    # 2b level
    # ------------------------------------------------------------------
    print(f"\n  {'--- 2b level ---':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-2b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_2b = 0.0
    for key in DELTA_1B_IN_2B:
        raw    = row[key]
        signed = +raw
        sum_1b_in_2b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-2b':<20}  {'':>16}  {sum_1b_in_2b:>+16.6e}")
    print(f"    {'Σ 2b  [FORM I]':<20}  {'':>16}  {sum_2b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(sum_1b_in_2b, sum_2b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 3b level
    # ------------------------------------------------------------------
    print(f"\n  {'--- 3b level ---':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-3b  (sign -)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_3b = 0.0
    for key in DELTA_1B_IN_3B:
        raw    = row[key]
        signed = -raw
        sum_1b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-3b':<20}  {'':>16}  {sum_1b_in_3b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-3b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_3b = 0.0
    for key in DELTA_2B_IN_3B:
        raw    = row[key]
        signed = +raw
        sum_2b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-3b':<20}  {'':>16}  {sum_2b_in_3b:>+16.6e}")
    print(SEP3)

    net_3b = sum_1b_in_3b + sum_2b_in_3b
    print(f"\n    {'net 3b (FORM II)':<20}  {'':>16}  {net_3b:>+16.6e}")
    print(f"    {'Σ 3b  [FORM I]':<20}  {'':>16}  {sum_3b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_3b, sum_3b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 4b level
    # ------------------------------------------------------------------
    print(f"\n  {'--- 4b level ---':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-4b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_4b = 0.0
    for key in DELTA_1B_IN_4B:
        raw    = row[key]
        signed = +raw
        sum_1b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-4b':<20}  {'':>16}  {sum_1b_in_4b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-4b  (sign -)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_4b = 0.0
    for key in DELTA_2B_IN_4B:
        raw    = row[key]
        signed = -raw
        sum_2b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-4b':<20}  {'':>16}  {sum_2b_in_4b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 3b-in-4b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_3b_in_4b = 0.0
    for key in DELTA_3B_IN_4B:
        raw    = row[key]
        signed = +raw
        sum_3b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 3b-in-4b':<20}  {'':>16}  {sum_3b_in_4b:>+16.6e}")
    print(SEP3)

    net_4b = sum_1b_in_4b + sum_2b_in_4b + sum_3b_in_4b
    print(f"\n    {'net 4b (FORM II)':<20}  {'':>16}  {net_4b:>+16.6e}")
    print(f"    {'4b  [FORM I]':<20}  {'':>16}  {b4_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_4b, b4_f1):>32}")
    print(SEP)

    # Grand total
    form2_total = row["total_bsse_form2"]
    diff        = abs(form2_total - total_f1)
    print(f"\n  {'─ Grand Total ─':^72}")
    print(SEP)
    print(f"  {'total (FORM I)':<22}  {total_f1:>+16.6e}")
    print(f"  {'total (FORM II)':<22}  {form2_total:>+16.6e}")
    print(f"  {'|FORM I - FORM II|':<22}  {diff:.2e}  "
          f"{'✅' if diff < 1e-10 else '⚠️  MISMATCH'}")
    print(SEP)


# ---------------------------------------------------------------------------
# Scaling summary — kcal/mol, tail condition
# ---------------------------------------------------------------------------

def print_scaling_table(molecule, basis=BASIS):
    """
    Print body-order scaling summary in kcal/mol with tail condition.

    Columns:
        Σ 2b   Σ 3b   4b   total   |Σ3b + 4b|   < 1 kcal/mol?

    The tail condition |Σ 3b + 4b| is the error incurred by truncating
    the BSSE at 2-body only. Pass (✅) if below 1 kcal/mol chemical accuracy.
    """
    THRESHOLD = 1.0    # kcal/mol

    print(f"\n  {'─ Body-order scaling (kcal/mol) ─':^76}")
    print(SEP2)
    print(f"  {'Method':<10}  {'Σ 2b':>12}  {'Σ 3b':>12}  "
          f"{'4b':>12}  {'total':>12}  {'|Σ3b+4b|':>12}  {'<1 kcal?':>10}")
    print(SEP)
    for method in METHODS:
        row    = load_csv(method, basis)
        sum_2b = sum_2b_bsse(row) * KCAL
        sum_3b = sum_3b_bsse(row) * KCAL
        b4     = row["4b_bsse"]   * KCAL
        tot    = row["total_bsse"]* KCAL
        tail   = abs(sum_3b + b4)
        flag   = "✅" if tail < THRESHOLD else "❌"
        print(f"  {method:<10}  {sum_2b:>+12.4f}  {sum_3b:>+12.4f}  "
              f"{b4:>+12.4f}  {tot:>+12.4f}  {tail:>12.4f}  {flag:>10}")
    print(SEP)
    print(f"\n  Tail condition: |Σ 3b + 4b| = error from truncating BSSE at 2b only.")
    print(f"  Threshold: {THRESHOLD} kcal/mol (chemical accuracy).")
    print(SEP2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Print BSSE summary tables for tetramer"
    )
    parser.add_argument(
        "--mol", required=True, choices=["Ne", "HF", "H2O"],
        help="Molecule: Ne, HF, or H2O"
    )
    parser.add_argument(
        "--method", default="CCSD_T", choices=["SCF", "MP2", "CCSD_T", "all"],
        help="Method to display (default: CCSD_T)"
    )
    parser.add_argument(
        "--scaling-only", action="store_true",
        help="Print only the body-order scaling and tail condition table"
    )
    args    = parser.parse_args()
    methods = METHODS if args.method == "all" else [args.method]

    print(f"\n{SEP2}")
    print(f"  BSSE Analysis -- {args.mol} Tetramer  |  {BASIS}")
    print(SEP2)

    if args.scaling_only:
        print_scaling_table(args.mol)
    else:
        for method in methods:
            row = load_csv(method, BASIS)
            sum_2b, sum_3b, b4, total = print_form1_table(row, method)
            print_form2_table(row, method, sum_2b, sum_3b, b4, total)
        print_scaling_table(args.mol)