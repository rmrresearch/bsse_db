"""
print_summary_table.py
Location: bsse_db/data/{molecule}/4/data_frames_plots/

Reads four_body_bsse_{molecule}_4.pickle and prints formatted terminal tables.
No files are written — use this for quick inspection and sharing with the PI.

Table structure per method
--------------------------
  TABLE 1 — FORM(I)  : 2b/3b/4b terms → total_bsse
  TABLE 2 — FORM(II) : delta group subtotals compared to FORM(I) body terms
                        net per body order vs FORM(I) → grand total check

Scaling summary
---------------
  Σ 2b, Σ 3b, 4b, total per method
  + convergence ratios |3b/2b|, |4b/3b|, |4b/2b|

Usage
-----
    python3 print_summary_table.py --mol Ne
    python3 print_summary_table.py --mol Ne --method CCSD_T
    python3 print_summary_table.py --mol Ne --method all
    python3 print_summary_table.py --mol Ne --scaling-only
    python3 print_summary_table.py --mol HF --method MP2
"""

import pickle
import argparse
from pathlib import Path

# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------
CLUSTER = "4"
CONFIG  = "0"
BASIS   = "aug-cc-pvdz"
METHODS = ["SCF", "MP2", "CCSD_T"]
PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]
DELTA_1B_IN_4B = [
    "A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD",
]
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]
DELTA_3B_IN_4B = [
    "ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD",
]

# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
SEP  = "-" * 76
SEP2 = "=" * 76
SEP3 = "·" * 76


def _match(val1, val2, tol=1e-10):
    diff = abs(val1 - val2)
    return f"{diff:.2e}  {'✅' if diff < tol else '⚠️  MISMATCH'}"


def _ratio(num, denom):
    """Safe ratio |num/denom| — returns '    N/A' if denom is zero."""
    if abs(denom) < 1e-30:
        return "    N/A"
    return f"{abs(num / denom):>7.4f}"


# ---------------------------------------------------------------------------
# TABLE 1 — FORM(I)
# ---------------------------------------------------------------------------

def print_form1_table(d, method):
    """Print FORM(I) table. Returns (sum_2b, sum_3b, b4, total) for FORM(II) use."""
    print(f"\n  ── TABLE 1: FORM(I)  |  {method} ──")
    print(SEP)
    print(f"  {'Term':<18}  {'no_vmfc (Ha)':>16}  {'vmfc (Ha)':>16}  {'bsse (Ha)':>16}")
    print(SEP)

    # 2b
    sum_2b = 0.0
    for pair in PAIRS:
        nv = d['2b'][pair]['no_vmfc']
        v  = d['2b'][pair]['vmfc']
        b  = d['2b'][pair]['bsse']
        sum_2b += b
        print(f"  2b_{pair:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 2b':<18}  {'':>16}  {'':>16}  {sum_2b:>+16.6e}")
    print(SEP)

    # 3b
    sum_3b = 0.0
    for triple in TRIPLES:
        nv = d['3b'][triple]['no_vmfc']
        v  = d['3b'][triple]['vmfc']
        b  = d['3b'][triple]['bsse']
        sum_3b += b
        print(f"  3b_{triple:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 3b':<18}  {'':>16}  {'':>16}  {sum_3b:>+16.6e}")
    print(SEP)

    # 4b
    nv = d['4b']['no_vmfc']
    v  = d['4b']['vmfc']
    b  = d['4b']['bsse']
    print(f"  {'4b':<18}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(SEP)

    # Total
    total = d['total_bsse']
    print(f"  {'total_bsse':<18}  {'':>16}  {'':>16}  {total:>+16.6e}")
    print(SEP)

    return sum_2b, sum_3b, b, total


# ---------------------------------------------------------------------------
# TABLE 2 — FORM(II)
# ---------------------------------------------------------------------------

def print_form2_table(d, method, sum_2b_f1, sum_3b_f1, b4_f1, total_f1):
    """Print FORM(II) table with delta groups, subtotals, and FORM(I) comparisons."""
    deltas = d['delta_terms']

    print(f"\n  ── TABLE 2: FORM(II)  |  {method} ──")

    # ------------------------------------------------------------------
    # 2b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 2b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-2b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_2b = 0.0
    for key in DELTA_1B_IN_2B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_2b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-2b':<20}  {'':>16}  {sum_1b_in_2b:>+16.6e}")
    print(f"    {'Σ 2b  [FORM I]':<20}  {'':>16}  {sum_2b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(sum_1b_in_2b, sum_2b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 3b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 3b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-3b  (sign −)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_3b = 0.0
    for key in DELTA_1B_IN_3B:
        raw    = deltas[key]
        signed = -raw
        sum_1b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-3b':<20}  {'':>16}  {sum_1b_in_3b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-3b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_3b = 0.0
    for key in DELTA_2B_IN_3B:
        raw    = deltas[key]
        signed = +raw
        sum_2b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-3b':<20}  {'':>16}  {sum_2b_in_3b:>+16.6e}")
    print(SEP3)

    net_3b = sum_1b_in_3b + sum_2b_in_3b
    print(f"\n    {'net 3b (FORM II)':<20}  {'':>16}  {net_3b:>+16.6e}")
    print(f"    {'Σ 3b  [FORM I]':<20}  {'':>16}  {sum_3b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_3b, sum_3b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 4b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 4b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-4b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_4b = 0.0
    for key in DELTA_1B_IN_4B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-4b':<20}  {'':>16}  {sum_1b_in_4b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-4b  (sign −)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_4b = 0.0
    for key in DELTA_2B_IN_4B:
        raw    = deltas[key]
        signed = -raw
        sum_2b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-4b':<20}  {'':>16}  {sum_2b_in_4b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 3b-in-4b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_3b_in_4b = 0.0
    for key in DELTA_3B_IN_4B:
        raw    = deltas[key]
        signed = +raw
        sum_3b_in_4b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 3b-in-4b':<20}  {'':>16}  {sum_3b_in_4b:>+16.6e}")
    print(SEP3)

    net_4b = sum_1b_in_4b + sum_2b_in_4b + sum_3b_in_4b
    print(f"\n    {'net 4b (FORM II)':<20}  {'':>16}  {net_4b:>+16.6e}")
    print(f"    {'4b  [FORM I]':<20}  {'':>16}  {b4_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_4b, b4_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # Grand total
    # ------------------------------------------------------------------
    form2_total = d['total_bsse_form2']
    diff        = abs(form2_total - total_f1)
    print(f"\n  {'─ Grand Total ─':^72}")
    print(SEP)
    print(f"  {'total (FORM I)':<22}  {total_f1:>+16.6e}")
    print(f"  {'total (FORM II)':<22}  {form2_total:>+16.6e}")
    print(f"  {'|FORM I - FORM II|':<22}  {diff:.2e}  "
          f"{'✅' if diff < 1e-10 else '⚠️  MISMATCH'}")
    print(SEP)


# ---------------------------------------------------------------------------
# Scaling summary with convergence ratios
# ---------------------------------------------------------------------------

def print_scaling_table(bsse_data, molecule, basis=BASIS):
    """
    Print body-order scaling summary with convergence ratios.

    Columns:
        Σ 2b_bsse   Σ 3b_bsse   |3b/2b|   4b_bsse   |4b/3b|   |4b/2b|   total
    """
    print(f"\n  {'─ Body-order scaling & convergence ratios ─':^76}")
    print(SEP2)
    print(f"  {'Method':<10}  {'Σ 2b (Ha)':>14}  {'Σ 3b (Ha)':>14}  "
          f"{'|3b/2b|':>8}  {'4b (Ha)':>14}  {'|4b/3b|':>8}  "
          f"{'|4b/2b|':>8}  {'total (Ha)':>14}")
    print(SEP)
    for method in METHODS:
        d       = bsse_data[molecule][CLUSTER][CONFIG][method][basis]
        sum_2b  = sum(d['2b'][p]['bsse'] for p in PAIRS)
        sum_3b  = sum(d['3b'][t]['bsse'] for t in TRIPLES)
        b4      = d['4b']['bsse']
        tot     = d['total_bsse']
        r_3b_2b = _ratio(sum_3b, sum_2b)
        r_4b_3b = _ratio(b4,     sum_3b)
        r_4b_2b = _ratio(b4,     sum_2b)
        print(f"  {method:<10}  {sum_2b:>+14.4e}  {sum_3b:>+14.4e}  "
              f"{r_3b_2b:>8}  {b4:>+14.4e}  {r_4b_3b:>8}  "
              f"{r_4b_2b:>8}  {tot:>+14.4e}")
    print(SEP)
    print(f"\n  Ratio interpretation:")
    print(f"    |3b/2b| — 3b BSSE as a fraction of 2b BSSE")
    print(f"    |4b/3b| — 4b BSSE as a fraction of 3b BSSE")
    print(f"    |4b/2b| — 4b BSSE as a fraction of 2b BSSE (overall decay)")
    print(SEP2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Print BSSE summary tables for Ne or HF tetramer"
    )
    parser.add_argument(
        "--mol", required=True, choices=["Ne", "HF"],
        help="Molecule: Ne or HF"
    )
    parser.add_argument(
        "--method", default="CCSD_T", choices=["SCF", "MP2", "CCSD_T", "all"],
        help="Method to display (default: CCSD_T)"
    )
    parser.add_argument(
        "--scaling-only", action="store_true",
        help="Print only the body-order scaling and convergence ratios table"
    )
    args = parser.parse_args()

    here        = Path(__file__).resolve().parent
    data_dir    = here.parent.parent.parent
    pickle_path = data_dir / f"four_body_bsse_{args.mol}_{CLUSTER}.pickle"

    with open(pickle_path, "rb") as f:
        bsse_data = pickle.load(f)

    methods = METHODS if args.method == "all" else [args.method]

    print(f"\n{SEP2}")
    print(f"  BSSE Analysis — {args.mol} Tetramer  |  {BASIS}")
    print(SEP2)

    if args.scaling_only:
        print_scaling_table(bsse_data, args.mol)
    else:
        for method in methods:
            d = bsse_data[args.mol][CLUSTER][CONFIG][method][BASIS]
            sum_2b, sum_3b, b4, total = print_form1_table(d, method)
            print_form2_table(d, method, sum_2b, sum_3b, b4, total)
        print_scaling_table(bsse_data, args.mol)