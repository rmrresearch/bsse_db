# HF/4/ — HF Tetramer (CCSD(T)/aug-cc-pvdz)

## Overview

This folder contains the BSSE calculations for the optimal HF tetramer
at the CCSD(T)/aug-cc-pvdz level of theory. There is a single geometry
(the optimal tetramer configuration — no distance scan).

The focus is on decomposing the total BSSE into its 2-body, 3-body, and
4-body contributions using two complementary formulations (FORM(I) and
FORM(II)).

---

## Folder Structure

```
HF/4/
├── CCSD_T/aug-cc-pvdz/    ← 65 .nw (input) + 65 .out (output) files
├── original_data/
│   ├── optimal_HF_tetramer.tar   ← original raw files (authoritative backup)
│   └── geometry_optimization/    ← geometry optimization input/output files
├── pymol_xyz_files/
│   └── HF_abcd.xyz               ← tetramer geometry for PyMOL
├── load_tetramer.pml             ← PyMOL loader script (basic ball-and-stick)
├── HF_tetramer_I.pml             ← PyMOL script: F-F distances with labels
├── HF_tetramer_II.pml            ← PyMOL script: H-bond network (H...F dashes)
├── data_frames_plots/
│   ├── build_tetramer_dataframe.py
│   ├── print_summary_table.py
│   ├── plot_tetramer_bsse.py
│   ├── tetramer_SCF_aug-cc-pvdz.csv
│   ├── tetramer_MP2_aug-cc-pvdz.csv
│   ├── tetramer_CCSD_T_aug-cc-pvdz.csv
│   ├── tetramer_mode1_overview_aug-cc-pvdz.png
│   ├── tetramer_mode1_overview_abs_aug-cc-pvdz.png
│   ├── tetramer_mode2_2b_decomp_aug-cc-pvdz.png
│   ├── tetramer_mode3_3b_decomp_aug-cc-pvdz.png
│   ├── tetramer_mode4_4b_decomp_aug-cc-pvdz.png
│   ├── tetramer_mode5_series_terms_aug-cc-pvdz.png
│   ├── tetramer_mode5_series_terms_abs_aug-cc-pvdz.png
│   ├── tetramer_mode6_abs_partial_sums_aug-cc-pvdz.png
│   ├── tetramer_mode7_signed_partial_sums_aug-cc-pvdz.png
│   ├── HF_tetramer_I.png         ← geometry figure: F-F distances
│   └── HF_tetramer_II.png        ← geometry figure: H-bond network
├── README.md
└── scripts/
    ├── copy_rename_files_HF.py
    ├── verify_copy_HF.py
    ├── nwchem_to_pymol_HF.py
    └── make_load_pml_HF.py
```

---

## Geometry

The HF tetramer geometry is the optimal (minimum energy) configuration.
The four HF units are arranged in a cyclic hydrogen-bonded ring in the
XY plane. Cartesian coordinates (Angstroms):

```
F  0.00000000   0.00000000   0.00000000
H  0.00000000   0.94700000   0.00000000
F  0.41876306   2.47879029   0.00000000
H  1.36576306   2.47879029   0.00000000
F  2.89755335   2.06002723   0.00000000
H  2.89755335   1.11302723   0.00000000
F  2.47879029  -0.41876306   0.00000000
H  1.53179029  -0.41876306   0.00000000
```

The geometry source is `original_data/optimal_HF_tetramer.tar` →
`input_E_ABCD_ABCD.txt`. The NWChem geometry block uses a plain
`geometry` header (no `noautoz autosym`).

Monomer assignment (verified from `CCSD_T/aug-cc-pvdz/A_ABCD.nw`):
- Monomer A: atoms 1–2 (F index 1, H index 2)
- Monomer B: atoms 3–4 (F index 3, H index 4)
- Monomer C: atoms 5–6 (F index 5, H index 6)
- Monomer D: atoms 7–8 (F index 7, H index 8)

**Note:** The four HF monomers are not identical in orientation.
Therefore `B_B ≠ A_A` — all four monomer calculations are independent.

---

## F–F Distances

| Pair | F–F Distance (Å) | Type |
|------|-----------------|------|
| AB   | ~2.51           | neighboring |
| BC   | ~2.51           | neighboring |
| CD   | ~2.51           | neighboring |
| DA   | ~2.51           | neighboring |
| AC   | ~3.56           | diagonal |
| BD   | ~3.56           | diagonal |

C4 symmetry confirmed: all four neighboring pairs are equivalent, both
diagonal pairs are equivalent.

---

## Hydrogen Bond Network

Each HF monomer donates its H to the F of the next monomer in the ring
(cyclic pattern):

| Donor H | Acceptor F | H···F (Å) |
|---------|-----------|-----------|
| H_A (index 2) | F_B (index 3) | ~1.59 |
| H_B (index 4) | F_C (index 5) | ~1.59 |
| H_C (index 6) | F_D (index 7) | ~1.59 |
| H_D (index 8) | F_A (index 1) | ~1.59 |

All four H···F distances are equivalent by C4 symmetry.

---

## File Naming Convention

Files in `CCSD_T/aug-cc-pvdz/` follow the `REAL_BASIS` convention:

```
REAL_BASIS.nw   ← NWChem input file
REAL_BASIS.out  ← NWChem output file
```

Where:
- `REAL`  = the fragment whose energy is computed (e.g. `A`, `AB`, `ABC`)
- `BASIS` = the basis set used (ghost functions included, e.g. `ABCD`, `AB`)

Examples:
- `A_A.nw`       — monomer A in its own basis
- `A_ABCD.nw`    — monomer A in the full tetramer basis (ghost functions for B, C, D)
- `AB_ABCD.nw`   — dimer AB in the full tetramer basis
- `ABCD_ABCD.nw` — full tetramer in its own basis

Original files were named `input_E_BASIS_REAL.txt` / `output_E_BASIS_REAL.txt`
and renamed using `scripts/copy_rename_files_HF.py`.

---

## File Key Count

For a 4-monomer VMFC calculation:

| Fragment type      | Count       |
|--------------------|-------------|
| Monomers (1b)      | 4 × 8 = 32  |
| Dimers (2b)        | 6 × 4 = 24  |
| Trimers (3b)       | 4 × 2 = 8   |
| Tetramer (4b)      | 1           |
| **Total**          | **65**      |

Total files: 65 `.nw` + 65 `.out` = **130 files**.

---

## Key Scientific Results (CCSD(T)/aug-cc-pvdz)

### BSSE by body order — FORM(I)

| Term | Value (Ha) |
|------|------------|
| Σ 2b_bsse | −9.7867 × 10⁻³ |
| Σ 3b_bsse | +7.1960 × 10⁻⁴ |
| 4b_bsse   | −2.4858 × 10⁻⁴ |
| **total_bsse** | **−9.3157 × 10⁻³** |

### Many-body series convergence

Treating FORM(I) as a series with a_0 = Σ 2b_bsse, a_1 = Σ 3b_bsse,
a_2 = 4b_bsse:

| Ratio | Value |
|-------|-------|
| \|a_1/a_0\| | 0.0735 |
| \|a_2/a_1\| | 0.3454 |

Sign alternation at correlated level: a_0 < 0, a_1 > 0, a_2 < 0.
Absolute convergence holds: \|S_0\| > \|S_1\| > \|S_2\|.

### FORM(I) = FORM(II) verification

Verified at ~1e-14 Ha for all three methods (SCF, MP2, CCSD(T)).

---

## Data Frames and Plots (`data_frames_plots/`)

### `build_tetramer_dataframe.py`
Reads `four_body_bsse_HF_4.pickle` (in `bsse_db/data/`) and exports
one CSV per method: `tetramer_SCF_aug-cc-pvdz.csv`,
`tetramer_MP2_aug-cc-pvdz.csv`, `tetramer_CCSD_T_aug-cc-pvdz.csv`.

Each CSV has 88 columns: 3 metadata, 18 two-body (no_vmfc/vmfc/bsse × 6
pairs), 12 three-body, 3 four-body, 1 total_bsse (FORM I), 50 FORM(II)
delta terms, 1 total_bsse_form2 (consistency check).

### `print_summary_table.py`
Terminal-only summary (no CSV writing). Flags: `--method CCSD_T`
(default), `--method all`, `--scaling-only`. Includes convergence
ratios `|a_1/a_0|` and `|a_2/a_1|` in the scaling table.

### `plot_tetramer_bsse.py`
Seven-mode plotting script.
Usage: `python3 plot_tetramer_bsse.py --mol HF --plot N [--method M] [--abs] [--save]`

| Mode | Content |
|------|---------|
| 1 | Overview: Σ 2b_bsse, Σ 3b_bsse, 4b_bsse, total_bsse per method. `--abs` for absolute values. |
| 2 | 2b decomposition: total bar + 12 individual 1b-in-2b FORM(II) terms. |
| 3 | 3b decomposition: total bar + 1b-in-3b (−) and 2b-in-3b (+) groups. |
| 4 | 4b decomposition: total bar + 1b-in-4b (+), 2b-in-4b (−), 3b-in-4b (+) groups. |
| 5 | Two-panel: left — series terms a_0, a_1, a_2 (signed or `--abs`); right — ratio test \|a_1/a_0\|, \|a_2/a_1\| with ratio=1 reference line. |
| 6 | Absolute partial sums \|S_k\| as dots+line — absolute convergence. |
| 7 | Signed partial sums S_k as dots+line — conditional convergence; dotted reference lines at S_2 = total_bsse per method. |

Generated plots:
- `tetramer_mode1_overview_aug-cc-pvdz.png`
- `tetramer_mode1_overview_abs_aug-cc-pvdz.png`
- `tetramer_mode2_2b_decomp_aug-cc-pvdz.png`
- `tetramer_mode3_3b_decomp_aug-cc-pvdz.png`
- `tetramer_mode4_4b_decomp_aug-cc-pvdz.png`
- `tetramer_mode5_series_terms_aug-cc-pvdz.png`
- `tetramer_mode5_series_terms_abs_aug-cc-pvdz.png`
- `tetramer_mode6_abs_partial_sums_aug-cc-pvdz.png`
- `tetramer_mode7_signed_partial_sums_aug-cc-pvdz.png`

---

## Visualization

Three PyMOL scripts are provided. Run from the `HF/4/` directory.

### `load_tetramer.pml` — basic loading script
Loads `pymol_xyz_files/HF_abcd.xyz` with ball-and-stick rendering and
`util.cbaw` coloring. No distance objects or labels.

```bash
pymol load_tetramer.pml
```

### `HF_tetramer_I.pml` — F–F distances
Displays only the F atoms with dashed lines connecting all 6 F–F pairs
(4 neighboring ~2.51 Å + 2 diagonal ~3.56 Å). A/B/C/D labels on F
atoms. White background. Distance values shown.
Produces: `data_frames_plots/HF_tetramer_I.png`

```bash
pymol HF_tetramer_I.pml
```

### `HF_tetramer_II.pml` — H-bond network
Displays all atoms (F and H) with dashed lines showing the 4 H···F
hydrogen bonds forming the cyclic ring (~1.59 Å each). H atoms colored
grey60 for visibility on white background. A/B/C/D labels on F atoms.
White background. Distance values shown.
Produces: `data_frames_plots/HF_tetramer_II.png`

```bash
pymol HF_tetramer_II.pml
```

---

## Scripts

All scripts in `HF/4/scripts/` can be run from any directory.

| Script | Description |
|--------|-------------|
| `copy_rename_files_HF.py` | Extracts from tar, renames, copies files |
| `verify_copy_HF.py` | Byte-level verification of all 130 files |
| `nwchem_to_pymol_HF.py` | Generates `pymol_xyz_files/HF_abcd.xyz` |
| `make_load_pml_HF.py` | Generates `load_tetramer.pml` |

---

## Downstream Pipeline Scripts (`bsse_db/data/`)

| Script | Input | Output | Description |
|--------|-------|--------|-------------|
| `build_raw_data_4.py --mol HF` | `4.tar.gz` | `raw_data_HF_4.pickle` | Extracts energies into nested dict (no monomer injection) |
| `many_body_interactions_4.py --mol HF` | `raw_data_HF_4.pickle` | `many_body_interactions_HF_4.pickle` | Computes 2b, 3b, 4b interaction energies |
| `four_body_bsse.py --mol HF` | `many_body_interactions_HF_4.pickle` | `four_body_bsse_HF_4.pickle` | FORM(I) and FORM(II) BSSE decomposition |

**Energy storage convention** (incremental, not cumulative):

| Key | Quantity stored |
|-----|----------------|
| `SCF` | Total HF energy |
| `MP2` | Correlation component: E_MP2 − E_SCF |
| `CCSD_T` | Triples component: E_CCSD(T) − E_MP2 |

---

## Branch

`fcuantico` — part of `rmrresearch/bsse_db`, GitHub Issue #46.

## References

- Valiron & Mayer (1997) *Chem. Phys. Lett.* **275**, 46–55 — VMFC method
- GitHub Issue #46 — PI's revised task list and file naming conventions