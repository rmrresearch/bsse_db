# HF/4/ — HF Tetramer (CCSD(T)/aug-cc-pvdz)

## Overview

This folder contains the BSSE calculations for the optimal HF tetramer
at the CCSD(T)/aug-cc-pvdz level of theory. There is a single geometry
(the optimal tetramer configuration — no distance scan).

---

## Folder Structure

```
HF/4/
├── CCSD_T/aug-cc-pvdz/    ← 65 .nw (input) + 65 .out (output) files
├── original_data/
│   ├── optimal_HF_tetramer.tar   ← original raw files (authoritative backup)
│   └── geometry_optimization/    ← geometry optimization input/output files
├── pymol_xyz_files/
│   └── HF_abcd.xyz               ← tetramer geometry for PyMOL
├── load_tetramer.pml             ← PyMOL loader script
├── data_frames_plots/            ← pipeline output (CSVs, plots)
├── README.md
└── scripts/
    ├── copy_rename_files_HF.py
    ├── verify_copy_HF.py
    ├── nwchem_to_pymol_HF.py
    └── make_load_pml_HF.py
```

---

## Geometry

The HF tetramer geometry is the optimal (minimum energy) configuration.
The four HF units are arranged in a cyclic hydrogen-bonded ring in the
XY plane. Cartesian coordinates (Angstroms):

```
F  0.00000000   0.00000000   0.00000000
H  0.00000000   0.94700000   0.00000000
F  0.41876306   2.47879029   0.00000000
H  1.36576306   2.47879029   0.00000000
F  2.89755335   2.06002723   0.00000000
H  2.89755335   1.11302723   0.00000000
F  2.47879029  -0.41876306   0.00000000
H  1.53179029  -0.41876306   0.00000000
```

The geometry source is `original_data/optimal_HF_tetramer.tar` →
`input_E_ABCD_ABCD.txt`. The NWChem geometry block uses a plain
`geometry` header (no `noautoz autosym`).

Monomer assignment:
- Monomer A: atoms 1–2 (F, H)
- Monomer B: atoms 3–4 (F, H)
- Monomer C: atoms 5–6 (F, H)
- Monomer D: atoms 7–8 (F, H)

**Note:** The four HF monomers are not identical in orientation.
Therefore `B_B ≠ A_A` — all four monomer calculations are independent.

---

## File Naming Convention

Files in `CCSD_T/aug-cc-pvdz/` follow the `REAL_BASIS` convention:

```
REAL_BASIS.nw   ← NWChem input file
REAL_BASIS.out  ← NWChem output file
```

Where:
- `REAL`  = the fragment whose energy is computed (e.g. `A`, `AB`, `ABC`)
- `BASIS` = the basis set used (ghost functions included, e.g. `ABCD`, `AB`)

Examples:
- `A_A.nw`       — monomer A in its own basis
- `A_ABCD.nw`    — monomer A in the full tetramer basis (ghost functions for B, C, D)
- `AB_ABCD.nw`   — dimer AB in the full tetramer basis
- `ABCD_ABCD.nw` — full tetramer in its own basis

Original files were named `input_E_BASIS_REAL.txt` / `output_E_BASIS_REAL.txt`
and renamed using `scripts/copy_rename_files_HF.py`.

---

## File Key Count

For a 4-monomer VMFC calculation:

| Fragment type      | Count       |
|--------------------|-------------|
| Monomers (1b)      | 4 × 8 = 32  |
| Dimers (2b)        | 6 × 4 = 24  |
| Trimers (3b)       | 4 × 2 = 8   |
| Tetramer (4b)      | 1           |
| **Total**          | **65**      |

Total files: 65 `.nw` + 65 `.out` = **130 files**.

---

## PyMOL Visualization

From `HF/4/`:
```bash
pymol load_tetramer.pml
```

---

## Scripts

All scripts in `HF/4/scripts/` can be run from any directory.

| Script | Description |
|--------|-------------|
| `copy_rename_files_HF.py` | Extracts from tar, renames, copies files |
| `verify_copy_HF.py` | Byte-level verification of all 130 files |
| `nwchem_to_pymol_HF.py` | Generates `pymol_xyz_files/HF_abcd.xyz` |
| `make_load_pml_HF.py` | Generates `load_tetramer.pml` |

---

## Branch

`fcuantico` — part of `rmrresearch/bsse_db`, GitHub Issue #46.