"""
nwchem_to_pymol_HF.py
----------------------
Extracts the HF tetramer geometry from HF/4/CCSD_T/aug-cc-pvdz/ABCD_ABCD.nw
and writes a clean .xyz file to HF/4/pymol_xyz_files/HF_abcd.xyz.

Can be run from any directory, including HF/4/scripts/.

Usage:
    python3 nwchem_to_pymol_HF.py
"""

from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
NW_FILE    = SCRIPT_DIR.parent / "CCSD_T" / "aug-cc-pvdz" / "ABCD_ABCD.nw"
OUT_FILE   = SCRIPT_DIR.parent / "pymol_xyz_files" / "HF_abcd.xyz"

coord_lines = []
in_geometry = False

with open(NW_FILE) as f:
    for line in f:
        stripped = line.strip()
        if stripped.startswith("geometry"):
            in_geometry = True
            continue
        if stripped == "end" and in_geometry:
            break
        if in_geometry and stripped:
            coord_lines.append(stripped)

if len(coord_lines) != 8:
    print(f"⚠️  Expected 8 atoms (4 HF units), found {len(coord_lines)}. Check {NW_FILE.name}.")
else:
    print(f"Found {len(coord_lines)} atoms (4 F + 4 H) ✅")

with open(OUT_FILE, "w") as f:
    f.write(f"{len(coord_lines)}\n")
    f.write("HF tetramer optimal geometry\n")
    for line in coord_lines:
        parts = line.split()
        element = parts[0]
        x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
        f.write(f"{element} {x:.8f} {y:.8f} {z:.8f}\n")

print(f"Written: {OUT_FILE}")