"""
make_load_pml_HF.py
--------------------
Generates HF/4/load_tetramer.pml for visualizing the HF tetramer
in PyMOL.

Can be run from any directory, including HF/4/scripts/.

Usage:
    python3 make_load_pml_HF.py
"""

from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PML_FILE   = SCRIPT_DIR.parent / "load_tetramer.pml"
XYZ_FILE   = "pymol_xyz_files/HF_abcd.xyz"

pml_content = f"""\
load {XYZ_FILE}, HF_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw
"""

PML_FILE.write_text(pml_content)
print(f"Written: {PML_FILE}")