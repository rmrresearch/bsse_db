load pymol_xyz_files/HF_abcd.xyz, HF_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white

# Hide hydrogens — show F atoms only
hide everything, name H

# F-F connectivity by atom index (F atoms at positions 1, 3, 5, 7)
# 4 neighboring pairs (~2.51 Ang) + 2 diagonal pairs (~3.56 Ang)
distance FF_AB, index 1, index 3
distance FF_BC, index 3, index 5
distance FF_CD, index 5, index 7
distance FF_DA, index 7, index 1
distance FF_AC, index 1, index 5
distance FF_BD, index 3, index 7

# Black dashes — visible on white background
color black, FF_AB
color black, FF_BC
color black, FF_CD
color black, FF_DA
color black, FF_AC
color black, FF_BD

# Distance labels visible — black on white
set label_color, black, FF_AB
set label_color, black, FF_BC
set label_color, black, FF_CD
set label_color, black, FF_DA
set label_color, black, FF_AC
set label_color, black, FF_BD

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25
set label_size, 16

# Labels on F atoms — A, B, C, D (confirmed from A_ABCD.nw)
label index 1, "A"
label index 3, "B"
label index 5, "C"
label index 7, "D"

# Label style
set label_size, 24
set label_color, blue
set label_font_id, 5

# Center and orient
zoom all
orient
