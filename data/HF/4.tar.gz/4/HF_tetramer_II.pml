load pymol_xyz_files/HF_abcd.xyz, HF_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white

# H atoms are white after util.cbaw — recolor grey so they show on white background
color grey60, name H

# H...F hydrogen bond network (cyclic ring, H...F ~1.59 Ang)
# H_A(index 2) -> F_B(index 3)
# H_B(index 4) -> F_C(index 5)
# H_C(index 6) -> F_D(index 7)
# H_D(index 8) -> F_A(index 1)
distance HA_FB, index 2, index 3
distance HB_FC, index 4, index 5
distance HC_FD, index 6, index 7
distance HD_FA, index 8, index 1

# Black dashes — visible on white background
color black, HA_FB
color black, HB_FC
color black, HC_FD
color black, HD_FA

# Hide distance number labels
hide labels, HA_FB
hide labels, HB_FC
hide labels, HC_FD
hide labels, HD_FA

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Labels on F atoms — A, B, C, D (confirmed from A_ABCD.nw)
label index 1, "A"
label index 3, "B"
label index 5, "C"
label index 7, "D"

# Label style
set label_size, 24
set label_color, blue
set label_font_id, 5

# Center and orient
zoom all
orient
