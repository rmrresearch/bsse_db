load pymol_xyz_files/HF_abcd.xyz, HF_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw
