# H2O_tetramer_I.pml — H2O Tetramer | O-O distances | H atoms hidden
# Asymmetric geometry (no rotational symmetry)
# O atoms: O_A=1, O_B=4, O_C=7, O_D=10  (confirmed from A_ABCD.nw)
# Neighboring O-O: BC=2.742, AC=2.798, AB=2.873, BD=2.895 Å
# Non-neighboring O-O: CD=5.060, AD=5.101 Å

load pymol_xyz_files/H2O_abcd.xyz, H2O_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white
set ray_opaque_background, 1

# Hide H atoms — show O skeleton only
hide everything, name H

# O-O distances — all 6 pairs
distance OO_AB, index 1, index 4
distance OO_AC, index 1, index 7
distance OO_AD, index 1, index 10
distance OO_BC, index 4, index 7
distance OO_BD, index 4, index 10
distance OO_CD, index 7, index 10

# Black dashes
color black, OO_AB
color black, OO_AC
color black, OO_AD
color black, OO_BC
color black, OO_BD
color black, OO_CD

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
set label_distance_digits, 2

# Global label settings BEFORE per-distance overrides
set label_size, 12
set label_color, black
set label_font_id, 5

# Labels on O atoms
label index 1,  "A"
label index 4,  "B"
label index 7,  "C"
label index 10, "D"

# Distance labels — black
set label_color, black, OO_AB
set label_color, black, OO_AC
set label_color, black, OO_AD
set label_color, black, OO_BC
set label_color, black, OO_BD
set label_color, black, OO_CD
set label_size, 16, OO_AB
set label_size, 16, OO_AC
set label_size, 16, OO_AD
set label_size, 16, OO_BC
set label_size, 16, OO_BD
set label_size, 16, OO_CD

# Fit to view — rotate z to get sideways/landscape orientation
zoom all, 0.8
rotate x, 120
rotate y, 0.0
rotate z, 60


# Render
png H2O_tetramer_I.png, width=800, height=800, dpi=300, ray=1
