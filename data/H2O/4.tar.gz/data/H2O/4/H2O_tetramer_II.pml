# H2O_tetramer_II.pml — H2O Tetramer | H-bond network | H atoms visible
# H-bond network (confirmed from A_ABCD.nw, H...O < 2.1 Å):
#   H_B1(index 5)  -> O_A(index 1)  ~2.03 Å
#   H_A1(index 2)  -> O_C(index 7)  ~1.88 Å
#   H_B2(index 6)  -> O_D(index 10) ~1.92 Å
#   H_C2(index 9)  -> O_B(index 4)  ~1.81 Å
# Monomer B is hub (donates to A and D); monomer D only accepts

load pymol_xyz_files/H2O_abcd.xyz, H2O_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white
set ray_opaque_background, 1

# H atoms visible — grey60 for contrast on white background
color grey60, name H

# H-bond distances
distance HB1_OA, index 5, index 1
distance HA1_OC, index 2, index 7
distance HB2_OD, index 6, index 10
distance HC2_OB, index 9, index 4

# Black dashes
color black, HB1_OA
color black, HA1_OC
color black, HB2_OD
color black, HC2_OB

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Global label settings BEFORE per-distance overrides
set label_size, 12
set label_color, black
set label_font_id, 5

# Labels on O atoms
label index 1,  "A"
label index 4,  "B"
label index 7,  "C"
label index 10, "D"

# Hide H-bond distance labels — network topology shown by dashes only
hide labels, HB1_OA
hide labels, HA1_OC
hide labels, HB2_OD
hide labels, HC2_OB

# Fit to view — no orient: use XYZ natural coordinates
zoom all, 0.8

# Render
png H2O_tetramer_II.png, width=800, height=800, dpi=300, ray=1
