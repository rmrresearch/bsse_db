"""
plot_tetramer_bsse.py
Location: bsse_db/data/H2O/4/data_frames_plots/

Reads tetramer CSVs and produces 4 plot modes.

Usage:
    python3 plot_tetramer_bsse.py --plot 1
    python3 plot_tetramer_bsse.py --plot 1 --abs
    python3 plot_tetramer_bsse.py --plot 2 --method MP2
    python3 plot_tetramer_bsse.py --plot 2 --sign
    python3 plot_tetramer_bsse.py --plot 3 --method all
    python3 plot_tetramer_bsse.py --plot 4 --method SCF --save
    python3 plot_tetramer_bsse.py --plot 2 --save --name v2

Flags:
    --plot    1-4              plot mode (required)
    --method  SCF/MP2/CCSD_T/all   default: all
    --basis   aug-cc-pvdz      default: aug-cc-pvdz
    --abs                      plot absolute values (mode 1 only)
    --sign                     negate all values: -BSSE (mode 2 only)
    --save                     save figure as PNG
    --name    STRING           custom suffix for saved filename, e.g. --name v2
"""

import argparse
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths and topology
# ---------------------------------------------------------------------------
here   = Path(__file__).resolve().parent
BASIS  = "aug-cc-pvdz"

PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]
METHODS = ["SCF", "MP2", "CCSD_T"]

# FORM(II) delta term groups
DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]
DELTA_1B_IN_4B = ["A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD"]
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]
DELTA_3B_IN_4B = ["ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD"]

METHOD_COLORS = {"SCF": "steelblue", "MP2": "darkorange", "CCSD_T": "seagreen"}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def load_csv(method, basis):
    path = here / f"tetramer_{method}_{basis}.csv"
    return pd.read_csv(path)

def sci_formatter():
    return ticker.FuncFormatter(lambda x, _: f"{x:.2e}")

def sum_2b_bsse(row):
    return sum(row[f"2b_bsse_{p}"] for p in PAIRS)

def sum_3b_bsse(row):
    return sum(row[f"3b_bsse_{t}"] for t in TRIPLES)

# ---------------------------------------------------------------------------
# Mode 1 — Overview: summed 2b, 3b, 4b vs total BSSE
# ---------------------------------------------------------------------------
def plot_mode1(methods, basis, save, abs_vals=False, name=None):
    """Bar chart: 2b_bsse, 3b_bsse, 4b_bsse, total_bsse per method."""
    labels    = ["2b_bsse", "3b_bsse", "4b_bsse", "total_bsse"]
    n_groups  = len(labels)
    n_methods = len(methods)
    x         = np.arange(n_groups)
    width     = 0.25

    fig, ax = plt.subplots(figsize=(12, 6))

    all_method_vals = []
    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        vals = [
            sum_2b_bsse(row),
            sum_3b_bsse(row),
            row["4b_bsse"],
            row["total_bsse"],
        ]
        if abs_vals:
            vals = [abs(v) for v in vals]
        all_method_vals.append((method, vals))

    all_flat  = [v for _, vs in all_method_vals for v in vs]
    y_range   = max(all_flat) - min(all_flat)
    min_pad   = 0.025 * abs(y_range)

    for i, (method, vals) in enumerate(all_method_vals):
        offset = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, vals, width, label=method,
                      color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")

        for bar, v in zip(bars, vals):
            x_pos = bar.get_x() + bar.get_width() / 2
            y_tip = bar.get_height()
            pad   = max(0.03 * abs(y_tip), min_pad)
            y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
            va    = "bottom" if y_tip >= 0 else "top"
            ax.text(x_pos, y_pos, f"{v:.2e}",
                    ha="center", va=va, fontsize=7, rotation=0,
                    color=METHOD_COLORS[method], fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ylabel = "|BSSE| (Hartree)" if abs_vals else "BSSE (Hartree)"
    ax.set_ylabel(ylabel, fontsize=10)
    title_suffix = " — absolute values" if abs_vals else ""
    ax.set_title(f"H$_2$O Tetramer — BSSE by Body Order ({basis}){title_suffix}", fontsize=11)
    ax.yaxis.set_major_formatter(sci_formatter())
    if not abs_vals:
        ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left', bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    ymin, ymax = ax.get_ylim()
    ax.set_ylim(ymin * 1.15, ymax * 1.15 if ymax > 0 else ymax * 0.85)
    fig.tight_layout()

    if save:
        abs_suffix  = "_abs" if abs_vals else ""
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode1_overview{abs_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()

# ---------------------------------------------------------------------------
# Mode 2 — 2b_bsse decomposition: 12 × 1b-in-2b terms
# ---------------------------------------------------------------------------
def plot_mode2(methods, basis, save, sign=False, name=None):
    """Bar chart of total 2b_bsse + 12 FORM(II) 1b-in-2b delta terms.

    sign=True  →  plot −BSSE: dominant negative bars flip to positive,
                  AD repulsive contributions flip to negative.
                  Relative contributions are fully preserved.
    """
    n_total = 1 + len(DELTA_1B_IN_2B)
    x       = np.arange(n_total)
    width   = 0.25
    n_methods = len(methods)

    fig, ax = plt.subplots(figsize=(18, 6))

    label_data = []
    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        all_vals = [sum_2b_bsse(row)] + [row[k] for k in DELTA_1B_IN_2B]
        if sign:
            all_vals = [-v for v in all_vals]
        offset   = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, all_vals, width, label=method,
                      color=METHOD_COLORS[method], alpha=0.85,
                      edgecolor="k",
                      linewidth=[2.5] + [0.8] * len(DELTA_1B_IN_2B))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0]
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    ax.text(x_pos, y_pos, f"{total_val:.2e}",
            ha="center", va=va, fontsize=8, rotation=0,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5, color="black", linewidth=1.5, linestyle="--")

    all_labels = ["Total\n2b_bsse"] + [k.replace("_in_", "\nin ") for k in DELTA_1B_IN_2B]
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=8, rotation=0, ha="center")

    ylabel = "$-$BSSE contribution (Hartree)" if sign else "BSSE contribution (Hartree)"
    ax.set_ylabel(ylabel, fontsize=10)
    title_suffix = " — negated ($-$BSSE)" if sign else ""
    ax.set_title(
        f"H$_2$O Tetramer — 2b BSSE Decomposition: 1b-in-2b terms ({basis}){title_suffix}",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(sci_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left', bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        sign_suffix = "_sign" if sign else ""
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode2_2b_decomp{sign_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()

# ---------------------------------------------------------------------------
# Mode 3 — 3b_bsse decomposition: 1b-in-3b (−) and 2b-in-3b (+)
# ---------------------------------------------------------------------------
def plot_mode3(methods, basis, save, name=None):
    """Bar chart of total 3b_bsse + 24 FORM(II) 3b delta terms split by group."""
    all_keys  = DELTA_1B_IN_3B + DELTA_2B_IN_3B
    n_total   = 1 + len(all_keys)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)
    split = 1 + len(DELTA_1B_IN_3B)

    fig, ax = plt.subplots(figsize=(20, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        signed_vals = [-row[k] for k in DELTA_1B_IN_3B] + [row[k] for k in DELTA_2B_IN_3B]
        all_vals = [sum_3b_bsse(row)] + signed_vals
        offset   = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, all_vals, width, label=method,
               color=METHOD_COLORS[method], alpha=0.85, edgecolor="k",
               linewidth=[2.5] + [0.8] * len(all_keys))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0]
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    ax.text(x_pos, y_pos, f"{total_val:.2e}",
            ha="center", va=va, fontsize=8, rotation=0,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5,         color="black", linewidth=1.5, linestyle="--")
    ax.axvline(split - 0.5, color="gray",  linewidth=1,   linestyle=":")

    all_labels = ["Total\n3b_bsse"] + [k.replace("_in_", "\nin ") for k in all_keys]
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=7, rotation=0, ha="center")

    ymin = ax.get_ylim()[0]
    ax.text((1 + split - 1) / 2,       ymin * 0.85, "← 1b-in-3b (−) →",
            ha="center", fontsize=9, color="crimson", fontweight="bold")
    ax.text((split + n_total - 1) / 2, ymin * 0.85, "← 2b-in-3b (+) →",
            ha="center", fontsize=9, color="purple",  fontweight="bold")

    ax.set_ylabel("Signed BSSE contribution (Hartree)", fontsize=10)
    ax.set_title(f"H$_2$O Tetramer — 3b BSSE Decomposition ({basis})", fontsize=11)
    ax.yaxis.set_major_formatter(sci_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left', bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode3_3b_decomp{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()

# ---------------------------------------------------------------------------
# Mode 4 — 4b_bsse decomposition: 1b-in-4b (+), 2b-in-4b (−), 3b-in-4b (+)
# ---------------------------------------------------------------------------
def plot_mode4(methods, basis, save, name=None):
    """Bar chart of total 4b_bsse + 14 FORM(II) 4b delta terms in 3 signed groups."""
    all_keys  = DELTA_1B_IN_4B + DELTA_2B_IN_4B + DELTA_3B_IN_4B
    n_total   = 1 + len(all_keys)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)
    s1 = 1 + len(DELTA_1B_IN_4B)
    s2 = s1 + len(DELTA_2B_IN_4B)

    group_colors = (
        ["k"]
      + ["#2ca02c"] * len(DELTA_1B_IN_4B)
      + ["#9467bd"] * len(DELTA_2B_IN_4B)
      + ["#d62728"] * len(DELTA_3B_IN_4B)
    )

    fig, ax = plt.subplots(figsize=(18, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        signed_vals = (
            [row[k]  for k in DELTA_1B_IN_4B]
          + [-row[k] for k in DELTA_2B_IN_4B]
          + [row[k]  for k in DELTA_3B_IN_4B]
        )
        all_vals = [row["4b_bsse"]] + signed_vals
        offset   = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, all_vals, width, label=method,
               color=METHOD_COLORS[method], alpha=0.85,
               edgecolor=group_colors,
               linewidth=[2.5] + [1.5] * len(all_keys))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0]
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    ax.text(x_pos, y_pos, f"{total_val:.2e}",
            ha="center", va=va, fontsize=8, rotation=0,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5,      color="black", linewidth=1.5, linestyle="--")
    ax.axvline(s1 - 0.5, color="gray",  linewidth=1,   linestyle=":")
    ax.axvline(s2 - 0.5, color="gray",  linewidth=1,   linestyle=":")

    all_labels = ["Total\n4b_bsse"] + [k.replace("_in_", "\nin ") for k in all_keys]
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=8, rotation=0, ha="center")

    ymin, ymax = ax.get_ylim()
    label_y = ymin * 1.10
    ax.set_ylim(ymin * 1.28, ymax * 1.15)

    ax.text((1 + s1 - 1) / 2,          label_y, "← 1b-in-4b (+) →",
            ha="center", fontsize=9, color="#2ca02c", fontweight="bold")
    ax.text((s1 + s2 - 1) / 2,         label_y, "← 2b-in-4b (−) →",
            ha="center", fontsize=9, color="#9467bd", fontweight="bold")
    ax.text((s2 + n_total - 1) / 2,    label_y, "← 3b-in-4b (+) →",
            ha="center", fontsize=9, color="#d62728", fontweight="bold")

    ax.set_ylabel("Signed BSSE contribution (Hartree)", fontsize=10)
    ax.set_title(f"H$_2$O Tetramer — 4b BSSE Decomposition ({basis})", fontsize=11)
    ax.yaxis.set_major_formatter(sci_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left', bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode4_4b_decomp{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser(description="Tetramer BSSE plots")
    p.add_argument("--plot",   type=int, required=True, choices=[1, 2, 3, 4])
    p.add_argument("--method", default="all",
                   choices=["SCF", "MP2", "CCSD_T", "all"])
    p.add_argument("--basis",  default=BASIS)
    p.add_argument("--save",   action="store_true")
    p.add_argument("--abs",    action="store_true",
                   help="Plot absolute values (mode 1 only)")
    p.add_argument("--sign",   action="store_true",
                   help="Negate all values: plot -BSSE (mode 2 only)")
    p.add_argument("--name",   default=None,
                   help="Custom suffix for saved filename, e.g. --name v2")
    return p.parse_args()

if __name__ == "__main__":
    args    = parse_args()
    methods = METHODS if args.method == "all" else [args.method]

    if args.plot == 1:
        plot_mode1(methods, args.basis, args.save, abs_vals=args.abs, name=args.name)
    elif args.plot == 2:
        plot_mode2(methods, args.basis, args.save, sign=args.sign, name=args.name)
    else:
        dispatch = {3: plot_mode3, 4: plot_mode4}
        dispatch[args.plot](methods, args.basis, args.save, name=args.name)