"""
build_tetramer_dataframe.py
Location: bsse_db/data/H2O/4/data_frames_plots/

Reads four_body_bsse_H2O_4.pickle and exports one CSV per method to
bsse_db/data/H2O/4/data_frames_plots/.

Mirrors build_trimer_dataframe.py with tetramer topology:
  - Single geometry (config '0') — no distance scan
  - 6 pairs  : AB, AC, AD, BC, BD, CD
  - 4 triples: ABC, ABD, ACD, BCD
  - 1 four-body scalar term
  - 50 FORM(II) delta terms
"""

import pickle
from pathlib import Path
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
here       = Path(__file__).resolve().parent          # data_frames_plots/
data_dir   = here.parent.parent.parent                # data/
pickle_path = data_dir / "four_body_bsse_H2O_4.pickle"
out_dir    = here                                     # CSVs written here

# ---------------------------------------------------------------------------
# Tetramer topology
# ---------------------------------------------------------------------------
MOLECULE = "H2O"
CLUSTER  = "4"
CONFIG   = "0"
BASIS    = "aug-cc-pvdz"
METHODS  = ["SCF", "MP2", "CCSD_T"]

PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]

# FORM(II) delta term keys — 50 total
# 1b-in-2b  (+)  12 terms
DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]

# 1b-in-3b  (-)  12 terms
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]

# 2b-in-3b  (+)  12 terms
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]

# 1b-in-4b  (+)  4 terms
DELTA_1B_IN_4B = [
    "A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD",
]

# 2b-in-4b  (-)  6 terms
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]

# 3b-in-4b  (+)  4 terms
DELTA_3B_IN_4B = [
    "ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD",
]

ALL_DELTA_TERMS = (
    DELTA_1B_IN_2B
    + DELTA_1B_IN_3B
    + DELTA_2B_IN_3B
    + DELTA_1B_IN_4B
    + DELTA_2B_IN_4B
    + DELTA_3B_IN_4B
)

assert len(ALL_DELTA_TERMS) == 50, f"Expected 50 delta terms, got {len(ALL_DELTA_TERMS)}"

# ---------------------------------------------------------------------------
# Load pickle
# ---------------------------------------------------------------------------
with open(pickle_path, "rb") as f:
    bsse_data = pickle.load(f)

print(f"Loaded: {pickle_path.name}")

# ---------------------------------------------------------------------------
# Build one DataFrame per method
# ---------------------------------------------------------------------------
for method in METHODS:
    rows = []

    entry = bsse_data[MOLECULE][CLUSTER][CONFIG][method][BASIS]

    row = {
        "config" : CONFIG,
        "method" : method,
        "basis"  : BASIS,
    }

    # --- 2b terms (6 pairs × 3 quantities) ---
    for pair in PAIRS:
        for qty in ("no_vmfc", "vmfc", "bsse"):
            row[f"2b_{qty}_{pair}"] = entry["2b"][pair][qty]

    # --- 3b terms (4 triples × 3 quantities) ---
    for triple in TRIPLES:
        for qty in ("no_vmfc", "vmfc", "bsse"):
            row[f"3b_{qty}_{triple}"] = entry["3b"][triple][qty]

    # --- 4b terms (scalar × 3 quantities) ---
    for qty in ("no_vmfc", "vmfc", "bsse"):
        row[f"4b_{qty}"] = entry["4b"][qty]

    # --- FORM(I) total ---
    row["total_bsse"] = entry["total_bsse"]

    # --- FORM(II) delta terms (50 keys) ---
    for key in ALL_DELTA_TERMS:
        row[key] = entry["delta_terms"][key]

    # --- FORM(II) consistency check ---
    row["total_bsse_form2"] = entry["total_bsse_form2"]

    rows.append(row)

    df = pd.DataFrame(rows)

    out_file = out_dir / f"tetramer_{method}_{BASIS}.csv"
    df.to_csv(out_file, index=False)
    print(f"Wrote: {out_file.name}  ({len(df.columns)} columns)")

print("\nDone. CSVs written to:", out_dir)