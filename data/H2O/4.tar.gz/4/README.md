# H2O Tetramer — `bsse_db/data/H2O/4/`

## Overview

This folder contains all NWChem input and output files needed to compute the
BSSE-corrected interaction energy of the optimal water tetramer using the
Valiron-Mayer Function Counterpoise (VMFC) method at the CCSD(T)/aug-cc-pvdz
level of theory, along with the complete downstream analysis pipeline.

Unlike the trimer study (which sampled 5 O–O distances), this is a **single
geometry**: the optimal water tetramer obtained from a geometry optimization.
The focus is on decomposing the total BSSE into its 2-body, 3-body, and 4-body
contributions using two complementary formulations (FORM(I) and FORM(II)).

---

## Geometry

**Source:** `original_data/input_E_ABCD_ABCD.txt`
**Format:** XYZ (12 atoms — 4 × H₂O)

```
12
pymol coord for H2O optimal tetramer
O  1.43578615 -1.81362614  0.02883928
H  0.51948659 -2.05981895  0.27379913
H  1.97323208 -1.99738588  0.80705304
O -0.20046914  0.37272269 -0.86419396
H  0.63389482 -0.08242954 -0.65336297
H -0.11854055  1.27366879 -0.50868257
O -1.33729724 -1.77663235  0.40232204
H -1.94652043 -2.27621778 -0.15290166
H -1.18633327 -0.92442897 -0.06636188
O  0.02509624  3.08759520  0.11490845
H  0.17771767  3.32038150  1.03857842
H  0.52221739  3.73343873 -0.40131992
```

Monomers are labeled A (0th), B (1st), C (2nd), D (3rd).

---

## File Naming Convention

All NWChem files follow the `<real>_<basis>` convention defined in GitHub
Issue #46:

- `<real>` — the monomer(s) with real atoms
- `<basis>` — the monomer(s) contributing basis functions
- `.nw` — NWChem input file
- `.out` — NWChem output file

**Example:** monomer A computed in the full tetramer basis → `A_ABCD.nw` / `A_ABCD.out`

The original files used a `input_E_BASIS_REAL.txt` / `output_E_BASIS_REAL.txt`
convention. The `scripts/copy_rename_files.py` script handled the translation
and renaming; originals are preserved in `original_data/`.

---

## Calculation Count

The VMFC method for a 4-body cluster requires **65 unique NWChem calculations**,
broken down by fragment size:

| Fragment type | Own-basis | Ghost-basis | Total |
|---|---|---|---|
| Monomers (k=1) | 4 | 28 | 32 |
| Dimers (k=2) | 6 | 18 | 24 |
| Trimers (k=3) | 4 | 4 | 8 |
| Tetramer (k=4) | 1 | 0 | 1 |
| **Total** | **15** | **50** | **65** |

This count follows from the general formula for the number of unique VMFC
calculations at N-body order: `3^N − (2^N + 1)` unique ghost-basis evaluations
plus `2^N − 1` own-basis evaluations. At N=4: 50 ghost-basis + 15 own-basis = 65.

All 65 calculations converged successfully (SCF, MP2, and CCSD(T) energies
present in all output files, verified with `check_convergence_4.py` in
`bsse_db/data/H2O/`).

---

## BSSE Formulations

This study uses two algebraically equivalent decompositions of the total BSSE,
referred to throughout as FORM(I) and FORM(II).

### FORM(I) — Body-ordered grouping

BSSE is expressed as a sum over body-order contributions:

```
BSSE = Σ 2b_bsse(XY)   [6 dimer terms]
     + Σ 3b_bsse(XYZ)  [4 trimer terms]
     + 4b_bsse(ABCD)   [1 four-body term]
```

where each `nb_bsse` is computed as the difference between the no-VMFC and
VMFC interaction energies at that body order. FORM(I) is compact and efficient
but does not expose the internal sign structure.

### FORM(II) — Explicit basis-set-difference expansion

BSSE is expressed as a sum of 50 individual basis-set-difference terms:

```
BSSE = Σ_{∅ ≠ X ⊊ Y ⊆ {A,B,C,D}} (−1)^(|Y|−|X|+1) [E_X(Y) − E_X(X)]
```

Terms organize into 6 sign groups by (|X|, |Y|):

| Group | Count | Sign | Name |
|---|---|---|---|
| k=1, n=2 | 12 | + | 1b-in-2b |
| k=1, n=3 | 12 | − | 1b-in-3b |
| k=2, n=3 | 12 | + | 2b-in-3b |
| k=1, n=4 |  4 | + | 1b-in-4b |
| k=2, n=4 |  6 | − | 2b-in-4b |
| k=3, n=4 |  4 | + | 3b-in-4b |
| **Total** | **50** | | |

FORM(I) and FORM(II) are algebraically identical; their equivalence was
verified numerically for all three methods (see `four_body_bsse.py`).

FORM(II) is the diagnostic tool for understanding *why* the body-order
hierarchy holds: the 2b level is the only level with no internal sign
cancellation (all 12 terms are positive), whereas 3b and 4b each have
alternating groups that partially cancel, producing the observed hierarchy
`|2b_bsse| >> |3b_bsse| ≈ |4b_bsse|`.

---

## Key Scientific Results (CCSD(T)/aug-cc-pvdz)

### BSSE by body order

FORM(I) results (CCSD(T)/aug-cc-pvdz):

| Term | Value (Ha) |
|---|---|
| Σ 2b_bsse | −6.418 × 10⁻³ |
| Σ 3b_bsse | −7.8 × 10⁻⁵ |
| 4b_bsse | +6.6 × 10⁻⁵ |
| **total_bsse** | **−6.431 × 10⁻³** |

The 2b contribution dominates: `|Σ 2b_bsse|` is approximately **80× larger**
than `|Σ 3b_bsse|`, consistent with the trimer result and supporting the
approximation hypothesis of Task 10.

### FORM(I) vs FORM(II) consistency check

The total BSSE was computed independently via both formulations. FORM(II)
sums all 50 individual `[E_X(Y) − E_X(X)]` terms with their respective signs
(see sign group table above); FORM(I) sums the `nb_bsse` quantities at each
body order. The two totals agree exactly for all three methods (SCF, MP2,
CCSD(T)), confirming that both implementations are correct. This check is
performed in `four_body_bsse.py` and the result is stored as `total_bsse_form2`
alongside `total_bsse` in each CSV for reference.

### BSSE by pair (2b terms)

| Pair | 2b_bsse (Ha) |
|---|---|
| AB | −1.28 × 10⁻³ |
| AC | −1.61 × 10⁻³ |
| AD | **+8.4 × 10⁻⁵** |
| BC | −1.91 × 10⁻³ |
| BD | −1.62 × 10⁻³ |
| CD | −0.72 × 10⁻⁴ |

The AD pair has a **positive** 2b_bsse, indicating a repulsive pair geometry.
This mirrors the AC repulsive pair observed in the trimer and reflects an
orientation-dependent BSSE consistent with the monomers being unfavorably
oriented at this geometry.

### BSSE method decomposition

The three method columns in the pipeline are **additive components** of the
total CCSD(T) BSSE, not independent estimates:

```
BSSE_total(CCSD(T)) = BSSE_SCF_part + BSSE_MP2_part + BSSE_(T)_part
```

| Component | 2b_bsse (Ha) | Fraction of total |
|---|---|---|
| SCF | ~1.33 × 10⁻³ | ~10% |
| MP2 correlation | ~5.95 × 10⁻³ | ~43% |
| (T) triples | ~6.42 × 10⁻³ | ~47% |

The correlation components together account for ~90% of total BSSE. This
has a direct implication for Step 10 thresholding: any approximation criterion
must be calibrated on the full CCSD(T) BSSE, not on the SCF component alone.

### Body-order hierarchy across method components

| Term | SCF | MP2 | CCSD_T |
|---|---|---|---|
| 2b_bsse | 1.33 × 10⁻³ | 5.95 × 10⁻³ | 6.42 × 10⁻³ |
| 3b_bsse | 3.08 × 10⁻⁴ | 8.92 × 10⁻⁵ | 7.79 × 10⁻⁵ |
| 4b_bsse | 1.34 × 10⁻⁴ | 7.33 × 10⁻⁵ | 6.55 × 10⁻⁵ |

Note the ordering **reverses** between 2b and higher body orders. At 2b:
`|(T)| > |MP2| >> |SCF|`. At 3b and 4b: `|SCF| > |MP2| ≈ |(T)|`. This
is explained by the disproportionate sensitivity of higher-order correlation
to ghost-function completeness, combined with more efficient sign cancellation
in FORM(II) at higher body orders for correlated methods.

---

## Folder Structure

```
4/
├── CCSD_T/
│   └── aug-cc-pvdz/            ← 65 .nw + 65 .out files
├── data_frames_plots/
│   ├── build_tetramer_dataframe.py
│   ├── plot_tetramer_bsse.py
│   ├── tetramer_SCF_aug-cc-pvdz.csv
│   ├── tetramer_MP2_aug-cc-pvdz.csv
│   ├── tetramer_CCSD_T_aug-cc-pvdz.csv
│   ├── tetramer_mode1_overview_aug-cc-pvdz.png
│   ├── tetramer_mode1_overview_abs_aug-cc-pvdz.png
│   ├── tetramer_mode2_2b_decomp_aug-cc-pvdz.png
│   ├── tetramer_mode3_3b_decomp_aug-cc-pvdz.png
│   └── tetramer_mode4_4b_decomp_aug-cc-pvdz.png
├── original_data/
│   ├── geometry_optimization/  ← geometry optimization files for reference
│   ├── input_E_*.txt           ← 65 original NWChem input files (pre-rename)
│   └── output_E_*.txt          ← 65 original NWChem output files (pre-rename)
├── pymol_xyz_files/
│   └── H2O_abcd.xyz            ← tetramer geometry for PyMOL
├── load_tetramer.pml           ← PyMOL loading script
├── README.md                   ← this file
└── scripts/
    ├── copy_rename_files.py
    ├── verify_copy.py
    └── cleanup_originals.py
```

**Note on `original_data/`:** Serves as a general backup and reference archive.
Contains the original `input_E_BASIS_REAL.txt` / `output_E_BASIS_REAL.txt`
files before renaming, and the `geometry_optimization/` folder with auxiliary
NWChem files from the geometry optimization run. The geometry used for all
BSSE calculations originates from `original_data/input_E_ABCD_ABCD.txt`.

---

## Scripts in This Folder (`scripts/`)

### `scripts/copy_rename_files.py`
Copies original `input_E_BASIS_REAL.txt` / `output_E_BASIS_REAL.txt` files
into `CCSD_T/aug-cc-pvdz/`, renaming them to the `REAL_BASIS.nw` /
`REAL_BASIS.out` convention. Backups are preserved in `original_data/`.

### `scripts/verify_copy.py`
Byte-by-byte verification of all copied files using `filecmp.cmp()`.
Result: **130/130 files verified OK**.

### `scripts/cleanup_originals.py`
Removes the original `input_E_*.txt` / `output_E_*.txt` files from the
root of `4/` after verification passes. The `original_data/` backup is
preserved. (Note: originals in `original_data/` are intentionally kept.)

---

## Downstream Pipeline Scripts (`bsse_db/data/`)

The following scripts in `bsse_db/data/` process this folder:

| Script | Input | Output | Description |
|---|---|---|---|
| `check_convergence_4.py` | `4/CCSD_T/aug-cc-pvdz/*.out` | stdout | Verifies SCF, MP2, CCSD(T) markers in all 65 files |
| `tar_output_discovery_4.py` | `4.tar.gz` | stream | Streams `.out` texts from tarball |
| `build_raw_data_4.py` | `4.tar.gz` | `raw_data_H2O_4.pickle` | Extracts SCF, MP2, CCSD(T) energies into nested dict |
| `many_body_interactions_4.py` | `raw_data_H2O_4.pickle` | `many_body_interactions_H2O_4.pickle` | Computes 2b, 3b, 4b interaction energies (no_vmfc and vmfc) |
| `four_body_bsse.py` | `many_body_interactions_H2O_4.pickle` | `four_body_bsse_H2O_4.pickle` | Computes FORM(I) and FORM(II) BSSE decomposition |

### `build_raw_data_4.py` — energy storage convention

NWChem energies are stored as additive components, not cumulative totals:

| Key | Quantity stored |
|---|---|
| `SCF` | Total SCF energy (~−76.04 Ha per monomer) |
| `MP2` | Correlation component: E_MP2 − E_SCF (~−0.22 Ha) |
| `CCSD_T` | Triples component: E_CCSD(T) − E_MP2 (~−0.012 Ha) |

This convention is defined in Step 3 of PI task list (GitHub Issue #46).

---

## Data Frames and Plots (`data_frames_plots/`)

### `build_tetramer_dataframe.py`
Reads `four_body_bsse_H2O_4.pickle` and exports one CSV per method:
`tetramer_SCF_aug-cc-pvdz.csv`, `tetramer_MP2_aug-cc-pvdz.csv`,
`tetramer_CCSD_T_aug-cc-pvdz.csv`.

Each CSV has 88 columns: 3 metadata, 18 two-body (no_vmfc/vmfc/bsse × 6 pairs),
12 three-body (no_vmfc/vmfc/bsse × 4 triples), 3 four-body, 1 total_bsse
(FORM I), 50 FORM(II) delta terms, 1 total_bsse_form2 (consistency check).

### `plot_tetramer_bsse.py`
Four-mode plotting script. Usage: `python3 plot_tetramer_bsse.py --plot N [--abs] [--sign] [--save]`

| Mode | Content |
|---|---|
| 1 | Overview: Σ 2b_bsse, Σ 3b_bsse, 4b_bsse, total_bsse per method. `--abs` for absolute values. |
| 2 | 2b decomposition: total bar + 12 individual 1b-in-2b terms. `--sign` to negate (flip dominant bars to positive axis). |
| 3 | 3b decomposition: total bar + 12 1b-in-3b (−) and 12 2b-in-3b (+) terms. |
| 4 | 4b decomposition: total bar + 4 1b-in-4b (+), 6 2b-in-4b (−), 4 3b-in-4b (+) terms. |

Generated plots:
- `tetramer_mode1_overview_aug-cc-pvdz.png`
- `tetramer_mode1_overview_abs_aug-cc-pvdz.png`
- `tetramer_mode2_2b_decomp_aug-cc-pvdz.png`
- `tetramer_mode3_3b_decomp_aug-cc-pvdz.png`
- `tetramer_mode4_4b_decomp_aug-cc-pvdz.png`

---

## Visualization

To load the tetramer in PyMOL, run from the `4/` directory:

```bash
pymol load_tetramer.pml
```

The script loads `pymol_xyz_files/H2O_abcd.xyz` and applies ball-and-stick
rendering.

---

## Tarball

The tarball `bsse_db/data/H2O/4.tar.gz` was created from `bsse_db/data/H2O/`
with:

```bash
tar -czf 4.tar.gz 4
```

Internal paths are of the form `4/CCSD_T/aug-cc-pvdz/REAL_BASIS.out`.
The downstream scripts `tar_output_discovery_4.py` and `build_raw_data_4.py`
expect this path structure.

---

## References

- Valiron & Mayer (1997) *Chem. Phys. Lett.* **275**, 46–55 — VMFC method
- Richard, Bakr & Sherrill (2018) *J. Chem. Theory Comput.* **14**, 2386 — PI's unified VMFC/MBE framework
- Salvador & Szczęśniak (2003) *J. Chem. Phys.* **118**, 537 — explicit tetramer VMFC
- GitHub Issue #46 — PI's revised task list and file naming conventions