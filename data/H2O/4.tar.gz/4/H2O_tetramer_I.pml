load pymol_xyz_files/H2O_abcd.xyz, H2O_tetramer
preset.ball_and_stick(selection='all', mode=1)

# Hide hydrogens
hide everything, name H

# O-O connectivity by atom index (oxygens at positions 1, 4, 7, 10)
distance OO_12, index 1, index 4
distance OO_13, index 1, index 7
distance OO_23, index 4, index 7
distance OO_24, index 4, index 10
distance OO_14, index 1, index 10
distance OO_34, index 7, index 10

# Color all dashes white
color white, OO_12
color white, OO_13
color white, OO_23
color white, OO_24
color white, OO_14
color white, OO_34

# Color of dahsed lines values
set label_color, yellow, OO_12
set label_color, yellow, OO_13
set label_color, yellow, OO_23
set label_color, yellow, OO_24
set label_color, yellow, OO_14
set label_color, yellow, OO_34

# Number font size
set label_size, 16, OO_12
set label_size, 16, OO_13
set label_size, 16, OO_23
set label_size, 16, OO_24
set label_size, 16, OO_14
set label_size, 16, OO_34

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Labels on oxygen atoms — A, B, C, D (confirmed from A_ABCD.nw)
label index 1, "A"
label index 4, "B"
label index 7, "C"
label index 10, "D"

# Label style — no inline comments on set commands
set label_size, 24
set label_color, white
set label_font_id, 5

# Center and orient
zoom all
orient
