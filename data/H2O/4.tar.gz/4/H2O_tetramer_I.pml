load pymol_xyz_files/H2O_abcd.xyz, H2O_tetramer
preset.ball_and_stick(selection='all', mode=1)

# White background
bg_color white

# Hide hydrogens
hide everything, name H

# O-O connectivity by atom index (oxygens at positions 1, 4, 7, 10)
distance OO_12, index 1, index 4
distance OO_13, index 1, index 7
distance OO_23, index 4, index 7
distance OO_24, index 4, index 10
distance OO_14, index 1, index 10
distance OO_34, index 7, index 10

# Black dashes — visible on white background
color black, OO_12
color black, OO_13
color black, OO_23
color black, OO_24
color black, OO_14
color black, OO_34

# Distance labels — black on white (keep visible)
set label_color, black, OO_12
set label_color, black, OO_13
set label_color, black, OO_23
set label_color, black, OO_24
set label_color, black, OO_14
set label_color, black, OO_34

# Distance label font size
set label_size, 16, OO_12
set label_size, 16, OO_13
set label_size, 16, OO_23
set label_size, 16, OO_24
set label_size, 16, OO_14
set label_size, 16, OO_34

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Labels on oxygen atoms — A, B, C, D (confirmed from A_ABCD.nw)
label index 1, "A"
label index 4, "B"
label index 7, "C"
label index 10, "D"

# A/B/C/D label style
set label_size, 24
set label_color, white
set label_font_id, 5

# Center and orient
zoom all
orient
