load pymol_xyz_files/H2O_abcd.xyz, H2O_tetramer
preset.ball_and_stick(selection='all', mode=1)