load pymol_xyz_files/H2O_abcd.xyz, H2O_tetramer
preset.ball_and_stick(selection='all', mode=1)

# H...O hydrogen bond connectivity (confirmed from geometry, H...O < 2.1 Ang)
# H_B1(index 5) -> O_A(index 1)  ~2.03 Ang
# H_A1(index 2) -> O_C(index 7)  ~1.88 Ang
# H_B2(index 6) -> O_D(index 10) ~1.92 Ang
# H_C2(index 9) -> O_B(index 4)  ~1.81 Ang
distance HB1_OA, index 5, index 1
distance HA1_OC, index 2, index 7
distance HB2_OD, index 6, index 10
distance HC2_OB, index 9, index 4

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Hide distance number labels
hide labels, HB1_OA
hide labels, HA1_OC
hide labels, HB2_OD
hide labels, HC2_OB

# Color all dashes white
color white, HB1_OA
color white, HA1_OC
color white, HB2_OD
color white, HC2_OB

# Labels on oxygen atoms — A, B, C, D (confirmed from A_ABCD.nw)
label index 1, "A"
label index 4, "B"
label index 7, "C"
label index 10, "D"

# Label style
set label_size, 24
set label_color, white
set label_font_id, 5

# Center and orient
zoom all
orient
