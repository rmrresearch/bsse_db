import filecmp
from pathlib import Path

here         = Path(__file__).resolve().parent
base_dir     = here.parent
original_dir = base_dir / "original_data"
dest_dir     = base_dir / "CCSD_T" / "aug-cc-pvdz"

mismatches = 0
checked    = 0

for orig_file in sorted(original_dir.iterdir()):
    if not orig_file.is_file():
        continue

    # Reconstruct the new name from the original
    if orig_file.name.startswith("input_E_"):
        stem       = orig_file.name.removeprefix("input_E_").removesuffix(".txt")
        real, basis = stem.split("_", 1)[1], stem.split("_", 1)[0]
        new_name   = f"{real}_{basis}.nw"
    elif orig_file.name.startswith("output_E_"):
        stem       = orig_file.name.removeprefix("output_E_").removesuffix(".txt")
        real, basis = stem.split("_", 1)[1], stem.split("_", 1)[0]
        new_name   = f"{real}_{basis}.out"
    else:
        continue

    dest_file = dest_dir / new_name
    if not dest_file.exists():
        print(f"MISSING: {new_name}")
        mismatches += 1
        continue

    if filecmp.cmp(orig_file, dest_file, shallow=False):
        print(f"OK: {orig_file.name}  →  {new_name}")
    else:
        print(f"MISMATCH: {orig_file.name}  →  {new_name}")
        mismatches += 1
    checked += 1

print(f"\nChecked: {checked} files")
print(f"Mismatches/Missing: {mismatches}")
if mismatches == 0:
    print("✅ All files verified OK.")