from pathlib import Path

here     = Path(__file__).resolve().parent
base_dir = here.parent

deleted = 0
for file in sorted(base_dir.iterdir()):
    if file.is_file() and (file.name.startswith("input_E_") or file.name.startswith("output_E_")):
        file.unlink()
        print(f"Deleted: {file.name}")
        deleted += 1

print(f"\nDeleted {deleted} files from {base_dir}")