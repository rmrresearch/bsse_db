import shutil
from pathlib import Path

# --- Paths ---
here     = Path(__file__).resolve().parent          # 4_optimal_water_tetramer/scripts/
base_dir = here.parent                              # 4_optimal_water_tetramer/

original_data = base_dir / "original_data"
dest_dir      = base_dir / "CCSD_T" / "aug-cc-pvdz"

original_data.mkdir(exist_ok=True)
dest_dir.mkdir(parents=True, exist_ok=True)

# --- Process files ---
for file in sorted(base_dir.iterdir()):
    if not file.is_file():
        continue

    # --- Backup originals ---
    if file.name.startswith("input_E_") or file.name.startswith("output_E_"):
        shutil.copy2(file, original_data / file.name)

    # --- Rename and copy to CCSD_T/aug-cc-pvdz/ ---
    if file.name.startswith("input_E_"):
        stem       = file.name.removeprefix("input_E_").removesuffix(".txt")  # e.g. "ABCD_ABC"
        real, basis = stem.split("_", 1)[1], stem.split("_", 1)[0]            # reverse
        new_name   = f"{real}_{basis}.nw"
        shutil.copy2(file, dest_dir / new_name)
        print(f"  {file.name}  →  {new_name}")

    elif file.name.startswith("output_E_"):
        stem       = file.name.removeprefix("output_E_").removesuffix(".txt")
        real, basis = stem.split("_", 1)[1], stem.split("_", 1)[0]
        new_name   = f"{real}_{basis}.out"
        shutil.copy2(file, dest_dir / new_name)
        print(f"  {file.name}  →  {new_name}")

print(f"\nDone. Originals backed up to: {original_data}")
print(f"Renamed files in:             {dest_dir}")