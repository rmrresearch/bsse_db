"""
build_trimer_dataframe.py
==========================
Trimer analogue of build_rot_dataframe.py.

Reads many_body_interactions_H2O_3.pickle and raw_data_H2O_3.pickle,
computes BSSE quantities via three_body_bsse.py, and writes one CSV
per method containing FORM(I) and FORM(II) quantities for all
configurations.

Lives in data/H2O/3/data_frames_plots/ following the same convention
as build_rot_dataframe.py in data/H2O/2/data_frames_plots/.

Path navigation
---------------
here      = data/H2O/3/data_frames_plots/build_trimer_dataframe.py
data_dir  = data/                          (3 levels up)

Output CSVs
-----------
One file per method, saved in the same folder as this script:
    trimer_SCF_aug-cc-pvdz.csv
    trimer_MP2_aug-cc-pvdz.csv
    trimer_CCSD_T_aug-cc-pvdz.csv

CSV columns
-----------
FORM(I) quantities:
    config          : configuration index (0, 1, 2, ...)
    distance        : O-O distance in Angstroms (from parameters)
    method          : level of theory (SCF, MP2, CCSD_T)
    basis           : basis set (aug-cc-pvdz)

    2b_no_vmfc_AB   : two-body interaction energy without CP, pair AB
    2b_vmfc_AB      : two-body interaction energy with CP, pair AB
    2b_bsse_AB      : two-body BSSE, pair AB
    2b_no_vmfc_AC   : same for pair AC
    2b_vmfc_AC
    2b_bsse_AC
    2b_no_vmfc_BC   : same for pair BC
    2b_vmfc_BC
    2b_bsse_BC

    3b_no_vmfc      : three-body interaction energy without CP
    3b_vmfc         : three-body interaction energy with CP
    3b_bsse         : three-body BSSE

    total_bsse      : total BSSE = sum of 2b_bsse(AB,AC,BC) + 3b_bsse  [FORM I]

FORM(II) delta terms (raw positive differences, signs in DELTA_SIGNS):
    A_in_AB, B_in_AB                    : 1b in 2b basis (+)
    A_in_AC, C_in_AC
    B_in_BC, C_in_BC
    A_in_ABC, B_in_ABC, C_in_ABC        : 1b in 3b basis (-)
    AB_in_ABC, AC_in_ABC, BC_in_ABC     : 2b in 3b basis (+)

    total_bsse_form2 : total BSSE recovered from signed sum of delta terms
                       must equal total_bsse to machine precision
"""

# ---- path setup ----
import sys
from pathlib import Path

here     = Path(__file__).resolve().parent          # data_frames_plots/
data_dir = here.parent.parent.parent                # data/
sys.path.insert(0, str(data_dir))

# ---- imports that depend on that path ----
from open_pickle_data import open_pickle
from three_body_bsse import threebody_bsse

# ---- standard imports ----
import pandas as pd


def main():
    # ---- pickle files ----
    many_body_pickle = data_dir / 'many_body_interactions_H2O_3.pickle'
    raw_pickle       = data_dir / 'raw_data_H2O_3.pickle'

    # ---- compute BSSE quantities ----
    three_b_bsse = threebody_bsse(many_body_pickle, 'H2O')
    parameters   = open_pickle(raw_pickle)['parameters']

    # ---- shorthand ----
    trimer_bsse = three_b_bsse['H2O']['3']
    trimer_pars = parameters['H2O']['3']

    # ---- discover methods and basis dynamically ----
    first_cfg    = next(iter(trimer_bsse))
    methods      = list(trimer_bsse[first_cfg].keys())
    basis        = list(trimer_bsse[first_cfg][methods[0]].keys())[0]

    # ---- build one CSV per method ----
    for method in methods:
        rows = []

        for cfg in sorted(trimer_bsse.keys(), key=int):
            p = trimer_pars[cfg]['params']
            e = trimer_bsse[cfg][method][basis]

            row = {
                # geometry
                'config'         : cfg,
                'distance'       : p['distance'],
                'method'         : method,
                'basis'          : basis,

                # FORM(I) — two-body per pair
                '2b_no_vmfc_AB'  : e['2b']['AB']['no_vmfc'],
                '2b_vmfc_AB'     : e['2b']['AB']['vmfc'],
                '2b_bsse_AB'     : e['2b']['AB']['bsse'],
                '2b_no_vmfc_AC'  : e['2b']['AC']['no_vmfc'],
                '2b_vmfc_AC'     : e['2b']['AC']['vmfc'],
                '2b_bsse_AC'     : e['2b']['AC']['bsse'],
                '2b_no_vmfc_BC'  : e['2b']['BC']['no_vmfc'],
                '2b_vmfc_BC'     : e['2b']['BC']['vmfc'],
                '2b_bsse_BC'     : e['2b']['BC']['bsse'],

                # FORM(I) — three-body
                '3b_no_vmfc'     : e['3b']['no_vmfc'],
                '3b_vmfc'        : e['3b']['vmfc'],
                '3b_bsse'        : e['3b']['bsse'],

                # FORM(I) — total BSSE
                'total_bsse'     : e['total_bsse'],

                # FORM(II) — 12 individual delta terms
                'A_in_AB'        : e['delta_terms']['A_in_AB'],
                'B_in_AB'        : e['delta_terms']['B_in_AB'],
                'A_in_AC'        : e['delta_terms']['A_in_AC'],
                'C_in_AC'        : e['delta_terms']['C_in_AC'],
                'B_in_BC'        : e['delta_terms']['B_in_BC'],
                'C_in_BC'        : e['delta_terms']['C_in_BC'],
                'A_in_ABC'       : e['delta_terms']['A_in_ABC'],
                'B_in_ABC'       : e['delta_terms']['B_in_ABC'],
                'C_in_ABC'       : e['delta_terms']['C_in_ABC'],
                'AB_in_ABC'      : e['delta_terms']['AB_in_ABC'],
                'AC_in_ABC'      : e['delta_terms']['AC_in_ABC'],
                'BC_in_ABC'      : e['delta_terms']['BC_in_ABC'],

                # FORM(II) — total BSSE (must equal total_bsse)
                'total_bsse_form2': e['total_bsse_form2'],
            }
            rows.append(row)

        df = pd.DataFrame(rows)

        out_file = here / f'trimer_{method}_{basis}.csv'
        df.to_csv(out_file, index=False)

        print(f'{method}  {df.shape}  saved to: {out_file}')


if __name__ == '__main__':
    main()