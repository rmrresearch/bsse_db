"""
plot_trimer_bsse_vs_distance.py
================================
Plots BSSE quantities vs O-O distance for the H2O trimer.

Reads CSVs from the same folder (data_frames_plots/):
    trimer_SCF_aug-cc-pvdz.csv
    trimer_MP2_aug-cc-pvdz.csv
    trimer_CCSD_T_aug-cc-pvdz.csv

Five plot modes (--plot flag):

    FORM(I) — interaction-order decomposition (line plots):
    1 : total BSSE vs R  [--method all overlays all methods on one axes]
    2 : total BSSE + 2b_bsse_total + 3b_bsse vs R
    3 : 2b_bsse(AB) + 2b_bsse(AC) + 2b_bsse(BC) + 3b_bsse vs R

    FORM(II) — individual basis-sharing contributions (bar charts per config):
    4 : 2b BSSE full decomposition
        [θ total, θ(AB), A/AB, B/AB,
                  θ(AC), A/AC, C/AC,
                  θ(BC), B/BC, C/BC]
        Use --abs to plot absolute values (bars grow upward).

    5 : 3b BSSE full decomposition — signed contributions as in FORM(II)
        3b_bsse (net, gray), -delta[A/B/C,ABC] (red family), +delta[AB/AC/BC,ABC] (purple family)
        No --abs needed — signs are physical.

Usage
-----
    # FORM(I) line plots
    python3 plot_trimer_bsse_vs_distance.py --plot 1
    python3 plot_trimer_bsse_vs_distance.py --plot 1 --method all
    python3 plot_trimer_bsse_vs_distance.py --plot 2 --method MP2
    python3 plot_trimer_bsse_vs_distance.py --plot 3 --method all --save

    # Control panel width for multi-panel line plots (modes 2-3)
    python3 plot_trimer_bsse_vs_distance.py --plot 2 --method all --figwidth 9 --save
    python3 plot_trimer_bsse_vs_distance.py --plot 3 --method all --figwidth 9 --save

    # FORM(II) bar charts
    python3 plot_trimer_bsse_vs_distance.py --plot 4
    python3 plot_trimer_bsse_vs_distance.py --plot 4 --abs
    python3 plot_trimer_bsse_vs_distance.py --plot 4 --method CCSD_T --abs --ncols 1 --configs_per_canvas 1 --save
    python3 plot_trimer_bsse_vs_distance.py --plot 5 --method SCF
    python3 plot_trimer_bsse_vs_distance.py --plot 5 --method all --ncols 1 --configs_per_canvas 1 --save

Flags
-----
    --plot                1-5                  plot mode (required)
    --method              SCF/MP2/CCSD_T/all   default: all
    --basis               default: aug-cc-pvdz
    --abs                 plot absolute values — bars grow upward (mode 4 only)
    --save                save figure as PNG in the same folder
    --ncols               columns in bar chart grid (modes 4-5). Default: 2
    --configs_per_canvas  max configs per figure canvas (modes 4-5).
                          Default: all configs in one figure.
                          H2O has 5 configs → --configs_per_canvas 1 gives 5 part files.
    --figwidth            width per panel in inches for multi-panel line plots (modes 2-3).
                          Default: 6. Use 9 or 10 for wider, more readable panels.

Notes
-----
    Modes 1-3 : --method all produces 3 subplots side by side (one per method)
                except mode 1 which overlays all methods on a single axes
    Modes 4-5 : --method all produces one canvas per method sequentially
                grid layout is flexible via --ncols (default 2)
    Mode 5    : --abs flag has no effect — signed contributions are physically
                meaningful and self-explanatory without taking absolute values
"""

import argparse
import math
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

here = Path(__file__).resolve().parent

# ---- color conventions ----
METHOD_COLORS = {
    'SCF'   : 'steelblue',
    'MP2'   : 'darkorange',
    'CCSD_T': 'forestgreen',
}

# Colors for FORM(I) terms
FORM1_COLORS = {
    'total_bsse': 'black',
    '2b_bsse_AB': 'steelblue',
    '2b_bsse_AC': 'darkorange',
    '2b_bsse_BC': 'forestgreen',
    '3b_bsse'   : 'crimson',
    '2b_total'  : 'royalblue',
}

# Colors for FORM(II) delta term groups
DELTA_COLORS = {
    'A_in_AB' : '#1f77b4', 'B_in_AB' : '#aec7e8',
    'A_in_AC' : '#ff7f0e', 'C_in_AC' : '#ffbb78',
    'B_in_BC' : '#2ca02c', 'C_in_BC' : '#98df8a',
    'A_in_ABC': '#d62728', 'B_in_ABC': '#ff9896', 'C_in_ABC': '#ff6961',
    'AB_in_ABC':'#9467bd', 'AC_in_ABC':'#c5b0d5', 'BC_in_ABC':'#7b4f9e',
}


def load_csv(method, basis):
    """Load CSV for a given method and basis."""
    csv_file = here / f'trimer_{method}_{basis}.csv'
    if not csv_file.exists():
        raise FileNotFoundError(f'CSV not found: {csv_file}')
    return pd.read_csv(csv_file)


def get_methods(method_arg):
    """Resolve method argument to a list."""
    if method_arg == 'all':
        return ['SCF', 'MP2', 'CCSD_T']
    return [method_arg]


def add_bsse_columns(df):
    """Add convenience columns for 2b_bsse per pair and 3b_bsse."""
    df = df.copy()
    df['2b_bsse_total'] = df['2b_bsse_AB'] + df['2b_bsse_AC'] + df['2b_bsse_BC']
    return df


def grid_shape(n_configs, ncols=2):
    """Return (nrows, ncols) for a bar chart canvas given n_configs."""
    nrows = math.ceil(n_configs / ncols)
    return nrows, ncols


# Only mode 1 supports single-axes overlay when --method all is used
OVERLAY_MODES = {1}

# =============================================================================
# Plot modes 1-3  (line plots)
# =============================================================================

def plot_mode_1(axes, df, method, label_suffix='', overlay=False):
    """Mode 1: total BSSE vs R."""
    label = f'total BSSE {label_suffix}'.strip() if label_suffix else f'total BSSE ({method})'
    axes.plot(df['distance'], df['total_bsse'],
              color=METHOD_COLORS[method],
              marker='o',
              label=label)
    axes.set_ylabel('BSSE (Hartree)')
    axes.set_title('Total BSSE vs O-O Distance')


def plot_mode_2(axes, df, method, label_suffix='', overlay=False):
    """Mode 2: total BSSE + sum(2b_bsse) + 3b_bsse vs R."""
    df = add_bsse_columns(df)
    axes.plot(df['distance'], df['total_bsse'],
              color='black',     marker='o',
              label='total BSSE')
    axes.plot(df['distance'], df['2b_bsse_total'],
              color='royalblue', marker='s', linestyle='--',
              label='2b BSSE total')
    axes.plot(df['distance'], df['3b_bsse'],
              color='crimson',   marker='^', linestyle=':',
              label='3b BSSE')
    axes.set_ylabel('BSSE (Hartree)')
    axes.set_title('BSSE Decomposition vs O-O Distance')


def plot_mode_3(axes, df, method, label_suffix='', overlay=False):
    """Mode 3: 2b_bsse per pair + 3b_bsse vs R."""
    axes.plot(df['distance'], df['2b_bsse_AB'],
              color=FORM1_COLORS['2b_bsse_AB'], marker='o',
              label='2b_bsse(AB)')
    axes.plot(df['distance'], df['2b_bsse_AC'],
              color=FORM1_COLORS['2b_bsse_AC'], marker='s',
              label='2b_bsse(AC)')
    axes.plot(df['distance'], df['2b_bsse_BC'],
              color=FORM1_COLORS['2b_bsse_BC'], marker='^',
              label='2b_bsse(BC)')
    axes.plot(df['distance'], df['3b_bsse'],
              color=FORM1_COLORS['3b_bsse'], marker='D', linestyle='--',
              label='3b_bsse')
    axes.set_ylabel('BSSE (Hartree)')
    axes.set_title('2-body and 3-body BSSE vs O-O Distance')


# Stubs — modes 4 and 5 are handled by their canvas functions
def plot_mode_4(axes, df, method, label_suffix='', overlay=False):
    pass


def plot_mode_5(axes, df, method, label_suffix='', overlay=False):
    pass


# =============================================================================
# FORM(II) bar chart mode 4
# =============================================================================

def _plot_mode_4_canvas(methods, basis, save, here, use_abs=False, ncols=2,
                        configs_per_canvas=None):
    """
    Draw the 2b BSSE bar chart canvas for mode 4.
    """
    import numpy as np

    PAIR_COLORS = {
        'AB': {'total': '#1f77b4', 'c1': '#6baed6', 'c2': '#bdd7e7'},
        'AC': {'total': '#e6550d', 'c1': '#fd8d3c', 'c2': '#fdd0a2'},
        'BC': {'total': '#31a354', 'c1': '#74c476', 'c2': '#c7e9c0'},
    }

    PAIR_KEYS = {
        'AB': ('2b_bsse_AB', 'A_in_AB', 'B_in_AB'),
        'AC': ('2b_bsse_AC', 'A_in_AC', 'C_in_AC'),
        'BC': ('2b_bsse_BC', 'B_in_BC', 'C_in_BC'),
    }

    sign    = -1 if use_abs else 1
    ylabel  = '|Energy| (Hartree)' if use_abs else 'Energy (Hartree)'
    abs_lbl = ' (absolute values)' if use_abs else ''

    for method in methods:
        df      = load_csv(method, basis)
        configs = sorted(df['config'].astype(str).unique(), key=int)
        n_total = len(configs)

        cpc     = configs_per_canvas if configs_per_canvas else n_total
        batches = [configs[i:i+cpc] for i in range(0, n_total, cpc)]

        for batch_idx, batch in enumerate(batches):
            n          = len(batch)
            nrows, _nc = grid_shape(n, ncols)
            n_axes     = nrows * _nc

            fig, axes_grid = plt.subplots(nrows, _nc,
                                          figsize=(16 * _nc, 8 * nrows))
            fig.subplots_adjust(hspace=0.80, wspace=0.4, bottom=0.15)
            axes_flat = axes_grid.flatten() if n_axes > 1 else [axes_grid]

            for idx, cfg in enumerate(batch):
                ax   = axes_flat[idx]
                row  = df[df['config'].astype(str) == cfg].iloc[0]
                dist = row['distance']

                bar_width  = 0.50
                bar_gap    = 0.40
                group_gap  = 1.00
                group_size = 3 * bar_width + 2 * bar_gap + group_gap

                x_tick_positions = []
                x_tick_labels    = []

                total_2b = sign * (row['2b_bsse_AB'] + row['2b_bsse_AC'] + row['2b_bsse_BC'])
                x_pos    = 0
                ax.bar(x_pos, total_2b, width=bar_width * 0.9,
                       color='#2d2d2d', edgecolor='gray', linewidth=0.5)
                coeff  = total_2b / 1e-4
                y_text = total_2b * 1.05
                va     = 'bottom' if use_abs else 'top'
                ax.text(x_pos, y_text, f'{coeff:.2f}',
                        ha='center', va=va, fontsize=9, color='black')
                x_tick_positions.append(x_pos)
                x_tick_labels.append('θ\ntotal')

                pair_x_offset = bar_width + group_gap

                for g_idx, (pair, (tot_key, c1_key, c2_key)) in enumerate(PAIR_KEYS.items()):
                    x_base = pair_x_offset + g_idx * group_size
                    m1, m2 = c1_key.split('_in_')
                    m3, m4 = c2_key.split('_in_')
                    short_labels = [f'θ({pair})', f'{m1}\n{m2}', f'{m3}\n{m4}']
                    vals   = [sign * row[tot_key],
                              sign * row[c1_key],
                              sign * row[c2_key]]
                    colors = [PAIR_COLORS[pair]['total'],
                              PAIR_COLORS[pair]['c1'],
                              PAIR_COLORS[pair]['c2']]

                    for b_idx, (val, color, lbl) in enumerate(zip(vals, colors, short_labels)):
                        x_pos = x_base + b_idx * (bar_width + bar_gap)
                        ax.bar(x_pos, val, width=bar_width * 0.9,
                               color=color, edgecolor='gray', linewidth=0.5)
                        coeff  = val / 1e-4
                        y_text = val * 1.05
                        va     = 'bottom' if use_abs else 'top'
                        ax.text(x_pos, y_text, f'{coeff:.2f}',
                                ha='center', va=va, fontsize=9, color='black',
                                rotation=0)
                        x_tick_positions.append(x_pos)
                        x_tick_labels.append(lbl)

                ax.set_xticks(x_tick_positions)
                ax.set_xticklabels(x_tick_labels, fontsize=9, rotation=0, ha='center')
                ax.tick_params(axis='x', pad=8)
                ax.set_title(f'cfg={cfg}  (R={dist} Å)', fontsize=11)
                ax.set_ylabel(ylabel, fontsize=10)
                ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
                ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0),
                                    useMathText=True)
                ax.grid(True, axis='y', linestyle='--', alpha=0.4)
                ax.margins(y=0.20)

            for i in range(n, n_axes):
                axes_flat[i].set_visible(False)

            fig.suptitle(
                f'H₂O Trimer — 2b BSSE and Monomer-in-Dimer Contributions{abs_lbl}\n'
                f'{method} / {basis}',
                fontsize=16
            )

            if save:
                suffix   = f'_part{batch_idx+1}' if len(batches) > 1 else ''
                out_file = here / f'plot4_{method}_{basis}{suffix}.png'
                plt.savefig(out_file, dpi=300, bbox_inches='tight')
                print(f'Saved: {out_file}')
            else:
                plt.show()
            plt.close(fig)


# =============================================================================
# FORM(II) bar chart mode 5
# =============================================================================

def _plot_mode_5_canvas(methods, basis, save, here, use_abs=False, ncols=2,
                        configs_per_canvas=None):
    """
    Mode 5: Complete 3b BSSE decomposition — signed contributions as in FORM(II).
    """
    BAR_COLORS = {
        '3b_bsse'  : '#2d2d2d',
        'A_in_ABC' : '#d62728',
        'B_in_ABC' : '#ff9896',
        'C_in_ABC' : '#ff6961',
        'AB_in_ABC': '#9467bd',
        'AC_in_ABC': '#c5b0d5',
        'BC_in_ABC': '#7b4f9e',
    }

    FORM2_SIGNS = {
        '3b_bsse'  :  1,
        'A_in_ABC' : -1,
        'B_in_ABC' : -1,
        'C_in_ABC' : -1,
        'AB_in_ABC':  1,
        'AC_in_ABC':  1,
        'BC_in_ABC':  1,
    }

    ylabel = 'Signed contribution to BSSE (×10⁻⁴ Hartree)'

    keys   = ['3b_bsse',
              'A_in_ABC', 'B_in_ABC', 'C_in_ABC',
              'AB_in_ABC', 'AC_in_ABC', 'BC_in_ABC']
    labels = ['3b_bsse\n(total)',
              'A_in_ABC', 'B_in_ABC', 'C_in_ABC',
              'AB_in_ABC', 'AC_in_ABC', 'BC_in_ABC']

    for method in methods:
        df      = load_csv(method, basis)
        configs = sorted(df['config'].astype(str).unique(), key=int)
        n_total = len(configs)

        cpc     = configs_per_canvas if configs_per_canvas else n_total
        batches = [configs[i:i+cpc] for i in range(0, n_total, cpc)]

        for batch_idx, batch in enumerate(batches):
            n          = len(batch)
            nrows, _nc = grid_shape(n, ncols)
            n_axes     = nrows * _nc

            fig, axes_grid = plt.subplots(nrows, _nc, figsize=(7 * _nc, 6 * nrows))
            fig.subplots_adjust(hspace=0.75, wspace=0.35)
            axes_flat = axes_grid.flatten() if n_axes > 1 else [axes_grid]

            for idx, cfg in enumerate(batch):
                ax   = axes_flat[idx]
                row  = df[df['config'].astype(str) == cfg].iloc[0]
                dist = row['distance']

                bar_width = 0.20
                gap       = 0.12
                x_positions = []
                x_base = 0.0
                for i, key in enumerate(keys):
                    if i == 1:
                        x_base += gap
                    if i == 4:
                        x_base += gap
                    x_positions.append(x_base)
                    x_base += bar_width + gap * 0.5

                x_tick_positions = []
                x_tick_labels    = []

                for x_pos, key, lbl in zip(x_positions, keys, labels):
                    raw   = row[key]
                    val   = FORM2_SIGNS[key] * raw
                    color = BAR_COLORS[key]

                    ax.bar(x_pos, val, width=bar_width * 0.9,
                           color=color, edgecolor='gray', linewidth=0.5)

                    coeff  = val / 1e-4
                    y_max  = max(abs(FORM2_SIGNS[k] * row[k]) for k in keys)
                    offset = max(abs(val) * 0.05, y_max * 0.08)
                    if val >= 0:
                        y_text, va = val + offset, 'bottom'
                    else:
                        y_text, va = val - offset, 'top'

                    ax.text(x_pos, y_text, f'{coeff:.2f}',
                            ha='center', va=va, fontsize=6.5, color='black')

                    x_tick_positions.append(x_pos)
                    x_tick_labels.append(lbl)

                mid_1b  = sum(x_positions[1:4]) / 3
                mid_2b  = sum(x_positions[4:7]) / 3
                y_range = ax.get_ylim()
                y_span  = y_range[1] - y_range[0]
                pad     = y_span * 0.06

                ax.annotate('← 1b-in-3b →', xy=(mid_1b, 0),
                            xytext=(mid_1b, -pad * 1.8),
                            fontsize=7, ha='center', color='crimson',
                            xycoords='data', textcoords='data')
                ax.annotate('← 2b-in-3b →', xy=(mid_2b, 0),
                            xytext=(mid_2b, +pad),
                            fontsize=7, ha='center', color='purple',
                            xycoords='data', textcoords='data')

                ax.set_xticks(x_tick_positions)
                ax.set_xticklabels(x_tick_labels, fontsize=6, rotation=0)
                ax.tick_params(axis='x', pad=4)
                ax.set_title(f'cfg={cfg}  (R={dist} Å)', fontsize=9)
                ax.set_ylabel(ylabel, fontsize=8)
                ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
                ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0),
                                    useMathText=True)
                ax.grid(True, axis='y', linestyle='--', alpha=0.4)
                ax.margins(y=0.25)

            for i in range(n, n_axes):
                axes_flat[i].set_visible(False)

            fig.suptitle(
                f'H₂O Trimer — 3b BSSE Full Decomposition (signed contributions)\n'
                f'1b-in-3b and 2b-in-3b Terms  |  {method} / {basis}',
                fontsize=12
            )

            if save:
                suffix   = f'_part{batch_idx+1}' if len(batches) > 1 else ''
                out_file = here / f'plot5_{method}_{basis}{suffix}.png'
                plt.savefig(out_file, dpi=300, bbox_inches='tight')
                print(f'Saved: {out_file}')
            else:
                plt.show()
            plt.close(fig)


PLOT_FUNCTIONS = {
    1: plot_mode_1,
    2: plot_mode_2,
    3: plot_mode_3,
    4: plot_mode_4,
    5: plot_mode_5,
}


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Plot trimer BSSE quantities vs O-O distance for H2O.'
    )
    parser.add_argument('--plot',   type=int, required=True, choices=range(1, 6),
                        help='Plot mode 1-5')
    parser.add_argument('--method', type=str, default='all',
                        choices=['SCF', 'MP2', 'CCSD_T', 'all'],
                        help='Level of theory (default: all)')
    parser.add_argument('--basis',  type=str, default='aug-cc-pvdz',
                        help='Basis set (default: aug-cc-pvdz)')
    parser.add_argument('--abs',    action='store_true',
                        help='Plot absolute values — bars grow upward (mode 4 only)')
    parser.add_argument('--save',   action='store_true',
                        help='Save figure as PNG')
    parser.add_argument('--ncols',  type=int, default=None,
                        help='Number of columns in the subplot grid. '
                             'Modes 2-3: controls layout of method panels (default: all in one row). '
                             'Modes 4-5: controls bar chart grid (default: 2). '
                             'Use --ncols 2 for 2-col layout (2 top + 1 bottom for 3 methods).')
    parser.add_argument('--configs_per_canvas', type=int, default=None,
                        help='Max configs per figure canvas (modes 4-5). Default: all. '
                             'H2O has 5 configs → --configs_per_canvas 1 gives 5 part files.')
    parser.add_argument('--figwidth', type=float, default=6.0,
                        help='Width per panel in inches for multi-panel line plots '
                             '(modes 2-3). Default: 6. Try 9 or 10 for wider panels.')
    parser.add_argument('--hspace', type=float, default=None,
                        help='Vertical space between rows in multi-panel line plots '
                             '(modes 2-3). Default: tight_layout auto. '
                             'Try 0.5 or 0.6 when using --ncols 1.')
    args = parser.parse_args()

    methods = get_methods(args.method)

    # Modes 4 and 5 use separate bar chart canvases
    if args.plot == 4:
        ncols = args.ncols if args.ncols is not None else 2
        _plot_mode_4_canvas(methods, args.basis, args.save, here,
                            use_abs=args.abs, ncols=ncols,
                            configs_per_canvas=args.configs_per_canvas)
        return
    if args.plot == 5:
        ncols = args.ncols if args.ncols is not None else 2
        _plot_mode_5_canvas(methods, args.basis, args.save, here,
                            use_abs=False, ncols=ncols,
                            configs_per_canvas=args.configs_per_canvas)
        return

    plot_fn = PLOT_FUNCTIONS[args.plot]
    overlay = (args.method == 'all' and args.plot in OVERLAY_MODES)

    if overlay:
        # Mode 1 + --method all: single axes, all methods overlaid
        fig, ax = plt.subplots(1, 1, figsize=(8, 5))
        for method in methods:
            df = load_csv(method, args.basis)
            plot_fn(ax, df, method, label_suffix=f'({method})')
        ax.set_xlabel('O-O Distance (Å)')
        ax.set_title(f'{args.basis} — all methods\n{ax.get_title()}')
        ax.legend(fontsize=7)
        ax.grid(True, linestyle='--', alpha=0.4)
        ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
        ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0), useMathText=True)

    else:
        # One subplot per method — layout controlled by --ncols and --figwidth
        n_methods = len(methods)
        ncols_line = args.ncols if args.ncols is not None else n_methods
        nrows_line = math.ceil(n_methods / ncols_line)

        fig, axes_grid = plt.subplots(nrows_line, ncols_line,
                                      figsize=(args.figwidth * ncols_line,
                                               5 * nrows_line))
        if n_methods == 1:
            axes_flat = [axes_grid]
        elif nrows_line == 1:
            axes_flat = list(axes_grid)
        else:
            axes_flat = list(axes_grid.flatten())

        # Hide unused axes (e.g. 3 methods, ncols=2 → 4th cell unused)
        for i in range(n_methods, nrows_line * ncols_line):
            axes_flat[i].set_visible(False)

        for ax, method in zip(axes_flat, methods):
            df = load_csv(method, args.basis)
            plot_fn(ax, df, method)
            ax.set_xlabel('O-O Distance (Å)')
            ax.set_ylabel('BSSE (Hartree)')
            ax.set_title(f'{method} / {args.basis}\n' + ax.get_title())
            ax.legend(fontsize=8)
            ax.grid(True, linestyle='--', alpha=0.4)
            ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
            ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0),
                                useMathText=True)

    fig.suptitle(f'H₂O Trimer — Plot mode {args.plot}', fontsize=13)
    if args.hspace is not None:
        plt.subplots_adjust(hspace=args.hspace, top=0.90)
    else:
        plt.tight_layout(rect=[0, 0, 1, 0.95])

    if args.save:
        out_file = here / f'plot{args.plot}_{args.method}_{args.basis}.png'
        plt.savefig(out_file, dpi=300, bbox_inches='tight')
        print(f'Saved: {out_file}')
    else:
        plt.show()


if __name__ == '__main__':
    main()