'''
This script reads the NWChem input files copied to pymol_files_xyz/ and converts
them into clean .xyz files readable by PyMOL and other molecular visualizers.
The conversion extracts only the atomic coordinate lines, discarding all NWChem
directives (geometry, basis, task blocks). The original NWChem files are deleted
after conversion.

Output format:
    Line 1: total number of atoms
    Line 2: comment line with O-O distance
    Line 3+: element symbol and x y z coordinates
'''

# Modules
from pathlib import Path
import re

# Folder where script lives
here = Path(__file__).resolve().parent
# Base data folder: where the directory of interest lives
base_dir = here.parent
# Working directory
work_dir = base_dir/"pymol_files_xyz"

# coord pattern to extract:
coord_pattern = r"[A-Za-z]+\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+"

# Creation of pymol files
for file in work_dir.glob("*.xyz"):
    new_file = work_dir/file.name.replace("_H2O_trimer", "")
    with open(file,"r") as f:
        contents = f.readlines()
  
    coord_lines = [line for line in contents if re.match(coord_pattern,line)]

    with open(new_file, "w") as nw_f:
        number_atoms = len(coord_lines)
        distance = file.stem.split('_')[-1]
        title_section = f"pymol coord for H2O trimer with O-O distance: {distance} Angstroms"
        nw_f.write(f"{number_atoms}\n")
        nw_f.write(f"{title_section}\n")
        for line in coord_lines:
            nw_f.write(f"{line}")

# Deletion of nwchem files:
for old_file in work_dir.glob("*H2O_trimer*"):
    old_file.unlink()
    print(f"Deleted: {old_file}")
