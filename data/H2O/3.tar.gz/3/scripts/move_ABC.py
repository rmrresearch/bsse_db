'''
This script goes to each trimer folder, locates the input_E_ABC_ABC.txt file 
(which contains the full trimer geometry ABC with full basis ABC),
copies it to the pymol_files_xyz folder and renames it to:
{index}_H2O_trimer_{OO_distance}.xyz for visualization in PyMOL.
'''
from pathlib import Path 
import shutil 

# Folder to work on
here = Path(__file__).resolve().parent
data_dir = here.parent
#Destination folder
destination_path = here.parent/"pymol_files_xyz"
destination_path.mkdir(exist_ok=True)


# Loop through subfolders
n = 0 #<-- counter
for subfolder in sorted(data_dir.iterdir()):
    if subfolder.is_dir() and subfolder.name.startswith("H20_trimer"):
        distance = subfolder.name.split("_")[-1]
        #print(subfolder.name, "->", distance) 

        #File to locatation and creation of new file name with correspoding identifiers label and distance    
        source_file = subfolder / "input_E_ABC_ABC.txt"
        if source_file.exists():
            new_name = f"{n}_H2O_trimer_{distance}.xyz"
            dest_file = destination_path/new_name
            shutil.copy2(source_file, dest_file)
            n +=1
        else:
            print(f"WARNING: {source_file} not found in {subfolder.name}")
   
