from pathlib import Path


# Folders where script lives
here = Path(__file__).resolve().parent
# Base data folder: where the directory of interest lives
base_dir = here.parent
# working directory
work_dir = base_dir/"pymol_files_xyz"
# pml file name
pml_name = "load_trimers.pml"

def make_loader_pml(work_dir: str, pml_name: str):
    # This organize all files by the leading configuration number
    xyz_files = sorted(work_dir.glob("*.xyz"), key=lambda p: int(p.stem.split("_", 1)[0]))
    # This is the full path to the .pml file for pymol
    pml_path = work_dir.parent / pml_name

    with open(pml_path,"w") as f:
        # Load each xyz file as its own object
        for xyz in xyz_files:
            obj_name = xyz.stem
            rel_path = xyz.relative_to(work_dir.parent)  # so the pml works from ROOT
            f.write(f"load {rel_path}, {obj_name}\n")

        # Apply ball-and-stick to everything after loading
        f.write("preset.ball_and_stick(selection='all', mode=1)\n")
    #--
    print(f"Wrote: {pml_path}")
    print(f"Objects loaded: {len(xyz_files)}")

#-----
make_loader_pml(work_dir, pml_name)
