# tar_cluster.py
import tarfile
from pathlib import Path

here     = Path(__file__).resolve().parent   # bsse_db/data/H2O/3/scripts/
base_dir = here.parent                        # bsse_db/data/H2O/3/
molecule_dir = base_dir.parent               # bsse_db/data/H2O/

cluster_name = base_dir.name                 # "3"
tarball_path = molecule_dir / f"{cluster_name}.tar.gz"

print(f"Creating {tarball_path} ...")

with tarfile.open(tarball_path, "w:gz") as tar:
    tar.add(base_dir, arcname=cluster_name)

print(f"Done. Tarball size: {tarball_path.stat().st_size / 1e6:.2f} MB")
print(f"Original folder preserved at: {base_dir}")