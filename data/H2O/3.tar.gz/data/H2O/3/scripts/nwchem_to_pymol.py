import re
from pathlib import Path

# Pattern to recognize in the nwchem input files
coord_pattern = r"[A-Za-z]+\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+"

#Folder to work on
here = Path(__file__).parent
data_dir = here.parent/"pymol_files_xyz"
# Destination Folder
destination_path = here/"pymol_files_xyz"
destination_path.mkdir(exist_ok=True)