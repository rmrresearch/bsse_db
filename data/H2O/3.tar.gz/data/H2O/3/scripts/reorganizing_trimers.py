from pathlib import Path

# Folder where script live
here = Path(__file__).resolve().parent
# Where folders to work on live
base_dir = here.parent


trimer_folder = [f for f in base_dir.iterdir() if f.is_dir() and f.name.startswith("H20_trimer")]

for n, subfolder in enumerate(sorted(trimer_folder, key=lambda p: float(p.name.split("_")[-1]))):
    distance = subfolder.name.split("_")[-1]
    new_folder = f"{n}_{distance}/CCSD_T/aug-cc-pvdz"
    dest_dir = base_dir/new_folder
    dest_dir.mkdir(parents=True, exist_ok=True)

