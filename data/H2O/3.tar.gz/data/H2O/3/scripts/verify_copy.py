from pathlib import Path
import filecmp

# Folder where script lives
here     = Path(__file__).resolve().parent
# Where folders to work on live
base_dir = here.parent

trimer_folder = [f for f in base_dir.iterdir() if f.is_dir() and f.name.startswith("H20_trimer")]

for n, subfolder in enumerate(sorted(trimer_folder, key=lambda p: float(p.name.split("_")[-1]))):
    distance = subfolder.name.split("_")[-1]
    dest_dir = base_dir / f"{n}_{distance}/CCSD_T/aug-cc-pvdz"
    print(f"\nChecking {subfolder.name} -> {n}_{distance}/CCSD_T/aug-cc-pvdz/")

    for file in subfolder.iterdir():
        if file.is_file():
            if file.name.startswith("input_E"):
                stem = file.name.removeprefix("input_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name = "_".join(name_parts) + ".nw"
            elif file.name.startswith("output_E"):
                stem = file.name.removeprefix("output_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name = "_".join(name_parts) + ".out"

            copied_file = dest_dir / new_name
            if filecmp.cmp(file, copied_file, shallow=False):
                print(f"  OK: {file.name} == {new_name}")
            else:
                print(f"  MISMATCH: {file.name} != {new_name}")