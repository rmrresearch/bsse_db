from pathlib import Path
import shutil

# Folder where script live
here = Path(__file__).resolve().parent
# Where folders to work on live
base_dir = here.parent


trimer_folder = [f for f in base_dir.iterdir() if f.is_dir() and f.name.startswith("H20_trimer")]

for n, subfolder in enumerate(sorted(trimer_folder, key=lambda p: float(p.name.split("_")[-1]))):
    distance = subfolder.name.split("_")[-1]
    new_folder = f"{n}_{distance}/CCSD_T/aug-cc-pvdz"
    dest_dir = base_dir/new_folder
    for file in subfolder.iterdir():
        if file.is_file():
            if file.name.startswith("input_E"):
                #input file new name with format melcule_base
                stem = file.name.removeprefix("input_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name = "_".join(name_parts) + ".nw"
                shutil.copy2(file, dest_dir / new_name)
            elif file.name.startswith("output_E"):
                #output file new name with format melcule_base
                stem = file.name.removeprefix("output_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name = "_".join(name_parts) + ".out"
                shutil.copy2(file, dest_dir / new_name)
