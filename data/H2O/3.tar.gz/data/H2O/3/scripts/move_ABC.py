from pathlib import Path 
import shutil 

# Folder to work on
here = Path(__file__).resolve().parent
data_dir = here.parent
#Destination folder
destination_path = here.parent/"pymol_files_xyz"
destination_path.mkdir(exist_ok=True)


# Loop through subfolders
n = 0 #<-- counter
for n, subfolder in enumerate(sorted(data_dir.iterdir())):
    if subfolder.is_dir() and subfolder.name.startswith("H20_trimer"):
        distance = subfolder.name.split("_")[-1]
        #print(subfolder.name, "->", distance) 

        #File to locatation and creation of new file name with correspoding identifiers label and distance    
        source_file = subfolder / "input_E_ABC_ABC.txt"
        if source_file.exists():
            new_name = f"{n}_H2O_trimer_{distance}.xyz"
            dest_file = destination_path/new_name
            shutil.copy2(source_file, dest_file)
            n +=1
        else:
            print(f"WARNING: {source_file} not found in {subfolder.name}")
   
'''
Let's break it down piece by piece:

- `data_dir.iterdir()` — yields everything inside `3/`, files and folders alike
- `sorted()` — makes sure we go through them in order (2.75, 3.0, 3.25...)
- `subfolder.is_dir()` — filters out any loose files
- `subfolder.name.startswith("H20_trimer")` — makes sure we skip `pymol_files_xyz` or anything else that isn't a trimer folder
- `subfolder.name.split("_")[-1]` — splits `"H20_trimer_2.75"` into `["H20", "trimer", "2.75"]` and grabs the last element

Run it and you should see something like:

H20_trimer_2.75 -> 2.75
H20_trimer_3.0 -> 3.0
'''