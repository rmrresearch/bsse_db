# H2O_trimer_I.pml — H2O Trimer | O-O distances | Config 0 (R = 2.75 Å)
# Representative geometry: equilateral triangle, all O-O = 2.75 Å
# Atom order (from 0_2.75.xyz): O_A=1, H_A1=2, H_A2=3, O_B=4, H_B1=5, H_B2=6,
#                                O_C=7, H_C1=8, H_C2=9

load pymol_files_xyz/0_2.75.xyz, H2O_trimer
preset.ball_and_stick(selection='all', mode=1)

# White background
bg_color white

# Hide hydrogens
hide everything, name H

# O-O connectivity — all three pairs of the equilateral triangle
distance OO_AB, index 1, index 4
distance OO_AC, index 1, index 7
distance OO_BC, index 4, index 7

# Black dashes — visible on white background
color black, OO_AB
color black, OO_AC
color black, OO_BC

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
set label_distance_digits, 2

# A/B/C atom label style — set global white first (labels sit on red O spheres)
set label_size, 24
set label_color, white
set label_font_id, 5

# Labels on oxygen atoms — A, B, C
label index 1, "A"
label index 4, "B"
label index 7, "C"

# Distance labels — black and sized (must come AFTER global label_color, white)
set label_color, black, OO_AB
set label_color, black, OO_AC
set label_color, black, OO_BC
set label_size, 16, OO_AB
set label_size, 16, OO_AC
set label_size, 16, OO_BC

# Center and fit — no orient needed, atoms already in z=0 plane
zoom all, 0.5

# Render
set ray_opaque_background, 1
png H2O_trimer_I.png, width=800, height=800, dpi=300, ray=1
