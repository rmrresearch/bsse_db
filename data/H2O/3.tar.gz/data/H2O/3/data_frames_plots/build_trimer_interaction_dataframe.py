"""
build_trimer_interaction_dataframe.py
======================================
Builds a CSV for the PI's analysis: does BSSE scale with interaction energy
regardless of orientation?

Reads:
    data/raw_data_H2O_3.pickle                ← for interaction energies in trimer basis
    data/many_body_interactions_H2O_3.pickle  ← for BSSE delta terms
    data/raw_data_H2O_3.pickle                ← for geometry parameters

Writes:
    data/H2O/3/data_frames_plots/trimer_bsse_vs_interaction_{method}_{basis}.csv

CSV format (long format — 6 rows per config/method/basis):
    config        : configuration index (0-4)
    distance      : O-O distance in Angstroms
    method        : SCF, MP2, CCSD_T
    basis         : aug-cc-pvdz
    pair          : AB, AC, BC
    basis_context : own   → pair evaluated in its own dimer basis
                    trimer → pair evaluated in the full trimer basis
    theta         : BSSE of pair in given basis context (Hartree)
    delta_E       : interaction energy of pair in given basis context (Hartree)

Definitions
-----------
Own basis:
    Θ_AB(AB)   = EA(AB) + EB(AB) − EA(A) − EB(B)    = 2b_bsse(AB)
    ΔE_AB(AB)  = EAB(AB) − EA(AB) − EB(AB)           = 2b_vmfc(AB)

Trimer basis:
    Θ_AB(ABC)  = EA(ABC) + EB(ABC) − EA(A) − EB(B)
               = δ[A,ABC] + δ[B,ABC]
    ΔE_AB(ABC) = EAB(ABC) − EA(ABC) − EB(ABC)         ← computed from raw_data

Same pattern for AC and BC pairs.

The PI's hypothesis: if BSSE scales purely with interaction strength
(not orientation), all 6 points per config should fall on the same line
when plotting Θ vs ΔE.
"""

# ---- path setup ----
import sys
from pathlib import Path

here     = Path(__file__).resolve().parent          # data_frames_plots/
data_dir = here.parent.parent.parent                # data/
sys.path.insert(0, str(data_dir))

# ---- imports ----
from open_pickle_data import open_pickle
from three_body_bsse import threebody_bsse

import pandas as pd


def get_energy(raw_data, molecule, cluster, config, method, basis, file_key):
    """
    Reconstruct total energy from stored components.
    Mirrors get_total_energy() from many_body_interactions_3.py.
    """
    cfg = raw_data[molecule][cluster][config]
    e_scf = cfg['SCF'][basis][file_key]
    if method == 'SCF':
        return e_scf
    e_mp2 = e_scf + cfg['MP2'][basis][file_key]
    if method == 'MP2':
        return e_mp2
    return e_mp2 + cfg['CCSD_T'][basis][file_key]


def main():
    molecule = 'H2O'
    cluster  = '3'

    # ---- pickle files ----
    many_body_pickle = data_dir / f'many_body_interactions_{molecule}_{cluster}.pickle'
    raw_pickle       = data_dir / f'raw_data_{molecule}_{cluster}.pickle'

    # ---- load data ----
    three_b_bsse = threebody_bsse(many_body_pickle, molecule)
    raw_stored   = open_pickle(raw_pickle)
    raw_data     = raw_stored['raw_data']
    parameters   = raw_stored['parameters']

    # ---- shorthands ----
    trimer_bsse = three_b_bsse[molecule][cluster]
    trimer_pars = parameters[molecule][cluster]

    # ---- discover methods and basis dynamically ----
    first_cfg  = next(iter(trimer_bsse))
    methods    = list(trimer_bsse[first_cfg].keys())
    basis      = list(trimer_bsse[first_cfg][methods[0]].keys())[0]

    # ---- build one CSV per method ----
    for method in methods:
        rows = []

        for cfg in sorted(trimer_bsse.keys(), key=int):
            dist   = trimer_pars[cfg]['params']['distance']
            e      = trimer_bsse[cfg][method][basis]
            deltas = e['delta_terms']

            def E(file_key):
                return get_energy(raw_data, molecule, cluster,
                                  cfg, method, basis, file_key)

            # ----------------------------------------------------------
            # OWN BASIS quantities (already in trimer_bsse)
            # Θ_IJ(IJ)  = 2b_bsse(IJ)   = no_vmfc − vmfc ... actually
            # Θ_IJ(IJ)  = EA(IJ)+EB(IJ) − EA(A)−EB(B)
            #            = δ[A,IJ] + δ[B,IJ]   (from delta_terms, 1b-in-2b group)
            # ΔE_IJ(IJ) = 2b_vmfc(IJ)
            # ----------------------------------------------------------
            for pair, theta_key1, theta_key2, vmfc_key in [
                ('AB', 'A_in_AB', 'B_in_AB', 'AB'),
                ('AC', 'A_in_AC', 'C_in_AC', 'AC'),
                ('BC', 'B_in_BC', 'C_in_BC', 'BC'),
            ]:
                theta_own   = deltas[theta_key1] + deltas[theta_key2]
                delta_E_own = e['2b'][pair]['vmfc']

                rows.append({
                    'config'       : cfg,
                    'distance'     : dist,
                    'method'       : method,
                    'basis'        : basis,
                    'pair'         : pair,
                    'basis_context': 'own',
                    'theta'        : theta_own,
                    'delta_E'      : delta_E_own,
                })

            # ----------------------------------------------------------
            # TRIMER BASIS quantities
            # Θ_IJ(ABC)  = δ[I,ABC] + δ[J,ABC]   (from delta_terms, 1b-in-3b group)
            # ΔE_IJ(ABC) = E_IJ(ABC) − EI(ABC) − EJ(ABC)   computed from raw_data
            # ----------------------------------------------------------
            theta_AB_abc   = deltas['A_in_ABC'] + deltas['B_in_ABC']
            theta_AC_abc   = deltas['A_in_ABC'] + deltas['C_in_ABC']
            theta_BC_abc   = deltas['B_in_ABC'] + deltas['C_in_ABC']

            delta_E_AB_abc = E('AB_ABC') - E('A_ABC') - E('B_ABC')
            delta_E_AC_abc = E('AC_ABC') - E('A_ABC') - E('C_ABC')
            delta_E_BC_abc = E('BC_ABC') - E('B_ABC') - E('C_ABC')

            for pair, theta_abc, delta_E_abc in [
                ('AB', theta_AB_abc, delta_E_AB_abc),
                ('AC', theta_AC_abc, delta_E_AC_abc),
                ('BC', theta_BC_abc, delta_E_BC_abc),
            ]:
                rows.append({
                    'config'       : cfg,
                    'distance'     : dist,
                    'method'       : method,
                    'basis'        : basis,
                    'pair'         : pair,
                    'basis_context': 'trimer',
                    'theta'        : theta_abc,
                    'delta_E'      : delta_E_abc,
                })

        df       = pd.DataFrame(rows)
        out_file = here / f'trimer_bsse_vs_interaction_{method}_{basis}.csv'
        df.to_csv(out_file, index=False)
        print(f'{method}  {df.shape}  saved to: {out_file}')


if __name__ == '__main__':
    main()