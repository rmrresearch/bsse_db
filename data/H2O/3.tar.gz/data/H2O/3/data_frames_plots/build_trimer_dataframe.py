"""
build_trimer_dataframe.py
=========================
Location: bsse_db/data/{molecule}/3/data_frames_plots/

Reads three_body_bsse_{molecule}.pickle and:
  1. Always prints a compact FORM(I)/FORM(II) verification summary
     (one row per config, all configs at a glance).
  2. With --verbose: prints full per-config FORM(I) + FORM(II) tables
     (same style as build_tetramer_dataframe.py).
  3. Writes one CSV per method with INCREMENTAL correlation components.

CONVENTION (fixed):
  The pickle stores cumulative theory-level BSSE values:
      SCF    -> total SCF BSSE
      MP2    -> total MP2-level BSSE  (SCF + MP2_corr contribution)
      CCSD_T -> total CCSD(T)-level BSSE
  The CSVs store incremental components (what the PI requires):
      SCF         -> same as cumulative SCF
      MP2_comp    -> cumulative_MP2    - cumulative_SCF
      CCSD_T_comp -> cumulative_CCSD_T - cumulative_MP2
  The method column still reads 'SCF', 'MP2', 'CCSD_T'; the labels
  'MP2_comp' and 'CCSD_T_comp' are applied by the plotter.

Key difference from tetramer: trimers have a distance scan (multiple
configs). The compact table shows all configs; --verbose expands each.

Usage
-----
    python3 build_trimer_dataframe.py --mol H2O
    python3 build_trimer_dataframe.py --mol Ne
    python3 build_trimer_dataframe.py --mol HF
    python3 build_trimer_dataframe.py --mol H2O --verbose
    python3 build_trimer_dataframe.py --mol H2O --method CCSD_T --verbose

Path navigation
---------------
    here        = data/{mol}/3/data_frames_plots/
    data_dir    = data/                              (3 levels up)
    pickle_path = data/three_body_bsse_{mol}.pickle

Output CSVs (saved alongside this script)
------------------------------------------
    trimer_SCF_aug-cc-pvdz.csv
    trimer_MP2_aug-cc-pvdz.csv
    trimer_CCSD_T_aug-cc-pvdz.csv

CSV columns
-----------
FORM(I) [incremental]:
    config, distance, method, basis
    2b_no_vmfc_AB, 2b_vmfc_AB, 2b_bsse_AB
    2b_no_vmfc_AC, 2b_vmfc_AC, 2b_bsse_AC
    2b_no_vmfc_BC, 2b_vmfc_BC, 2b_bsse_BC
    3b_no_vmfc, 3b_vmfc, 3b_bsse
    total_bsse

FORM(II) delta terms [incremental]:
    A_in_AB, B_in_AB, A_in_AC, C_in_AC, B_in_BC, C_in_BC  (+)
    A_in_ABC, B_in_ABC, C_in_ABC                            (-)
    AB_in_ABC, AC_in_ABC, BC_in_ABC                         (+)
    total_bsse_form2
"""

import pickle
import argparse
from pathlib import Path
import pandas as pd

# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------
CLUSTER = "3"
BASIS   = "aug-cc-pvdz"
METHODS = ["SCF", "MP2", "CCSD_T"]
PAIRS   = ["AB", "AC", "BC"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "B_in_BC", "C_in_BC",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
]
ALL_DELTA_TERMS = DELTA_1B_IN_2B + DELTA_1B_IN_3B + DELTA_2B_IN_3B
assert len(ALL_DELTA_TERMS) == 12, \
    f"Expected 12 delta terms, got {len(ALL_DELTA_TERMS)}"

# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
SEP  = "-" * 76
SEP2 = "=" * 76
SEP3 = "·" * 76


def _match(val1, val2, tol=1e-10):
    diff = abs(val1 - val2)
    return f"{diff:.2e}  {'✅' if diff < tol else '⚠️  MISMATCH'}"


def _ratio(num, denom):
    """Safe ratio |num/denom| — returns '    N/A' if denom ≈ 0."""
    if abs(denom) < 1e-30:
        return "    N/A"
    return f"{abs(num / denom):>7.4f}"


# ---------------------------------------------------------------------------
# Incremental subtraction helper  ← NEW
# ---------------------------------------------------------------------------

def _subtract_entry(e_curr, e_prev):
    """
    Compute incremental BSSE entry: e_curr minus e_prev for all fields.

    Converts cumulative theory-level values from the pickle into
    incremental correlation components:
        MP2_comp    = cumulative_MP2    - cumulative_SCF
        CCSD_T_comp = cumulative_CCSD_T - cumulative_MP2

    Parameters
    ----------
    e_curr : dict   entry at the higher theory level  (e.g. MP2)
    e_prev : dict   entry at the lower theory level   (e.g. SCF)

    Returns
    -------
    dict with same structure as e_curr, all values replaced by differences.
    """
    inc = {}

    # 2b per pair: no_vmfc, vmfc, bsse
    inc['2b'] = {}
    for pair in PAIRS:
        inc['2b'][pair] = {
            'no_vmfc': e_curr['2b'][pair]['no_vmfc'] - e_prev['2b'][pair]['no_vmfc'],
            'vmfc':    e_curr['2b'][pair]['vmfc']    - e_prev['2b'][pair]['vmfc'],
            'bsse':    e_curr['2b'][pair]['bsse']    - e_prev['2b'][pair]['bsse'],
        }

    # 3b: no_vmfc, vmfc, bsse
    inc['3b'] = {
        'no_vmfc': e_curr['3b']['no_vmfc'] - e_prev['3b']['no_vmfc'],
        'vmfc':    e_curr['3b']['vmfc']    - e_prev['3b']['vmfc'],
        'bsse':    e_curr['3b']['bsse']    - e_prev['3b']['bsse'],
    }

    # total_bsse
    inc['total_bsse'] = e_curr['total_bsse'] - e_prev['total_bsse']

    # delta_terms — all 12 keys
    inc['delta_terms'] = {
        key: e_curr['delta_terms'][key] - e_prev['delta_terms'][key]
        for key in e_curr['delta_terms']
    }

    # total_bsse_form2
    inc['total_bsse_form2'] = e_curr['total_bsse_form2'] - e_prev['total_bsse_form2']

    return inc


# ---------------------------------------------------------------------------
# Compact summary (always printed) — one row per config
# NOTE: reads from pickle directly → shows CUMULATIVE values for
#       FORM(I)/FORM(II) verification. Not affected by the CSV convention.
# ---------------------------------------------------------------------------

def print_compact_summary(bsse_data, molecule, method):
    """
    One-line-per-config table showing Σ2b, 3b, total and |FI-FII| check.
    Printed for every method in the default (non-verbose) run.
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)

    print(f"\n{SEP2}")
    print(f"  BSSE Analysis — {molecule} Trimer  |  {BASIS}  |  {method}  [cumulative, from pickle]")
    print(SEP2)
    print(f"  {'Config':>6}  {'Σ 2b_bsse (Ha)':>18}  {'3b_bsse (Ha)':>16}"
          f"  {'total (Ha)':>16}  {'|FI−FII|':>12}")
    print(SEP)

    for cfg in configs:
        e      = trimer_bsse[cfg][method][BASIS]
        sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
        b3     = e['3b']['bsse']
        total  = e['total_bsse']
        form2  = e['total_bsse_form2']
        diff   = abs(total - form2)
        flag   = "✅" if diff < 1e-10 else "⚠️"
        print(f"  {cfg:>6}  {sum_2b:>+18.6e}  {b3:>+16.6e}"
              f"  {total:>+16.6e}  {diff:.2e} {flag}")

    print(SEP2)


# ---------------------------------------------------------------------------
# Incremental summary (always printed) — one row per config per component
# ---------------------------------------------------------------------------

def print_incremental_summary(bsse_data, molecule):
    """
    Print incremental correlation components for all configs and all methods.
    One block per method showing SCF | MP2_comp | CCSD_T_comp per config.
    These are the values written to the CSVs.
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)

    print(f"\n{SEP2}")
    print(f"  Incremental Components — {molecule} Trimer  |  {BASIS}  [written to CSVs]")
    print(SEP2)
    print(f"  {'Config':>6}  {'Method':>10}  {'Σ 2b_bsse (Ha)':>18}  "
          f"{'3b_bsse (Ha)':>16}  {'total_bsse (Ha)':>18}  {'|FI−FII|':>12}")
    print(SEP)

    method_labels = {'SCF': 'SCF', 'MP2': 'MP2_comp', 'CCSD_T': 'CCSD_T_comp'}

    for cfg in configs:
        e_scf = trimer_bsse[cfg]['SCF'][BASIS]
        e_mp2 = trimer_bsse[cfg]['MP2'][BASIS]
        e_cct = trimer_bsse[cfg]['CCSD_T'][BASIS]

        incremental_cfg = {
            'SCF':    e_scf,
            'MP2':    _subtract_entry(e_mp2, e_scf),
            'CCSD_T': _subtract_entry(e_cct, e_mp2),
        }

        for method in METHODS:
            e      = incremental_cfg[method]
            sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
            b3     = e['3b']['bsse']
            total  = e['total_bsse']
            form2  = e['total_bsse_form2']
            diff   = abs(total - form2)
            flag   = "✅" if diff < 1e-10 else "⚠️"
            label  = method_labels[method]
            print(f"  {cfg:>6}  {label:>10}  {sum_2b:>+18.6e}  "
                  f"{b3:>+16.6e}  {total:>+18.6e}  {diff:.2e} {flag}")
        print(SEP)

    print(SEP2)


# ---------------------------------------------------------------------------
# Verbose: FORM(I) table for one config
# ---------------------------------------------------------------------------

def print_form1_table(e, method, cfg):
    """Print FORM(I) table for a single config. Returns (sum_2b, b3, total)."""
    print(f"\n  ── TABLE 1: FORM(I)  |  {method}  |  config {cfg} ──")
    print(SEP)
    print(f"  {'Term':<18}  {'no_vmfc (Ha)':>16}  {'vmfc (Ha)':>16}  {'bsse (Ha)':>16}")
    print(SEP)

    # 2b
    sum_2b = 0.0
    for pair in PAIRS:
        nv = e['2b'][pair]['no_vmfc']
        v  = e['2b'][pair]['vmfc']
        b  = e['2b'][pair]['bsse']
        sum_2b += b
        print(f"  2b_{pair:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 2b':<18}  {'':>16}  {'':>16}  {sum_2b:>+16.6e}")
    print(SEP)

    # 3b
    nv = e['3b']['no_vmfc']
    v  = e['3b']['vmfc']
    b3 = e['3b']['bsse']
    print(f"  {'3b':<18}  {nv:>+16.6e}  {v:>+16.6e}  {b3:>+16.6e}")
    print(SEP)

    # Total
    total = e['total_bsse']
    print(f"  {'total_bsse':<18}  {'':>16}  {'':>16}  {total:>+16.6e}")
    print(SEP)

    return sum_2b, b3, total


# ---------------------------------------------------------------------------
# Verbose: FORM(II) table for one config
# ---------------------------------------------------------------------------

def print_form2_table(e, method, cfg, sum_2b_f1, b3_f1, total_f1):
    """Print FORM(II) delta-group table for a single config."""
    deltas = e['delta_terms']

    print(f"\n  ── TABLE 2: FORM(II)  |  {method}  |  config {cfg} ──")

    # ------------------------------------------------------------------
    # 2b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 2b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-2b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_2b = 0.0
    for key in DELTA_1B_IN_2B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_2b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-2b':<20}  {'':>16}  {sum_1b_in_2b:>+16.6e}")
    print(f"    {'Σ 2b  [FORM I]':<20}  {'':>16}  {sum_2b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(sum_1b_in_2b, sum_2b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 3b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 3b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-3b  (sign −)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_3b = 0.0
    for key in DELTA_1B_IN_3B:
        raw    = deltas[key]
        signed = -raw
        sum_1b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-3b':<20}  {'':>16}  {sum_1b_in_3b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-3b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_3b = 0.0
    for key in DELTA_2B_IN_3B:
        raw    = deltas[key]
        signed = +raw
        sum_2b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-3b':<20}  {'':>16}  {sum_2b_in_3b:>+16.6e}")
    print(SEP3)

    net_3b = sum_1b_in_3b + sum_2b_in_3b
    print(f"\n    {'net 3b (FORM II)':<20}  {'':>16}  {net_3b:>+16.6e}")
    print(f"    {'3b  [FORM I]':<20}  {'':>16}  {b3_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_3b, b3_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # Grand total comparison
    # ------------------------------------------------------------------
    form2_total = e['total_bsse_form2']
    diff        = abs(form2_total - total_f1)
    print(f"\n  {'─ Grand Total ─':^72}")
    print(SEP)
    print(f"  {'total (FORM I)':<22}  {total_f1:>+16.6e}")
    print(f"  {'total (FORM II)':<22}  {form2_total:>+16.6e}")
    print(f"  {'|FORM I - FORM II|':<22}  {diff:.2e}  "
          f"{'✅' if diff < 1e-10 else '⚠️  MISMATCH'}")
    print(SEP)


# ---------------------------------------------------------------------------
# CSV builder  ← FIXED: writes incremental components, not cumulative totals
# ---------------------------------------------------------------------------

def build_csvs(bsse_data, molecule, out_dir, parameters=None):
    """
    Write one CSV per method with INCREMENTAL correlation components.

    The pickle stores cumulative theory-level BSSE values built using
    get_total_energy() which reconstructs: MP2 = SCF + MP2_corr,
    CCSD_T = SCF + MP2_corr + CCSD_T_comp.

    This function subtracts consecutive levels before writing:
        SCF         -> unchanged  (SCF BSSE component)
        MP2_comp    -> cumulative_MP2    - cumulative_SCF
        CCSD_T_comp -> cumulative_CCSD_T - cumulative_MP2

    Consistent with: dimer pipeline (reads raw_data directly at each
    method key, which stores incremental components per PI task list §3)
    and build_decamer_dataframe.py (subtracts explicitly).
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)

    # Pre-compute incremental entries for all configs
    incremental = {}
    for cfg in configs:
        e_scf = trimer_bsse[cfg]['SCF'][BASIS]
        e_mp2 = trimer_bsse[cfg]['MP2'][BASIS]
        e_cct = trimer_bsse[cfg]['CCSD_T'][BASIS]
        incremental[cfg] = {
            'SCF':    e_scf,                          # SCF: same as cumulative
            'MP2':    _subtract_entry(e_mp2, e_scf),  # MP2 correlation component
            'CCSD_T': _subtract_entry(e_cct, e_mp2),  # CCSD_T component
        }

    print(f"\nWriting CSVs to: {out_dir}  [INCREMENTAL components]")
    for method in METHODS:
        rows = []
        for cfg in configs:
            e = incremental[cfg][method]

            # Try to get distance from parameters dict if provided
            distance = None
            if parameters is not None:
                try:
                    distance = parameters[molecule][CLUSTER][cfg]['params']['distance']
                except (KeyError, TypeError):
                    pass
            if distance is None:
                distance = float('nan')

            row = {
                'config'          : cfg,
                'distance'        : distance,
                'method'          : method,
                'basis'           : BASIS,

                # FORM(I) — two-body per pair (incremental)
                '2b_no_vmfc_AB'   : e['2b']['AB']['no_vmfc'],
                '2b_vmfc_AB'      : e['2b']['AB']['vmfc'],
                '2b_bsse_AB'      : e['2b']['AB']['bsse'],
                '2b_no_vmfc_AC'   : e['2b']['AC']['no_vmfc'],
                '2b_vmfc_AC'      : e['2b']['AC']['vmfc'],
                '2b_bsse_AC'      : e['2b']['AC']['bsse'],
                '2b_no_vmfc_BC'   : e['2b']['BC']['no_vmfc'],
                '2b_vmfc_BC'      : e['2b']['BC']['vmfc'],
                '2b_bsse_BC'      : e['2b']['BC']['bsse'],

                # FORM(I) — three-body (incremental)
                '3b_no_vmfc'      : e['3b']['no_vmfc'],
                '3b_vmfc'         : e['3b']['vmfc'],
                '3b_bsse'         : e['3b']['bsse'],

                # FORM(I) — total BSSE (incremental)
                'total_bsse'      : e['total_bsse'],

                # FORM(II) — 12 individual delta terms (incremental)
                'A_in_AB'         : e['delta_terms']['A_in_AB'],
                'B_in_AB'         : e['delta_terms']['B_in_AB'],
                'A_in_AC'         : e['delta_terms']['A_in_AC'],
                'C_in_AC'         : e['delta_terms']['C_in_AC'],
                'B_in_BC'         : e['delta_terms']['B_in_BC'],
                'C_in_BC'         : e['delta_terms']['C_in_BC'],
                'A_in_ABC'        : e['delta_terms']['A_in_ABC'],
                'B_in_ABC'        : e['delta_terms']['B_in_ABC'],
                'C_in_ABC'        : e['delta_terms']['C_in_ABC'],
                'AB_in_ABC'       : e['delta_terms']['AB_in_ABC'],
                'AC_in_ABC'       : e['delta_terms']['AC_in_ABC'],
                'BC_in_ABC'       : e['delta_terms']['BC_in_ABC'],

                # FORM(II) — total incremental (equals incremental total_bsse)
                'total_bsse_form2': e['total_bsse_form2'],
            }
            rows.append(row)

        df       = pd.DataFrame(rows)
        out_file = out_dir / f'trimer_{method}_{BASIS}.csv'
        df.to_csv(out_file, index=False)
        print(f"  Wrote: {out_file.name}  ({len(df.columns)} columns, "
              f"{len(df)} rows)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Build trimer BSSE dataframes with FORM(I)/FORM(II) tables"
    )
    parser.add_argument(
        "--mol", required=True, choices=["H2O", "Ne", "HF"],
        help="Molecule: H2O, Ne, or HF"
    )
    parser.add_argument(
        "--method", default="all", choices=["SCF", "MP2", "CCSD_T", "all"],
        help="Method to display in verbose mode (default: all)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Print full per-config FORM(I) + FORM(II) tables"
    )
    args = parser.parse_args()

    mol = args.mol

    # --- paths ---
    here        = Path(__file__).resolve().parent   # mol/3/data_frames_plots/
    data_dir    = here.parent.parent.parent         # bsse_db/data/
    pickle_path = data_dir / f'three_body_bsse_{mol}.pickle'

    # --- load pickle ---
    with open(pickle_path, 'rb') as f:
        bsse_data = pickle.load(f)
    print(f"Loaded: {pickle_path.name}")

    # --- try to load parameters for distance column ---
    parameters = None
    raw_pickle = data_dir / f'raw_data_{mol}_3.pickle'
    if raw_pickle.exists():
        with open(raw_pickle, 'rb') as f:
            raw = pickle.load(f)
        parameters = raw.get('parameters', None)

    trimer_bsse = bsse_data[mol][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)
    methods     = METHODS if args.method == "all" else [args.method]

    # --- compact summary (cumulative, from pickle — FORM I/II verification) ---
    for method in METHODS:
        print_compact_summary(bsse_data, mol, method)

    # --- incremental summary (what goes into the CSVs) ---
    print_incremental_summary(bsse_data, mol)

    # --- verbose: full per-config FORM(I) + FORM(II) ---
    if args.verbose:
        print(f"\n{'#' * 76}")
        print(f"  VERBOSE OUTPUT — Full per-config tables  [cumulative, from pickle]")
        print(f"{'#' * 76}")
        for method in methods:
            for cfg in configs:
                e = trimer_bsse[cfg][method][BASIS]
                sum_2b, b3, total = print_form1_table(e, method, cfg)
                print_form2_table(e, method, cfg, sum_2b, b3, total)

    # --- write CSVs (incremental components) ---
    build_csvs(bsse_data, mol, here, parameters)

    print("\nDone ✅")


if __name__ == '__main__':
    main()