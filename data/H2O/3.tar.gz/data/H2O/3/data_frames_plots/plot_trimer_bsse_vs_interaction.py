"""
plot_trimer_bsse_vs_interaction.py
====================================
Plots BSSE (Theta) vs interaction energy (DeltaE) for each dimer pair
evaluated in two basis contexts: own dimer basis and full trimer basis.

Scientific question (PI's request):
    Does BSSE scale purely with interaction strength, regardless of orientation?
    If yes: all pairs (AB, AC, BC) fall on the same line when plotting
            Theta_IJ(X) vs DeltaE_IJ(X) for a given basis context X.
    If no:  orientation matters independently of interaction strength.

Reads CSVs from the same folder (data_frames_plots/):
    trimer_bsse_vs_interaction_SCF_aug-cc-pvdz.csv
    trimer_bsse_vs_interaction_MP2_aug-cc-pvdz.csv
    trimer_bsse_vs_interaction_CCSD_T_aug-cc-pvdz.csv

Plot layout:
    --method SCF/MP2/CCSD_T : 1 figure with 2 subplots (own | trimer basis)
    --method all            : 3 figures sequentially, one per method

Each subplot shows:
    x-axis : DeltaE_IJ(X)  — interaction energy of pair IJ in basis X (Hartree)
    y-axis : Theta_IJ(X)   — BSSE of pair IJ in basis X (Hartree)
    Points : one per configuration (5 configs × 3 pairs = 15 points per subplot)
    Color  : pair (AB=blue, AC=orange, BC=green)
    Marker : configuration index labeled on each point

If all points fall on a single line → BSSE scales with interaction energy,
orientation does not matter independently.

Usage
-----
    python3 plot_trimer_bsse_vs_interaction.py
    python3 plot_trimer_bsse_vs_interaction.py --method MP2
    python3 plot_trimer_bsse_vs_interaction.py --method all --save

Flags
-----
    --method  SCF/MP2/CCSD_T/all   default: all
    --basis   default: aug-cc-pvdz
    --save    save figure as PNG
"""

import argparse
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

here = Path(__file__).resolve().parent

# ---- color and marker conventions ----
PAIR_COLORS  = {'AB': 'steelblue', 'AC': 'darkorange', 'BC': 'forestgreen'}
CTX_MARKERS  = {'own': 'o', 'trimer': '^'}
CTX_LABELS   = {'own': 'Dimer basis', 'trimer': 'Trimer basis'}
CTX_LINESTYLE = {'own': '-', 'trimer': '--'}


def load_csv(method, basis):
    csv_file = here / f'trimer_bsse_vs_interaction_{method}_{basis}.csv'
    if not csv_file.exists():
        raise FileNotFoundError(f'CSV not found: {csv_file}')
    return pd.read_csv(csv_file)


def get_methods(method_arg):
    if method_arg == 'all':
        return ['SCF', 'MP2', 'CCSD_T']
    return [method_arg]


def plot_one_context(ax, df, context, title_suffix=''):
    """
    Plot Theta vs DeltaE for one basis context (dimer or trimer).
    Points for the same PAIR are connected across configurations (distance trend).
    No fitting.
    """
    sub = df[df['basis_context'] == context].copy()

    for pair, color in PAIR_COLORS.items():
        pair_data = sub[sub['pair'] == pair].sort_values('distance')

        # Connect same-pair points across distances
        ax.plot(pair_data['delta_E'].abs(), pair_data['theta'].abs(),
                color=color, linestyle='-',
                linewidth=1.0, alpha=0.5)

        # Plot each point
        ax.scatter(pair_data['delta_E'].abs(), pair_data['theta'].abs(),
                   color=color,
                   marker=CTX_MARKERS[context],
                   s=70, zorder=5, label=f'pair {pair}')

        # Label with config index
        for _, row in pair_data.iterrows():
            ax.annotate(f"  {row['config']}", (abs(row['delta_E']), abs(row['theta'])),
                        fontsize=7, color=color, va='center')

    ax.set_xlabel(r'$|\Delta E_{IJ}(X)|$ (Hartree)', fontsize=12)
    ax.set_ylabel(r'$|\Theta_{IJ}(X)|$ (Hartree)',   fontsize=12)
    ax.set_title(f'{CTX_LABELS[context]}{title_suffix}', fontsize=14)
    ax.ticklabel_format(axis='both', style='sci', scilimits=(0, 0), useMathText=True)
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.axhline(0, color='gray', linewidth=0.6, linestyle=':')
    ax.axvline(0, color='gray', linewidth=0.6, linestyle=':')
    ax.legend(fontsize=7, loc='best')


def main():
    parser = argparse.ArgumentParser(
        description='Plot BSSE vs interaction energy for H2O trimer pairs.'
    )
    parser.add_argument('--method', type=str, default='all',
                        choices=['SCF', 'MP2', 'CCSD_T', 'all'],
                        help='Level of theory (default: all)')
    parser.add_argument('--basis', type=str, default='aug-cc-pvdz',
                        help='Basis set (default: aug-cc-pvdz)')
    parser.add_argument('--save', action='store_true',
                        help='Save figure as PNG')
    args = parser.parse_args()

    methods = get_methods(args.method)

    for method in methods:
        df = load_csv(method, args.basis)

        fig, (ax_own, ax_tri) = plt.subplots(
            1, 2, figsize=(14, 6)
        )

        plot_one_context(ax_own, df, 'own')
        plot_one_context(ax_tri, df, 'trimer')

        fig.suptitle(
            f'H₂O Trimer — BSSE vs Interaction Energy\n'
            f'{method} / {args.basis}',
            fontsize=12
        )
        plt.tight_layout(rect=[0, 0, 1, 0.95])

        if args.save:
            out_file = here / f'plot_bsse_vs_interaction_{method}_{args.basis}.png'
            plt.savefig(out_file, dpi=150, bbox_inches='tight')
            print(f'Saved: {out_file}')
        else:
            plt.show()


if __name__ == '__main__':
    main()