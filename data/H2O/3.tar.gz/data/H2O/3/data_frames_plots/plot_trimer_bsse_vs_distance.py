"""
plot_trimer_bsse_vs_distance.py
================================
Plots BSSE quantities vs intermolecular distance for H2O, HF, or Ne trimers.

Reads CSVs from the same folder (data_frames_plots/):
    trimer_SCF_aug-cc-pvdz.csv       <- SCF BSSE component
    trimer_MP2_aug-cc-pvdz.csv       <- MP2 correlation component (MP2_comp)
    trimer_CCSD_T_aug-cc-pvdz.csv    <- CCSD(T) component (CCSD(T)_comp)

CONVENTION:
    CSVs store INCREMENTAL correlation components (Hartree).
    All plotted values are converted to kcal/mol (1 Ha = 627.509474 kcal/mol).

Rendering:
    Uses TeX Live (text.usetex = True, font.family = serif, amsmath + amssymb).

Five plot modes (--plot flag):
    1 : total BSSE vs R  [--method all overlays all three on one axes]
    2 : total BSSE + 2b_bsse_total + 3b_bsse vs R
    3 : 2b_bsse(AB) + 2b_bsse(AC) + 2b_bsse(BC) + 3b_bsse vs R
    4 : 2b BSSE full FORM(II) bar chart per config
    5 : 3b BSSE full FORM(II) decomposition bar chart per config

Usage
-----
    python3 plot_trimer_bsse_vs_distance.py --mol H2O --plot 1 --method all --save
    python3 plot_trimer_bsse_vs_distance.py --mol HF  --plot 2 --method all --save
    python3 plot_trimer_bsse_vs_distance.py --mol Ne  --plot 3 --method all --save
    python3 plot_trimer_bsse_vs_distance.py --mol H2O --plot 4 --method CCSD_T --configs_per_canvas 1 --save
    python3 plot_trimer_bsse_vs_distance.py --mol Ne  --plot 5 --method all --configs_per_canvas 1 --save
"""

import argparse
import math
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
from pathlib import Path

# ---------------------------------------------------------------------------
# LaTeX rendering — consistent with dimer, tetramer, and decamer plotters
# ---------------------------------------------------------------------------
plt.rcParams.update({
    "text.usetex"        : True,
    "font.family"        : "serif",
    "text.latex.preamble": r"\usepackage{amsmath} \usepackage{amssymb}",
})

here = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# Unit conversion
# ---------------------------------------------------------------------------
KCAL = 627.509474    # Hartree -> kcal/mol

# ---------------------------------------------------------------------------
# Molecule display labels and x-axis labels
# ---------------------------------------------------------------------------
MOL_LABELS = {
    "Ne" : r"Ne",
    "HF" : r"HF",
    "H2O": r"H$_2$O",
}

MOL_XLABEL = {
    "Ne" : r"Ne--Ne Distance (\AA)",
    "HF" : r"H--F Distance (\AA)",
    "H2O": r"O--O Distance (\AA)",
}


def mol_title(molecule):
    """Return LaTeX-safe molecule display string for plot titles."""
    return MOL_LABELS.get(molecule, molecule)


# ---------------------------------------------------------------------------
# Display labels — incremental components, LaTeX
# ---------------------------------------------------------------------------
METHOD_DISPLAY = {
    'SCF'   : r'SCF',
    'MP2'   : r'MP2$_\mathrm{comp}$',
    'CCSD_T': r'CCSD(T)$_\mathrm{comp}$',
}

METHOD_COLORS = {
    'SCF'   : 'steelblue',
    'MP2'   : 'darkorange',
    'CCSD_T': 'forestgreen',
}

FORM1_COLORS = {
    'total_bsse': 'black',
    '2b_bsse_AB': 'steelblue',
    '2b_bsse_AC': 'darkorange',
    '2b_bsse_BC': 'forestgreen',
    '3b_bsse'   : 'crimson',
    '2b_total'  : 'royalblue',
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def fmt_kcal(v):
    """Adaptive format for kcal/mol bar annotations (mirrors tetramer plotter)."""
    av = abs(v)
    if av == 0.0:
        return "0"
    elif av >= 0.1:
        return f"{v:.3f}"
    elif av >= 0.001:
        return f"{v:.4f}"
    else:
        return f"{v:.2e}"


def kcal_formatter():
    """ScalarFormatter for kcal/mol axes."""
    fmt = ScalarFormatter()
    fmt.set_scientific(True)
    fmt.set_powerlimits((-2, 3))
    return fmt


def load_csv(method, basis):
    csv_file = here / f'trimer_{method}_{basis}.csv'
    if not csv_file.exists():
        raise FileNotFoundError(f'CSV not found: {csv_file}')
    return pd.read_csv(csv_file)


def get_methods(method_arg):
    if method_arg == 'all':
        return ['SCF', 'MP2', 'CCSD_T']
    return [method_arg]


def add_bsse_columns(df):
    """Add 2b_bsse_total convenience column (Hartree — conversion done at plot time)."""
    df = df.copy()
    df['2b_bsse_total'] = df['2b_bsse_AB'] + df['2b_bsse_AC'] + df['2b_bsse_BC']
    return df


def grid_shape(n_configs, ncols=2):
    nrows = math.ceil(n_configs / ncols)
    return nrows, ncols


OVERLAY_MODES = {1}

# =============================================================================
# Plot modes 1-3  (line plots, all values in kcal/mol)
# =============================================================================

def plot_mode_1(axes, df, method, label_suffix='', overlay=False):
    """Mode 1: total BSSE vs R (kcal/mol)."""
    disp  = METHOD_DISPLAY[method]
    label = r'total BSSE (' + disp + r')'
    axes.plot(df['distance'], df['total_bsse'] * KCAL,
              color=METHOD_COLORS[method], marker='o', label=label)
    axes.set_ylabel(r'BSSE (kcal/mol)')
    axes.set_title(r'Total BSSE vs $R$')


def plot_mode_2(axes, df, method, label_suffix='', overlay=False):
    """Mode 2: total BSSE + sum(2b_bsse) + 3b_bsse vs R (kcal/mol)."""
    df = add_bsse_columns(df)
    axes.plot(df['distance'], df['total_bsse']    * KCAL,
              color='black',     marker='o',              label=r'total BSSE')
    axes.plot(df['distance'], df['2b_bsse_total'] * KCAL,
              color='royalblue', marker='s', linestyle='--', label=r'2b BSSE total')
    axes.plot(df['distance'], df['3b_bsse']       * KCAL,
              color='crimson',   marker='^', linestyle=':',  label=r'3b BSSE')
    axes.set_ylabel(r'BSSE (kcal/mol)')
    axes.set_title(r'BSSE Decomposition vs $R$')


def plot_mode_3(axes, df, method, label_suffix='', overlay=False):
    """Mode 3: 2b_bsse per pair + 3b_bsse vs R (kcal/mol)."""
    axes.plot(df['distance'], df['2b_bsse_AB'] * KCAL,
              color=FORM1_COLORS['2b_bsse_AB'], marker='o',
              label=r'2b\_bsse(AB)')
    axes.plot(df['distance'], df['2b_bsse_AC'] * KCAL,
              color=FORM1_COLORS['2b_bsse_AC'], marker='s',
              label=r'2b\_bsse(AC)')
    axes.plot(df['distance'], df['2b_bsse_BC'] * KCAL,
              color=FORM1_COLORS['2b_bsse_BC'], marker='^',
              label=r'2b\_bsse(BC)')
    axes.plot(df['distance'], df['3b_bsse']    * KCAL,
              color=FORM1_COLORS['3b_bsse'],    marker='D', linestyle='--',
              label=r'3b\_bsse')
    axes.set_ylabel(r'BSSE (kcal/mol)')
    axes.set_title(r'2-body and 3-body BSSE vs $R$')


def plot_mode_4(axes, df, method, label_suffix='', overlay=False):
    pass


def plot_mode_5(axes, df, method, label_suffix='', overlay=False):
    pass


# =============================================================================
# FORM(II) bar chart mode 4  (kcal/mol)
# =============================================================================

def _plot_mode_4_canvas(molecule, methods, basis, save, here,
                        use_abs=False, ncols=2, configs_per_canvas=None):
    """Mode 4: 2b BSSE and 1b-in-2b contributions (kcal/mol)."""
    PAIRS = ['AB', 'AC', 'BC']
    PAIR_COLORS = {
        'AB': {'total': '#1f77b4', 'c1': '#6baed6', 'c2': '#bdd7e7'},
        'AC': {'total': '#e6550d', 'c1': '#fd8d3c', 'c2': '#fdd0a2'},
        'BC': {'total': '#31a354', 'c1': '#74c476', 'c2': '#c7e9c0'},
    }
    PAIR_KEYS = {
        'AB': ('2b_bsse_AB', 'A_in_AB', 'B_in_AB'),
        'AC': ('2b_bsse_AC', 'A_in_AC', 'C_in_AC'),
        'BC': ('2b_bsse_BC', 'B_in_BC', 'C_in_BC'),
    }

    sign    = -1 if use_abs else 1
    ylabel  = r'$|$Energy$|$ (kcal/mol)' if use_abs else r'Energy (kcal/mol)'
    abs_lbl = r' (absolute values)' if use_abs else ''

    for method in methods:
        disp    = METHOD_DISPLAY[method]
        df      = load_csv(method, basis)
        configs = sorted(df['config'].astype(str).unique(), key=int)
        n_total = len(configs)
        cpc     = configs_per_canvas if configs_per_canvas else n_total
        batches = [configs[i:i+cpc] for i in range(0, n_total, cpc)]

        for batch_idx, batch in enumerate(batches):
            n     = len(batch)
            _nc   = min(ncols, n)   # never more columns than configs in batch
            nrows = math.ceil(n / _nc)
            n_axes = nrows * _nc

            fig, axes_grid = plt.subplots(nrows, _nc, figsize=(16 * _nc, 8 * nrows))
            fig.subplots_adjust(hspace=0.80, wspace=0.4, bottom=0.15)
            axes_flat = axes_grid.flatten() if n_axes > 1 else [axes_grid]

            for idx, cfg in enumerate(batch):
                ax   = axes_flat[idx]
                row  = df[df['config'].astype(str) == cfg].iloc[0]
                dist = row['distance']

                bar_width  = 0.50
                bar_gap    = 0.40
                group_gap  = 1.00
                group_size = 3 * bar_width + 2 * bar_gap + group_gap

                x_tick_positions = []
                x_tick_labels    = []

                total_2b = sign * (row['2b_bsse_AB'] + row['2b_bsse_AC'] + row['2b_bsse_BC']) * KCAL
                x_pos    = 0
                ax.bar(x_pos, total_2b, width=bar_width * 0.9,
                       color='#2d2d2d', edgecolor='gray', linewidth=0.5)
                y_text = total_2b * 1.05
                va     = 'bottom' if use_abs else 'top'
                ax.text(x_pos, y_text, fmt_kcal(total_2b),
                        ha='center', va=va, fontsize=9, color='black')
                x_tick_positions.append(x_pos)
                x_tick_labels.append(r'2b\_bsse' + '\ntotal')

                pair_x_offset = bar_width + group_gap
                for g_idx, (pair, (tot_key, c1_key, c2_key)) in enumerate(PAIR_KEYS.items()):
                    x_base = pair_x_offset + g_idx * group_size
                    m1, m2 = c1_key.split('_in_')
                    m3, m4 = c2_key.split('_in_')
                    short_labels = [r'2b\_bsse' + '\n(' + pair + ')',
                                    f'{m1}\n{m2}',
                                    f'{m3}\n{m4}']
                    vals   = [sign * row[tot_key] * KCAL,
                              sign * row[c1_key]  * KCAL,
                              sign * row[c2_key]  * KCAL]
                    colors = [PAIR_COLORS[pair]['total'],
                              PAIR_COLORS[pair]['c1'],
                              PAIR_COLORS[pair]['c2']]

                    for b_idx, (val, color, lbl) in enumerate(zip(vals, colors, short_labels)):
                        x_pos = x_base + b_idx * (bar_width + bar_gap)
                        ax.bar(x_pos, val, width=bar_width * 0.9,
                               color=color, edgecolor='gray', linewidth=0.5)
                        y_text = val * 1.05
                        va     = 'bottom' if use_abs else 'top'
                        ax.text(x_pos, y_text, fmt_kcal(val),
                                ha='center', va=va, fontsize=9, color='black')
                        x_tick_positions.append(x_pos)
                        x_tick_labels.append(lbl)

                ax.set_xticks(x_tick_positions)
                ax.set_xticklabels(x_tick_labels, fontsize=9, rotation=0, ha='center')
                ax.tick_params(axis='x', pad=8)
                ax.set_title(r'cfg=' + str(cfg) + r'  ($R=' + str(dist) + r'$\,\AA)', fontsize=11)
                ax.set_ylabel(ylabel, fontsize=10)
                ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
                ax.yaxis.set_major_formatter(kcal_formatter())
                ax.margins(y=0.20)

            for i in range(n, n_axes):
                axes_flat[i].set_visible(False)

            fig.suptitle(
                mol_title(molecule) + r' Trimer --- 2b BSSE and Monomer-in-Dimer Contributions'
                + abs_lbl + '\n' + disp + r' / ' + basis,
                fontsize=16
            )

            if save:
                part_suffix = f'_part{batch_idx+1}' if len(batches) > 1 else ''
                abs_suffix  = '_abs' if use_abs else ''
                out_file = here / f'plot4_{method}_{basis}{abs_suffix}{part_suffix}.png'
                plt.savefig(out_file, dpi=300, bbox_inches='tight')
                print(f'Saved: {out_file}')
            else:
                plt.show()
            plt.close(fig)


# =============================================================================
# FORM(II) bar chart mode 5  (kcal/mol)
# =============================================================================

def _plot_mode_5_canvas(molecule, methods, basis, save, here,
                        use_abs=False, ncols=2, configs_per_canvas=None):
    """Mode 5: 3b BSSE full FORM(II) decomposition — signed (kcal/mol)."""
    BAR_COLORS = {
        '3b_bsse'  : '#2d2d2d',
        'A_in_ABC' : '#d62728', 'B_in_ABC' : '#ff9896', 'C_in_ABC' : '#ff6961',
        'AB_in_ABC': '#9467bd', 'AC_in_ABC': '#c5b0d5', 'BC_in_ABC': '#7b4f9e',
    }
    FORM2_SIGNS = {
        '3b_bsse'  :  1,
        'A_in_ABC' : -1, 'B_in_ABC' : -1, 'C_in_ABC' : -1,
        'AB_in_ABC':  1, 'AC_in_ABC':  1, 'BC_in_ABC':  1,
    }

    ylabel = r'Signed contribution to BSSE (kcal/mol)'
    keys   = ['3b_bsse',
              'A_in_ABC', 'B_in_ABC', 'C_in_ABC',
              'AB_in_ABC', 'AC_in_ABC', 'BC_in_ABC']
    labels = [r'3b\_bsse' + '\n(total)',
              'A\nABC', 'B\nABC', 'C\nABC',
              'AB\nABC', 'AC\nABC', 'BC\nABC']

    for method in methods:
        disp    = METHOD_DISPLAY[method]
        df      = load_csv(method, basis)
        configs = sorted(df['config'].astype(str).unique(), key=int)
        n_total = len(configs)
        cpc     = configs_per_canvas if configs_per_canvas else n_total
        batches = [configs[i:i+cpc] for i in range(0, n_total, cpc)]

        for batch_idx, batch in enumerate(batches):
            n     = len(batch)
            _nc   = min(ncols, n)   # never more columns than configs in batch
            nrows = math.ceil(n / _nc)
            n_axes = nrows * _nc

            fig, axes_grid = plt.subplots(nrows, _nc, figsize=(7 * _nc, 6 * nrows))
            fig.subplots_adjust(hspace=0.75, wspace=0.35)
            axes_flat = axes_grid.flatten() if n_axes > 1 else [axes_grid]

            for idx, cfg in enumerate(batch):
                ax   = axes_flat[idx]
                row  = df[df['config'].astype(str) == cfg].iloc[0]
                dist = row['distance']

                bar_width = 0.20
                gap       = 0.12
                x_positions = []
                x_base = 0.0
                for i, key in enumerate(keys):
                    if i == 1: x_base += gap
                    if i == 4: x_base += gap
                    x_positions.append(x_base)
                    x_base += bar_width + gap * 0.5

                x_tick_positions = []
                x_tick_labels    = []

                for x_pos, key, lbl in zip(x_positions, keys, labels):
                    val   = FORM2_SIGNS[key] * row[key] * KCAL
                    color = BAR_COLORS[key]

                    ax.bar(x_pos, val, width=bar_width * 0.9,
                           color=color, edgecolor='gray', linewidth=0.5)

                    y_max  = max(abs(FORM2_SIGNS[k] * row[k] * KCAL) for k in keys)
                    offset = max(abs(val) * 0.05, y_max * 0.08)
                    y_text, va = (val + offset, 'bottom') if val >= 0 else (val - offset, 'top')
                    ax.text(x_pos, y_text, fmt_kcal(val),
                            ha='center', va=va, fontsize=6.5, color='black')
                    x_tick_positions.append(x_pos)
                    x_tick_labels.append(lbl)

                mid_1b = sum(x_positions[1:4]) / 3
                mid_2b = sum(x_positions[4:7]) / 3
                y_range = ax.get_ylim()
                y_span  = y_range[1] - y_range[0]
                pad     = y_span * 0.06

                ax.annotate(r'$\leftarrow$ 1b-in-3b $\rightarrow$',
                            xy=(mid_1b, 0), xytext=(mid_1b, -pad * 1.8),
                            fontsize=7, ha='center', color='crimson',
                            xycoords='data', textcoords='data')
                ax.annotate(r'$\leftarrow$ 2b-in-3b $\rightarrow$',
                            xy=(mid_2b, 0), xytext=(mid_2b, +pad),
                            fontsize=7, ha='center', color='purple',
                            xycoords='data', textcoords='data')

                ax.set_xticks(x_tick_positions)
                ax.set_xticklabels(x_tick_labels, fontsize=6, rotation=0)
                ax.tick_params(axis='x', pad=4)
                ax.set_title(r'cfg=' + str(cfg) + r'  ($R=' + str(dist) + r'$\,\AA)', fontsize=9)
                ax.set_ylabel(ylabel, fontsize=8)
                ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
                ax.yaxis.set_major_formatter(kcal_formatter())
                ax.margins(y=0.25)

            for i in range(n, n_axes):
                axes_flat[i].set_visible(False)

            fig.suptitle(
                mol_title(molecule) + r' Trimer --- 3b BSSE Full Decomposition (signed contributions)'
                + '\n' + r'1b-in-3b and 2b-in-3b Terms  |  ' + disp + r' / ' + basis,
                fontsize=12
            )

            if save:
                part_suffix = f'_part{batch_idx+1}' if len(batches) > 1 else ''
                out_file = here / f'plot5_{method}_{basis}{part_suffix}.png'
                plt.savefig(out_file, dpi=300, bbox_inches='tight')
                print(f'Saved: {out_file}')
            else:
                plt.show()
            plt.close(fig)


PLOT_FUNCTIONS = {1: plot_mode_1, 2: plot_mode_2, 3: plot_mode_3,
                  4: plot_mode_4, 5: plot_mode_5}


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Plot trimer BSSE quantities vs distance (kcal/mol). '
                    'Works for H2O, HF, and Ne trimers.'
    )
    parser.add_argument('--mol',    required=True, choices=['H2O', 'HF', 'Ne'],
                        help='Molecule: H2O, HF, or Ne')
    parser.add_argument('--plot',   type=int, required=True, choices=range(1, 6))
    parser.add_argument('--method', type=str, default='all',
                        choices=['SCF', 'MP2', 'CCSD_T', 'all'])
    parser.add_argument('--basis',  type=str, default='aug-cc-pvdz')
    parser.add_argument('--abs',    action='store_true')
    parser.add_argument('--save',   action='store_true')
    parser.add_argument('--ncols',  type=int, default=None)
    parser.add_argument('--configs_per_canvas', type=int, default=None)
    parser.add_argument('--figwidth', type=float, default=6.0)
    parser.add_argument('--hspace', type=float, default=None)
    args = parser.parse_args()

    molecule = args.mol
    methods  = get_methods(args.method)
    xlabel   = MOL_XLABEL[molecule]

    # Modes 4 and 5 use separate bar chart canvases
    if args.plot == 4:
        ncols = args.ncols if args.ncols is not None else 2
        _plot_mode_4_canvas(molecule, methods, args.basis, args.save, here,
                            use_abs=args.abs, ncols=ncols,
                            configs_per_canvas=args.configs_per_canvas)
        return
    if args.plot == 5:
        ncols = args.ncols if args.ncols is not None else 2
        _plot_mode_5_canvas(molecule, methods, args.basis, args.save, here,
                            use_abs=False, ncols=ncols,
                            configs_per_canvas=args.configs_per_canvas)
        return

    plot_fn = PLOT_FUNCTIONS[args.plot]
    overlay = (args.method == 'all' and args.plot in OVERLAY_MODES)

    if overlay:
        fig, ax = plt.subplots(1, 1, figsize=(8, 5))
        for method in methods:
            df = load_csv(method, args.basis)
            plot_fn(ax, df, method)
        ax.set_xlabel(xlabel)
        ax.set_title(
            args.basis + r' --- SCF $|$ MP2$_\mathrm{comp}$ $|$ CCSD(T)$_\mathrm{comp}$'
            + '\n' + ax.get_title()
        )
        ax.legend(fontsize=7, frameon=False)
        ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
        ax.yaxis.set_major_formatter(kcal_formatter())

    else:
        n_methods  = len(methods)
        ncols_line = args.ncols if args.ncols is not None else n_methods
        nrows_line = math.ceil(n_methods / ncols_line)

        fig, axes_grid = plt.subplots(nrows_line, ncols_line,
                                      figsize=(args.figwidth * ncols_line,
                                               5 * nrows_line))
        if n_methods == 1:
            axes_flat = [axes_grid]
        elif nrows_line == 1:
            axes_flat = list(axes_grid)
        else:
            axes_flat = list(axes_grid.flatten())

        for i in range(n_methods, nrows_line * ncols_line):
            axes_flat[i].set_visible(False)

        for ax, method in zip(axes_flat, methods):
            disp = METHOD_DISPLAY[method]
            df   = load_csv(method, args.basis)
            plot_fn(ax, df, method)
            ax.set_xlabel(xlabel)
            ax.set_ylabel(r'BSSE (kcal/mol)')
            ax.set_title(disp + r' / ' + args.basis + '\n' + ax.get_title())
            ax.legend(fontsize=8, frameon=False)
            ax.axhline(0, color='gray', linewidth=0.8, linestyle=':')
            ax.yaxis.set_major_formatter(kcal_formatter())

    fig.suptitle(mol_title(molecule) + r' Trimer --- Plot mode ' + str(args.plot),
                 fontsize=13)
    if args.hspace is not None:
        plt.subplots_adjust(hspace=args.hspace, top=0.90)
    else:
        plt.tight_layout(rect=[0, 0, 1, 0.95])

    if args.save:
        out_file = here / f'plot{args.plot}_{args.method}_{args.basis}.png'
        plt.savefig(out_file, dpi=300, bbox_inches='tight')
        print(f'Saved: {out_file}')
    else:
        plt.show()


if __name__ == '__main__':
    main()