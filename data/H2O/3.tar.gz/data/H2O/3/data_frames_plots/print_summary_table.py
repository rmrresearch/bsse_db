"""
print_summary_table.py
======================
Location: bsse_db/data/{molecule}/3/data_frames_plots/

Reads three_body_bsse_{molecule}.pickle and prints formatted terminal tables.
No files are written — use this for quick inspection and sharing with the PI.

CONVENTION:
  Cumulative tables read directly from the pickle (for FORM I/II verification).
  Incremental tables subtract consecutive levels to give correlation components:
      SCF         -> SCF BSSE component
      MP2_comp    -> cumulative_MP2    - cumulative_SCF
      CCSD_T_comp -> cumulative_CCSD_T - cumulative_MP2

Default output (--method CCSD_T, all configs)
----------------------------------------------
  1. Compact cumulative table (from pickle) — FORM I/II verification
  2. Compact incremental table — SCF | MP2_comp | CCSD_T_comp per config

With --method all
-----------------
  Both tables for each of SCF, MP2, CCSD_T in sequence (cumulative),
  then full incremental summary.

With --config <n>
-----------------
  Full FORM(I) + FORM(II) tables (cumulative) for that single config,
  followed by incremental components for that config.

With --scaling-only
-------------------
  Body-order scaling summary across all methods (mean across configs).

Usage
-----
    python3 print_summary_table.py --mol H2O
    python3 print_summary_table.py --mol Ne --method CCSD_T
    python3 print_summary_table.py --mol HF --method all
    python3 print_summary_table.py --mol H2O --config 0
    python3 print_summary_table.py --mol Ne --scaling-only
    python3 print_summary_table.py --mol HF --method MP2 --config 3
"""

import pickle
import argparse
from pathlib import Path

# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------
CLUSTER = "3"
BASIS   = "aug-cc-pvdz"
METHODS = ["SCF", "MP2", "CCSD_T"]
PAIRS   = ["AB", "AC", "BC"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "B_in_BC", "C_in_BC",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
]

METHOD_LABELS = {
    "SCF"   : "SCF",
    "MP2"   : "MP2_comp",
    "CCSD_T": "CCSD_T_comp",
}

# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
SEP  = "-" * 76
SEP2 = "=" * 76
SEP3 = "·" * 76


def _match(val1, val2, tol=1e-10):
    diff = abs(val1 - val2)
    return f"{diff:.2e}  {'✅' if diff < tol else '⚠️  MISMATCH'}"


def _ratio(num, denom):
    """Safe ratio |num/denom| — returns '    N/A' if denom ≈ 0."""
    if abs(denom) < 1e-30:
        return "    N/A"
    return f"{abs(num / denom):>7.4f}"


# ---------------------------------------------------------------------------
# Incremental subtraction helper
# ---------------------------------------------------------------------------

def _subtract_entry(e_curr, e_prev):
    """
    Compute incremental BSSE entry: e_curr minus e_prev for all fields.

    Converts cumulative theory-level values from the pickle into
    incremental correlation components:
        MP2_comp    = cumulative_MP2    - cumulative_SCF
        CCSD_T_comp = cumulative_CCSD_T - cumulative_MP2

    Parameters
    ----------
    e_curr : dict   entry at the higher theory level  (e.g. MP2)
    e_prev : dict   entry at the lower theory level   (e.g. SCF)

    Returns
    -------
    dict with same structure as e_curr, all values replaced by differences.
    """
    inc = {}

    # 2b per pair: no_vmfc, vmfc, bsse
    inc['2b'] = {}
    for pair in PAIRS:
        inc['2b'][pair] = {
            'no_vmfc': e_curr['2b'][pair]['no_vmfc'] - e_prev['2b'][pair]['no_vmfc'],
            'vmfc':    e_curr['2b'][pair]['vmfc']    - e_prev['2b'][pair]['vmfc'],
            'bsse':    e_curr['2b'][pair]['bsse']    - e_prev['2b'][pair]['bsse'],
        }

    # 3b: no_vmfc, vmfc, bsse
    inc['3b'] = {
        'no_vmfc': e_curr['3b']['no_vmfc'] - e_prev['3b']['no_vmfc'],
        'vmfc':    e_curr['3b']['vmfc']    - e_prev['3b']['vmfc'],
        'bsse':    e_curr['3b']['bsse']    - e_prev['3b']['bsse'],
    }

    # total_bsse
    inc['total_bsse'] = e_curr['total_bsse'] - e_prev['total_bsse']

    # delta_terms — all 12 keys
    inc['delta_terms'] = {
        key: e_curr['delta_terms'][key] - e_prev['delta_terms'][key]
        for key in e_curr['delta_terms']
    }

    # total_bsse_form2
    inc['total_bsse_form2'] = e_curr['total_bsse_form2'] - e_prev['total_bsse_form2']

    return inc


def _get_incremental(bsse_data, molecule):
    """
    Build incremental dict for all configs.
    Returns: incremental[cfg]['SCF'|'MP2'|'CCSD_T'] -> entry dict
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)
    incremental = {}
    for cfg in configs:
        e_scf = trimer_bsse[cfg]['SCF'][BASIS]
        e_mp2 = trimer_bsse[cfg]['MP2'][BASIS]
        e_cct = trimer_bsse[cfg]['CCSD_T'][BASIS]
        incremental[cfg] = {
            'SCF':    e_scf,
            'MP2':    _subtract_entry(e_mp2, e_scf),
            'CCSD_T': _subtract_entry(e_cct, e_mp2),
        }
    return incremental


# ---------------------------------------------------------------------------
# Compact cumulative table — all configs for one method  (FORM I/II check)
# ---------------------------------------------------------------------------

def print_compact_table(bsse_data, molecule, method):
    """
    One line per config: Config, Σ2b, 3b, total, |3b/2b|, |FI-FII|.
    Reads cumulative values from pickle — use for FORM I/II verification.
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)

    print(f"\n{SEP2}")
    print(f"  Body-order summary — {molecule} Trimer  |  {BASIS}  |  {method}"
          f"  [cumulative, from pickle]")
    print(SEP2)
    print(f"  {'Config':>6}  {'Σ 2b_bsse (Ha)':>18}  {'3b_bsse (Ha)':>16}"
          f"  {'total (Ha)':>16}  {'|3b/2b|':>8}  {'|FI−FII|':>12}")
    print(SEP)

    for cfg in configs:
        e      = trimer_bsse[cfg][method][BASIS]
        sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
        b3     = e['3b']['bsse']
        total  = e['total_bsse']
        form2  = e['total_bsse_form2']
        diff   = abs(total - form2)
        ratio  = _ratio(b3, sum_2b)
        flag   = "✅" if diff < 1e-10 else "⚠️"
        print(f"  {cfg:>6}  {sum_2b:>+18.6e}  {b3:>+16.6e}"
              f"  {total:>+16.6e}  {ratio:>8}  {diff:.2e} {flag}")

    print(SEP2)


# ---------------------------------------------------------------------------
# Compact incremental table — all configs, all three components
# ---------------------------------------------------------------------------

def print_incremental_table(bsse_data, molecule):
    """
    One block per config showing SCF | MP2_comp | CCSD_T_comp.
    These are the incremental correlation components written to the CSVs.
    |FI-FII| is verified for the incremental values as well.
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)
    incremental = _get_incremental(bsse_data, molecule)

    print(f"\n{SEP2}")
    print(f"  Incremental Components — {molecule} Trimer  |  {BASIS}"
          f"  [written to CSVs]")
    print(SEP2)
    print(f"  {'Config':>6}  {'Component':>12}  {'Σ 2b_bsse (Ha)':>18}"
          f"  {'3b_bsse (Ha)':>16}  {'total_bsse (Ha)':>18}  {'|FI−FII|':>12}")
    print(SEP)

    for cfg in configs:
        for method in METHODS:
            e      = incremental[cfg][method]
            sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
            b3     = e['3b']['bsse']
            total  = e['total_bsse']
            form2  = e['total_bsse_form2']
            diff   = abs(total - form2)
            flag   = "✅" if diff < 1e-10 else "⚠️"
            label  = METHOD_LABELS[method]
            print(f"  {cfg:>6}  {label:>12}  {sum_2b:>+18.6e}"
                  f"  {b3:>+16.6e}  {total:>+18.6e}  {diff:.2e} {flag}")
        print(SEP)

    print(SEP2)


# ---------------------------------------------------------------------------
# Full FORM(I) table for one config  [cumulative, from pickle]
# ---------------------------------------------------------------------------

def print_form1_table(e, method, cfg):
    """Print FORM(I) table for a single config. Returns (sum_2b, b3, total)."""
    print(f"\n  ── TABLE 1: FORM(I)  |  {method}  |  config {cfg}"
          f"  [cumulative, from pickle] ──")
    print(SEP)
    print(f"  {'Term':<18}  {'no_vmfc (Ha)':>16}  {'vmfc (Ha)':>16}  {'bsse (Ha)':>16}")
    print(SEP)

    # 2b
    sum_2b = 0.0
    for pair in PAIRS:
        nv = e['2b'][pair]['no_vmfc']
        v  = e['2b'][pair]['vmfc']
        b  = e['2b'][pair]['bsse']
        sum_2b += b
        print(f"  2b_{pair:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 2b':<18}  {'':>16}  {'':>16}  {sum_2b:>+16.6e}")
    print(SEP)

    # 3b
    nv = e['3b']['no_vmfc']
    v  = e['3b']['vmfc']
    b3 = e['3b']['bsse']
    print(f"  {'3b':<18}  {nv:>+16.6e}  {v:>+16.6e}  {b3:>+16.6e}")
    print(SEP)

    # Total
    total = e['total_bsse']
    print(f"  {'total_bsse':<18}  {'':>16}  {'':>16}  {total:>+16.6e}")
    print(SEP)

    return sum_2b, b3, total


# ---------------------------------------------------------------------------
# Full incremental summary for one config
# ---------------------------------------------------------------------------

def print_incremental_config(bsse_data, molecule, cfg):
    """
    Print incremental components (SCF, MP2_comp, CCSD_T_comp) for one config.
    Shows Σ2b, 3b, and total for each component, with |FI-FII| check.
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    e_scf = trimer_bsse[cfg]['SCF'][BASIS]
    e_mp2 = trimer_bsse[cfg]['MP2'][BASIS]
    e_cct = trimer_bsse[cfg]['CCSD_T'][BASIS]

    incremental = {
        'SCF':    e_scf,
        'MP2':    _subtract_entry(e_mp2, e_scf),
        'CCSD_T': _subtract_entry(e_cct, e_mp2),
    }

    print(f"\n  ── Incremental Components  |  config {cfg} ──")
    print(SEP)
    print(f"  {'Component':>12}  {'Σ 2b_bsse (Ha)':>18}  {'3b_bsse (Ha)':>16}"
          f"  {'total_bsse (Ha)':>18}  {'|FI−FII|':>12}")
    print(SEP)

    for method in METHODS:
        e      = incremental[method]
        sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
        b3     = e['3b']['bsse']
        total  = e['total_bsse']
        form2  = e['total_bsse_form2']
        diff   = abs(total - form2)
        flag   = "✅" if diff < 1e-10 else "⚠️"
        label  = METHOD_LABELS[method]
        print(f"  {label:>12}  {sum_2b:>+18.6e}  {b3:>+16.6e}"
              f"  {total:>+18.6e}  {diff:.2e} {flag}")

    print(SEP)


# ---------------------------------------------------------------------------
# Full FORM(II) table for one config  [cumulative, from pickle]
# ---------------------------------------------------------------------------

def print_form2_table(e, method, cfg, sum_2b_f1, b3_f1, total_f1):
    """Print FORM(II) delta-group table for a single config."""
    deltas = e['delta_terms']

    print(f"\n  ── TABLE 2: FORM(II)  |  {method}  |  config {cfg}"
          f"  [cumulative, from pickle] ──")

    # ------------------------------------------------------------------
    # 2b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 2b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-2b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_2b = 0.0
    for key in DELTA_1B_IN_2B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_2b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-2b':<20}  {'':>16}  {sum_1b_in_2b:>+16.6e}")
    print(f"    {'Σ 2b  [FORM I]':<20}  {'':>16}  {sum_2b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(sum_1b_in_2b, sum_2b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 3b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 3b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-3b  (sign −)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_3b = 0.0
    for key in DELTA_1B_IN_3B:
        raw    = deltas[key]
        signed = -raw
        sum_1b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-3b':<20}  {'':>16}  {sum_1b_in_3b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-3b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_3b = 0.0
    for key in DELTA_2B_IN_3B:
        raw    = deltas[key]
        signed = +raw
        sum_2b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-3b':<20}  {'':>16}  {sum_2b_in_3b:>+16.6e}")
    print(SEP3)

    net_3b = sum_1b_in_3b + sum_2b_in_3b
    print(f"\n    {'net 3b (FORM II)':<20}  {'':>16}  {net_3b:>+16.6e}")
    print(f"    {'3b  [FORM I]':<20}  {'':>16}  {b3_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_3b, b3_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # Grand total comparison
    # ------------------------------------------------------------------
    form2_total = e['total_bsse_form2']
    diff        = abs(form2_total - total_f1)
    print(f"\n  {'─ Grand Total ─':^72}")
    print(SEP)
    print(f"  {'total (FORM I)':<22}  {total_f1:>+16.6e}")
    print(f"  {'total (FORM II)':<22}  {form2_total:>+16.6e}")
    print(f"  {'|FORM I - FORM II|':<22}  {diff:.2e}  "
          f"{'✅' if diff < 1e-10 else '⚠️  MISMATCH'}")
    print(SEP)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Print BSSE summary tables for H2O, Ne, or HF trimer"
    )
    parser.add_argument(
        "--mol", required=True, choices=["H2O", "Ne", "HF"],
        help="Molecule: H2O, Ne, or HF"
    )
    parser.add_argument(
        "--method", default="CCSD_T", choices=["SCF", "MP2", "CCSD_T", "all"],
        help="Method for cumulative compact table (default: CCSD_T)"
    )
    parser.add_argument(
        "--config", default=None, type=str,
        help="Print full FORM(I)+FORM(II) tables (cumulative) + incremental"
             " components for a single config index"
    )
    args = parser.parse_args()

    # --- paths ---
    here        = Path(__file__).resolve().parent
    data_dir    = here.parent.parent.parent
    pickle_path = data_dir / f'three_body_bsse_{args.mol}.pickle'

    with open(pickle_path, 'rb') as f:
        bsse_data = pickle.load(f)

    methods = METHODS if args.method == "all" else [args.method]

    print(f"\n{SEP2}")
    print(f"  BSSE Analysis — {args.mol} Trimer  |  {BASIS}")
    print(SEP2)

    if args.config is not None:
        # Full FORM(I) + FORM(II) tables (cumulative) for a single config
        cfg = args.config
        for method in methods:
            e = bsse_data[args.mol][CLUSTER][cfg][method][BASIS]
            sum_2b, b3, total = print_form1_table(e, method, cfg)
            print_form2_table(e, method, cfg, sum_2b, b3, total)
        # Incremental summary for this config
        print_incremental_config(bsse_data, args.mol, cfg)

    else:
        # Compact cumulative table (FORM I/II verification)
        for method in methods:
            print_compact_table(bsse_data, args.mol, method)

        # Compact incremental table (what goes into the CSVs)
        print_incremental_table(bsse_data, args.mol)