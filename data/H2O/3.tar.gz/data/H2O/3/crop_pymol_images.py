"""
crop_pymol_images.py
Post-process PyMOL PNG outputs: auto-crop near-white borders with small padding.
Uses a pixel threshold (>245 in all channels = background) to handle PyMOL's
anti-aliased ray-traced backgrounds which are not pure white.

Usage: python3 crop_pymol_images.py
Run from the folder where your PyMOL PNGs are saved.
"""
from PIL import Image
from pathlib import Path

PADDING   = 15    # pixels of white border to keep around the molecule
THRESHOLD = 245   # pixels brighter than this in all channels = background

FILES = [
    "H2O_trimer_I.png",
    "H2O_trimer_II.png",
    "Ne_trimer_I.png",
    "Ne_trimer_II.png",
    "HF_trimer_I.png",
    "HF_trimer_II.png",
]

for fname in FILES:
    p = Path(fname)
    if not p.exists():
        print(f"  SKIP  {fname} (not found)")
        continue

    img = Image.open(p).convert("RGB")
    w, h = img.size

    # Threshold: pixels darker than THRESHOLD in ANY channel = content
    # Convert to grayscale-like binary mask via point()
    # We need: pixel is background if R>245 AND G>245 AND B>245
    r, g, b = img.split()
    mask_r = r.point(lambda x: 255 if x > THRESHOLD else 0)
    mask_g = g.point(lambda x: 255 if x > THRESHOLD else 0)
    mask_b = b.point(lambda x: 255 if x > THRESHOLD else 0)

    # Background = all three channels above threshold
    # Content = any channel below threshold → invert to get content mask
    from PIL import ImageChops
    bg_mask  = ImageChops.darker(ImageChops.darker(mask_r, mask_g), mask_b)
    content  = ImageChops.invert(bg_mask)   # white = content, black = background

    bbox = content.getbbox()
    if bbox is None:
        print(f"  SKIP  {fname} (no content detected)")
        continue

    # Add padding, clamped to image bounds
    left   = max(bbox[0] - PADDING, 0)
    top    = max(bbox[1] - PADDING, 0)
    right  = min(bbox[2] + PADDING, w)
    bottom = min(bbox[3] + PADDING, h)

    cropped = img.crop((left, top, right, bottom))
    cropped.save(p, dpi=(300, 300))
    print(f"  OK    {fname}  {w}x{h}  ->  {cropped.width}x{cropped.height}")

print("Done.")