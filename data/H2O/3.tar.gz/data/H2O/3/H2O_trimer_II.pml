# H2O_trimer_II.pml — H2O Trimer | H-bond contacts | Config 0 (R = 2.75 Å)
# Representative geometry: equilateral triangle, all O-O = 2.75 Å
# Atom order (from 0_2.75.xyz): O_A=1, H_A1=2, H_A2=3, O_B=4, H_B1=5, H_B2=6,
#                                O_C=7, H_C1=8, H_C2=9
#
# H-bond contacts confirmed from geometry (H...O < 2.1 Å):
#   H_A2(idx 3) -> O_B(idx 4):  1.800 Å  (A donates to B)
#   H_B1(idx 5) -> O_C(idx 7):  1.797 Å  (B donates to C)
#   No C->A contact in this geometry (chain arrangement, not cyclic ring)

load pymol_files_xyz/0_2.75.xyz, H2O_trimer
preset.ball_and_stick(selection='all', mode=1)

# White background (ray_opaque_background required for bg_color to apply during ray tracing)
bg_color white
set ray_opaque_background, 1

# H atoms are white by default — recolor grey so they show on white background
color grey60, name H

# H...O hydrogen bond contacts (A->B and B->C, confirmed H...O < 2.1 Å)
distance HA2_OB, index 3, index 4
distance HB1_OC, index 5, index 7

# Black dashes for H-bonds — visible on white background
color black, HA2_OB
color black, HB1_OC

# Hide distance labels on H-bonds (same style as tetramer II)
set label_color, white, HA2_OB
set label_color, white, HB1_OC

# A-C O-O connection — grey dashes to show no H-bond on this side
distance OO_AC, index 1, index 7
color grey50, OO_AC
set label_color, white, OO_AC

# Dash style — H-bonds (black)
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Dash style — A-C reference line (grey, same gap/length, slightly thinner)
set dash_radius, 0.008, OO_AC
set dash_gap, 0.35, OO_AC
set dash_length, 0.15, OO_AC

# Labels on oxygen atoms — A, B, C
label index 1, "A"
label index 4, "B"
label index 7, "C"

# A/B/C label style
set label_size, 24
set label_color, white
set label_font_id, 5

# Center and fit — no orient needed, atoms already in z=0 plane
zoom all, 0.5

png H2O_trimer_II.png, width=800, height=800, dpi=300, ray=1
