load pymol_files_xyz/0_2.75.xyz, 0_2.75
load pymol_files_xyz/1_3.0.xyz, 1_3.0
load pymol_files_xyz/2_3.25.xyz, 2_3.25
load pymol_files_xyz/3_3.5.xyz, 3_3.5
load pymol_files_xyz/4_3.75.xyz, 4_3.75
preset.ball_and_stick(selection='all', mode=1)
