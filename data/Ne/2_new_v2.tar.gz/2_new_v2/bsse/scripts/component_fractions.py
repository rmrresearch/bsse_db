#!/usr/bin/env python3
"""
component_fractions.py — Ne/2_new_v2, R-resolved BSSE component fractions
=========================================================================

Emits, per basis, the fraction of the two-body BSSE carried by each of the
three additive components AT EACH SEPARATION, as a CSV in `data_frames/`.

    fraction_X(R) = 100 * BSSE_X(R) / BSSE_total(R)          X in {SCF, MP2c, CCSD_Tc}

WHY THIS SCRIPT EXISTS
----------------------
The window-averaged weights (handoff 09-30 §7D: 41.5 / 47.9 / 10.7 % at DZ)
are a single number per component per basis. They sit inside the R-resolved
range but describe no separation in particular. At DZ the SCF and MP2c shares
exchange the leading share within the window, and the average hides that
entirely. This script produces the R-resolved evidence.


THE DENOMINATOR IS THE SIGNED TOTAL
-----------------------------------
Signed component divided by signed total, NOT by |total|.

Under this project's convention `bsse = no_vmfc - vmfc`, the total is
negative. Dividing by |total| would flip the sign of every fraction and would
report all three components as negative contributors to a negative total,
which is backwards. With the signed denominator the fractions sum to exactly
100 at every R, and a component that genuinely opposes the others -- Ne
CCSD(T)c at aug-cc-pVQZ -- shows up as a NEGATIVE fraction, which is the
informative behaviour.

This convention is inherited from `plot_bsse_model.py` §7D and is not a
choice made here.


WHAT IS ASSERTED RATHER THAN ASSUMED
------------------------------------
Both of the following are checked and the script REFUSES TO WRITE if either
fails, because a fraction is meaningless when they do not hold:

  1. COMPONENT SUM IDENTITY.  SCF + MP2c + CCSD_Tc == total, to `--tol-sum`
     relative (default 1e-12). The columns are incremental
     (`MP2c = E_MP2 - E_SCF`, `CCSD_Tc = E_CCSD(T) - E_MP2`), so this is a
     property of the stored file, not of the physics, and a violation means
     the CSV is wrong.

  2. SINGLE-SIGNEDNESS OF THE TOTAL over the window. If the total passed
     through zero the fraction would diverge and change sign across the
     crossing, and no percentage statement would be defensible. Ne totals
     were verified single-signed at all 50 R at all three bases (handoff 03,
     Part 3.3); this script re-checks it rather than trusting that record.

  NOTE the components themselves are NOT required to be single-signed --
  Ne CCSD(T)c is positive at every R at QZ and negative at every R at DZ and
  TZ. That is a result, and constraining it away would suppress it.


PERCENTAGES ARE A PROPERTY OF THE WINDOW
----------------------------------------
The window is written into the output filename and into the CSV header
comment, because the same quantity over a different window is a different
number: the [1.5, 3.5] A window at 100 points gave 41.6/47.7/10.7 and the
older `Ne/2` study over [1.5, 3.0] gave 44/46/10. Any sentence quoting a
fraction must quote its window.


CROSSOVERS
----------
The script locates every separation at which the rank ordering of the three
fractions changes, by linear interpolation between the bracketing grid
points. These are reported to stdout and written to a companion `_crossovers`
CSV. They are located on the GRID: a crossover narrower than dR = 0.0408 A
would not be resolved, and the interpolated location is not claimed to better
precision than the spacing.


Location: bsse_db/data/Ne/2_new_v2/bsse/scripts/
Input:    <study-root>/data_frames/ne_dimer_bsse_vs_R_aug-cc-pv{d,t,q}z.csv
Output:   <study-root>/data_frames/ne_dimer_component_fractions_<basis>_R<lo>-<hi>.csv
          <study-root>/data_frames/ne_dimer_component_crossovers_<basis>_R<lo>-<hi>.csv

Usage
-----
    cd bsse_db/data/Ne/2_new_v2/bsse/scripts
    python3 component_fractions.py                       # all three bases, full window
    python3 component_fractions.py --basis qz            # one basis
    python3 component_fractions.py --R-min 1.5 --R-max 3.0
    python3 component_fractions.py --study-root /path/to/Ne/2_new_v2
    python3 component_fractions.py --dry-run             # print, write nothing

# TODO: pending PI discussion -- which subset of the 50 rows, if any, goes
# into the manuscript table. This script emits all of them; the sampling
# decision is a prose decision and is deliberately not made here.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ── Paths ────────────────────────────────────────────────────────────────────
# This script reads all three components and the total, so it lives in
# `bsse/scripts/` rather than under any one component directory, and the study
# root is TWO levels up. Note this differs from fit_scf.py, which sits one
# level deeper at `2b_bsse_scf/fit_study/scripts/` and anchors three levels up.
# Override with --study-root if this file is moved.
SCRIPT_DIR    = Path(__file__).resolve().parent
DEFAULT_ROOT  = SCRIPT_DIR.parent.parent

TOTAL_COL = 'total_bsse'
COMPONENTS = {
    'SCF':      '2b_bsse_SCF',
    'MP2c':     '2b_bsse_MP2c',
    'CCSD_Tc':  '2b_bsse_CCSD_Tc',
}

BASES = {
    'dz': {'tag': 'DZ', 'label': 'aug-cc-pVDZ', 'nbf': 46,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvdz.csv', 'slug': 'aug-cc-pvdz'},
    'tz': {'tag': 'TZ', 'label': 'aug-cc-pVTZ', 'nbf': 92,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvtz.csv', 'slug': 'aug-cc-pvtz'},
    'qz': {'tag': 'QZ', 'label': 'aug-cc-pVQZ', 'nbf': 160,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvqz.csv', 'slug': 'aug-cc-pvqz'},
}


class CheckFailed(Exception):
    """A precondition for forming fractions does not hold."""


# ── Checks ───────────────────────────────────────────────────────────────────
def check_sum_identity(df, tol):
    """SCF + MP2c + CCSD_Tc == total. Property of the stored file."""
    comp_sum = sum(df[c] for c in COMPONENTS.values())
    scale = np.maximum(np.abs(df[TOTAL_COL]), 1e-30)
    rel = np.abs(comp_sum - df[TOTAL_COL]) / scale
    worst = float(rel.max())
    if worst > tol:
        bad = df.loc[rel.idxmax(), 'R']
        raise CheckFailed(
            f"component sum != total: max relative deviation {worst:.3e} "
            f"at R = {bad:.6g} A, tolerance {tol:.1e}"
        )
    return worst


def check_single_signed(df):
    """
    The total must not change sign or vanish anywhere in the window.

    If it did, the fraction would diverge at the crossing and reverse sign
    across it, and no percentage statement over the window would be
    defensible.
    """
    t = df[TOTAL_COL].to_numpy()
    if np.any(t == 0.0):
        raise CheckFailed("total_bsse is exactly zero at one or more R")
    signs = np.sign(t)
    if not np.all(signs == signs[0]):
        flips = df['R'].to_numpy()[1:][signs[1:] != signs[:-1]]
        raise CheckFailed(
            "total_bsse changes sign within the window, near R = "
            + ', '.join(f"{r:.4f}" for r in flips)
        )
    return int(signs[0])


# ── Crossovers ───────────────────────────────────────────────────────────────
def find_crossovers(R, fracs):
    """
    Every R at which the rank ordering of the fractions changes.

    Located by linear interpolation between the two bracketing grid points.
    Resolution is bounded by the grid spacing: a crossover narrower than dR
    is not resolved and none is claimed to finer precision.
    """
    names = list(fracs)
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            d = fracs[a] - fracs[b]
            for k in range(len(R) - 1):
                if d[k] == 0.0:
                    rows.append({'pair': f'{a}-{b}', 'R': float(R[k]),
                                 'located': 'on grid point'})
                elif d[k] * d[k + 1] < 0.0:
                    w = d[k] / (d[k] - d[k + 1])
                    rows.append({'pair': f'{a}-{b}',
                                 'R': float(R[k] + w * (R[k + 1] - R[k])),
                                 'located': 'linear interpolation'})
    rows.sort(key=lambda r: r['R'])
    return pd.DataFrame(rows, columns=['pair', 'R', 'located'])


# ── Per-basis driver ─────────────────────────────────────────────────────────
def process(key, meta, csv_dir, r_min, r_max, tol, dry_run):
    path = csv_dir / meta['csv']
    if not path.exists():
        raise CheckFailed(f"input not found: {path}")

    df = pd.read_csv(path)
    missing = [c for c in [*COMPONENTS.values(), TOTAL_COL, 'R']
               if c not in df.columns]
    if missing:
        raise CheckFailed(f"{path.name} is missing columns: {missing}")

    df = df.sort_values('R').reset_index(drop=True)
    lo = df['R'].min() if r_min is None else r_min
    hi = df['R'].max() if r_max is None else r_max
    df = df[(df['R'] >= lo) & (df['R'] <= hi)].reset_index(drop=True)
    if len(df) < 2:
        raise CheckFailed(f"window [{lo}, {hi}] leaves {len(df)} points")

    worst_sum = check_sum_identity(df, tol)
    sign = check_single_signed(df)

    out = pd.DataFrame({'R': df['R']})
    fracs = {}
    for name, col in COMPONENTS.items():
        out[f'bsse_{name}'] = df[col]
        f = 100.0 * df[col] / df[TOTAL_COL]
        out[f'frac_{name}_pct'] = f
        fracs[name] = f.to_numpy()
    out['total_bsse'] = df[TOTAL_COL]
    out['frac_sum_pct'] = sum(out[f'frac_{n}_pct'] for n in COMPONENTS)

    cross = find_crossovers(df['R'].to_numpy(), fracs)

    r_lo, r_hi = float(df['R'].min()), float(df['R'].max())
    tag = f"R{r_lo:.2f}-{r_hi:.2f}"
    stem = f"ne_dimer_component_fractions_{meta['slug']}_{tag}"
    cstem = f"ne_dimer_component_crossovers_{meta['slug']}_{tag}"

    # ── report ──────────────────────────────────────────────────────────
    print(f"\n{meta['label']}  ({meta['nbf']} bf)   "
          f"window [{r_lo:.4f}, {r_hi:.4f}] A, {len(df)} points, "
          f"dR = {(r_hi - r_lo) / (len(df) - 1):.6f} A")
    print(f"  checks: component sum identity max rel dev {worst_sum:.2e} "
          f"(tol {tol:.0e}); total single-signed, sign "
          f"{'negative' if sign < 0 else 'positive'} at all {len(df)} R")
    print(f"  {'component':<10}{'min %':>10}{'max %':>10}{'range':>10}"
          f"{'window avg %':>15}")
    for name in COMPONENTS:
        f = fracs[name]
        # Window average of the fraction is NOT the same quantity as the
        # ratio of window-averaged components (handoff 09-30 7D). Both are
        # printed so they are never confused.
        print(f"  {name:<10}{f.min():>10.1f}{f.max():>10.1f}"
              f"{f.max() - f.min():>10.1f}{f.mean():>15.1f}")
    print("  ratio of window-mean signed component to window-mean signed "
          "total (the 7D quantity, for comparison only):")
    tot_mean = float(df[TOTAL_COL].mean())
    for name, col in COMPONENTS.items():
        print(f"    {name:<10}{100.0 * float(df[col].mean()) / tot_mean:>8.2f} %")

    if cross.empty:
        print("  rank crossovers: none in this window")
    else:
        print(f"  rank crossovers ({len(cross)}), grid spacing bounds the "
              f"resolution:")
        for _, r in cross.iterrows():
            print(f"    {r['pair']:<16} R = {r['R']:.4f} A   ({r['located']})")

    if dry_run:
        print("  --dry-run: nothing written")
        return

    hdr = (f"# Ne dimer two-body BSSE component fractions, {meta['label']}\n"
           f"# fraction = 100 * signed component / signed total, per R\n"
           f"# window [{r_lo:.6g}, {r_hi:.6g}] A, {len(df)} points -- these "
           f"percentages are a property of this window\n"
           f"# generated by component_fractions.py from {meta['csv']}\n")
    for p, frame in ((csv_dir / f"{stem}.csv", out),
                     (csv_dir / f"{cstem}.csv", cross)):
        with open(p, 'w') as fh:
            fh.write(hdr)
            frame.to_csv(fh, index=False, float_format='%.15g')
        print(f"  wrote {p}")


def main():
    ap = argparse.ArgumentParser(
        description="R-resolved BSSE component fractions for the Ne dimer.")
    ap.add_argument('--basis', type=str.lower,
                    choices=list(BASES) + ['all'], default='all')
    ap.add_argument('--study-root', type=Path, default=DEFAULT_ROOT,
                    help='study root containing data_frames/ '
                         f'(default: {DEFAULT_ROOT})')
    ap.add_argument('--R-min', dest='r_min', type=float, default=None)
    ap.add_argument('--R-max', dest='r_max', type=float, default=None)
    ap.add_argument('--tol-sum', type=float, default=1e-12,
                    help='relative tolerance on the component sum identity')
    ap.add_argument('--dry-run', action='store_true',
                    help='report only; write no files')
    a = ap.parse_args()

    csv_dir = a.study_root / 'data_frames'
    if not csv_dir.is_dir():
        sys.exit(f"data_frames/ not found under {a.study_root} "
                 f"-- pass --study-root")

    keys = list(BASES) if a.basis == 'all' else [a.basis]
    failed = []
    for k in keys:
        try:
            process(k, BASES[k], csv_dir, a.r_min, a.r_max,
                    a.tol_sum, a.dry_run)
        except CheckFailed as e:
            failed.append((BASES[k]['label'], str(e)))
            print(f"\n{BASES[k]['label']}: REFUSED -- {e}", file=sys.stderr)

    if failed:
        sys.exit(f"\n{len(failed)} basis/bases failed their preconditions; "
                 f"no fractions written for those.")


if __name__ == '__main__':
    main()
