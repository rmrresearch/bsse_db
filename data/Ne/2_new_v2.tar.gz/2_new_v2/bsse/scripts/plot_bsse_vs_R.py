#!/usr/bin/env python3
"""
plot_bsse_vs_R.py — Ne/2_new_v2 (dimer radial scan, three bases)
================================================================

Generates the two data figures for each basis from the per-basis BSSE CSVs:

  1. ne_dimer_bsse_vs_R_<BASIS>.png
     |BSSE| (kcal/mol) vs R (A) for the three components and the total
     (full CCSD(T)), with the 1 and 0.5 kcal/mol reference thresholds.
     --signed plots the signed quantity instead (see SIGN CONVENTION).

  2. ne_dimer_component_breakdown_<BASIS>.png
     Bar plot of each component's percentage contribution to the total
     BSSE (see DENOMINATOR below).

Location:  bsse_db/data/Ne/2_new_v2/bsse_fits/scripts/
Input:     bsse_db/data/Ne/2_new_v2/data_frames/
             ne_dimer_bsse_vs_R_aug-cc-pv{dz,tz,qz}.csv     (50 x 23 each)
Output:    bsse_db/data/Ne/2_new_v2/bsse_fits/figures/{DZ,TZ,QZ}/

The third figure in each basis directory — the fit overlay — is written by
plot_bsse_model.py, not by this script (handoff 30-Jul, 6F).


What changed from the v1 script
-------------------------------
v1 lived in Ne/2_new/scripts/, read ONE CSV on a 100-point grid, and wrote
into data_frames_plots/. Four substantive changes:

  1. THREE CSVs, one per basis, selected by --basis. Default is 'all', which
     regenerates every figure in one invocation.
  2. Figures are written into a per-basis subdirectory of figures/, so each
     of DZ/TZ/QZ is self-contained.
  3. The component breakdown no longer takes absolute values per component.
     v1's denominator (the sum of the component means of |BSSE_c|) is not
     valid at aug-cc-pVQZ, where CCSD(T)c has the opposite sign to the other
     two components at all 50 R (handoff 30-Jul, 5). See DENOMINATOR.
  4. Path anchoring follows option A of handoff 30-Jul 6E: this script is
     two levels below the study root, so CSV_DIR = SCRIPT_DIR.parent.parent
     / 'data_frames'.

Unchanged from v1: colours, marker sizes, threshold lines, bar annotation
style, in-figure titles OFF by default, and the R-window filename suffix.


SIGN CONVENTION
---------------
The CSVs store signed BSSE, defined as (no_vmfc - vmfc). For Ne2 v2 every
value of total_bsse is negative at all 50 R at all three bases.

Absolute values are taken HERE, at plot time only, and never written back.

Figure 1 defaults to |BSSE|, matching v1 and the published draft. --signed
plots the signed quantity instead; this is worth looking at at QZ, where
CCSD(T)c sits on the opposite side of zero from the other two components and
an absolute-value plot cannot show that. Which of the two the paper uses is
an open decision (handoff 30-Jul, 6D) — hence a flag rather than a default.

In --signed mode the 1.0 and 0.5 kcal/mol reference lines are drawn at -1.0
and -0.5, because the quantity plotted is negative throughout. That is a
consequence of the sign convention, not a separate choice.

Log scale is unavailable in --signed mode: the signed traces straddle zero
at QZ.


DENOMINATOR (figure 2)
----------------------
Each component's percentage is its window-mean divided by the window-mean of
the total, both SIGNED:

    pct_c = 100 * mean(BSSE_c) / mean(BSSE_SCF + BSSE_MP2c + BSSE_CCSD_Tc)

Read as: the fraction of the total BSSE contributed by component c, with the
sign taken relative to the total. The three percentages sum to 100 by
construction, since the CSV satisfies the component sum exactly (verified:
max |sum of components - total_bsse| <= 6e-15 kcal/mol at all three bases).

Two properties of this definition:

  * A component opposing the total gets a NEGATIVE percentage and its bar
    points downward. At aug-cc-pVQZ, CCSD(T)c is -3.76%; at DZ and TZ all
    three components are positive. The sign reversal is therefore visible in
    the figure rather than hidden by an absolute value.

  * The denominator is the SIGNED total, not |total|. Dividing by |total|
    would invert every sign — the two dominant components would come out
    negative and CCSD(T)c positive — because the total itself is negative
    under this project's sign convention.

v1 instead used the sum of the component means of |BSSE_c| as denominator.
At DZ and TZ that gives the same answer to rounding, because all three
components share a sign there. At QZ it does not: that denominator is
0.21484 kcal/mol against |mean total_bsse| = 0.19980, a 7.5% discrepancy
arising entirely from the CCSD(T)c sign reversal.

`% TODO: pending PI discussion` — the choice of denominator, and whether the
QZ sign reversal is reported as a result or a caveat, are both on the PI
question list (handoff 30-Jul, 10 items 2 and 5).


R window
--------
--R-min / --R-max restrict the analysis to a sub-range of the 50-point grid.
This is a PLOT-TIME filter only: the CSVs always hold all 50 R and are never
modified.

The window changes the component-breakdown percentages, because those are
means over whichever R are included. The quoted percentages are therefore a
property of the chosen R window, not of the Ne dimer alone, and any figure or
number derived from them must state its window.

Applying a window appends a suffix to the output filenames (e.g.
ne_dimer_bsse_vs_R_DZ_Rmax3p5.png), so a windowed figure can never silently
overwrite the full-range one.


Usage
-----
    cd bsse_db/data/Ne/2_new_v2/bsse_fits/scripts
    python3 plot_bsse_vs_R.py                        # all bases, both figures
    python3 plot_bsse_vs_R.py --basis qz             # QZ only
    python3 plot_bsse_vs_R.py --plot breakdown       # just figure 2, all bases
    python3 plot_bsse_vs_R.py --basis qz --signed    # signed traces at QZ
    python3 plot_bsse_vs_R.py --yscale log           # log y on figure 1
    python3 plot_bsse_vs_R.py --title                # in-figure titles on
    python3 plot_bsse_vs_R.py --R-min 2.0 --R-max 3.0
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# LaTeX rendering for all text (project convention).
plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})


# ── Paths (option A anchoring: 2 levels below the study root) ─────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
STUDY_ROOT = SCRIPT_DIR.parent.parent
CSV_DIR    = STUDY_ROOT / 'data_frames'
FIG_DIR    = SCRIPT_DIR.parent / 'figures'


# ── Basis registry ───────────────────────────────────────────────────────────
# One dict per basis: CLI alias -> everything that differs between bases.
# A fourth basis is added here and nowhere else.
BASES = {
    'dz': {
        'tag':   'DZ',
        'csv':   'ne_dimer_bsse_vs_R_aug-cc-pvdz.csv',
        'label': 'aug-cc-pVDZ',
        'nbf':   46,
    },
    'tz': {
        'tag':   'TZ',
        'csv':   'ne_dimer_bsse_vs_R_aug-cc-pvtz.csv',
        'label': 'aug-cc-pVTZ',
        'nbf':   92,
    },
    'qz': {
        'tag':   'QZ',
        'csv':   'ne_dimer_bsse_vs_R_aug-cc-pvqz.csv',
        'label': 'aug-cc-pVQZ',
        'nbf':   160,
    },
}

# ── Traces: (CSV column, legend label, colour, marker alpha) ──────────────────
COMPONENTS = [
    ('2b_bsse_SCF',     'SCF',            'tab:blue',   0.65),
    ('2b_bsse_MP2c',    'MP2 corr.',      'tab:orange', 0.65),
    ('2b_bsse_CCSD_Tc', 'CCSD(T) corr.',  'tab:green',  0.65),
]
TOTAL = ('total_bsse', 'Total (full CCSD(T))', 'black', 0.85)

# Tolerance on the component-sum identity, kcal/mol. The CSVs achieve ~6e-15;
# this is loose enough for accumulated floating point and tight enough that a
# real bookkeeping error cannot pass.
SUM_TOL = 1.0e-10


def _ytick_fmt(x, pos):
    """Y-axis tick formatter: '1.0','10.0',... for |x|>=1, else '%g'."""
    return f"{x:.1f}" if abs(x) >= 1 else f"{x:g}"


def window_suffix(r_min, r_max):
    """
    Filename suffix encoding the applied R window. Empty when no window is
    set, so full-range output keeps the canonical filename.
    """
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace('.', 'p'))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace('.', 'p'))
    return ('_' + '_'.join(parts)) if parts else ''


def apply_window(df, r_min, r_max):
    """Restrict the dataframe to r_min <= R <= r_max. Returns a new frame."""
    out = df
    if r_min is not None:
        out = out[out['R'] >= r_min]
    if r_max is not None:
        out = out[out['R'] <= r_max]
    out = out.reset_index(drop=True)
    if out.empty:
        raise ValueError(
            f"R window [{r_min}, {r_max}] selects no rows "
            f"(CSV spans [{df['R'].min():.3f}, {df['R'].max():.3f}] A)."
        )
    return out


def load_csv(basis_key):
    """
    Load one basis's CSV, sorted by R, and check the component-sum identity.

    The check is cheap and guards the figure-2 denominator: the percentages
    only sum to 100 if the components sum to the total, so it is verified
    here rather than assumed.
    """
    path = CSV_DIR / BASES[basis_key]['csv']
    if not path.is_file():
        raise FileNotFoundError(
            f"No CSV at {path}. Run build_bsse_csv.py first."
        )
    df = pd.read_csv(path).sort_values('R').reset_index(drop=True)

    comp_sum = sum(df[col] for col, _, _, _ in COMPONENTS)
    resid = float(np.max(np.abs(comp_sum - df[TOTAL[0]])))
    if resid > SUM_TOL:
        raise ValueError(
            f"{path.name}: components do not sum to total_bsse "
            f"(max residual {resid:.3e} kcal/mol > {SUM_TOL:.1e}). "
            f"The figure-2 percentages would not sum to 100."
        )
    return df, resid


# ── Figure 1: BSSE vs R ──────────────────────────────────────────────────────
def plot_bsse_vs_R(df, out_path, basis_label,
                   show_title=False, yscale='linear', signed=False):
    """
    Scatter BSSE vs R for the three components and the total.

    Parameters
    ----------
    df : pandas.DataFrame
        One basis's CSV, windowed and sorted by R.
    out_path : pathlib.Path
        Destination PNG.
    basis_label : str
        Pretty basis name, used only in the optional in-figure title.
    show_title : bool
        Draw an in-figure title. Off for publication output.
    yscale : {'linear', 'log'}
        Y-axis scale. Ignored (forced linear) when signed=True.
    signed : bool
        Plot the signed BSSE rather than |BSSE|.
    """
    transform = (lambda s: s) if signed else np.abs

    fig, ax = plt.subplots(figsize=(8, 6))

    for col, label, color, alpha in COMPONENTS:
        ax.scatter(df['R'], transform(df[col]),
                   s=22, alpha=alpha, label=label, color=color)

    col, label, color, alpha = TOTAL
    ax.scatter(df['R'], transform(df[col]),
               s=22, alpha=alpha, label=label, color=color)

    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$\mathrm{BSSE}$ (kcal/mol)" if signed
                  else r"$|\mathrm{BSSE}|$ (kcal/mol)")

    if not signed:
        ax.set_yscale(yscale)
    if signed or yscale == 'linear':
        ax.yaxis.set_major_formatter(FuncFormatter(_ytick_fmt))

    # Reference thresholds. In signed mode the plotted quantity is negative
    # throughout, so the lines go below zero; see SIGN CONVENTION.
    sgn = -1.0 if signed else 1.0
    ax.axhline(y=sgn * 1.0, color="red", linestyle="--", linewidth=1.0,
               alpha=0.7, label="1 kcal/mol threshold")
    ax.axhline(y=sgn * 0.5, color="grey", linestyle="--", linewidth=1.0,
               alpha=0.7)
    if signed:
        ax.axhline(y=0.0, color="black", linewidth=0.8, alpha=0.5)

    if show_title:
        kind = "BSSE" if signed else "$|$BSSE$|$"
        ax.set_title(f"Ne dimer: {kind} vs inter-monomer distance "
                     f"({basis_label})")

    ax.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    flags = []
    if signed:
        flags.append("signed")
    if not signed and yscale == 'log':
        flags.append("log y")
    tail = f"  ({', '.join(flags)})" if flags else ""
    print(f"  Saved plot: {out_path.name}{tail}")


# ── Figure 2: component breakdown ────────────────────────────────────────────
def plot_component_breakdown(df, out_path, basis_label, show_title=False):
    """
    Bar plot of each component's percentage contribution to the total BSSE.

        pct_c = 100 * mean(BSSE_c) / mean(total BSSE)      [both signed]

    See DENOMINATOR in the module docstring. A component opposing the total
    gets a negative percentage and its bar points down; its value label is
    placed below the bar so it cannot collide with the axis.
    """
    means = {col: float(np.mean(df[col])) for col, _, _, _ in COMPONENTS}
    denom = float(np.mean(df[TOTAL[0]]))          # signed, not |.|

    if denom == 0.0:
        raise ValueError(
            "Mean total_bsse is exactly zero over this window; the "
            "percentage denominator is undefined."
        )

    labels      = [lab for _, lab, _, _ in COMPONENTS]
    percentages = [100 * means[col] / denom for col, _, _, _ in COMPONENTS]
    colors      = [c for _, _, c, _ in COMPONENTS]

    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(labels, percentages, color=colors, alpha=0.8)

    # Label above positive bars, below negative ones.
    span = max(percentages) - min(min(percentages), 0.0)
    pad  = 0.02 * span
    for bar, pct in zip(bars, percentages):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2,
                h + pad if h >= 0 else h - pad,
                f"{pct:.1f}\\%", ha="center",
                va="bottom" if h >= 0 else "top", fontsize=11)

    ax.set_ylabel(r"Contribution to total $\mathrm{BSSE}$ (\%)")

    # Limits must accommodate a negative bar and its label.
    top = max(percentages) + 0.12 * span
    bot = min(min(percentages), 0.0)
    bot = bot - 0.12 * span if bot < 0 else 0.0
    ax.set_ylim(bot, top)
    if bot < 0:
        ax.axhline(y=0.0, color="black", linewidth=0.8)

    if show_title:
        ax.set_title(f"Ne dimer: BSSE component breakdown ({basis_label})")

    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"  Saved plot: {out_path.name}")

    # Console report — these are the numbers the paper text quotes.
    print(f"\n  Component breakdown — signed means over {len(df)} R "
          f"in [{df['R'].min():.3f}, {df['R'].max():.3f}] A")
    print("  (percentages are a property of THIS R window)")
    print(f"  {'-' * 64}")
    for (col, lab, _, _), pct in zip(COMPONENTS, percentages):
        print(f"    {lab:<15s} : {means[col]:+.5f} kcal/mol   ({pct:+7.2f}%)")
    print(f"  {'-' * 64}")
    print(f"    mean total_bsse : {denom:+.5f} kcal/mol   "
          f"(percentage denominator)")
    print(f"    sum of pct      : {sum(percentages):+.2f}%  "
          f"(100 by construction)")
    print(f"    sum of mean|.|  : "
          f"{sum(abs(v) for v in means.values()):.5f} kcal/mol   "
          f"(v1 denominator, for reference)")
    print(f"  {'-' * 64}")
    n_neg = sum(1 for p in percentages if p < 0)
    if n_neg:
        print(f"    NOTE: {n_neg} component(s) oppose the total and are "
              f"plotted below zero.")
    print(f"  {'-' * 64}")


# ── Per-basis driver ─────────────────────────────────────────────────────────
def run_basis(basis_key, args, win):
    """Generate the requested figures for a single basis."""
    meta = BASES[basis_key]
    tag  = meta['tag']

    out_dir = FIG_DIR / tag
    out_dir.mkdir(parents=True, exist_ok=True)

    df_all, resid = load_csv(basis_key)
    print(f"\n{'-' * 68}")
    print(f"  {meta['label']}  ({meta['nbf']} basis functions)")
    print(f"{'-' * 68}")
    print(f"  CSV      : {meta['csv']}")
    print(f"  Out dir  : {out_dir}")
    print(f"  Loaded {len(df_all)} rows, "
          f"R in [{df_all['R'].min():.3f}, {df_all['R'].max():.3f}] A   "
          f"(sum check {resid:.1e} kcal/mol)")

    df = apply_window(df_all, args.r_min, args.r_max)
    if win:
        print(f"  Window applied: {len(df)}/{len(df_all)} rows, "
              f"R in [{df['R'].min():.3f}, {df['R'].max():.3f}] A")
    print()

    if args.plot in ("bsse_vs_R", "all"):
        scale = '_log' if (args.yscale == 'log' and not args.signed) else ''
        sgn   = '_signed' if args.signed else ''
        plot_bsse_vs_R(
            df,
            out_dir / f'ne_dimer_bsse_vs_R_{tag}{win}{scale}{sgn}.png',
            meta['label'],
            show_title=args.title, yscale=args.yscale, signed=args.signed,
        )

    if args.plot in ("breakdown", "all"):
        plot_component_breakdown(
            df,
            out_dir / f'ne_dimer_component_breakdown_{tag}{win}.png',
            meta['label'],
            show_title=args.title,
        )


# ── CLI ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Generate the Ne/2_new_v2 dimer BSSE data figures from "
                    "the per-basis CSVs.",
    )
    parser.add_argument(
        "--basis", choices=list(BASES) + ["all"], default="all",
        help="Which basis to plot. Default: all.",
    )
    parser.add_argument(
        "--plot", choices=["bsse_vs_R", "breakdown", "all"], default="all",
        help="Which figure(s) to generate. Default: all.",
    )
    parser.add_argument(
        "--signed", action="store_true",
        help="Plot signed BSSE on figure 1 instead of |BSSE|. Relevant at "
             "QZ, where CCSD(T)c has the opposite sign to the other two "
             "components. Incompatible with --yscale log.",
    )
    parser.add_argument(
        "--title", action="store_true",
        help="Draw in-figure titles. Off by default: publication figures "
             "carry their description in the LaTeX caption.",
    )
    parser.add_argument(
        "--yscale", choices=["linear", "log"], default="linear",
        help="Y-axis scale for figure 1. Default: linear.",
    )
    parser.add_argument(
        "--R-min", dest="r_min", type=float, default=None, metavar="R",
        help="Lower bound of the R window, in Angstrom. Plot-time filter "
             "only; the CSVs are never modified.",
    )
    parser.add_argument(
        "--R-max", dest="r_max", type=float, default=None, metavar="R",
        help="Upper bound of the R window, in Angstrom. Applying a window "
             "appends a suffix to the output filenames.",
    )
    args = parser.parse_args()

    if args.signed and args.yscale == 'log':
        parser.error(
            "--signed is incompatible with --yscale log: the signed traces "
            "straddle zero at aug-cc-pVQZ."
        )
    if (args.r_min is not None and args.r_max is not None
            and args.r_min > args.r_max):
        parser.error(f"--R-min ({args.r_min}) exceeds --R-max ({args.r_max}).")

    keys = list(BASES) if args.basis == "all" else [args.basis]
    win  = window_suffix(args.r_min, args.r_max)

    print(f"\n{'=' * 68}")
    print("  Ne/2_new_v2 figures")
    print(f"{'=' * 68}")
    print(f"  Study root : {STUDY_ROOT}")
    print(f"  CSV dir    : {CSV_DIR}")
    print(f"  Figure dir : {FIG_DIR}")
    print(f"  Bases      : {', '.join(BASES[k]['tag'] for k in keys)}")
    print(f"  Figures    : {args.plot}")
    print(f"  Titles     : {'on' if args.title else 'off (publication)'}")
    print(f"  Figure 1   : {'signed BSSE' if args.signed else '|BSSE|'}")
    print(f"{'=' * 68}")

    if not CSV_DIR.is_dir():
        sys.exit(f"\nNo data_frames directory at {CSV_DIR}.\n"
                 f"Check that this script is in bsse_fits/scripts/.")

    for k in keys:
        run_basis(k, args, win)

    print()


if __name__ == '__main__':
    main()
