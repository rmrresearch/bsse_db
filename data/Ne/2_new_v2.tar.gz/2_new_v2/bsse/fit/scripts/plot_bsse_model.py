#!/usr/bin/env python3
"""
plot_bsse_model.py — Ne/2_new_v2, bsse/fit
==========================================

Assembles the three independently fitted BSSE components into a model of
the total, and compares it against the computed `total_bsse` and against
the Heindel-Xantheas erf form fitted to the total.

TWO FIGURES PER BASIS
---------------------
  1. model_components_<BASIS>.png
     the three fitted component curves drawn individually together with
     their sum, over the computed total. Shows what each channel
     contributes and how they combine.

  2. model_total_<BASIS>.png
     summed model vs computed total, with the Heindel-Xantheas fit to the
     total overlaid (left), and computed vs predicted for both models
     (right). Signed quantities.

  3. model_abs_<BASIS>.png
     |BSSE| vs R: summed model (left) and Heindel-Xantheas (right), on a
     shared y-axis, with the 1 and 0.5 kcal/mol reference levels and the
     crossing marked. This is the magnitude view the deliverable is stated
     in terms of.

ONE CSV PER BASIS, written to ../fit_csv/model_total_<BASIS>.csv. See
write_model_csv below for the schema and for why no ratio column appears.


THE SUMMED MODEL IS NOT REFITTED
--------------------------------
    BSSE_model(R) = BSSE_SCF_fit(R) + BSSE_MP2c_fit(R) + BSSE_CCSD(T)c_fit(R)

Each component fit is taken exactly as produced by its own study -- same
form, same multi-start, same window -- and the three are added. NO
parameter is adjusted against the total. The summed model therefore costs
ZERO new parameters, and its agreement with `total_bsse` is a genuine test
rather than a fit.

This follows handoff 29-Jul 11A: summing the three fits already IS a model
of the total, so no separate fit of the total is performed on our side; the
Heindel-Xantheas form appears only as a comparison.

A direct 7-parameter fit of the total with the combined form
(a0+a2R^2)exp(-bR^2) + a1 exp(-c1 R) + a2 exp(-c2 R) was tested and
REJECTED: max sigma/|p| reaches 154 and cond(covariance) 7.7e18, because
two free exponentials are very nearly collinear -- amplitude can be traded
between them with almost no change to the sum. It gives a lower RMSE, as
any 7-parameter fit would, with parameters that carry no information. Use
--direct to reproduce that failure rather than to use it.


ABSOLUTE VALUES ARE TAKEN ON THE SUM
------------------------------------
    |BSSE|_model = | SCF_fit + MP2c_fit + CCSD(T)c_fit |

never the sum of absolute values. At aug-cc-pVQZ, CCSD(T)c is POSITIVE at
all 50 R while the other two components are negative (handoff 30-Jul, 5),
so it subtracts from the total. `abs(a0+a1+a2)`, never
`abs(a0)+abs(a1)+abs(a2)`. At DZ and TZ the two happen to coincide; at QZ
they differ by 7.5%.

The signed quantities are plotted, and absolute values appear only where a
magnitude is required -- the 1 kcal/mol crossing.


THE 1 kcal/mol CROSSING
-----------------------
Reported per model, with the spread across models (handoff 29-Jul, 11C).
If all models place the crossing within a few thousandths of an Angstrom
they are equivalent for the purpose of the study, and the choice of form
rests on derivation and parsimony rather than fit quality.

At aug-cc-pVQZ the computed `max |total_bsse|` is 0.823 kcal/mol, so the
1 kcal/mol level is never reached on this grid and no crossing exists. The
script reports that rather than extrapolating to find one.


Location:  bsse_db/data/Ne/2_new_v2/bsse/fit/scripts/
Input:     bsse_db/data/Ne/2_new_v2/data_frames/
Output:    bsse_db/data/Ne/2_new_v2/bsse/fit/figures/<BASIS>/
           bsse_db/data/Ne/2_new_v2/bsse/fit/fit_csv/

NOTE ON DEPTH: this script sits THREE levels below the study root
(bsse/fit/scripts), not two. `plot_bsse_vs_R.py` in bsse/scripts is two.
If the tree is restructured, both anchors must be checked by hand -- the
wrong path may still exist, in which case a script resolves to something
incorrect rather than raising (handoff 30-Jul, 6E).

Usage
-----
    cd bsse_db/data/Ne/2_new_v2/bsse/fit/scripts
    python3 plot_bsse_model.py                 # all bases, figures + CSV
    python3 plot_bsse_model.py --mode csv      # model CSVs only; figures kept
    python3 plot_bsse_model.py --basis QZ      # one basis
    python3 plot_bsse_model.py --plot total    # just figure 2
    python3 plot_bsse_model.py --direct        # show the rejected 7-par fit
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.special import erf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})

# ── Paths (option A anchoring: THREE levels below the study root) ───────────
SCRIPT_DIR = Path(__file__).resolve().parent
STUDY_ROOT = SCRIPT_DIR.parent.parent.parent
CSV_DIR    = STUDY_ROOT / 'data_frames'
FIG_DIR    = SCRIPT_DIR.parent / 'figures'
CSV_OUT_DIR = SCRIPT_DIR.parent / 'fit_csv'

BASES = {
    'dz': {'tag': 'DZ', 'label': 'aug-cc-pVDZ', 'nbf': 46,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvdz.csv'},
    'tz': {'tag': 'TZ', 'label': 'aug-cc-pVTZ', 'nbf': 92,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvtz.csv'},
    'qz': {'tag': 'QZ', 'label': 'aug-cc-pVQZ', 'nbf': 160,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvqz.csv'},
}


# ── Component forms, identical to the component studies ─────────────────────
def f_scf(R, a0, a2, b):
    return (a0 + a2 * R**2) * np.exp(-b * R**2)


def f_exp(R, a, c):
    return a * np.exp(-c * R)


def f_hx(R, a, b):
    return a * (1.0 + erf(-b * R))


def f_direct(R, a0, a2, b, a1, c1, a3, c3):
    return (f_scf(R, a0, a2, b) + f_exp(R, a1, c1) + f_exp(R, a3, c3))


SEEDS_SCF = [[-2, .1, .6], [-.2, -.03, .4], [-1, 0, 1], [-.5, .05, .3],
             [-3, .5, 1.5], [10, -9, 1.1], [-8, 2, .9]]
SEEDS_EXP = [[-2, 1.], [-.5, .5], [-10, 2.], [-1, 1.5], [8, 3.4], [1, 2.]]
SEEDS_HX  = [[-2, .8], [-.4, .5], [-1, 1.], [-8, .3]]

COMPONENTS = [
    ('2b_bsse_SCF',     'SCF',           f_scf, SEEDS_SCF, 'tab:blue',
     r"$(a_0+a_2R^2)e^{-bR^2}$"),
    ('2b_bsse_MP2c',    'MP2 corr.',     f_exp, SEEDS_EXP, 'tab:orange',
     r"$a\,e^{-cR}$"),
    ('2b_bsse_CCSD_Tc', 'CCSD(T) corr.', f_exp, SEEDS_EXP, 'tab:green',
     r"$a\,e^{-cR}$"),
]


def rmse_tex(v, e=-3):
    return rf"{v / 10.0**e:.3f}\times 10^{{{e}}}"


def rmse_txt(v, e=-3):
    return f"{v / 10.0**e:.3f} x 10^{e}"


def fit_one(f, R, y, seeds):
    """Multi-start least squares; lowest-RMSE solution retained."""
    sols = []
    for p0 in seeds:
        try:
            with np.errstate(over='ignore', invalid='ignore'):
                p, cov = curve_fit(f, R, y, p0=p0, maxfev=400000)
        except (RuntimeError, TypeError, ValueError):
            continue
        pred = f(R, *p)
        if not np.all(np.isfinite(pred)):
            continue
        sols.append((float(np.sqrt(np.mean((y - pred)**2))), p, cov))
    if not sols:
        raise RuntimeError("no seed converged")
    sols.sort(key=lambda t: t[0])
    rm, p, cov = sols[0]
    with np.errstate(invalid='ignore'):
        perr = np.sqrt(np.abs(np.diag(cov)))
    return p, perr, cov, rm


def crossing(R, mag, level=1.0):
    """
    First R at which |BSSE| falls through `level`, by linear interpolation
    between grid points. None if the level is never reached.
    """
    if mag.max() < level:
        return None
    for i in range(len(R) - 1):
        if (mag[i] - level) * (mag[i + 1] - level) <= 0 and mag[i] != mag[i + 1]:
            t = (level - mag[i]) / (mag[i + 1] - mag[i])
            return float(R[i] + t * (R[i + 1] - R[i]))
    return None


def figure_components(R, y_tot, comps, summed, meta, out_path, show_title):
    """Figure 1: the three fitted components and their sum."""
    fig, ax = plt.subplots(figsize=(8.4, 6.0))
    Rf = np.linspace(R.min(), R.max(), 600)

    ax.scatter(R, y_tot, s=30, color='black', alpha=0.8, zorder=4,
               label='computed total')
    for (col, lab, f, _, colour, _), p in comps:
        ax.plot(Rf, f(Rf, *p), lw=1.5, color=colour, label=lab)
    ax.plot(Rf, sum(f(Rf, *p) for (_, _, f, _, _, _), p in comps),
            lw=2.0, color='crimson', label='sum of components')

    ax.axhline(0.0, color='black', lw=0.8, alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$\mathrm{BSSE}$ (kcal/mol)")
    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + 0.30 * (hi - lo))
    ax.annotate(rf"{meta['label']} ({meta['nbf']} bf)",
                xy=(0.035, 0.965), xycoords='axes fraction',
                ha='left', va='top', fontsize=11)
    ax.legend(frameon=False, loc='lower right', fontsize=10)

    if show_title:
        fig.suptitle(rf"Ne dimer: fitted BSSE components, {meta['label']}",
                     fontsize=13)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"    Saved figure: {out_path.name}")


def figure_total(R, y_tot, summed, hx_p, hx_pred, rm_sum, rm_hx,
                 r2_sum, r2_hx, meta, out_path, show_title):
    """Figure 2: summed model and the HX comparison against the total."""
    fig, (ax, axc) = plt.subplots(1, 2, figsize=(12.4, 5.4))
    Rf = np.linspace(R.min(), R.max(), 600)

    ax.scatter(R, y_tot, s=30, color='black', alpha=0.8, zorder=4,
               label='computed total')
    ax.plot(R, summed, lw=1.9, color='crimson',
            label=r"summed components (0 new par.)")
    ax.plot(Rf, f_hx(Rf, *hx_p), lw=1.6, color='tab:orange', ls='--',
            label=r"Heindel--Xantheas $a[1+\mathrm{erf}(-bR)]$ (2 par.)")
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$\mathrm{BSSE}_{\mathrm{total}}$ (kcal/mol)")

    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + 0.42 * (hi - lo))
    ax.annotate("\n".join([
        rf"{meta['label']} ({meta['nbf']} bf)",
        rf"summed: RMSE $= {rmse_tex(rm_sum)}$ kcal/mol",
        rf"HX: RMSE $= {rmse_tex(rm_hx)}$ kcal/mol",
    ]), xy=(0.035, 0.965), xycoords='axes fraction',
        ha='left', va='top', fontsize=10, linespacing=1.5)
    ax.legend(frameon=False, loc='lower right', fontsize=9)

    for pred, colour, lab, r2 in ((summed, 'crimson', 'summed components',
                                   r2_sum),
                                  (hx_pred, 'tab:orange', 'Heindel--Xantheas',
                                   r2_hx)):
        axc.scatter(y_tot, pred, s=28, alpha=0.7, color=colour,
                    label=rf"{lab},  $R^2={r2:.5f}$")
    allv = np.concatenate([y_tot, summed, hx_pred])
    lo, hi = float(allv.min()), float(allv.max())
    pad = 0.05 * (hi - lo)
    axc.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color='grey',
             ls='--', lw=1.0, zorder=1)
    axc.set_xlim(lo - pad, hi + pad); axc.set_ylim(lo - pad, hi + pad)
    axc.set_aspect('equal', adjustable='box')
    axc.set_xlabel(r"computed $\mathrm{BSSE}_{\mathrm{total}}$ (kcal/mol)")
    axc.set_ylabel(r"predicted $\mathrm{BSSE}_{\mathrm{total}}$ (kcal/mol)")
    axc.legend(frameon=False, loc='upper left', fontsize=9)

    if show_title:
        fig.suptitle(rf"Ne dimer: summed model vs computed total, "
                     rf"{meta['label']}", fontsize=13)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"    Saved figure: {out_path.name}")


def figure_abs(R, y_tot, summed, hx_pred, rm_sum, rm_hx, cr, meta,
               out_path, show_title):
    """Figure 3: |BSSE| vs R, summed model and HX, shared y-axis."""
    fig, axes = plt.subplots(1, 2, figsize=(12.6, 5.4), sharey=True)
    mag_tot = np.abs(y_tot)

    panels = (
        (axes[0], np.abs(summed), 'crimson',
         r"summed components (0 new par.)", rm_sum, cr['summed']),
        (axes[1], np.abs(hx_pred), 'tab:orange',
         r"Heindel--Xantheas (2 par.)", rm_hx, cr['HX']),
    )

    for ax, mag_mod, colour, lab, rm, xc in panels:
        ax.scatter(R, mag_tot, s=28, color='black', alpha=0.8, zorder=4,
                   label=r'computed $|\mathrm{BSSE}|$')
        ax.plot(R, mag_mod, lw=1.9, color=colour, label=lab)
        ax.axhline(1.0, color='red', ls='--', lw=1.0, alpha=0.7,
                   label='1 kcal/mol')
        ax.axhline(0.5, color='grey', ls='--', lw=1.0, alpha=0.7)
        if xc is not None:
            ax.axvline(xc, color=colour, ls=':', lw=1.2, alpha=0.8)
        ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
        txt = []
        if ax is axes[0]:
            txt.append(rf"{meta['label']} ({meta['nbf']} bf)")
        txt.append(rf"RMSE $= {rmse_tex(rm)}$ kcal/mol")
        txt.append(rf"1 kcal/mol at $R = {xc:.4f}$ \AA" if xc is not None
                   else r"1 kcal/mol not reached")
        ax.annotate("\n".join(txt), xy=(0.96, 0.94),
                    xycoords='axes fraction', ha='right', va='top',
                    fontsize=10, linespacing=1.5)
        ax.legend(frameon=False, loc='center right', fontsize=9)

    axes[0].set_ylabel(r"$|\mathrm{BSSE}_{\mathrm{total}}|$ (kcal/mol)")
    lo, hi = axes[0].get_ylim()
    axes[0].set_ylim(lo, hi + 0.30 * (hi - lo))

    if show_title:
        fig.suptitle(rf"Ne dimer: $|\mathrm{{BSSE}}|$ vs $R$, "
                     rf"{meta['label']}", fontsize=13)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"    Saved figure: {out_path.name}")


def write_model_csv(comps, summed_stats, hx_stats, cr, meta, R, y_tot, path):
    """
    Write the model comparison for one basis: one row per PARAMETER, across
    both models, with the model-level statistics and the 1 kcal/mol
    crossings repeated on every row.

    WHY THE COMPONENT PARAMETERS ARE HERE. The summed model is not fitted,
    so it has no parameters of its own -- it is the three component fits
    evaluated and added. Writing those nine numbers into this file makes it
    self-contained AND checkable: they must equal the values in
    2b_bsse_scf/fit_csv/, 2b_bsse_mp2c/fit_csv/ and
    2b_bsse_ccsd_tc/fit_csv/. If they ever diverge, the summed model was
    built from different fits than the ones reported per component, and the
    two files disagreeing is how that would be caught.

    `n_par_fitted_to_total` IS THE POINT OF THE COMPARISON: 0 for the summed
    model, 2 for Heindel-Xantheas. The RMSE comparison is therefore NOT
    like-for-like, and the column exists so that no table can quote the two
    RMSE values side by side without the parameter counts beside them.
    `like_for_like` states this in words on every row for the same reason.

    NO IMPROVEMENT OR RATIO COLUMN IS WRITTEN. RMSE is descriptive and does
    not discriminate between forms; a stored percentage difference would
    invite exactly the superiority sentence the claim is not making. The two
    RMSE values are stored and any comparison is made explicitly, in prose,
    where it can carry its caveat.

    CROSSINGS are stored per model plus their spread. `crossing_*` is None
    (empty) where the level is never reached -- at aug-cc-pVQZ the computed
    max |total| is below 1 kcal/mol, and an empty cell records that the
    level was not reached rather than that the number is missing;
    `crossing_reached` distinguishes the two.

    Full precision (%.17g); rounding for display is the manuscript's job.
    """
    rows = []
    common = {
        'basis_tag':   meta['tag'],
        'basis_label': meta['label'],
        'nbf':         meta['nbf'],
        'R_min':       float(R.min()),
        'R_max':       float(R.max()),
        'n_points':    int(len(R)),
        'y_total_min': float(y_tot.min()),
        'y_total_max': float(y_tot.max()),
        'max_abs_total': float(np.abs(y_tot).max()),
        'crossing_level_kcal': 1.0,
        'crossing_reached':  'yes' if cr['computed'] is not None else 'no',
        'crossing_computed': ('' if cr['computed'] is None else cr['computed']),
        'crossing_summed':   ('' if cr['summed'] is None else cr['summed']),
        'crossing_hx':       ('' if cr['HX'] is None else cr['HX']),
    }
    vals = [v for v in cr.values() if v is not None]
    common['crossing_spread'] = (max(vals) - min(vals)) if len(vals) > 1 else ''

    # ── summed model: no parameters of its own; carry the component fits ──
    for (col, lab, f, _, _, tex), p in comps:
        names = (['a0', 'a2', 'b'] if col == '2b_bsse_SCF' else ['a', 'c'])
        unit = 'A^-2' if col == '2b_bsse_SCF' else 'A^-1'
        for pname, val in zip(names, p):
            rows.append({
                **common,
                'model':      'summed',
                'model_expr': 'SCF_fit + MP2c_fit + CCSD(T)c_fit',
                'component':  col,
                'component_form': tex,
                'param':      pname,
                'value':      float(val),
                'unit':       (unit if pname == names[-1] else 'kcal/mol'),
                'rmse':       summed_stats['rmse'],
                'r2':         summed_stats['r2'],
                'max_abs_dev': summed_stats['max_abs_dev'],
                'n_par_fitted_to_total': 0,
                'like_for_like': 'no -- 0 parameters fitted to the total',
            })

    # ── Heindel-Xantheas: fitted to the total ────────────────────────────
    for pname, val in zip(['a', 'b'], hx_stats['p']):
        rows.append({
            **common,
            'model':      'hx',
            'model_expr': 'a[1 + erf(-bR)]',
            'component':  '',
            'component_form': '',
            'param':      pname,
            'value':      float(val),
            'unit':       ('A^-1' if pname == 'b' else 'kcal/mol'),
            'rmse':       hx_stats['rmse'],
            'r2':         hx_stats['r2'],
            'max_abs_dev': hx_stats['max_abs_dev'],
            'n_par_fitted_to_total': 2,
            'like_for_like': 'no -- 2 parameters fitted to the total',
        })

    cols = ['basis_tag', 'basis_label', 'nbf', 'model', 'model_expr',
            'component', 'component_form', 'param', 'value', 'unit',
            'rmse', 'r2', 'max_abs_dev', 'n_par_fitted_to_total',
            'like_for_like',
            'R_min', 'R_max', 'n_points', 'y_total_min', 'y_total_max',
            'max_abs_total', 'crossing_level_kcal', 'crossing_reached',
            'crossing_computed', 'crossing_summed', 'crossing_hx',
            'crossing_spread']
    out = pd.DataFrame(rows, columns=cols)

    hdr = (f"# Ne dimer summed component model vs Heindel-Xantheas, "
           f"{meta['label']}\n"
           f"# Window [{R.min():.6g}, {R.max():.6g}] A, {len(R)} points.\n"
           "# The summed model is NOT fitted to the total: it is the three\n"
           "# component fits evaluated and added, 0 new parameters. HX is\n"
           "# fitted to the total with 2. The RMSE comparison is therefore\n"
           "# NOT like-for-like -- see n_par_fitted_to_total.\n"
           "# The claim is EQUIVALENCE, not improvement. No ratio or\n"
           "# percentage-difference column is written, by design.\n"
           "# Crossings are of |BSSE| through 1 kcal/mol, by linear\n"
           "# interpolation between grid points; empty means the level was\n"
           "# never reached (see crossing_reached), not that it is missing.\n"
           "# generated by plot_bsse_model.py from " + meta['csv'] + "\n")
    with open(path, 'w') as fh:
        fh.write(hdr)
        out.to_csv(fh, index=False, float_format='%.17g')
    print(f"    Saved model CSV: {path.name}")


def main():
    ap = argparse.ArgumentParser(
        description="Sum the three fitted BSSE components and compare "
                    "against the computed total and the Heindel-Xantheas "
                    "form.")
    ap.add_argument("--basis", type=str.lower, choices=list(BASES) + ["all"],
                    default="all", metavar="{dz,tz,qz,all}",
                    help="Basis; case-insensitive. Default: all.")
    ap.add_argument("--mode", choices=["all", "csv", "fig"], default="all",
                    help="Which outputs to produce. 'all' (default) writes "
                         "figures and the model CSV; 'csv' writes only the "
                         "CSV, leaving existing figures untouched; 'fig' "
                         "writes only figures. THE FITS RUN EITHER WAY -- "
                         "this selects what is written, not what is "
                         "computed. Under --mode csv the --plot selection "
                         "is ignored.")
    ap.add_argument("--plot", choices=["components", "total", "abs", "all"],
                    default="all",
                    help="Which figure(s), when figures are being written. "
                         "Default: all.")
    ap.add_argument("--direct", action="store_true",
                    help="Also fit the total directly with the 7-parameter "
                         "combined form, and report its identifiability. "
                         "This fit is REJECTED; the option exists to show "
                         "the failure, not to use it.")
    ap.add_argument("--title", action="store_true",
                    help="In-figure suptitle. Off by default.")
    ap.add_argument("--R-min", dest="r_min", type=float, default=None,
                    metavar="R", help="Lower bound of the window (A).")
    ap.add_argument("--R-max", dest="r_max", type=float, default=None,
                    metavar="R", help="Upper bound of the window (A).")
    args = ap.parse_args()

    if (args.r_min is not None and args.r_max is not None
            and args.r_min > args.r_max):
        ap.error(f"--R-min ({args.r_min}) exceeds --R-max ({args.r_max}).")
    parts = []
    if args.r_min is not None:
        parts.append("Rmin" + f"{args.r_min:g}".replace('.', 'p'))
    if args.r_max is not None:
        parts.append("Rmax" + f"{args.r_max:g}".replace('.', 'p'))
    win = ('_' + '_'.join(parts)) if parts else ''

    keys = list(BASES) if args.basis == "all" else [args.basis]

    print(f"\n{'=' * 72}")
    print("  Ne/2_new_v2 — summed component model vs computed total")
    print(f"{'=' * 72}")
    print(f"  Study root : {STUDY_ROOT}")
    print(f"  Figure dir : {FIG_DIR}")
    print(f"  Bases      : {', '.join(BASES[k]['tag'] for k in keys)}")
    print("  Model      : SCF_fit + MP2c_fit + CCSD(T)c_fit  "
          "(no refitting, 0 new parameters)")
    mode_desc = {'all': 'figures + model CSV',
                 'csv': 'model CSV only, figures untouched',
                 'fig': 'figures only, CSVs untouched'}[args.mode]
    print(f"  Mode       : {args.mode}   ({mode_desc})")
    print(f"{'=' * 72}")

    if not CSV_DIR.is_dir():
        sys.exit(f"\nNo data_frames directory at {CSV_DIR}.\n"
                 f"This script expects to be in bsse/fit/scripts/ "
                 f"(three levels below the study root).")

    crossings = {}

    for k in keys:
        meta = BASES[k]
        path = CSV_DIR / meta['csv']
        if not path.is_file():
            sys.exit(f"No CSV at {path}. Run build_bsse_csv.py first.")
        df = pd.read_csv(path).sort_values('R').reset_index(drop=True)
        if args.r_min is not None:
            df = df[df['R'] >= args.r_min]
        if args.r_max is not None:
            df = df[df['R'] <= args.r_max]
        df = df.reset_index(drop=True)
        if len(df) < 8:
            sys.exit(f"Window leaves {len(df)} points; too few.")

        R = df['R'].to_numpy(); y_tot = df['total_bsse'].to_numpy()
        out_dir = FIG_DIR / meta['tag']
        if args.mode in ('all', 'fig'):
            out_dir.mkdir(parents=True, exist_ok=True)
        if args.mode in ('all', 'csv'):
            CSV_OUT_DIR.mkdir(parents=True, exist_ok=True)

        print(f"\n  {meta['label']} ({meta['nbf']} bf) — {len(df)} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A")
        print(f"    {'-' * 66}")

        comps = []
        for spec in COMPONENTS:
            col, lab, f, seeds, _, tex = spec
            y = df[col].to_numpy()
            p, perr, cov, rm = fit_one(f, R, y, seeds)
            comps.append((spec, p))
            sgn = 'positive' if float(np.mean(y)) > 0 else 'negative'
            print(f"    {lab:<15} {tex:<26} RMSE {rmse_txt(rm)}  ({sgn})")

        summed = sum(f(R, *p) for (_, _, f, _, _, _), p in comps)
        resid = y_tot - summed
        rm_sum = float(np.sqrt(np.mean(resid**2)))
        ss_tot = float(np.sum((y_tot - y_tot.mean())**2))
        r2_sum = 1.0 - float(np.sum(resid**2)) / ss_tot

        hx_p, hx_e, hx_cov, rm_hx = fit_one(f_hx, R, y_tot, SEEDS_HX)
        hx_pred = f_hx(R, *hx_p)
        r2_hx = 1.0 - float(np.sum((y_tot - hx_pred)**2)) / ss_tot

        print(f"    {'-' * 66}")
        print(f"    summed model   : RMSE {rmse_txt(rm_sum)} kcal/mol   "
              f"R^2 {r2_sum:.6f}   0 new par.")
        print(f"                     max |deviation| "
              f"{rmse_txt(float(np.abs(resid).max()))} kcal/mol")
        print(f"    Heindel-Xantheas: RMSE {rmse_txt(rm_hx)} kcal/mol   "
              f"R^2 {r2_hx:.6f}   2 par. fitted TO the total")
        print("    NOTE: the summed model was never fitted to the total; "
              "HX was. Not a like-for-like RMSE.")

        # 1 kcal/mol crossing, on magnitudes
        cr = {}
        cr['computed'] = crossing(R, np.abs(y_tot))
        cr['summed']   = crossing(R, np.abs(summed))
        cr['HX']       = crossing(R, np.abs(hx_pred))
        crossings[meta['tag']] = cr
        print(f"    {'-' * 66}")
        if all(v is None for v in cr.values()):
            print(f"    1 kcal/mol crossing: NOT REACHED on this grid "
                  f"(max |total| = {np.abs(y_tot).max():.3f} kcal/mol)")
        else:
            for kk, v in cr.items():
                print(f"    1 kcal/mol crossing, {kk:<9}: "
                      + (f"{v:.4f} A" if v is not None else "not reached"))
            vals = [v for v in cr.values() if v is not None]
            if len(vals) > 1:
                print(f"    spread across models: "
                      f"{max(vals) - min(vals):.4f} A")

        if args.mode in ("all", "csv"):
            write_model_csv(
                comps,
                {'rmse': rm_sum, 'r2': r2_sum,
                 'max_abs_dev': float(np.abs(resid).max())},
                {'p': hx_p, 'rmse': rm_hx, 'r2': r2_hx,
                 'max_abs_dev': float(np.abs(y_tot - hx_pred).max())},
                cr, meta, R, y_tot,
                CSV_OUT_DIR / f"model_total_{meta['tag']}{win}.csv")

        if args.direct:
            seeds = [list(comps[0][1]) + list(comps[1][1]) + list(comps[2][1]),
                     [-1, 0, .5, -2, 2, -1, 1.5],
                     [-.2, -.03, .4, -20, 2.3, -1, 1.5]]
            p, perr, cov, rm = fit_one(f_direct, R, y_tot, seeds)
            mx = max(abs(e / v) if v else np.inf for v, e in zip(p, perr))
            print(f"    {'-' * 66}")
            print("    REJECTED direct 7-parameter fit of the total:")
            print(f"      RMSE {rmse_txt(rm)} kcal/mol   "
                  f"max sigma/|p| = {mx:.1f}   cond(cov) = "
                  f"{np.linalg.cond(cov):.1e}")
            print("      Two free exponentials are nearly collinear; the "
                  "parameters carry no information.")

        if args.mode in ("all", "fig") and args.plot in ("components", "all"):
            figure_components(R, y_tot, comps, summed, meta,
                              out_dir / f"model_components_"
                                        f"{meta['tag']}{win}.png",
                              args.title)
        if args.mode in ("all", "fig") and args.plot in ("abs", "all"):
            figure_abs(R, y_tot, summed, hx_pred, rm_sum, rm_hx, cr, meta,
                       out_dir / f"model_abs_{meta['tag']}{win}.png",
                       args.title)
        if args.mode in ("all", "fig") and args.plot in ("total", "all"):
            figure_total(R, y_tot, summed, hx_p, hx_pred, rm_sum, rm_hx,
                         r2_sum, r2_hx, meta,
                         out_dir / f"model_total_{meta['tag']}{win}.png",
                         args.title)

    if len(crossings) > 1:
        print("\n  1 kcal/mol crossing across bases (A)")
        print(f"  {'-' * 56}")
        print(f"  {'basis':<8}{'computed':>14}{'summed':>14}{'HX':>14}")
        for tag, cr in crossings.items():
            row = ''.join(f"{(f'{v:.4f}' if v is not None else '-'):>14}"
                          for v in (cr['computed'], cr['summed'], cr['HX']))
            print(f"  {tag:<8}{row}")
        print(f"  {'-' * 56}")
    print()


if __name__ == '__main__':
    main()
