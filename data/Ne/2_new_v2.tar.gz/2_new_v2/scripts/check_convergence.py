#!/usr/bin/env python3
"""
check_convergence.py — Verify Ne/2_new_v2 radial-scan NWChem output files
                      converged AND carry every field the downstream parsers
                      need, then report wallclock timing.

Location:  bsse_db/data/Ne/2_new_v2/scripts/
Input:     bsse_db/data/Ne/2_new_v2/R_config/<NNN>_R_<label>/CCSD_T/<basis>/*.out

Changes from v1
---------------
  1. Grid is 50 points on [1.5, 3.5] (v1: 100 points on [1.5, 4.5]).
  2. Three bases per R, so the expected file count is 50 x 3 x 4 = 600
     (v1: 100 x 1 x 4 = 400). New --basis flag.
  3. New SOFT check on the applied SCF convergence threshold (see below).

Per .out file, five label lines must be present and parseable. These are
exactly the quantities the downstream parsers consume — nothing more:

    1. "Total SCF energy ="        -> SCF component
    2. "Total MP2 energy:"         -> MP2_comp = MP2 - SCF
    3. "Total CCSD(T) energy:"     -> CCSD_T_comp = CCSD(T) - MP2   (also the
                                      completion signal: it prints only after
                                      SCF -> MP2 -> CCSD -> (T) all finish)
    4. "One-electron energy ="     -> E_1e
    5. "Two-electron energy ="     -> E_2e

Nuclear repulsion is intentionally NOT checked: no parser reads it, and for
A_A it is identically zero. We gate only on fields a parser actually uses.

SCF threshold check (soft)
--------------------------
generate_nw_inputs.py writes an `scf` block requesting `thresh 1.0e-8`. If
that block were malformed or ignored, every job would still run and still
produce all five fields — the failure would be silent, and would only show up
much later as unexplained scatter. This script therefore also looks for the
threshold NWChem reports it is using, and compares it against the request.

    ok        : reported threshold matches the request
    mismatch  : reported threshold differs -> WARNED, not failed
    unknown   : the line was not found -> reported once, not failed

It is deliberately non-fatal. THRESH_PATTERNS below holds the regex confirmed
against NWChem 7.2.0 output on 29 July 2026, matching the line:

    " Convergence threshold     :          1.000E-08"

A file where the line is absent reports `thresh=?` and is never failed on
that basis alone.

Status buckets (per file):
    ok         : all five fields present
    incomplete : CCSD(T) present (run finished) but >=1 of the other four
                 fields missing — the exact missing field(s) are named.
    failed     : CCSD(T) energy absent (crash/kill) or an NWChem task-failure
                 marker present.
    missing    : no .out file on disk.

Usage:
    python3 check_convergence.py                        # all 600 files
    python3 check_convergence.py --basis aug-cc-pvqz    # one basis (200)
    python3 check_convergence.py --R 2p439              # one R, all bases (12)
    python3 check_convergence.py --R 2p439 --basis aug-cc-pvqz   # one leaf (4)
    python3 check_convergence.py --summary              # counts + timing only
    python3 check_convergence.py --failed               # only non-ok files

Expected file counts:
    per leaf :   4  (A_A, AB_AB, A_AB, B_AB)
    per basis: 200  (50 R x 4)
    total    : 600  (50 R x 3 bases x 4)
"""

import re
import sys
import argparse
from pathlib import Path

import numpy as np

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR   = SCRIPT_DIR.parent / 'R_config'

# ── Grid (single source of truth, matches generate_nw_inputs.py) ──────────────
R_VALUES = np.linspace(1.5, 3.5, 50)

METHOD_DIR = 'CCSD_T'
BASES = ('aug-cc-pvdz', 'aug-cc-pvtz', 'aug-cc-pvqz')


def r_to_label(r: float) -> str:
    """1.5408163265 -> '1p541' (3-decimal folder label)."""
    return f'{r:.3f}'.replace('.', 'p')


R_LABELS = [r_to_label(r) for r in R_VALUES]

# Expected file keys per leaf
NW_KEYS = ['A_A', 'AB_AB', 'A_AB', 'B_AB']

# The five required label lines (verbatim NWChem 7.2.0 strings). Order matters
# only for display. "Total CCSD(T) energy:" is matched exactly so it is not
# confused with "Total CCSD energy:" or "Total CCSD+T(CCSD) energy:".
FIELD_CCSDT = 'Total CCSD(T) energy:'
FIELD_SCF   = 'Total SCF energy ='
FIELD_MP2   = 'Total MP2 energy:'
FIELD_1E    = 'One-electron energy ='
FIELD_2E    = 'Two-electron energy ='

# The four non-CCSD(T) fields, checked once CCSD(T) confirms the run finished.
OTHER_FIELDS = [
    ('SCF', FIELD_SCF),
    ('MP2', FIELD_MP2),
    ('1e',  FIELD_1E),
    ('2e',  FIELD_2E),
]

# NWChem timing regex: "Total times  cpu:  0.5s  wall:  0.6s"
WALL_RE = re.compile(r'Total times\s+cpu:\s+([\d.]+)s\s+wall:\s+([\d.]+)s')

# ── SCF threshold (soft check) ────────────────────────────────────────────────
# The value requested in generate_nw_inputs.py's SCF_BLOCK.
REQUESTED_THRESH = 1.0e-8

# Relative tolerance when comparing the reported threshold to the request.
THRESH_RTOL = 1e-3

# Pattern confirmed against NWChem 7.2.0 output (29 Jul 2026), line format:
#     " Convergence threshold     :          1.000E-08"
# Confirmed on an SCF-only job; re-verify once a CCSD(T) .out is available.
THRESH_PATTERNS = [
    re.compile(r'Convergence threshold\s*[:=]\s*([\d.]+[DdEe][+-]?\d+)'),
]


def _has(content: str, label: str) -> bool:
    """Presence test for a verbatim label line."""
    return label in content


def _fortran_float(text: str) -> float:
    """Parse a Fortran-style float, e.g. '1.000D-08' -> 1e-08."""
    return float(text.replace('D', 'E').replace('d', 'e'))


def extract_thresh(content: str):
    """
    Return the SCF convergence threshold NWChem reports, or None if no
    candidate pattern matched.
    """
    for pat in THRESH_PATTERNS:
        m = pat.search(content)
        if m:
            try:
                return _fortran_float(m.group(1))
            except ValueError:
                continue
    return None


# ── Per-file check ────────────────────────────────────────────────────────────
def check_output_file(filepath: Path):
    """
    Returns (status, missing_fields, wall_time, thresh, message):
        status         : 'ok' | 'incomplete' | 'failed' | 'missing'
        missing_fields : list[str] short names of absent fields
        wall_time      : float seconds or None
        thresh         : float reported SCF threshold, or None if not found
        message        : description for failed
    """
    if not filepath.exists():
        return 'missing', [], None, None, 'output file not found'

    content = filepath.read_text(errors='replace')

    # Wall time (independent of status; report whatever we can extract)
    m = WALL_RE.search(content)
    wall = float(m.group(2)) if m else None

    thresh = extract_thresh(content)

    # Hard failure: explicit NWChem task-failure marker.
    if 'task  ccsd(t)  energy  failed' in content.lower():
        return 'failed', [], wall, thresh, 'NWChem task failed'

    # Completion signal: the CCSD(T) total energy line.
    if not _has(content, FIELD_CCSDT):
        if 'ccsd(t)' in content.lower():
            return 'failed', [], wall, thresh, 'job likely killed (no CCSD(T) energy)'
        return 'failed', [], wall, thresh, 'no CCSD(T) energy found'

    # CCSD(T) present -> run finished. Now confirm the other four fields the
    # parsers read are individually present (not merely inferred).
    missing = [short for short, label in OTHER_FIELDS if not _has(content, label)]
    if missing:
        return 'incomplete', missing, wall, thresh, ''

    return 'ok', [], wall, thresh, ''


# ── Resolve which leaves to walk ──────────────────────────────────────────────
def resolve_r_dir(r_label: str):
    """Glob the bare label to its NNN-prefixed folder. Returns Path or None."""
    matches = sorted(BASE_DIR.glob(f'*_R_{r_label}'))
    if len(matches) == 1:
        return matches[0]
    return None


def iter_expected_files(r_label: str, basis: str, job_key=None):
    """Yield (nw_key, out_path) for one (R, basis) leaf.

    job_key restricts the yield to a single file type; None yields all four.
    """
    keys = [job_key] if job_key else NW_KEYS
    r_dir = resolve_r_dir(r_label)
    if r_dir is None:
        # Folder missing entirely: yield the expected-but-absent paths so
        # they register as 'missing'.
        for key in keys:
            yield key, (BASE_DIR / f'???_R_{r_label}' / METHOD_DIR / basis
                        / f'{key}.out')
        return
    nw_dir = r_dir / METHOD_DIR / basis
    for key in keys:
        yield key, nw_dir / f'{key}.out'


# ── Check one leaf ────────────────────────────────────────────────────────────
def check_leaf(r_label: str, basis: str, show_ok: bool, show_problem: bool,
               job_key=None, show_missing: bool = True):
    """Check the files of one (R, basis) leaf.

    job_key      : restrict to a single file type.
    show_missing : when False, absent .out files are not listed individually.
                   Used by --progress, where most files are legitimately
                   pending rather than problematic.
    """
    results = {'ok': [], 'incomplete': [], 'failed': [], 'missing': []}
    wall_times = []
    thresh_seen = []

    for nw_key, out_path in iter_expected_files(r_label, basis, job_key):
        status, missing, wall, thresh, message = check_output_file(out_path)
        results[status].append((nw_key, missing, wall, thresh, message))
        if wall is not None:
            wall_times.append(wall)
        if thresh is not None:
            thresh_seen.append((nw_key, thresh))

        label = f'{basis}/R_{r_label}/{nw_key}'
        if status == 'ok':
            if show_ok:
                wall_str = f'{wall:7.1f}s' if wall is not None else '    —   '
                if thresh is None:
                    t_str = 'thresh=?'
                elif abs(thresh - REQUESTED_THRESH) <= THRESH_RTOL * REQUESTED_THRESH:
                    t_str = 'thresh✓'
                else:
                    t_str = f'thresh={thresh:.1e}!'
                print(f'  ✅  {label:<44s}  5/5 fields  {t_str:<14s} wall={wall_str}')
        elif status == 'incomplete':
            if show_problem:
                miss = ' '.join(f'{s}✗' for s in missing)
                print(f'  ✗   {label:<44s}  converged but MISSING: {miss}')
        elif status == 'failed':
            if show_problem:
                print(f'  ❌  {label:<44s}  FAILED — {message}')
        elif status == 'missing':
            if show_problem and show_missing:
                print(f'  ⏳  {label:<44s}  missing (.out not found)')

    return results, wall_times, thresh_seen


# ── Summary printing ──────────────────────────────────────────────────────────
def print_summary(title, counts, expected, wall_times, thresh_seen,
                  thresh_unknown, progress=False):
    n_ok, n_inc, n_fail, n_miss = (counts['ok'], counts['incomplete'],
                                   counts['failed'], counts['missing'])
    if progress:
        # Missing means "not run yet"; clean = nothing that DID run is broken.
        clean = (n_inc == 0 and n_fail == 0)
    else:
        clean = (n_ok == expected and n_inc == 0
                 and n_fail == 0 and n_miss == 0)
    flag = '✅' if clean else '✗'

    print(f"{'─' * 74}")
    print(f"  {title}   {flag}")
    if progress and expected:
        pct = 100.0 * n_ok / expected
        print(f"  📊  progress          : {n_ok:>5} / {expected}  ({pct:.1f}%)")
    print(f"  ✅  ok (all 5 fields) : {n_ok:>5}   (expected {expected})")
    print(f"  ✗   incomplete        : {n_inc:>5}")
    print(f"  ❌  failed            : {n_fail:>5}")
    label_miss = 'pending' if progress else 'missing'
    print(f"  ⏳  {label_miss:<18s}: {n_miss:>5}")

    if wall_times:
        w_sum = sum(wall_times)
        print(f"  ⏱  walls (n={len(wall_times)}): "
              f"sum={w_sum:.1f}s ({w_sum/3600:.2f} h)  "
              f"mean={w_sum/len(wall_times):.1f}s  "
              f"min={min(wall_times):.1f}s  max={max(wall_times):.1f}s")

    # SCF threshold report
    if thresh_seen:
        bad = [(k, t) for k, t in thresh_seen
               if abs(t - REQUESTED_THRESH) > THRESH_RTOL * REQUESTED_THRESH]
        if bad:
            print(f"  ⚠️   SCF threshold MISMATCH in {len(bad)} file(s) "
                  f"(requested {REQUESTED_THRESH:.1e}):")
            for k, t in bad[:5]:
                print(f"         {k}: reported {t:.3e}")
            if len(bad) > 5:
                print(f"         ... and {len(bad) - 5} more")
        else:
            print(f"  ✅  SCF threshold {REQUESTED_THRESH:.1e} confirmed in "
                  f"{len(thresh_seen)} file(s)")
    if thresh_unknown:
        print(f"  ⚠️   SCF threshold line not found in {thresh_unknown} file(s) "
              f"— pattern expects 'Convergence threshold : <value>'")


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description='Check convergence + required parser fields + timing for '
                    'Ne/2_new_v2 NWChem outputs.'
    )
    parser.add_argument('--R', type=str, default=None, choices=R_LABELS,
                        metavar='LABEL',
                        help='R folder to check (e.g. 2p439). Omit for all 50.')
    parser.add_argument('--basis', type=str, default=None, choices=BASES,
                        metavar='NAME',
                        help=f'Basis to check. One of: {", ".join(BASES)}. '
                             f'Omit for all three.')
    parser.add_argument('--job', type=str, default=None, choices=NW_KEYS,
                        metavar='KEY',
                        help=f'Job type to check. One of: {", ".join(NW_KEYS)}. '
                             f'Omit for all four.')
    parser.add_argument('--summary', action='store_true',
                        help='Show only summary counts + timing.')
    parser.add_argument('--failed', action='store_true',
                        help='Show only non-ok files (incomplete/failed/missing).')
    parser.add_argument('--progress', action='store_true',
                        help='Progress mode: treat absent .out files as PENDING '
                             'rather than problems. Missing files are counted '
                             'but not listed, and the exit status ignores them. '
                             'Use this while a batch is still running.')
    args = parser.parse_args()

    show_ok      = not args.summary and not args.failed
    show_problem = not args.summary

    labels = [args.R] if args.R is not None else R_LABELS
    bases  = [args.basis] if args.basis is not None else list(BASES)

    grand = {'ok': 0, 'incomplete': 0, 'failed': 0, 'missing': 0}
    grand_walls = []
    grand_thresh = []
    grand_unknown = 0
    any_problem = False

    for basis in bases:
        b_counts = {'ok': 0, 'incomplete': 0, 'failed': 0, 'missing': 0}
        b_walls = []
        b_thresh = []
        b_unknown = 0

        if not args.summary:
            print(f"\n{'═' * 74}")
            print(f"  basis: {basis}")
            print(f"{'═' * 74}")

        for r_label in labels:
            results, walls, thresh_seen = check_leaf(
                r_label, basis, show_ok, show_problem,
                job_key=args.job, show_missing=not args.progress)

            for k in b_counts:
                b_counts[k] += len(results[k])
            b_walls.extend(walls)
            b_thresh.extend(thresh_seen)
            # Threshold is only meaningful for files that actually ran. A
            # missing or crashed job has no SCF block output to report, so
            # counting it as "unknown" would be noise.
            n_ran = len(results['ok']) + len(results['incomplete'])
            b_unknown += n_ran - len(thresh_seen)

            # In progress mode a missing .out means "not run yet", which is
            # not a problem to be flagged.
            problems = results['incomplete'] or results['failed']
            if not args.progress:
                problems = problems or results['missing']
            if problems:
                any_problem = True

        n_keys = 1 if args.job else len(NW_KEYS)
        print_summary(f'basis {basis}', b_counts,
                      len(labels) * n_keys, b_walls, b_thresh, b_unknown,
                      progress=args.progress)

        for k in grand:
            grand[k] += b_counts[k]
        grand_walls.extend(b_walls)
        grand_thresh.extend(b_thresh)
        grand_unknown += b_unknown

    if len(bases) > 1 or len(labels) > 1:
        n_keys = 1 if args.job else len(NW_KEYS)
        expected = len(labels) * len(bases) * n_keys
        print(f"\n{'═' * 74}")
        print_summary('GRAND TOTAL', grand, expected,
                      grand_walls, grand_thresh, grand_unknown,
                      progress=args.progress)
        print(f"{'═' * 74}")

    if not any_problem:
        if args.progress and grand['missing']:
            print(f"\nNothing broken so far; {grand['missing']} file(s) still "
                  f"pending ⏳")
        else:
            print("\nAll files converged with all five parser fields present ✅")
        sys.exit(0)
    else:
        print("\nSome files need attention (see ✗ / ❌ above)")
        sys.exit(1)


if __name__ == '__main__':
    main()
