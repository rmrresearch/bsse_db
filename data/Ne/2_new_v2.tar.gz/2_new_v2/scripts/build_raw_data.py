#!/usr/bin/env python3
"""
build_raw_data.py — Ne/2_new_v2 (dimer radial-scan study, three bases)
=====================================================================

Parser for the NWChem CCSD(T) output files produced by the Ne/2_new_v2 study
(uniform radial scan of the Ne-Ne separation R, at three basis sets).

Purpose
-------
Dynamically discover all NWChem .out files under R_config/, extract SCF, MP2,
and CCSD(T) total energies, and store them in a nested dict mirroring the
on-disk structure. Pickle the result for downstream use.

Changes from v1
---------------
  1. GRID. 50 uniform points on [1.5, 3.5] (v1: 100 on [1.5, 4.5]).

  2. THREE BASES. aug-cc-pVDZ, aug-cc-pVTZ, aug-cc-pVQZ. The basis was
     already a level in the v1 dict, so the SHAPE is unchanged — only more
     than one basis key is now populated.

  3. EXCLUSION UNIT IS THE (R, basis) LEAF, NOT THE R VALUE.
     This is the one behavioural change worth reading carefully.

     v1 excluded an entire R if any of its 4 files failed to parse. With one
     basis that was right. With three it is not: a QZ job killed on walltime
     would delete the perfectly good DZ data for the same R. Each (R, basis)
     leaf is therefore committed or excluded on its own.

  4. PER-BASIS MERGE. --basis re-parses one basis and merges it into the
     existing pickle, leaving the others untouched. Combined with --R, the
     merge unit is a single leaf. This is what makes one pickle sufficient:
     DZ can be parsed while QZ is still queued.

Directory structure expected
----------------------------
Run from bsse_db/data/Ne/2_new_v2/scripts/. The parser walks:

    data/Ne/2_new_v2/R_config/<NNN>_R_<label>/CCSD_T/<basis>/*.out

where:
    <NNN>      — zero-padded 1-based grid index, "001" through "050"
    <label>    — 3-decimal 'p' label of the grid point (e.g. 1p500, 2p439)
    <basis>    — aug-cc-pvdz | aug-cc-pvtz | aug-cc-pvqz
    file key   — one of A_A, AB_AB, A_AB, B_AB

R precision
-----------
The 3-decimal folder label is a ROUNDED human-readable tag, not the computed
geometry: the grid is np.linspace(1.5, 3.5, 50) with step 0.040816..., so
folder '002_R_1p541' has true R = 1.5408163265306123 A.

R is therefore recovered from the grid itself, indexed by the <NNN> folder
prefix, which IS the 1-based grid index by construction (see
generate_nw_inputs.py, which defines the same grid and writes full-precision
coordinates into the .nw files). The label is used only to locate folders.

Energies extracted per .out file
--------------------------------
Using the LAST occurrence of each pattern:
    E_scf   : total SCF energy      (Ha)
    E_mp2   : total MP2 energy      (Ha)
    E_ccsdt : total CCSD(T) energy  (Ha)

Then stored per PI Task List (incremental convention):
    SCF             = E_scf
    MP2_corcomp     = E_mp2   - E_scf     (MP2 correlation energy)
    CCSD_T_corcomp  = E_ccsdt - E_mp2     (CCSD(T) correlation component)

The CCSD(T) pattern matches the literal string "CCSD(T)" and therefore does
not collide with the "Total CCSD energy:" and "Total CCSD+T(CCSD) energy:"
lines that also appear in every output file.

Output data structures
----------------------
raw_data['R_config']['R_<label>']['CCSD_T'][<basis>][file_key]
    -> {'SCF': float, 'MP2_corcomp': float, 'CCSD_T_corcomp': float}   (Ha)

raw_data_noconv['R_config']['R_<label>'][<basis>]['failures']
    -> list of dicts recording which components were missing from which file.
       A (R, basis) leaf with ANY missing energy is EXCLUDED from raw_data.
       NOTE the extra <basis> level relative to v1.

parameters['R_config']['R_<label>']
    -> {'R': float, 'grid_index': int}
       Basis-independent, so stored once per R. Populated when at least one
       basis parses completely for that R.

Output pickle
-------------
ONE pickle for the whole study, all three bases, saved to:
    Ne/2_new_v2/R_config_pickle_data/raw_data.pickle

Contents:
    {'raw_data': ..., 'raw_data_noconv': ..., 'parameters': ...}

Symmetry diagnostic
-------------------
For the homonuclear Ne-Ne dimer, A_AB and B_AB are the same calculation up to
labelling, so their energies should agree to numerical precision. Reported
per basis as the max deviation over all R. DIAGNOSTIC ONLY — never fails the
parse: the tolerance at which a deviation becomes meaningful has not been
locked, and reporting keeps that decision with the user.

Usage
-----
    cd bsse_db/data/Ne/2_new_v2/scripts

    python3 build_raw_data.py                          # all R, all bases
    python3 build_raw_data.py --basis aug-cc-pvdz      # one basis, merged
    python3 build_raw_data.py --R 2p439                # one R, all bases
    python3 build_raw_data.py --R 2p439 --basis aug-cc-pvqz   # one leaf
    python3 build_raw_data.py --force                  # rebuild from scratch

Notes
-----
- Raw .out files are PRESERVED. This script only reads them.
- Re-runnable at any time; new .out files are picked up automatically.
"""

import re
import pickle
import argparse
from pathlib import Path

import numpy as np


# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR  = Path(__file__).resolve().parent
BASE_DIR    = SCRIPT_DIR.parent / 'R_config'
PICKLE_DIR  = SCRIPT_DIR.parent / 'R_config_pickle_data'
PICKLE_NAME = 'raw_data.pickle'

# ── Grid (single source of truth, matches generate_nw_inputs.py) ──────────────
R_MIN = 1.5
R_MAX = 3.5
N_POINTS = 50
R_VALUES = np.linspace(R_MIN, R_MAX, N_POINTS)

# Top-level key mirrors the on-disk folder name.
CONFIG_KEY = 'R_config'

# 4 expected file keys per (R, basis) leaf
FILE_KEYS = ['A_A', 'AB_AB', 'A_AB', 'B_AB']

# Component keys (naming locked to match HF/2_new and H2O/2_new)
COMP_KEYS = ['SCF', 'MP2_corcomp', 'CCSD_T_corcomp']

METHOD_KEY = 'CCSD_T'
BASES = ('aug-cc-pvdz', 'aug-cc-pvtz', 'aug-cc-pvqz')


# ── Regex patterns (reused verbatim from the v1 parser) ──────────────────────
SCF_PATTERN   = re.compile(r"Total\s+SCF\s+energy\s*[:=]\s*([\-0-9.+Ee]+)")
MP2_PATTERN   = re.compile(r"Total\s+MP2\s+energy\s*[:=]\s*([\-0-9.+Ee]+)")
CCSDT_PATTERN = re.compile(r"Total\s+CCSD\(T\)\s+energy\s*[:=]\s*([\-0-9.+Ee]+)")


# ── Grid helpers ──────────────────────────────────────────────────────────────
def r_to_label(r: float) -> str:
    """1.5408163265 -> '1p541' (3-decimal folder label)."""
    return f'{r:.3f}'.replace('.', 'p')


ALL_R_LABELS = [r_to_label(r) for r in R_VALUES]


def folder_name(index0: int) -> str:
    """0-based grid index -> '<NNN>_R_<label>'. 0 -> '001_R_1p500'."""
    return f'{index0 + 1:03d}_R_{r_to_label(R_VALUES[index0])}'


def index_of_label(r_label: str) -> int:
    """0-based grid index for a 3-decimal label. Raises if not a grid point."""
    return ALL_R_LABELS.index(r_label)


# ── Parsing helpers ───────────────────────────────────────────────────────────
def extract_last(pattern, text):
    """
    Return the last float matched by `pattern` in `text`, or None.

    Using the LAST occurrence handles NWChem output files where energies are
    printed multiple times during iterative convergence; the final printed
    value is always the converged result.
    """
    value = None
    for line in text.splitlines():
        m = pattern.search(line)
        if m:
            try:
                value = float(m.group(1))
            except ValueError:
                pass
    return value


def ensure_path(d, keys):
    """Ensure a chain of nested dicts exists and return the deepest one."""
    cur = d
    for k in keys:
        cur = cur.setdefault(k, {})
    return cur


def missing_energies(E_scf, E_mp2, E_ccsdt):
    """Return a list of labels for missing energy components."""
    missing = []
    if E_scf   is None: missing.append('SCF')
    if E_mp2   is None: missing.append('MP2')
    if E_ccsdt is None: missing.append('CCSD(T)')
    return missing


# ── Core builder (per leaf) ───────────────────────────────────────────────────
def build_leaf(r_label, basis, verbose=True):
    """
    Parse the 4 .out files for a single (R, basis) leaf.

    Returns
    -------
    (committed, components, failures) : (bool, dict, list)
        committed  : True iff all 4 files parsed completely.
        components : {file_key: {comp: float}} — empty if not committed.
        failures   : list of failure records for this leaf.
    """
    failures = []
    index0 = index_of_label(r_label)
    r_dir = BASE_DIR / folder_name(index0)

    if not r_dir.is_dir():
        failures.append({
            'missing':  ['directory'],
            'file_key': None,
            'path':     str(r_dir),
            'reason':   'expected R folder missing',
        })
        if verbose:
            print(f"  ⏳  {basis}/R_{r_label}: R folder missing")
        return False, {}, failures

    nw_dir = r_dir / METHOD_KEY / basis
    if not nw_dir.is_dir():
        failures.append({
            'missing':  ['directory'],
            'file_key': None,
            'path':     str(nw_dir),
            'reason':   f'expected {METHOD_KEY}/{basis} directory missing',
        })
        if verbose:
            print(f"  ⏳  {basis}/R_{r_label}: leaf directory missing")
        return False, {}, failures

    bucket = {}
    bad = False

    for file_key in FILE_KEYS:
        out_path = nw_dir / f'{file_key}.out'

        if not out_path.is_file():
            bad = True
            failures.append({
                'missing':  ['file'],
                'file_key': file_key,
                'path':     str(out_path),
                'reason':   '.out file not found',
            })
            continue

        text    = out_path.read_text(errors='replace')
        E_scf   = extract_last(SCF_PATTERN,   text)
        E_mp2   = extract_last(MP2_PATTERN,   text)
        E_ccsdt = extract_last(CCSDT_PATTERN, text)

        if (E_scf is None) or (E_mp2 is None) or (E_ccsdt is None):
            bad = True
            failures.append({
                'missing':  missing_energies(E_scf, E_mp2, E_ccsdt),
                'file_key': file_key,
                'path':     str(out_path),
                'reason':   'missing energy component(s)',
            })
            continue

        bucket[file_key] = {
            'SCF':            E_scf,
            'MP2_corcomp':    E_mp2   - E_scf,
            'CCSD_T_corcomp': E_ccsdt - E_mp2,
        }

    if bad or set(bucket.keys()) != set(FILE_KEYS):
        if not bad:
            missing_files = sorted(set(FILE_KEYS) - set(bucket.keys()))
            failures.append({
                'missing':  ['file(s)'],
                'file_key': missing_files,
                'path':     None,
                'reason':   f'incomplete file set (missing: {missing_files})',
            })
        if verbose:
            print(f"  ⚠️   {basis}/R_{r_label}: EXCLUDED "
                  f"({len(failures)} failure(s))")
        return False, {}, failures

    if verbose:
        print(f"  ✅  {basis}/R_{r_label}: R = {R_VALUES[index0]:.10f} A, "
              f"4/4 files parsed")

    return True, bucket, failures


# ── Symmetry diagnostic ───────────────────────────────────────────────────────
def report_symmetry(raw_data, bases, verbose=True):
    """
    Report the max |A_AB - B_AB| deviation per component, per basis.

    For the homonuclear Ne-Ne dimer these are the same calculation up to
    labelling. DIAGNOSTIC ONLY — never fails the parse.
    """
    entries = raw_data.get(CONFIG_KEY, {})
    if not entries:
        return {}

    out = {}
    for basis in bases:
        worst = {c: (0.0, None) for c in COMP_KEYS}
        n = 0
        for r_key, node in entries.items():
            leaf = node.get(METHOD_KEY, {}).get(basis)
            if not leaf or 'A_AB' not in leaf or 'B_AB' not in leaf:
                continue
            n += 1
            for c in COMP_KEYS:
                dev = abs(leaf['A_AB'][c] - leaf['B_AB'][c])
                if dev > worst[c][0]:
                    worst[c] = (dev, r_key)
        out[basis] = worst

        if verbose and n:
            print(f"\n  Symmetry diagnostic  A_AB vs B_AB  "
                  f"[{basis}]  (n = {n} R)")
            print(f"  {'─' * 66}")
            for c in COMP_KEYS:
                dev, r_key = worst[c]
                print(f"    max |Δ{c:<15s}| = {dev:.3e} Ha   at {r_key}")
            print(f"  {'─' * 66}")
            print("    Diagnostic only — no tolerance is enforced.")

    return out


# ── Coverage report ───────────────────────────────────────────────────────────
def report_coverage(payload, verbose=True):
    """Report how many R parsed completely, per basis."""
    entries = payload['raw_data'].get(CONFIG_KEY, {})
    counts = {b: 0 for b in BASES}
    for node in entries.values():
        for b in BASES:
            if node.get(METHOD_KEY, {}).get(b):
                counts[b] += 1

    if verbose:
        print(f"\n  Coverage  (out of {N_POINTS} grid points)")
        print(f"  {'─' * 66}")
        for b in BASES:
            n = counts[b]
            bar = '█' * int(30 * n / N_POINTS)
            print(f"    {b:<14s} {n:>3d}/{N_POINTS}  {bar}")
        print(f"  {'─' * 66}")
    return counts


# ── Pickle I/O ────────────────────────────────────────────────────────────────
def pickle_path():
    return PICKLE_DIR / PICKLE_NAME


def load_pickle():
    """Load the existing study pickle, or return empty containers."""
    p = pickle_path()
    if not p.is_file():
        return {'raw_data': {}, 'raw_data_noconv': {}, 'parameters': {}}
    with open(p, 'rb') as fh:
        return pickle.load(fh)


def save_pickle(payload):
    """Write the single study-wide pickle."""
    PICKLE_DIR.mkdir(parents=True, exist_ok=True)
    p = pickle_path()
    with open(p, 'wb') as fh:
        pickle.dump(payload, fh)
    return p


def merge_leaf(payload, r_label, basis, committed, components, failures):
    """
    Merge one (R, basis) leaf into the study payload, replacing any prior
    entry for that leaf and leaving every other leaf untouched.
    """
    r_key = f'R_{r_label}'
    index0 = index_of_label(r_label)

    # raw_data: replace this basis under this R
    method_node = ensure_path(payload['raw_data'], (CONFIG_KEY, r_key,
                                                    METHOD_KEY))
    method_node.pop(basis, None)
    if committed:
        method_node[basis] = components

    # Drop an R that now holds no bases at all, so empty shells do not linger.
    if not method_node:
        payload['raw_data'][CONFIG_KEY][r_key].pop(METHOD_KEY, None)
        if not payload['raw_data'][CONFIG_KEY][r_key]:
            payload['raw_data'][CONFIG_KEY].pop(r_key, None)

    # raw_data_noconv: replace this basis's failure list under this R
    nc_node = ensure_path(payload['raw_data_noconv'], (CONFIG_KEY, r_key))
    nc_node.pop(basis, None)
    if failures:
        nc_node[basis] = {'failures': failures}
    if not nc_node:
        payload['raw_data_noconv'][CONFIG_KEY].pop(r_key, None)

    # parameters: basis-independent; present iff at least one basis parsed
    par = ensure_path(payload['parameters'], (CONFIG_KEY,))
    still_present = (payload['raw_data'].get(CONFIG_KEY, {})
                     .get(r_key, {}).get(METHOD_KEY))
    if still_present:
        par[r_key] = {
            'R':          float(R_VALUES[index0]),
            'grid_index': index0 + 1,
        }
    else:
        par.pop(r_key, None)


def sort_payload(payload):
    """Reorder every container by ascending grid index for readability."""
    order = {f'R_{lab}': i for i, lab in enumerate(ALL_R_LABELS)}
    for container in ('raw_data', 'raw_data_noconv', 'parameters'):
        node = payload[container].get(CONFIG_KEY)
        if not node:
            continue
        payload[container][CONFIG_KEY] = {
            k: node[k] for k in sorted(node, key=lambda k: order.get(k, 1e9))
        }


# ── CLI ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description='Parse Ne/2_new_v2 NWChem .out files. One pickle for the '
                    'whole study, all three bases.'
    )
    parser.add_argument(
        '--R', type=str, default=None, choices=ALL_R_LABELS, metavar='LABEL',
        help='Single R to (re)parse, e.g. 2p439. Merged into the existing '
             'pickle; every other R is preserved.')
    parser.add_argument(
        '--basis', type=str, default=None, choices=BASES, metavar='NAME',
        help=f'Single basis to (re)parse. One of: {", ".join(BASES)}. '
             f'Merged into the existing pickle; the other bases are preserved.')
    parser.add_argument(
        '--force', action='store_true',
        help='Discard the existing pickle and rebuild from scratch. Without '
             'this, results are merged into whatever is already there.')
    parser.add_argument(
        '--quiet', action='store_true',
        help='Suppress the per-leaf lines; print summaries only.')
    args = parser.parse_args()

    verbose = not args.quiet

    labels = [args.R] if args.R else ALL_R_LABELS
    bases  = [args.basis] if args.basis else list(BASES)

    print(f"\n{'═' * 70}")
    print("  Ne/2_new_v2 raw-data parse")
    print(f"{'═' * 70}")
    print(f"  R_config : {BASE_DIR}")
    print(f"  pickle   : {pickle_path()}")
    print(f"  R values : {len(labels)}")
    print(f"  bases    : {', '.join(bases)}")
    print(f"  mode     : {'REBUILD (--force)' if args.force else 'merge'}")
    print(f"{'═' * 70}\n")

    if not BASE_DIR.is_dir():
        raise SystemExit(f"ERROR: R_config not found at {BASE_DIR}")

    payload = ({'raw_data': {}, 'raw_data_noconv': {}, 'parameters': {}}
               if args.force else load_pickle())

    n_committed = 0
    n_excluded = 0

    for basis in bases:
        if verbose:
            print(f"{'─' * 70}")
            print(f"  {basis}")
            print(f"{'─' * 70}")
        for r_label in labels:
            committed, components, failures = build_leaf(
                r_label, basis, verbose=verbose)
            merge_leaf(payload, r_label, basis, committed, components, failures)
            if committed:
                n_committed += 1
            else:
                n_excluded += 1

    sort_payload(payload)
    out_path = save_pickle(payload)

    report_coverage(payload, verbose=True)
    report_symmetry(payload['raw_data'], bases, verbose=True)

    print(f"\n{'═' * 70}")
    print(f"  leaves committed : {n_committed}")
    print(f"  leaves excluded  : {n_excluded}")
    print(f"  💾  {out_path}")
    print(f"{'═' * 70}\n")


if __name__ == '__main__':
    main()
