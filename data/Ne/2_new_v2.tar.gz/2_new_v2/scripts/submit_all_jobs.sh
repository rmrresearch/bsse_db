#!/bin/bash
# submit_all_jobs.sh
# Orchestrator for Ne/2_new_v2 CCSD(T) VMFC jobs on NOVA.
#
# Layout walked:
#   ~/BSSE/Ne/2_new_v2/R_config/<NNN>_R_<label>/CCSD_T/<basis>/*.nw
#   <basis> in {aug-cc-pvdz, aug-cc-pvtz, aug-cc-pvqz}
#
# Ne is spherical: there is NO orientation layer. Each R folder has three
# basis leaves, each with 4 .nw files.
#
#   50 R x 3 bases x 4 files = 600 jobs
#
# Changes from v1
# ---------------
#   1. Walks the basis level; new --basis flag to submit one basis at a time.
#   2. Passes PER-BASIS --time / --mem / --ntasks at sbatch time (see RESOURCES
#      below). sbatch CLI options override the #SBATCH defaults inside
#      submit_energy.sh, so one script serves all three bases.
#   3. New --dry-run: report what would be submitted without touching the queue.
#      Worth using before any --all run.
#
# For each .nw file with no matching .out, calls:
#   sbatch <per-basis resources> --export=ALL submit_energy.sh <path.nw>
#
# Two sentinel jobs bookend each batch and send email notifications:
#   1. "submitted" fires as soon as it runs.
#   2. "done" fires only after ALL jobs in the batch finish
#      (--dependency=afterany:<comma-separated job IDs>).
# NOTE: SLURM email relay has been observed to drop messages silently. Treat
# the sentinel LOG FILE as the authoritative completion signal, not the email.
#
# Usage:
#   ./submit_all_jobs.sh --R 2p439 --basis aug-cc-pvqz     # 4 jobs, test leaf
#   ./submit_all_jobs.sh --basis aug-cc-pvdz               # 200 jobs, one basis
#   ./submit_all_jobs.sh --R 2p439                         # 12 jobs, all bases
#   ./submit_all_jobs.sh --all                             # 600 jobs
#   ./submit_all_jobs.sh --all --dry-run                   # report only
#
# Skip-existing: any .nw with a matching .out is skipped, so a partial rerun
# after failures only submits the missing jobs.
#
# WARNING on skip-existing: the test is that the .out EXISTS, not that it is
# complete. The shell creates the .out the moment submit_energy.sh opens the
# redirect, so a job killed by walltime, OOM, node failure, scancel, or an
# NWChem crash leaves a truncated file that this script will silently skip on
# a rerun. Between batches run
#     python3 check_convergence.py --basis <name>
# on the laptop, delete the .out files it reports as failed/incomplete, and
# only then resubmit.
#
# Logs: ~/BSSE/Ne/2_new_v2/scripts/<batch_label>_logs/

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
EMAIL="frojas32@iastate.edu"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"                     # ~/BSSE/Ne/2_new_v2
R_CONFIG_DIR="${BASE_DIR}/R_config"
SUBMIT_ENERGY="${SCRIPT_DIR}/submit_energy.sh"

ALL_BASES=(aug-cc-pvdz aug-cc-pvtz aug-cc-pvqz)

# ── RESOURCES (per basis) ─────────────────────────────────────────────────────
# Dimer basis-function counts drive the CCSD(T) cost:
#
#     aug-cc-pvdz :  46 bf
#     aug-cc-pvtz :  92 bf
#     aug-cc-pvqz : 160 bf
#
# ---------------------------------------------------------------------------
# CALIBRATED 29 Jul 2026 — these are no longer estimates.
#
#   Measured NWChem wall times (from the "Total times" line in each .out):
#     DZ : n=200, mean   9.7 s, max  40.5 s   at ntasks=2
#     TZ : n=200, mean 111.5 s, max 231.0 s   at ntasks=2
#     QZ : A_AB 1088.2 s at ntasks=1; peak RSS 594 MB
#
#   QZ estimates scaled from the TZ job-type ratios (A_A is ~12x cheaper than
#   the ghost-bearing jobs; AB_AB ~1.1x A_AB):
#     A_A ~90 s, A_AB/B_AB ~1090 s, AB_AB ~1200 s.  Worst case ~20 min.
#
# ---------------------------------------------------------------------------
# QZ MUST RUN AT ntasks=1.
#
#   At ntasks=2, NWChem 7.2.0 segfaults (exit 139) after 10-13 s inside
#       scf_ -> scf_vectors_guess_ -> scf_lindep_ -> util_scalapack.F:31
#   i.e. the linear-dependence check on the initial guess, in a ScaLAPACK
#   call (the build reports use scalapack = T).
#
#   Reproduced twice, on two different nodes (nova18-wide-4, nova18-wide-9),
#   same binary and same input. The identical job at ntasks=1 completes
#   cleanly in 18 min. DZ and TZ run fine at ntasks=2 (400 jobs, 0 failures),
#   so the trigger is specific to QZ - plausibly a matrix-size threshold above
#   which NWChem routes the diagonalisation through ScaLAPACK, but that
#   threshold is not documented and the mechanism is NOT confirmed.
#
#   NOT a memory problem: the overlap matrix is 160x160 (~200 KB) against a
#   4096 MB global allocation, and peak RSS was 191 MB when it crashed.
#   Raising --mem or the .nw `memory total` will not help.
#
#   NOT a BLAS-threading problem either: --export=ALL,OMP_NUM_THREADS=1 at
#   ntasks=2 gave the same segfault at 12 s (job 11783924, nova18-wide-9).
#
#   Failure log: ntasks=2 crashed 3/3 times (11781452, 11783915, 11783924)
#   on 2 nodes; ntasks=1 succeeded (11783676, 18 min, exit 0).
#
#   Do not set QZ back to ntasks>1 without re-testing a single job first.
# ---------------------------------------------------------------------------
#
#   Two reasons not to simply pad these:
#     - The NOVA docs state that a maximum time much larger than the true
#       runtime makes a job harder to schedule. This matters: the nova
#       partition has run ~4000 jobs deep in the pending queue.
#     - QOSMaxMemoryPerUser is a documented queue-blocking reason; 200
#       simultaneous oversized requests can stall the whole batch.
#
#   Account limits (sacctmgr, twindus-lab): MaxJobs=80, MaxSubmit=5000.
#   Submitting 200 at once is fine; SLURM runs 80 and holds the rest with
#   reason AssocMaxJobsLimit.
#
#   Check the partition's own ceiling before requesting long walltimes:
#       sinfo -p nova
#
#   --mem must exceed  ntasks x (memory total in the .nw)  with headroom.
#   generate_nw_inputs.py writes: DZ none, TZ 4 gb, QZ 8 gb (per MPI process).
# ---------------------------------------------------------------------------

res_time() {
    case "$1" in
        aug-cc-pvdz) echo "01:00:00" ;;
        aug-cc-pvtz) echo "02:00:00" ;;
        aug-cc-pvqz) echo "01:00:00" ;;   # 3x the ~20 min worst case
        *) echo "01:00:00" ;;
    esac
}

res_mem() {
    case "$1" in
        aug-cc-pvdz) echo "20G" ;;
        aug-cc-pvtz) echo "20G" ;;
        aug-cc-pvqz) echo "32G" ;;
        *) echo "20G" ;;
    esac
}

res_ntasks() {
    case "$1" in
        aug-cc-pvdz) echo "2" ;;
        aug-cc-pvtz) echo "2" ;;
        aug-cc-pvqz) echo "1" ;;   # see the ScaLAPACK note above - do not raise
        *) echo "2" ;;
    esac
}

# Short tag for job names, so squeue output stays readable.
basis_tag() {
    case "$1" in
        aug-cc-pvdz) echo "dz" ;;
        aug-cc-pvtz) echo "tz" ;;
        aug-cc-pvqz) echo "qz" ;;
        *) echo "xx" ;;
    esac
}

# ── Parse CLI ─────────────────────────────────────────────────────────────────
R_LABEL=""
BASIS=""
JOB_KEY=""
ALL=0
DRY_RUN=0

ALL_JOB_KEYS=(A_A AB_AB A_AB B_AB)

while [[ $# -gt 0 ]]; do
    case "$1" in
        --R)       R_LABEL="$2"; shift 2 ;;
        --basis)   BASIS="$2";   shift 2 ;;
        --job)     JOB_KEY="$2"; shift 2 ;;
        --all)     ALL=1;        shift 1 ;;
        --dry-run) DRY_RUN=1;    shift 1 ;;
        -h|--help)
            cat <<EOF
Usage: $0 [--R <label>] [--basis <name>] [--job <key>] [--all] [--dry-run]

  --R <label>      restrict to one R, e.g. 1p500, 2p439, 3p500
  --basis <name>   restrict to one basis: ${ALL_BASES[*]}
  --job <key>      restrict to one job type: ${ALL_JOB_KEYS[*]}
  --all            all 50 R and all 3 bases (600 jobs)
  --dry-run        report what would be submitted; touch nothing

  --all is required only when none of --R / --basis / --job is given.

Examples:
  $0 --R 2p439 --basis aug-cc-pvqz --job A_AB   # exactly one job
  $0 --R 2p439 --basis aug-cc-pvqz              # one leaf, 4 jobs
  $0 --basis aug-cc-pvdz                        # one basis, 200 jobs
  $0 --all --dry-run                            # report the full grid
EOF
            exit 0
            ;;
        *) echo "Error: unknown arg $1"; exit 1 ;;
    esac
done

# --all is only needed when nothing else narrows the selection.
if [[ -z "$R_LABEL" && -z "$BASIS" && -z "$JOB_KEY" && "$ALL" -eq 0 ]]; then
    echo "Error: specify at least one of --R, --basis, --job, or --all."
    echo "Run '$0 --help' for usage."
    exit 1
fi

if [[ -n "$JOB_KEY" ]]; then
    valid=0
    for k in "${ALL_JOB_KEYS[@]}"; do
        [[ "$k" == "$JOB_KEY" ]] && valid=1
    done
    if [[ "$valid" -eq 0 ]]; then
        echo "Error: --job must be one of: ${ALL_JOB_KEYS[*]}"
        exit 1
    fi
fi

if [[ ! -d "$R_CONFIG_DIR" ]]; then
    echo "Error: R_config folder not found: $R_CONFIG_DIR"
    exit 1
fi

# ── Determine which bases to walk ─────────────────────────────────────────────
if [[ -n "$BASIS" ]]; then
    valid=0
    for b in "${ALL_BASES[@]}"; do
        [[ "$b" == "$BASIS" ]] && valid=1
    done
    if [[ "$valid" -eq 0 ]]; then
        echo "Error: --basis must be one of: ${ALL_BASES[*]}"
        exit 1
    fi
    BASES=("$BASIS")
else
    BASES=("${ALL_BASES[@]}")
fi

# ── Determine which R folders to walk ─────────────────────────────────────────
if [[ -n "$R_LABEL" ]]; then
    mapfile -t MATCHES < <(find "$R_CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d \
                           -name "*_R_${R_LABEL}" | sort)
    if [[ ${#MATCHES[@]} -eq 0 ]]; then
        echo "Error: no R folder matching *_R_${R_LABEL} under $R_CONFIG_DIR"
        exit 1
    fi
    if [[ ${#MATCHES[@]} -gt 1 ]]; then
        echo "Error: label ${R_LABEL} is ambiguous, matched ${#MATCHES[@]} folders:"
        printf '   %s\n' "${MATCHES[@]}"
        exit 1
    fi
    R_DIRS=("${MATCHES[0]}")
else
    mapfile -t R_DIRS < <(find "$R_CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d | sort)
    if [[ ${#R_DIRS[@]} -eq 0 ]]; then
        echo "Error: no R folders found under $R_CONFIG_DIR"
        exit 1
    fi
fi

# ── Batch label ───────────────────────────────────────────────────────────────
if [[ -n "$R_LABEL" && -n "$BASIS" ]]; then
    BATCH_LABEL="R_${R_LABEL}_$(basis_tag "$BASIS")"
elif [[ -n "$R_LABEL" ]]; then
    BATCH_LABEL="R_${R_LABEL}_allbasis"
elif [[ -n "$BASIS" ]]; then
    BATCH_LABEL="allgrid_$(basis_tag "$BASIS")"
else
    BATCH_LABEL="all_grid"
fi

# A --job restriction is part of the batch identity, so distinct job types
# never share a log directory.
if [[ -n "$JOB_KEY" ]]; then
    BATCH_LABEL="${BATCH_LABEL}_${JOB_KEY}"
fi

LOG_DIR="${SCRIPT_DIR}/${BATCH_LABEL}_logs"
[[ "$DRY_RUN" -eq 0 ]] && mkdir -p "$LOG_DIR"

echo "═══════════════════════════════════════════════════════════════════"
echo "  Ne/2_new_v2 batch submission"
echo "  R folders : ${#R_DIRS[@]}"
echo "  bases     : ${BASES[*]}"
echo "  job types : ${JOB_KEY:-all 4}"
echo "  batch     : ${BATCH_LABEL}"
echo "  log dir   : ${LOG_DIR}"
[[ "$DRY_RUN" -eq 1 ]] && echo "  MODE      : DRY RUN — nothing will be submitted"
echo "═══════════════════════════════════════════════════════════════════"
for b in "${BASES[@]}"; do
    printf "  %-14s ntasks=%s  mem=%-5s time=%s\n" \
        "$b" "$(res_ntasks "$b")" "$(res_mem "$b")" "$(res_time "$b")"
done
echo "═══════════════════════════════════════════════════════════════════"

# ── Sentinel #1: "submitted" ──────────────────────────────────────────────────
if [[ "$DRY_RUN" -eq 0 ]]; then
    SENTINEL_START=$(sbatch --parsable \
        --job-name="job ${BATCH_LABEL} submitted" \
        --output="${LOG_DIR}/${BATCH_LABEL}_submitted.log" \
        --time=00:01:00 --mem=100M --ntasks=1 \
        --mail-type=END --mail-user="${EMAIL}" \
        --wrap="echo '${BATCH_LABEL} batch submitted at' \$(date)")
    echo "Submitted 'batch-submitted' sentinel (jobid=${SENTINEL_START})"
fi

# ── Walk and submit ───────────────────────────────────────────────────────────
JOB_IDS=()
N_SUBMITTED=0
N_SKIPPED=0
N_TOTAL=0
declare -A PER_BASIS_SUBMITTED

for BASIS_NAME in "${BASES[@]}"; do
    PER_BASIS_SUBMITTED["$BASIS_NAME"]=0
    B_TIME=$(res_time   "$BASIS_NAME")
    B_MEM=$(res_mem     "$BASIS_NAME")
    B_NTASKS=$(res_ntasks "$BASIS_NAME")
    B_TAG=$(basis_tag   "$BASIS_NAME")

    for RDIR in "${R_DIRS[@]}"; do
        NW_DIR="${RDIR}/CCSD_T/${BASIS_NAME}"
        if [[ ! -d "$NW_DIR" ]]; then
            echo "Warning: expected input dir missing, skipping: $NW_DIR"
            continue
        fi

        R_FOLDER=$(basename "$RDIR")          # e.g. 024_R_2p439

        for NW_FILE in "$NW_DIR"/*.nw; do
            [[ -e "$NW_FILE" ]] || continue

            NW_BASE=$(basename "$NW_FILE")
            THIS_KEY="${NW_BASE%.nw}"

            # --job restricts to a single job type within each leaf.
            if [[ -n "$JOB_KEY" && "$THIS_KEY" != "$JOB_KEY" ]]; then
                continue
            fi

            N_TOTAL=$((N_TOTAL + 1))

            OUT_FILE="${NW_FILE%.nw}.out"
            if [[ -f "$OUT_FILE" ]]; then
                N_SKIPPED=$((N_SKIPPED + 1))
                continue
            fi

            JOB_NAME="${B_TAG}_${R_FOLDER}_${THIS_KEY}"   # qz_024_R_2p439_A_AB

            if [[ "$DRY_RUN" -eq 1 ]]; then
                N_SUBMITTED=$((N_SUBMITTED + 1))
                PER_BASIS_SUBMITTED["$BASIS_NAME"]=$(( ${PER_BASIS_SUBMITTED["$BASIS_NAME"]} + 1 ))
                continue
            fi

            JID=$(sbatch --parsable --export=ALL \
                --job-name="${JOB_NAME}" \
                --output="${LOG_DIR}/${JOB_NAME}.log" \
                --ntasks="${B_NTASKS}" \
                --mem="${B_MEM}" \
                --time="${B_TIME}" \
                "${SUBMIT_ENERGY}" "${NW_FILE}")

            JOB_IDS+=("$JID")
            N_SUBMITTED=$((N_SUBMITTED + 1))
            PER_BASIS_SUBMITTED["$BASIS_NAME"]=$(( ${PER_BASIS_SUBMITTED["$BASIS_NAME"]} + 1 ))
        done
    done
done

echo "───────────────────────────────────────────────────────────────────"
echo "  Total .nw files scanned : ${N_TOTAL}"
echo "  Skipped (out exists)    : ${N_SKIPPED}"
echo "  $([[ "$DRY_RUN" -eq 1 ]] && echo 'Would submit' || echo 'Submitted    ')           : ${N_SUBMITTED}"
for b in "${BASES[@]}"; do
    printf "     %-14s : %s\n" "$b" "${PER_BASIS_SUBMITTED[$b]}"
done
echo "───────────────────────────────────────────────────────────────────"

if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "DRY RUN — no jobs were submitted, no log directory created."
    exit 0
fi

# ── Sentinel #2: "done" (depends on all jobs) ────────────────────────────────
if [[ ${N_SUBMITTED} -gt 0 ]]; then
    DEP_LIST=$(IFS=,; echo "${JOB_IDS[*]}")
    SENTINEL_END=$(sbatch --parsable \
        --job-name="job ${BATCH_LABEL} finished" \
        --output="${LOG_DIR}/${BATCH_LABEL}_done.log" \
        --time=00:01:00 --mem=100M --ntasks=1 \
        --dependency=afterany:"${DEP_LIST}" \
        --mail-type=END --mail-user="${EMAIL}" \
        --wrap="echo '${BATCH_LABEL} batch done at' \$(date)")
    echo "Submitted 'batch-done' sentinel (jobid=${SENTINEL_END}), depends on ${N_SUBMITTED} jobs"
else
    echo "No jobs submitted (all outputs already exist). No 'done' sentinel needed."
fi

echo "═══════════════════════════════════════════════════════════════════"
echo "  Emails to  : ${EMAIL}  (relay may drop; trust the log file)"
echo "  Monitor    : squeue -u \$USER"
echo "  Completion : ${LOG_DIR}/${BATCH_LABEL}_done.log"
echo "  Next       : rsync .out back, then check_convergence.py on the laptop"
echo "═══════════════════════════════════════════════════════════════════"
