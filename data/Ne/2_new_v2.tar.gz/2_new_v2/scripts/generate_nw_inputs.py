"""
generate_nw_inputs.py — Generate NWChem input files for the Ne dimer radial
scan study (Ne/2_new_v2).

Rebuild of the Ne/2_new_v1 generator. Three changes, all recorded here so the
differences from v1 are traceable:

  1. GRID. 50 uniform points on [1.5, 3.5] A (v1: 100 points on [1.5, 4.5]).
     Rationale in ../README.md: the window contains R_e = 3.089-3.100 A
     (Wuest & Merkt 2003; Ema et al. ChemPhysChem 2023 Table 1) with margin,
     and its lower bound sits well onto the repulsive wall. The tail beyond
     3.5 A is not studied; v1 retains it.

     Spacing is UNIFORM by design. The study is exploratory with respect to
     the shape of |BSSE|(R); a grid refined around features seen in v1 would
     presuppose the result. dR = 0.0408 A places 5 points across the
     2.25-2.46 A interval, verified sufficient by subsampling the v1 data.

  2. THREE BASES. aug-cc-pVDZ, aug-cc-pVTZ, aug-cc-pVQZ, on the SAME 50 R
     values, so the basis comparison requires no interpolation. Each basis
     gets its own leaf directory:
         R_config/<NNN>_R_<label>/CCSD_T/<basis>/

  3. SCF CONVERGENCE. Tightened relative to v1, which used NWChem defaults.
     NWChem's `thresh` is the norm of the orbital gradient (default 1.0e-4),
     and the manual states the energy converges to approximately the SQUARE
     of that value -- so the v1 default already gave ~1e-8 Ha. The tightening
     is not needed to resolve the ~1.15e-5 Ha feature in |BSSE_SCF|(R); it
     follows the manual's own guidance for this class of problem. See
     SCF_BLOCK.

Geometry construction (per R), unchanged from v1:
    Two Ne atoms on the z-axis, Ne at (0, 0, 0) and the partner at (0, 0, R).
    Direction is irrelevant for spherical Ne. R is the full Ne-Ne distance.

Precision convention, unchanged from v1:
    - .nw geometry coordinate : FULL precision R (the true grid point).
    - Folder label            : 3 decimals, '.' -> 'p' (e.g. '1p541').
                                Human-readable tag only; verified
                                collision-free across the 50-point grid.
    - Zero-padded index NNN   : 001..050.

Clean-run guarantee (carried from v1): correctness of the SCF comes from
    running each job in its own clean leaf directory (submit_energy.sh does
    `cd "$NW_DIR"`), NOT from any input directive. No `.nw` here contains a
    `restart` directive. Raw .out files must be PRESERVED downstream.

Skip logic (per R, per basis):
    If all 4 .nw files exist for an (R, basis) leaf, that leaf is skipped.
    Otherwise all 4 are (re)written. Skipping is per-leaf, so adding a basis
    later does not rewrite the existing ones.

Usage:
    python3 generate_nw_inputs.py                        # all 50 R, all 3 bases
    python3 generate_nw_inputs.py --R 2p439              # one R, all 3 bases
    python3 generate_nw_inputs.py --basis aug-cc-pvqz    # all R, one basis
    python3 generate_nw_inputs.py --R 2p439 --basis aug-cc-pvqz   # one leaf
    python3 generate_nw_inputs.py --dry-run              # report, write nothing

CLI:
    --R <label>     Restrict to a single R folder, 3-decimal 'p' label.
    --basis <name>  Restrict to a single basis directory name.
    --dry-run       Print what would be written; create nothing.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np


# -----------------------------------------------------------------------------
# Grid
# -----------------------------------------------------------------------------

# 50 uniform points, inclusive endpoints, dR = 0.040816 A.
R_MIN = 1.5
R_MAX = 3.5
N_POINTS = 50
R_VALUES = np.linspace(R_MIN, R_MAX, N_POINTS)

METHOD_DIR = "CCSD_T"

# Basis directory names. These are also the NWChem library names, so the
# directory name and the `library` keyword stay in sync by construction.
BASES = ("aug-cc-pvdz", "aug-cc-pvtz", "aug-cc-pvqz")

# The four NWChem input keys per (R, basis). For homonuclear Ne-Ne,
# A_A == B_B and A_AB == B_AB by symmetry, but all four are kept for pipeline
# uniformity and as a symmetry sanity check.
FILE_KEYS = ("A_A", "AB_AB", "A_AB", "B_AB")


# -----------------------------------------------------------------------------
# SCF convergence
# -----------------------------------------------------------------------------
# Values below are taken from the NWChem SCF module documentation, not guessed.
#
#   thresh 1.0e-8
#     `thresh` is the norm of the ORBITAL GRADIENT; default 1.0e-4. The manual
#     states the energy converges to approximately the square of this value,
#     so the default already yields ~1e-8 Ha. The manual further states that
#     greater precision may be required for "weakly interacting systems", that
#     1e-6 suffices for most such cases, that 1e-8 "might be necessary for very
#     high accuracy or very weak interactions", and that 1e-8 "should be
#     regarded as the best that can be attained in most circumstances".
#     A rare-gas dimer BSSE study is squarely the weak-interaction case, and
#     1e-8 is the manual's ceiling, so there is no reason to go lower.
#
#   tol2e 1.0e-12
#     Integral screening threshold. The default is min(1e-6, 0.01*thresh),
#     i.e. 1e-10 at the thresh above. The manual states that for "very diffuse
#     basis sets, or for high-accuracy calculations" it may be necessary to set
#     this explicitly, and that 1e-12 "is sufficient for nearly all such
#     purposes". The aug-cc-pVxZ family is diffuse by construction.
#
#     SIDE EFFECT, relevant to MEMORY_BLOCK below: the manual notes that
#     integrals stored with a threshold greater than 1e-10 use a 32-bit
#     fixed-point format, while those below 1e-10 use 64-bit floating point.
#     Setting 1e-12 therefore roughly DOUBLES integral storage relative to the
#     default. This compounds the aug-cc-pVQZ memory question.
#
#   maxiter 100
#     The manual is internally inconsistent here: the directive line gives a
#     default of 8 while the accompanying text says 20. Setting it explicitly
#     removes the ambiguity. Ne is a closed-shell atom and should converge in
#     far fewer iterations; this is a ceiling, not an expectation.
#
# ---------------------------------------------------------------------------
# TODO: CONFIRM BY TEST RUN.
#   The values are documented rather than guessed, but no job has yet been run
#   with them. Confirm from the .out that the SCF reports convergence at the
#   requested threshold and that the job completes.
#   Suggested test leaf: 024_R_2p439 / CCSD_T / aug-cc-pvqz
#     - R = 2.439 A is the local maximum of |BSSE_SCF| found in v1, so this
#       job also shows whether the feature survives tighter convergence.
#     - aug-cc-pVQZ is the largest basis and the one most likely to fail on
#       memory or walltime; test the worst case, not the easiest.
# ---------------------------------------------------------------------------

SCF_BLOCK = (
    "scf\n"
    "  thresh 1.0e-8\n"
    "  tol2e  1.0e-12\n"
    "  maxiter 100\n"
    "end\n"
)


# -----------------------------------------------------------------------------
# Memory
# -----------------------------------------------------------------------------
# v1 wrote no `memory` directive, matching the minimal Ne/2 dimer inputs. That
# decision was made for aug-cc-pVDZ (46 basis functions in the dimer). The
# larger bases are a different regime:
#
#     aug-cc-pVDZ :  23 bf/atom,  46 bf dimer
#     aug-cc-pVTZ :  46 bf/atom,  92 bf dimer
#     aug-cc-pVQZ :  80 bf/atom, 160 bf dimer
#
# The (vv|vv) integral block grows roughly as the 4th power of the virtual
# count, so the QZ CCSD(T) step needs substantially more than the DZ default.
#
# ---------------------------------------------------------------------------
# TODO: CONFIRM BY TEST RUN.
#   These values are estimates and have NOT been tested. Confirm against the
#   test job, and keep them consistent with --mem in submit_energy.sh
#   (NWChem `memory total` is PER MPI PROCESS; submit_energy.sh requests
#   --ntasks=2 --mem=20G, so the per-process figure must leave headroom).
#   Also check --time=01:00:00 in submit_energy.sh: adequate for DZ, likely
#   short for QZ.
#
#   FALLBACK if aug-cc-pVQZ fails on memory: the SCF module accepts a
#   `direct` directive inside the scf block, which recomputes integrals
#   rather than caching them, trading time for memory. Add to SCF_BLOCK only
#   if needed -- it will slow every job that uses it.
# ---------------------------------------------------------------------------

MEMORY_BLOCK = {
    "aug-cc-pvdz": None,                    # as v1: no directive
    "aug-cc-pvtz": "memory total 4 gb\n",
    "aug-cc-pvqz": "memory total 8 gb\n",
}


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def r_to_label(r: float) -> str:
    """Convert a numeric R value to its 3-decimal folder label.

    1.5408163265 -> '1p541'. Human-readable tag only; the geometry written to
    the .nw file uses full precision (see _coord).
    """
    return f"{r:.3f}".replace(".", "p")


def all_labels() -> list[str]:
    """The 3-decimal labels for all 50 grid points, in grid order."""
    return [r_to_label(r) for r in R_VALUES]


def folder_name(index0: int, r: float) -> str:
    """Return '<NNN>_R_<label>' for a 0-based grid index.

    index0 = 0 -> '001_R_1p500', index0 = 49 -> '050_R_3p500'.
    """
    return f"{index0 + 1:03d}_R_{r_to_label(r)}"


def check_labels_unique() -> None:
    """Abort if the 3-decimal labels collide on this grid."""
    labels = all_labels()
    if len(set(labels)) != len(labels):
        dupes = sorted({x for x in labels if labels.count(x) > 1})
        print(f"ERROR: 3-decimal R labels are not unique on this grid: {dupes}",
              file=sys.stderr)
        sys.exit(1)


# -----------------------------------------------------------------------------
# NWChem template renderers
# -----------------------------------------------------------------------------
# Coordinates are written at full float precision (repr-grade) so the geometry
# is the exact grid point, independent of the 3-decimal folder label.

def _coord(r: float) -> str:
    """Full-precision string for the z-coordinate of the partner atom."""
    return repr(float(r))


def _prefix(basis: str) -> str:
    """Optional `memory` directive for this basis, or an empty string."""
    block = MEMORY_BLOCK.get(basis)
    return block if block else ""


def render_A_A(r: float, basis: str) -> str:
    """A alone in the A basis (single Ne at the origin, no ghost).

    Note this input is R-independent; `r` is accepted for signature
    uniformity and deliberately unused.
    """
    return (
        f"{_prefix(basis)}"
        "geometry\n"
        "  Ne 0 0 0\n"
        "end\n"
        "basis spherical\n"
        f"  Ne library {basis}\n"
        "end\n"
        f"{SCF_BLOCK}"
        "task ccsd(t) energy\n"
    )


def render_AB_AB(r: float, basis: str) -> str:
    """Full dimer AB in the AB basis (two real Ne)."""
    return (
        f"{_prefix(basis)}"
        "geometry\n"
        "  Ne 0 0 0\n"
        f"  Ne 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        f"  Ne library {basis}\n"
        "end\n"
        f"{SCF_BLOCK}"
        "task ccsd(t) energy\n"
    )


def render_A_AB(r: float, basis: str) -> str:
    """A real at origin, B as a ghost at (0,0,R), in the AB (union) basis."""
    return (
        f"{_prefix(basis)}"
        "geometry\n"
        "  Ne 0 0 0\n"
        f"  bqNe 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        f"  Ne library {basis}\n"
        f"  bqNe library Ne {basis}\n"
        "end\n"
        f"{SCF_BLOCK}"
        "task ccsd(t) energy\n"
    )


def render_B_AB(r: float, basis: str) -> str:
    """B real at (0,0,R), A as a ghost at the origin, in the AB (union) basis."""
    return (
        f"{_prefix(basis)}"
        "geometry\n"
        "  bqNe 0 0 0\n"
        f"  Ne 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        f"  bqNe library Ne {basis}\n"
        f"  Ne library {basis}\n"
        "end\n"
        f"{SCF_BLOCK}"
        "task ccsd(t) energy\n"
    )


_RENDERERS = {
    "A_A":   render_A_A,
    "AB_AB": render_AB_AB,
    "A_AB":  render_A_AB,
    "B_AB":  render_B_AB,
}


def render_for_key(key: str, r: float, basis: str) -> str:
    """Dispatch to the correct renderer for a file key."""
    try:
        return _RENDERERS[key](r, basis)
    except KeyError:
        raise ValueError(f"Unknown file key: {key!r}") from None


# -----------------------------------------------------------------------------
# Per-leaf generation and skip logic
# -----------------------------------------------------------------------------

def leaf_paths(root: Path, index0: int, r: float, basis: str) -> dict[str, Path]:
    """Return {file_key -> .nw path} for one (R, basis) leaf."""
    nw_dir = root / "R_config" / folder_name(index0, r) / METHOD_DIR / basis
    return {key: nw_dir / f"{key}.nw" for key in FILE_KEYS}


def leaf_complete(nw_paths: dict[str, Path]) -> bool:
    """True iff all 4 .nw files exist for this leaf."""
    return all(p.exists() for p in nw_paths.values())


def write_leaf(root: Path, index0: int, r: float, basis: str) -> None:
    """Generate and write all 4 .nw files for one (R, basis) leaf."""
    nw_paths = leaf_paths(root, index0, r, basis)
    for p in nw_paths.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    for key, path in nw_paths.items():
        path.write_text(render_for_key(key, r, basis))


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate NWChem input files for the Ne dimer radial scan study "
            "(Ne/2_new_v2). Without --R or --basis, generates all 50 R "
            "folders for all 3 bases, skipping any leaf already complete."
        )
    )
    parser.add_argument(
        "--R", dest="r_label", default=None, metavar="LABEL",
        help=(
            "Restrict to a single R folder. LABEL is the 3-decimal 'p' label "
            "of a grid point, e.g. 1p500, 2p439, 3p500."
        ),
    )
    parser.add_argument(
        "--basis", dest="basis", default=None, metavar="NAME",
        choices=BASES,
        help=f"Restrict to a single basis. One of: {', '.join(BASES)}.",
    )
    parser.add_argument(
        "--dry-run", dest="dry_run", action="store_true",
        help="Report what would be written without creating anything.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    check_labels_unique()

    # Path anchoring: this script lives in Ne/2_new_v2/scripts/.
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent  # Ne/2_new_v2/
    if not (root / "R_config").is_dir():
        print(f"ERROR: expected 'R_config/' inside {root}, not found.",
              file=sys.stderr)
        sys.exit(1)

    labels = all_labels()

    if args.r_label is None:
        targets = list(enumerate(R_VALUES))
    else:
        if args.r_label not in labels:
            print(f"ERROR: --R {args.r_label!r} is not a grid label.",
                  file=sys.stderr)
            print(f"Valid labels: {labels[0]}, {labels[1]}, ..., {labels[-1]}",
                  file=sys.stderr)
            sys.exit(1)
        idx = labels.index(args.r_label)
        targets = [(idx, R_VALUES[idx])]

    bases = (args.basis,) if args.basis else BASES

    n_written = 0
    n_skipped = 0
    for basis in bases:
        for index0, r in targets:
            nw_paths = leaf_paths(root, index0, r, basis)
            if leaf_complete(nw_paths):
                n_skipped += 1
                continue
            if not args.dry_run:
                write_leaf(root, index0, r, basis)
            n_written += 1

    verb = "would write" if args.dry_run else "written"
    print(f"grid              : linspace({R_MIN}, {R_MAX}, {N_POINTS}), "
          f"step = {(R_MAX - R_MIN) / (N_POINTS - 1):.6f} A")
    print(f"bases             : {', '.join(bases)}")
    print(f"leaves {verb:<11s}: {n_written}")
    print(f"leaves skipped    : {n_skipped}  (already complete)")
    print(f"input files       : {n_written * len(FILE_KEYS)}")
    if args.dry_run:
        print("\nDRY RUN — nothing was created.")
    print("Done.")


if __name__ == "__main__":
    main()
