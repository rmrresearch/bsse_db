#!/usr/bin/env python3
"""
build_bsse_csv.py — Ne/2_new_v2 (dimer radial-scan study, three bases)
=====================================================================

Reads the study-wide raw_data pickle, computes the 2-body BSSE (PI
convention), and writes ONE CSV PER BASIS into data_frames/.

Location:  bsse_db/data/Ne/2_new_v2/scripts/
Input:     bsse_db/data/Ne/2_new_v2/R_config_pickle_data/raw_data.pickle
Output:    bsse_db/data/Ne/2_new_v2/data_frames/ne_dimer_bsse_vs_R_<basis>.csv

Changes from v1
---------------
  1. THREE CSVs, one per basis, rather than one. The pickle keeps all three
     bases in a single nested dict, but a CSV is a flat table: the basis has
     to become part of the filename. This is the layer where the split
     happens.

  2. OUTPUT DIRECTORY is ../data_frames/ (v1: ../data_frames_plots/). In v2
     data_frames/ holds ONLY CSVs; figures live in each analysis folder's own
     figures/ directory.

  3. PARTIAL DATA IS EXPECTED. The three bases will not finish together, and
     the parser excludes leaves per (R, basis). A CSV is therefore written
     for whatever R that basis has, with the row count reported. A basis with
     no parsed R is skipped with a warning rather than raising.

  4. EXACT-SUM ASSERTION. The three component BSSE columns must sum to
     total_bsse identically (they are incremental, not independent). This is
     now checked and reported per basis rather than left implicit.

BSSE definition (PI Task List 5 convention)
-------------------------------------------
Per component c in {SCF, MP2c, CCSD_Tc}:

    2b_no_vmfc(c) = E_AB(AB,c) - E_A(A,c)  - E_B(B,c)          # signed, Ha
    2b_vmfc(c)    = E_AB(AB,c) - E_A(AB,c) - E_B(AB,c)         # signed, Ha
    2b_bsse(c)    = ( 2b_no_vmfc(c) - 2b_vmfc(c) ) * 627.5094740631

For the homonuclear Ne dimer, monomer B is not computed in its own basis;
per the convention used throughout this project:

    E_B(B,c) = E_A(A,c)

i.e. the isolated-monomer energy for B equals that of A (same species, same
basis on a single monomer — equivalent by symmetry of the file setup).

    total_bsse = 2b_bsse_SCF + 2b_bsse_MP2c + 2b_bsse_CCSD_Tc

Locked 23-column schema (unchanged from v1)
-------------------------------------------
    R                                                   (Angstrom)
    A_A_{SCF,MP2c,CCSD_Tc}                              (Ha, signed)
    AB_AB_{SCF,MP2c,CCSD_Tc}                            (Ha, signed)
    A_AB_{SCF,MP2c,CCSD_Tc}                             (Ha, signed)
    B_AB_{SCF,MP2c,CCSD_Tc}                             (Ha, signed)
    2b_no_vmfc_{SCF,MP2c,CCSD_Tc}                       (Ha, signed)
    2b_vmfc_{SCF,MP2c,CCSD_Tc}                          (Ha, signed)
    2b_bsse_{SCF,MP2c,CCSD_Tc}                          (kcal/mol, signed)
    total_bsse                                          (kcal/mol, signed)

Raw and intermediate columns stay in Hartree, signed. BSSE columns are in
kcal/mol, signed. Absolute values are applied only at plot/fit time, never
stored.

Numeric precision
-----------------
Written with float_format='%.15g'. The raw component columns are ~1e2 Ha in
magnitude while the BSSE derived from them is ~1e-3 Ha. At 10 significant
figures the stored raw energies would be truncated near 1e-7 Ha, LARGER than
the quantity of interest — the BSSE could not be recomputed from the archived
CSV. 15 significant figures preserves every digit NWChem prints and keeps R
exact to ~1e-16 A.

v1 cross-check at R = 1.5 A
---------------------------
The v1 study (aug-cc-pVDZ, NWChem default SCF convergence) gave:
    2b_no_vmfc_SCF =  0.143654259666 Ha
    2b_vmfc_SCF    =  0.144879891105 Ha
    2b_bsse_SCF    = -0.769095       kcal/mol

R = 1.5 A is a grid point in both studies, so the aug-cc-pVDZ CSV can be
compared against these. A SMALL SHIFT IS EXPECTED AND IS NOT AN ERROR: v2
requests `thresh 1.0e-8` where v1 used the 1.0e-4 default, so total energies
may move in their last digits. The check is reported, never fatal — its value
is in quantifying how little the tighter convergence changed, not in passing.

Usage
-----
    cd bsse_db/data/Ne/2_new_v2/scripts
    python3 build_bsse_csv.py                        # all bases present
    python3 build_bsse_csv.py --basis aug-cc-pvdz    # one basis
"""

import pickle
import argparse
from pathlib import Path

import pandas as pd


# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR  = Path(__file__).resolve().parent
PICKLE_PATH = SCRIPT_DIR.parent / 'R_config_pickle_data' / 'raw_data.pickle'
CSV_DIR     = SCRIPT_DIR.parent / 'data_frames'


def csv_name(basis: str) -> str:
    """CSV filename for one basis."""
    return f'ne_dimer_bsse_vs_R_{basis}.csv'


# ── Keys (must match build_raw_data.py) ───────────────────────────────────────
CONFIG_KEY = 'R_config'
METHOD_KEY = 'CCSD_T'
BASES      = ('aug-cc-pvdz', 'aug-cc-pvtz', 'aug-cc-pvqz')
FILE_KEYS  = ['A_A', 'AB_AB', 'A_AB', 'B_AB']
COMP_KEYS  = ['SCF', 'MP2_corcomp', 'CCSD_T_corcomp']

# Short tags used in CSV column names (HF/H2O-consistent).
COMP_SHORT = {'SCF': 'SCF', 'MP2_corcomp': 'MP2c', 'CCSD_T_corcomp': 'CCSD_Tc'}

# CODATA 2018
HA_TO_KCAL = 627.5094740631

# ── v1 cross-check (aug-cc-pVDZ only) ─────────────────────────────────────────
V1_R        = 1.5
V1_NO_VMFC  = 0.143654259666
V1_VMFC     = 0.144879891105
V1_BSSE_SCF = -0.769095
V1_TOL      = 1e-5      # loose: v2 tightens SCF convergence, so a small
                        # shift in the last digits is expected

# Tolerance for the exact-sum identity. The components are incremental, so
# the sum is exact up to floating-point accumulation over three terms.
SUM_TOL = 1e-10


# ── Column construction ───────────────────────────────────────────────────────
def build_column_order():
    """
    Return the locked 23-column order.

    Grouped by file (all components of A_A, then AB_AB, ...), then the
    intermediate BSSE quantities per component, then the 4 kcal/mol columns.
    """
    cols = ['R']

    # Raw energies, grouped by file, cycling components   (12 cols, Ha)
    for fk in FILE_KEYS:
        for c in COMP_KEYS:
            cols.append(f'{fk}_{COMP_SHORT[c]}')

    # 2b_no_vmfc per component                            (3 cols, Ha)
    for c in COMP_KEYS:
        cols.append(f'2b_no_vmfc_{COMP_SHORT[c]}')

    # 2b_vmfc per component                               (3 cols, Ha)
    for c in COMP_KEYS:
        cols.append(f'2b_vmfc_{COMP_SHORT[c]}')

    # 2b_bsse per component                               (3 cols, kcal/mol)
    for c in COMP_KEYS:
        cols.append(f'2b_bsse_{COMP_SHORT[c]}')

    # Total BSSE                                          (1 col,  kcal/mol)
    cols.append('total_bsse')

    return cols


# ── Row assembly for one R ────────────────────────────────────────────────────
def compute_row(entry, params):
    """
    Compute one CSV row for a single R at one basis.

    Parameters
    ----------
    entry : dict
        raw_data['R_config']['R_<label>']['CCSD_T'][<basis>]
        i.e. dict keyed by file_key, each value a dict of the 3 components (Ha).
    params : dict
        parameters['R_config']['R_<label>'] -> {'R': float, 'grid_index': int}
    """
    row = {'R': params['R']}

    # Raw energies (Ha)
    for fk in FILE_KEYS:
        for c in COMP_KEYS:
            row[f'{fk}_{COMP_SHORT[c]}'] = entry[fk][c]

    # Per-component BSSE math (Ha for intermediates, kcal/mol for final BSSE)
    total_bsse_kcal = 0.0
    for c in COMP_KEYS:
        E_A_A   = entry['A_A'][c]
        E_AB_AB = entry['AB_AB'][c]
        E_A_AB  = entry['A_AB'][c]
        E_B_AB  = entry['B_AB'][c]

        # E_B(B,c) is not computed for this dimer; per project convention,
        # use E_A(A,c) as the isolated-B reference (monomers are equivalent
        # in their own basis).
        E_B_B = E_A_A

        no_vmfc = E_AB_AB - E_A_A  - E_B_B
        vmfc    = E_AB_AB - E_A_AB - E_B_AB
        bsse_ha = no_vmfc - vmfc

        row[f'2b_no_vmfc_{COMP_SHORT[c]}'] = no_vmfc                  # Ha
        row[f'2b_vmfc_{COMP_SHORT[c]}']    = vmfc                     # Ha
        row[f'2b_bsse_{COMP_SHORT[c]}']    = bsse_ha * HA_TO_KCAL     # kcal/mol
        total_bsse_kcal += bsse_ha * HA_TO_KCAL

    row['total_bsse'] = total_bsse_kcal                               # kcal/mol
    return row


# ── Checks ────────────────────────────────────────────────────────────────────
def check_sum(df, verbose=True):
    """
    Verify the three component BSSE columns sum to total_bsse.

    They are incremental by construction, so this is an identity, not a
    measurement. A failure means the pipeline is wrong, not the physics.
    """
    comps = [f'2b_bsse_{COMP_SHORT[c]}' for c in COMP_KEYS]
    resid = (df[comps].sum(axis=1) - df['total_bsse']).abs().max()
    ok = resid < SUM_TOL
    if verbose:
        flag = '✅' if ok else '❌'
        print(f"    {flag}  exact-sum check : max |Σ components − total| "
              f"= {resid:.2e} kcal/mol")
    return ok, resid


def check_v1(df, verbose=True):
    """
    Compare the R = 1.5 A row against the v1 aug-cc-pVDZ values.

    Reports rather than raises. A small shift is expected: v2 tightens the
    SCF convergence threshold, so total energies may move in their last
    digits. The value of the check is in quantifying that shift.
    """
    match = df[(df['R'] - V1_R).abs() < 1e-12]
    if match.empty:
        if verbose:
            print(f"    ⚠️   v1 cross-check: R = {V1_R} A not present")
        return None

    r = match.iloc[0]
    checks = [
        ('2b_no_vmfc_SCF', r['2b_no_vmfc_SCF'], V1_NO_VMFC,  'Ha'),
        ('2b_vmfc_SCF',    r['2b_vmfc_SCF'],    V1_VMFC,     'Ha'),
        ('2b_bsse_SCF',    r['2b_bsse_SCF'],    V1_BSSE_SCF, 'kcal/mol'),
    ]

    if verbose:
        print(f"    v1 cross-check at R = {V1_R} A  "
              f"(shift expected: v2 uses thresh 1e-8, v1 used the 1e-4 default)")
    all_close = True
    for name, got, want, unit in checks:
        delta = got - want
        close = abs(delta) < V1_TOL
        all_close &= close
        if verbose:
            flag = '✅' if close else '⚠️ '
            print(f"      {flag} {name:<16s} = {got:>16.12f}   "
                  f"Δ vs v1 = {delta:+.2e} {unit}")
    return all_close


# ── Pipeline ──────────────────────────────────────────────────────────────────
def build_csv_for_basis(payload, basis, verbose=True):
    """
    Build and write the CSV for one basis.

    Returns (df, path) or (None, None) if this basis has no parsed R.
    """
    raw  = payload['raw_data'].get(CONFIG_KEY, {})
    pars = payload['parameters'].get(CONFIG_KEY, {})

    rows = []
    for r_key, node in raw.items():
        entry = node.get(METHOD_KEY, {}).get(basis)
        if not entry:
            continue
        rows.append(compute_row(entry, pars[r_key]))

    if not rows:
        if verbose:
            print(f"  ⚠️   {basis}: no parsed R in the pickle — skipped")
        return None, None

    df = pd.DataFrame(rows, columns=build_column_order())
    df = df.sort_values('R').reset_index(drop=True)

    CSV_DIR.mkdir(parents=True, exist_ok=True)
    out_path = CSV_DIR / csv_name(basis)
    df.to_csv(out_path, index=False, float_format='%.15g')

    if verbose:
        print(f"\n  {basis}")
        print(f"  {'─' * 68}")
        print(f"    rows            : {len(df)} x {len(df.columns)} columns")
        print(f"    R range         : [{df['R'].min():.6f}, "
              f"{df['R'].max():.6f}] A")
        print(f"    total_bsse range: [{df['total_bsse'].min():.6f}, "
              f"{df['total_bsse'].max():.6f}] kcal/mol")

    check_sum(df, verbose=verbose)
    if basis == 'aug-cc-pvdz':
        check_v1(df, verbose=verbose)

    if verbose:
        print(f"    💾  {out_path.name}")

    return df, out_path


def report_exclusions(payload, bases, verbose=True):
    """Summarise which (R, basis) leaves the parser excluded."""
    nc = payload.get('raw_data_noconv', {}).get(CONFIG_KEY, {})
    if not nc:
        return
    per_basis = {b: [] for b in bases}
    for r_key, node in nc.items():
        for b in bases:
            if b in node:
                per_basis[b].append(r_key)
    if not any(per_basis.values()):
        return
    if verbose:
        print(f"\n  Excluded by the parser (absent from the CSVs)")
        print(f"  {'─' * 68}")
        for b in bases:
            lst = sorted(per_basis[b])
            if lst:
                shown = ', '.join(lst[:6])
                more = f'  ... +{len(lst) - 6} more' if len(lst) > 6 else ''
                print(f"    {b:<14s} {len(lst):>3d}:  {shown}{more}")


# ── CLI ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description='Build the per-basis Ne/2_new_v2 BSSE CSVs from the '
                    'study-wide raw_data pickle.'
    )
    parser.add_argument(
        '--basis', type=str, default=None, choices=BASES, metavar='NAME',
        help=f'Build only this basis. One of: {", ".join(BASES)}. '
             f'Omit to build every basis present in the pickle.')
    args = parser.parse_args()

    bases = [args.basis] if args.basis else list(BASES)

    print(f"\n{'═' * 72}")
    print("  Ne/2_new_v2 BSSE CSV build")
    print(f"{'═' * 72}")
    print(f"  Pickle  : {PICKLE_PATH}")
    print(f"  CSV dir : {CSV_DIR}")
    print(f"  Bases   : {', '.join(bases)}")
    print(f"{'═' * 72}")

    if not PICKLE_PATH.is_file():
        raise SystemExit(
            f"ERROR: no pickle at {PICKLE_PATH}. Run build_raw_data.py first."
        )

    with open(PICKLE_PATH, 'rb') as fh:
        payload = pickle.load(fh)

    if not payload['raw_data'].get(CONFIG_KEY):
        raise SystemExit(f"ERROR: pickle at {PICKLE_PATH} contains no parsed R.")

    written = []
    all_ok = True
    for basis in bases:
        df, path = build_csv_for_basis(payload, basis, verbose=True)
        if path is not None:
            written.append(path)
            ok, _ = check_sum(df, verbose=False)
            all_ok &= ok

    report_exclusions(payload, bases, verbose=True)

    print(f"\n{'═' * 72}")
    print(f"  CSVs written : {len(written)}")
    for p in written:
        print(f"    💾  {p}")
    if not all_ok:
        print("  ❌  EXACT-SUM CHECK FAILED — inspect before using these CSVs.")
    print(f"{'═' * 72}\n")


if __name__ == '__main__':
    main()
