#!/bin/bash
# submit_energy.sh
# Slurm batch script for a single NWChem CCSD(T) calculation for the
# Ne/2_new_v2 dimer radial-scan BSSE study.
#
# Layout of jobs on NOVA:
#   ~/BSSE/Ne/2_new_v2/R_config/<NNN>_R_<label>/CCSD_T/<basis>/*.nw
#   <basis> in {aug-cc-pvdz, aug-cc-pvtz, aug-cc-pvqz}
#
# RESOURCES
# ---------
# The #SBATCH lines below are DEFAULTS sized for aug-cc-pVDZ (46 basis
# functions in the dimer) — the v1 setting, proven on 400 jobs.
#
# They are deliberately NOT sized for the larger bases. sbatch command-line
# options override #SBATCH directives in the script, so submit_all_jobs.sh
# passes per-basis --time / --mem / --ntasks at submission time. That keeps a
# single script for all three bases and keeps DZ jobs small, so they are not
# held behind an oversized reservation.
#
# Running this script directly (without submit_all_jobs.sh) therefore gets the
# DZ defaults. For a hand-submitted TZ or QZ test, pass the overrides:
#
#   sbatch --time=04:00:00 --mem=32G submit_energy.sh /path/to/A_A.nw
#
# CALIBRATION
# -----------
# After the first job of each basis completes, run:
#
#   seff <jobid>
#
# which reports peak memory used and CPU efficiency. Set the per-basis values
# in submit_all_jobs.sh from those numbers rather than from the estimates
# shipped there. The NOVA docs note that requesting a maximum time much larger
# than the true runtime makes jobs harder to schedule, so padding is not free.
#
# Clean-run guarantee (carried from v1): each job runs in its own clean leaf
# directory via `cd "$NW_DIR"` below, so no stale .movecs is inherited and the
# SCF genuinely iterates (the One-electron / Two-electron breakdown must print
# in every .out). The raw .out is preserved; only NWChem scratch is removed.
#
# Usage (direct):
#   sbatch submit_energy.sh /full/path/to/file.nw
# Usage (via submit_all_jobs.sh):
#   submit_all_jobs.sh walks the tree and supplies the per-basis overrides.

#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --mem=20G
#SBATCH --time=01:00:00
#SBATCH --partition=nova

# ── Load NWChem ───────────────────────────────────────────────────────────────
module load nwchem/7.2.0-py39-py310-openmpi4-oxtctbu

# ── Resolve paths ─────────────────────────────────────────────────────────────
NW_FILE=$1

if [[ -z "$NW_FILE" ]]; then
    echo "Error: no .nw file provided."
    echo "Usage: sbatch submit_energy.sh /full/path/to/file.nw"
    exit 1
fi

if [[ ! -f "$NW_FILE" ]]; then
    echo "Error: file not found: $NW_FILE"
    exit 1
fi

NW_DIR=$(dirname  "$NW_FILE")
NW_BASE=$(basename "$NW_FILE")
OUT_BASE="${NW_BASE%.nw}.out"

# ── Report the resources actually granted ─────────────────────────────────────
# Printed into the Slurm log so that, when calibrating with seff, the request
# that produced a given runtime is recorded alongside it.
echo "host        : $(hostname)"
echo "job id      : ${SLURM_JOB_ID:-<none>}"
echo "ntasks      : ${SLURM_NTASKS:-<none>}"
echo "mem/node    : ${SLURM_MEM_PER_NODE:-<unset>} MB"
echo "time limit  : $(squeue -h -j "${SLURM_JOB_ID:-0}" -o %l 2>/dev/null || echo '<unknown>')"
echo "input       : ${NW_FILE}"
echo "started     : $(date)"

# ── Run NWChem ────────────────────────────────────────────────────────────────
cd "$NW_DIR" || { echo "Error: cannot cd to $NW_DIR"; exit 1; }

mpirun -np "$SLURM_NTASKS" nwchem "$NW_BASE" > "$OUT_BASE" 2>&1
NW_STATUS=$?

echo "finished    : $(date)"
echo "nwchem exit : ${NW_STATUS}"

# ── Clean up NWChem scratch files (keep only .nw and .out) ───────────────────
BASE="${NW_BASE%.nw}"
for f in "${BASE}".*; do
    if [[ "$f" != "${BASE}.nw" && "$f" != "${BASE}.out" ]]; then
        rm -f "$f"
    fi
done

exit "$NW_STATUS"
