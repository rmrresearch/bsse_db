#!/usr/bin/env python3
"""
fit_mp2c.py — Ne/2_new_v2, 2b_bsse_mp2c
=======================================

Fits the MP2-correlation component of the BSSE, `2b_bsse_MP2c`, and shows
the screen that chose the functional form.

TWO FIGURES PER BASIS
---------------------
  1. mp2c_ln_screen_<BASIS>.png
     ln|BSSE_MP2c| against R (left) and against R^2 (right), each with a
     least-squares straight line and the R^2 of that line. A pure
     exponential a*exp(-cR) is a straight line in the LEFT panel; a pure
     Gaussian a*exp(-bR^2) is a straight line in the RIGHT one. Whichever
     panel is straighter selects the form. The selected panel's line is
     drawn solid and coloured; the other is dashed grey. No text arrow is
     used -- the two R^2 values are printed and the reader can compare them.

  2. mp2c_fit_<BASIS>.png
     the selected form fitted to the signed data (left) and computed vs
     predicted with R^2 (right), matching the layout of fit_scf.py.

Figure 1 is a diagnostic. It exists so the choice of form can be seen
rather than asserted; whether it belongs in the paper is a decision for the
PI, not for this script.


THIS COMPONENT IS FITTED EMPIRICALLY. NO GPT FLOOR IS APPLIED.
--------------------------------------------------------------
The GPT/Boys argument used for the SCF component comes from the structure
of the Hartree-Fock integrals: every two-centre integral over primitive
Gaussians carries exp(-gamma R^2) with gamma = alpha*beta/(alpha+beta), and
S&O A.11 supplies the even polynomial prefactor. None of that transfers
here. The MP2 correlation energy (S&O eq. 6.74) is

    E_MP2 = sum_{i<j, a<b}  |<ij||ab>|^2 / (eps_i + eps_j - eps_a - eps_b)

-- a SQUARED two-electron integral over a linear orbital-energy
denominator, summed over all occupied-virtual pairs, with the MO
coefficients and the orbital energies each carrying their own
R-dependence. There is no A.11 equivalent to lean on, and Iwata's CBI is a
mechanism rather than a functional form.

A naive reading of the squaring would predict b_MP2c = 2 * b_SCF. Measured
on this data the ratio is 1.52 (DZ), 1.67 (TZ), 2.17 (QZ) -- not 2, and not
constant. That expectation is NOT supported and is recorded here only so it
is not re-derived and re-assumed later.

Consequently the acceptance criteria for this component are weaker than for
SCF. The GPT floor test does not apply and must not be reported for MP2c.
What remains: R -> infinity must vanish, parameters must be identifiable,
and held-out interpolation must hold.


WINDOW AND BASIS DEPENDENCE OF THE SCREEN
-----------------------------------------
The screen's verdict changes with the window and with the basis. On v2 data
MP2c reads Gaussian over [1.5, 2.0] at DZ and exponential everywhere else;
over the full [1.5, 3.5] window it reads exponential at all three bases, but
the DZ line quality is only 0.837, meaning exponential merely beats Gaussian
rather than describing the data well.

Any statement of functional form must therefore carry BOTH its window and
its basis. The window is printed on every figure and in every report.

One limitation of the screen, stated so it is not over-read: it
discriminates a PURE exponential from a PURE Gaussian. A polynomial times a
Gaussian -- the form adopted for the SCF component -- has log
ln|P(R)| - bR^2, which is a straight line in neither panel, so this screen
would misclassify it. The screen answers "which pure form is closer", not
"is a pure form adequate".


SIGN
----
`2b_bsse_MP2c` is negative at all 50 R at all three bases, so |.| inside the
logarithm loses no information. The script verifies this and refuses to
build the screen if the component changes sign inside the window, since
ln|y| would then straddle a singularity. This matters for the sibling
script: `2b_bsse_CCSD_Tc` is negative at DZ and TZ but POSITIVE at all 50 R
at QZ (handoff 30-Jul, 5). Single-signed, so the screen is still valid
there, but the amplitude must be free to change sign -- which it is here,
since the signed data are fitted as stored.

To produce fit_ccsd_tc.py, copy this file into 2b_bsse_ccsd_tc/scripts/ and
change COLUMN, TAG, and FIG_PREFIX. Nothing else is component-specific.


Location:  bsse_db/data/Ne/2_new_v2/2b_bsse_mp2c/scripts/
Input:     bsse_db/data/Ne/2_new_v2/data_frames/
Output:    bsse_db/data/Ne/2_new_v2/2b_bsse_mp2c/figures/
           bsse_db/data/Ne/2_new_v2/2b_bsse_mp2c/fit_csv/

Usage
-----
    cd bsse_db/data/Ne/2_new_v2/2b_bsse_mp2c/scripts
    python3 fit_mp2c.py                      # all bases, both figures
    python3 fit_mp2c.py --mode csv           # fit CSVs only; leave figures alone
    python3 fit_mp2c.py --basis QZ           # one basis; case-insensitive
    python3 fit_mp2c.py --form gauss         # override the screen
    python3 fit_mp2c.py --plot screen        # just the ln diagnostic
    python3 fit_mp2c.py --R-min 1.5 --R-max 2.5
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})

# ── Paths (option A anchoring: 2 levels below the study root) ────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
STUDY_ROOT = SCRIPT_DIR.parent.parent
CSV_DIR    = STUDY_ROOT / 'data_frames'
FIG_DIR    = SCRIPT_DIR.parent / 'figures'
CSV_OUT_DIR = SCRIPT_DIR.parent / 'fit_csv'

# ── Component. These three lines are the only component-specific content. ────
COLUMN     = '2b_bsse_MP2c'
TAG        = r"\mathrm{BSSE}_{\mathrm{MP2c}}"
FIG_PREFIX = 'mp2c'

BASES = {
    'dz': {'tag': 'DZ', 'label': 'aug-cc-pVDZ', 'nbf': 46,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvdz.csv'},
    'tz': {'tag': 'TZ', 'label': 'aug-cc-pVTZ', 'nbf': 92,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvtz.csv'},
    'qz': {'tag': 'QZ', 'label': 'aug-cc-pVQZ', 'nbf': 160,
           'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvqz.csv'},
}


# ── Candidate forms ─────────────────────────────────────────────────────────
def _exp(R, a, c):
    return a * np.exp(-c * R)


def _gauss(R, a, b):
    return a * np.exp(-b * R**2)


FORMS = {
    'exp':   {'fn': _exp,   'names': ['a', 'c'], 'unit': r"\AA$^{-1}$",
              'unit_txt': 'A^-1',
              'tex': r"$a\,e^{-cR}$",
              'seeds': [[-2.0, 1.0], [-0.5, 0.5], [-10.0, 2.0], [-1.0, 1.5]],
              'straight_in': 'R'},
    'gauss': {'fn': _gauss, 'names': ['a', 'b'], 'unit': r"\AA$^{-2}$",
              'unit_txt': 'A^-2',
              'tex': r"$a\,e^{-bR^2}$",
              'seeds': [[-2.0, 0.6], [-0.2, 0.3], [-8.0, 1.5], [-1.0, 1.0]],
              'straight_in': 'R^2'},
}


def rmse_tex(v, exp=-3):
    return rf"{v / 10.0**exp:.3f}\times 10^{{{exp}}}"


def rmse_txt(v, exp=-3):
    return f"{v / 10.0**exp:.3f} x 10^{exp}"


def line_r2(x, y):
    """Slope, intercept and R^2 of a least-squares straight line."""
    m, c = np.polyfit(x, y, 1)
    pred = m * x + c
    ss_tot = float(np.sum((y - y.mean())**2))
    r2 = 1.0 - float(np.sum((y - pred)**2)) / ss_tot if ss_tot else float('nan')
    return float(m), float(c), r2


def screen(R, y):
    """
    Log-linearity screen. Returns a dict with the straight-line quality in
    each panel and the selected form.
    """
    ly = np.log(np.abs(y))
    m_e, c_e, r2_e = line_r2(R,     ly)
    m_g, c_g, r2_g = line_r2(R**2,  ly)
    return {
        'ly': ly,
        'exp':   {'m': m_e, 'c': c_e, 'r2': r2_e},
        'gauss': {'m': m_g, 'c': c_g, 'r2': r2_g},
        'choice': 'exp' if r2_e >= r2_g else 'gauss',
        'margin': abs(r2_e - r2_g),
    }


def fit_one(f, R, y, seeds):
    """Multi-start least squares; lowest-RMSE solution retained."""
    sols = []
    for p0 in seeds:
        try:
            with np.errstate(over='ignore', invalid='ignore'):
                p, cov = curve_fit(f, R, y, p0=p0, maxfev=200000)
        except (RuntimeError, TypeError, ValueError):
            continue
        pred = f(R, *p)
        if not np.all(np.isfinite(pred)):
            continue
        sols.append((float(np.sqrt(np.mean((y - pred)**2))), p, cov))
    if not sols:
        raise RuntimeError("no seed converged")
    sols.sort(key=lambda t: t[0])
    rm = np.array([t[0] for t in sols])
    n_min = 1 + int(np.sum(np.abs(np.diff(rm)) / max(rm[0], 1e-30) > 1e-6))
    best, p, cov = sols[0]
    return p, np.sqrt(np.diag(cov)), cov, {
        'n_seed': len(seeds), 'n_conv': len(sols), 'n_minima': n_min,
        'rmse_best': best, 'rmse_worst': float(rm[-1])}


def held_out(f, R, y, seeds, ks=(3, 4, 5)):
    """
    Interpolation test; endpoints always retained.

    Returns (ratios, decay values). The decay constant is collected across
    splits for the same reason fit_scf.py collects it: a form whose decay
    constant wanders when a third of the points are withheld is not
    describing the data, and the spread is the evidence for that. There is
    no GPT floor to test it against here, so it is reported as a stability
    statistic only.
    """
    ratios, ds = [], []
    for k in ks:
        for off in range(k):
            m = np.ones(len(R), bool)
            m[off::k] = False
            m[0] = m[-1] = True
            if (~m).sum() < 2:
                continue
            try:
                pk, _, _, _ = fit_one(f, R[m], y[m], seeds)
            except RuntimeError:
                continue
            r_in  = np.sqrt(np.mean((y[m]  - f(R[m],  *pk))**2))
            r_out = np.sqrt(np.mean((y[~m] - f(R[~m], *pk))**2))
            if r_in > 0:
                ratios.append(r_out / r_in)
                ds.append(pk[-1])
    return np.array(ratios), np.array(ds)


# ── Figure 1: the ln screen ─────────────────────────────────────────────────
def figure_screen(R, y, sc, meta, out_path, show_title=False):
    fig, (axl, axr) = plt.subplots(1, 2, figsize=(12.4, 5.2))
    ly = sc['ly']

    for ax, xv, key, xlab in (
            (axl, R,      'exp',   r"$R_{\ce{Ne-Ne}}$ (\AA)"),
            (axr, R**2,   'gauss', r"$R_{\ce{Ne-Ne}}^2$ (\AA$^2$)")):
        d = sc[key]
        ax.scatter(xv, ly, s=26, color='black', alpha=0.8, zorder=3)
        xs = np.linspace(xv.min(), xv.max(), 200)
        chosen = (sc['choice'] == key)
        ax.plot(xs, d['m'] * xs + d['c'], lw=1.6,
                color=('tab:blue' if chosen else 'tab:grey'),
                ls=('-' if chosen else '--'))
        ax.set_xlabel(xlab)
        ax.set_ylabel(rf"$\ln|{TAG}|$")
        ax.annotate(rf"$R^2_{{\mathrm{{line}}}} = {d['r2']:.4f}$",
                    xy=(0.04, 0.06), xycoords='axes fraction', fontsize=11)

    axl.annotate(rf"{meta['label']} ({meta['nbf']} bf)" + "\n"
                 + rf"$R \in [{R.min():.3f}, {R.max():.3f}]$ \AA, "
                   rf"{len(R)} points",
                 xy=(0.96, 0.94), xycoords='axes fraction',
                 ha='right', va='top', fontsize=10, linespacing=1.5)

    if show_title:
        fig.suptitle(rf"Ne dimer: log-linearity screen for ${TAG}$, "
                     rf"{meta['label']}", fontsize=13)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"    Saved figure: {out_path.name}")


# ── Figure 2: the fit ───────────────────────────────────────────────────────
def figure_fit(R, y, name, res, meta, out_path, show_title=False):
    spec = FORMS[name]
    fig, (ax, axc) = plt.subplots(1, 2, figsize=(12.4, 5.4))

    ax.scatter(R, y, s=30, color='black', alpha=0.8, zorder=3,
               label='computed')
    Rf = np.linspace(R.min(), R.max(), 500)
    ax.plot(Rf, spec['fn'](Rf, *res['p']), lw=1.7, color='tab:blue',
            label=spec['tex'])
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(rf"${TAG}$ (kcal/mol)")
    ax.legend(frameon=False, loc='lower right', fontsize=10)

    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + 0.38 * (hi - lo))
    ps = r",\; ".join(rf"{n}={v:.4f}"
                      for n, v in zip(spec['names'], res['p']))
    ax.annotate("\n".join([
        rf"{meta['label']} ({meta['nbf']} bf)",
        rf"${ps}$",
        rf"RMSE $= {rmse_tex(res['rmse'])}$ kcal/mol",
    ]), xy=(0.035, 0.965), xycoords='axes fraction',
        ha='left', va='top', fontsize=10, linespacing=1.5)

    axc.scatter(y, res['pred'], s=30, alpha=0.75, color='tab:blue',
                label=rf"{spec['tex']},  $R^2={res['r2']:.5f}$")
    allv = np.concatenate([y, res['pred']])
    lo, hi = float(allv.min()), float(allv.max())
    pad = 0.05 * (hi - lo)
    axc.plot([lo - pad, hi + pad], [lo - pad, hi + pad],
             color='grey', ls='--', lw=1.0, zorder=1)
    axc.set_xlim(lo - pad, hi + pad); axc.set_ylim(lo - pad, hi + pad)
    axc.set_aspect('equal', adjustable='box')
    axc.set_xlabel(rf"computed ${TAG}$ (kcal/mol)")
    axc.set_ylabel(rf"predicted ${TAG}$ (kcal/mol)")
    axc.legend(frameon=False, loc='upper left', fontsize=9)

    if show_title:
        fig.suptitle(rf"Ne dimer: ${TAG}$ fit, {meta['label']}", fontsize=13)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"    Saved figure: {out_path.name}")


def write_fit_csv(res, minfo, sc, ratios, ds, chosen, forced, meta, R, y,
                  sign, path):
    """
    Write one row per fitted PARAMETER to a per-basis CSV.

    Long format, matching fit_scf.py: the parameter set differs between
    forms (`exp` has a, c; `gauss` has a, b), so a wide layout would need a
    column per possible name. Fit-level diagnostics repeat across the rows
    of a form, so a single row is self-contained.

    NO gpt_* COLUMNS APPEAR HERE, and their absence is deliberate rather
    than an oversight. The GPT floor is a bound on a Gaussian exponent
    derived from the structure of the Hartree-Fock integrals; no analogue
    exists for a correlation increment. Emitting the columns empty would
    invite them to be filled in later or read as a withheld verdict, when
    in fact the test does not apply. `fit_scf.py` writes them; this script
    does not, and a merge of the two files will show them as missing for
    MP2c, which is the correct state.

    THE SCREEN IS RECORDED. `screen_r2_exp`, `screen_r2_gauss`,
    `screen_choice` and `screen_margin` travel with the fit, because the
    form was CHOSEN FROM THE DATA rather than derived, and the verdict is
    window- and basis-dependent. A parameter quoted without the screen that
    selected it is not traceable. `form_source` records whether the screen
    or --form decided.

    `decay_unit` is A^-1 for `exp` and A^-2 for `gauss`. These are not
    interchangeable and a decay constant in one must never be compared as a
    ratio to one in the other.

    Full precision (%.17g); rounding for display is the manuscript's job.
    """
    spec = FORMS[chosen]
    unit_txt = spec['unit_txt']
    common = {
        'basis_tag':      meta['tag'],
        'basis_label':    meta['label'],
        'nbf':            meta['nbf'],
        'column':         COLUMN,
        'form':           chosen,
        'form_expr':      spec['tex'],
        'form_source':    'forced (--form)' if forced else 'log screen',
        'n_par':          len(spec['names']),
        'R_min':          float(R.min()),
        'R_max':          float(R.max()),
        'n_points':       int(len(R)),
        'y_min':          float(y.min()),
        'y_max':          float(y.max()),
        'y_sign':         sign,
        'rmse':           res['rmse'],
        'r2':             res['r2'],
        'max_sigma_rel':  res['max_rel'],
        'cond_cov':       res['cond'],
        'n_seed':         minfo['n_seed'],
        'n_converged':    minfo['n_conv'],
        'n_minima':       minfo['n_minima'],
        'rmse_best':      minfo['rmse_best'],
        'rmse_worst':     minfo['rmse_worst'],
        'decay_value':    float(res['p'][-1]),
        'decay_sigma':    float(res['perr'][-1]),
        'decay_unit':     unit_txt,
        'screen_r2_exp':   sc['exp']['r2'],
        'screen_r2_gauss': sc['gauss']['r2'],
        'screen_choice':   sc['choice'],
        'screen_margin':   sc['margin'],
        'heldout_mean':   (ratios.mean() if len(ratios) else ''),
        'heldout_min':    (ratios.min() if len(ratios) else ''),
        'heldout_max':    (ratios.max() if len(ratios) else ''),
        'n_splits':       int(len(ratios)),
        'decay_split_mean': (ds.mean() if len(ds) else ''),
        'decay_split_std':  (ds.std() if len(ds) else ''),
    }
    rows = []
    for pname, val, err in zip(spec['names'], res['p'], res['perr']):
        rows.append({
            **common,
            'param':     pname,
            'value':     float(val),
            'sigma':     float(err),
            'sigma_rel': (float(abs(err / val)) if val else float('inf')),
            'unit':      (unit_txt if pname == spec['names'][-1]
                          else 'kcal/mol'),
        })

    cols = ['basis_tag', 'basis_label', 'nbf', 'column', 'form', 'form_expr',
            'form_source', 'n_par', 'param', 'value', 'sigma', 'sigma_rel',
            'unit', 'R_min', 'R_max', 'n_points', 'y_min', 'y_max', 'y_sign',
            'rmse', 'r2', 'max_sigma_rel', 'cond_cov',
            'n_seed', 'n_converged', 'n_minima', 'rmse_best', 'rmse_worst',
            'decay_value', 'decay_sigma', 'decay_unit',
            'screen_r2_exp', 'screen_r2_gauss', 'screen_choice',
            'screen_margin',
            'heldout_mean', 'heldout_min', 'heldout_max', 'n_splits',
            'decay_split_mean', 'decay_split_std']
    out = pd.DataFrame(rows, columns=cols)

    hdr = (f"# Ne dimer {COLUMN} fit results, {meta['label']}\n"
           "# one row per fitted parameter; fit-level diagnostics repeat\n"
           f"# across the rows of a form. Window [{R.min():.6g}, "
           f"{R.max():.6g}] A, {len(R)} points.\n"
           "# EMPIRICAL form, selected by the log-linearity screen. No GPT "
           "floor applies\n"
           "# to a correlation increment, so no gpt_* columns are written.\n"
           "# The screen is window- and basis-dependent: its two line R^2 "
           "values are\n"
           "# recorded here so the form choice travels with the parameters.\n"
           "# Fitted from several starting points, the lowest-RMSE solution "
           "retained.\n"
           "# RMSE and R^2 are descriptive and do NOT discriminate between "
           "forms.\n"
           f"# generated by fit_mp2c.py from {meta['csv']}\n")
    with open(path, 'w') as fh:
        fh.write(hdr)
        out.to_csv(fh, index=False, float_format='%.17g')
    print(f"    Saved fit CSV: {path.name}")


def main():
    ap = argparse.ArgumentParser(
        description="Empirical fit of the MP2-correlation BSSE component, "
                    "with the log-linearity screen that selects the form.")
    ap.add_argument("--basis", type=str.lower,
                    choices=list(BASES) + ["all"], default="all",
                    metavar="{dz,tz,qz,all}",
                    help="Basis; case-insensitive. Default: all.")
    ap.add_argument("--form", type=str.lower, choices=list(FORMS),
                    default=None,
                    help="Override the screen and force a form.")
    ap.add_argument("--mode", choices=["all", "csv", "fig"], default="all",
                    help="Which outputs to produce. 'all' (default) writes "
                         "figures and the fit CSV; 'csv' writes only the "
                         "CSV, leaving existing figures untouched; 'fig' "
                         "writes only figures. The FIT AND THE SCREEN RUN "
                         "EITHER WAY -- this selects what is written, not "
                         "what is computed. Under --mode csv the --plot "
                         "selection is ignored.")
    ap.add_argument("--plot", choices=["screen", "fit", "all"], default="all",
                    help="Which figure(s), when figures are being written. "
                         "Default: all.")
    ap.add_argument("--title", action="store_true",
                    help="In-figure suptitle. Off by default.")
    ap.add_argument("--R-min", dest="r_min", type=float, default=None,
                    metavar="R", help="Lower bound of the window (A).")
    ap.add_argument("--R-max", dest="r_max", type=float, default=None,
                    metavar="R", help="Upper bound of the window (A).")
    args = ap.parse_args()

    if (args.r_min is not None and args.r_max is not None
            and args.r_min > args.r_max):
        ap.error(f"--R-min ({args.r_min}) exceeds --R-max ({args.r_max}).")

    parts = []
    if args.r_min is not None:
        parts.append("Rmin" + f"{args.r_min:g}".replace('.', 'p'))
    if args.r_max is not None:
        parts.append("Rmax" + f"{args.r_max:g}".replace('.', 'p'))
    win = ('_' + '_'.join(parts)) if parts else ''

    keys = list(BASES) if args.basis == "all" else [args.basis]

    print(f"\n{'=' * 72}")
    print(f"  Ne/2_new_v2 — {COLUMN} fit study (empirical)")
    print(f"{'=' * 72}")
    print(f"  Study root : {STUDY_ROOT}")
    print(f"  Column     : {COLUMN}   (signed; fitted as stored)")
    print(f"  Form       : {'screen-selected' if args.form is None else args.form}")
    print(f"  Bases      : {', '.join(BASES[k]['tag'] for k in keys)}")
    mode_desc = {'all': 'figures + fit CSV',
                 'csv': 'fit CSV only, figures untouched',
                 'fig': 'figures only, CSVs untouched'}[args.mode]
    print(f"  Mode       : {args.mode}   ({mode_desc})")
    print("  NOTE       : no GPT floor applies to this component.")
    print(f"{'=' * 72}")

    if not CSV_DIR.is_dir():
        sys.exit(f"\nNo data_frames directory at {CSV_DIR}.\n"
                 f"Check that this script is in 2b_bsse_mp2c/scripts/.")
    if args.mode in ('all', 'fig'):
        FIG_DIR.mkdir(parents=True, exist_ok=True)
    if args.mode in ('all', 'csv'):
        CSV_OUT_DIR.mkdir(parents=True, exist_ok=True)

    for k in keys:
        meta = BASES[k]
        path = CSV_DIR / meta['csv']
        if not path.is_file():
            sys.exit(f"No CSV at {path}. Run build_bsse_csv.py first.")
        df = pd.read_csv(path).sort_values('R').reset_index(drop=True)
        if args.r_min is not None:
            df = df[df['R'] >= args.r_min]
        if args.r_max is not None:
            df = df[df['R'] <= args.r_max]
        df = df.reset_index(drop=True)
        if len(df) < 8:
            sys.exit(f"Window leaves {len(df)} points; too few to fit.")

        R = df['R'].to_numpy(); y = df[COLUMN].to_numpy()

        n_pos, n_neg = int((y > 0).sum()), int((y < 0).sum())
        if n_pos and n_neg:
            sys.exit(f"{COLUMN} changes sign inside the window at "
                     f"{meta['tag']} ({n_pos} positive, {n_neg} negative). "
                     f"ln|y| straddles a zero; the screen is invalid here.")
        sign = 'negative' if n_neg else 'positive'

        print(f"\n  {meta['tag']}: {len(df)} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A, "
              f"{COLUMN} {sign} at all {len(df)} R")

        sc = screen(R, y)
        print(f"    ln screen : vs R    (exponential) line R^2 = "
              f"{sc['exp']['r2']:.4f}")
        print(f"                vs R^2  (Gaussian)    line R^2 = "
              f"{sc['gauss']['r2']:.4f}")
        chosen = args.form or sc['choice']
        why = 'forced by --form' if args.form else \
              f"selected, margin {sc['margin']:.4f}"
        print(f"    form      : {chosen}  ({why})")
        if args.form is None and sc['margin'] < 0.01:
            print(f"    WARNING: the two panels differ by less than 0.01; "
                  f"the screen is not decisive here.")
        if max(sc['exp']['r2'], sc['gauss']['r2']) < 0.95:
            print(f"    WARNING: the better line has R^2 < 0.95 -- the "
                  f"selected form beats the other but does not describe "
                  f"the data well.")

        if args.mode in ("all", "fig") and args.plot in ("screen", "all"):
            figure_screen(R, y, sc, meta,
                          FIG_DIR / f"{FIG_PREFIX}_ln_screen_"
                                    f"{meta['tag']}{win}.png",
                          show_title=args.title)

        spec = FORMS[chosen]
        p, perr, cov, minfo = fit_one(spec['fn'], R, y, spec['seeds'])
        pred = spec['fn'](R, *p)
        resid = y - pred
        ss_tot = float(np.sum((y - y.mean())**2))
        res = {'p': p, 'perr': perr, 'pred': pred,
               'rmse': float(np.sqrt(np.mean(resid**2))),
               'r2': 1.0 - float(np.sum(resid**2)) / ss_tot,
               'cond': float(np.linalg.cond(cov)),
               'max_rel': float(max(abs(e / v) if v else np.inf
                                    for v, e in zip(p, perr)))}
        ratios, ds = held_out(spec['fn'], R, y, spec['seeds'])

        print(f"      " + '  '.join(f"{n}={v:+.5f}+-{e:.5f}"
                                    for n, v, e in zip(spec['names'],
                                                       p, perr)))
        print(f"      RMSE  = {rmse_txt(res['rmse'])} kcal/mol   "
              f"R^2 = {res['r2']:.6f}")
        print(f"      ident : max sigma/|p| = {res['max_rel']:.3f}   "
              f"cond(cov) = {res['cond']:.2e}")
        tag = ('single minimum' if minfo['n_minima'] == 1
               else f"{minfo['n_minima']} DISTINCT MINIMA -- best retained")
        print(f"      seeds : {minfo['n_conv']}/{minfo['n_seed']} converged, "
              f"{tag}")
        if len(ratios):
            print(f"      held-out ratio : mean {ratios.mean():.3f}  "
                  f"range [{ratios.min():.3f}, {ratios.max():.3f}]  "
                  f"({len(ratios)} splits)")
            print(f"      {spec['names'][-1]} across splits: "
                  f"{ds.mean():.5f} +- {ds.std():.5f} {spec['unit_txt']}")
        print("      R -> inf : vanishes by construction")

        if args.mode in ("all", "csv"):
            write_fit_csv(res, minfo, sc, ratios, ds, chosen,
                          args.form is not None, meta, R, y, sign,
                          CSV_OUT_DIR / f"{FIG_PREFIX}_fit_"
                                        f"{meta['tag']}{win}.csv")

        if args.mode in ("all", "fig") and args.plot in ("fit", "all"):
            figure_fit(R, y, chosen, res, meta,
                       FIG_DIR / f"{FIG_PREFIX}_fit_{meta['tag']}{win}.png",
                       show_title=args.title)

    print(f"\n  The screen compares a PURE exponential with a PURE Gaussian.")
    print(f"  It cannot rule on a polynomial-prefactored form, whose log is")
    print(f"  straight in neither panel. Its verdict depends on the window")
    print(f"  and on the basis, so quote both wherever it is used.")
    print()


if __name__ == '__main__':
    main()
