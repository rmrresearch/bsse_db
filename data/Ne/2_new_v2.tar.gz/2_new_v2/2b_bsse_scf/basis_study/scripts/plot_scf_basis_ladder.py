#!/usr/bin/env python3
"""
plot_scf_basis_ladder.py — Ne/2_new_v2, 2b_bsse_scf basis study
===============================================================

One figure, six panels, answering one question:

    Is |BSSE_SCF|(R) monotonically decreasing, and does the answer
    depend on the basis set?

  TOP ROW     |BSSE_SCF| vs R, full range, one panel per basis.
              Independent y-axes: the point of this row is the SHAPE of
              each curve, and a shared axis would flatten aug-cc-pVQZ
              against the axis (max 0.120 vs aug-cc-pVDZ's 0.769
              kcal/mol). Each panel is annotated with its own maximum so
              the magnitude ordering is not lost.

  BOTTOM ROW  d|BSSE_SCF|/dR vs R, with a zero line.
              A turning point in the top row is a zero crossing here.
              This row exists because the feature is far too small to see
              in the top row: at aug-cc-pVDZ it spans 7.26e-03 kcal/mol
              against a panel height of 0.759, i.e. under 1% of the panel.
              The derivative is what makes monotonicity readable.

Location:  bsse_db/data/Ne/2_new_v2/2b_bsse_scf/basis_study/scripts/
Input:     bsse_db/data/Ne/2_new_v2/data_frames/
             ne_dimer_bsse_vs_R_aug-cc-pv{dz,tz,qz}.csv
Output:    bsse_db/data/Ne/2_new_v2/2b_bsse_scf/basis_study/figures/

This script owns only this figure. It writes nowhere else, and no other
script writes here (handoff 30-Jul, 6F).


Why turning points are detected on the raw values, not the derivative
---------------------------------------------------------------------
Detection uses a sign change in successive differences of |BSSE_SCF| at
INTERIOR points only:

    (s[i] - s[i-1]) * (s[i+1] - s[i]) < 0

so the reported turning points do not depend on the choice of derivative
estimator. The derivative in the bottom row is a display of the same
information, computed with np.gradient (central differences on the
interior, one-sided at the two endpoints). Endpoint values of the
derivative are therefore less reliable than interior ones and are not used
for any reported quantity.


Sign
----
BSSE_SCF is negative at all 50 R at all three bases, so |BSSE_SCF| loses
no information here and the sign ambiguity that affects the CCSD(T)
correlation component (handoff 30-Jul, 5) does not arise for this
component. The script verifies this rather than assuming it, and warns if
it ever stops being true.


What this figure does and does not establish
--------------------------------------------
It establishes, as a measurement on this grid:

  * |BSSE_SCF| has two interior turning points at aug-cc-pVDZ and at
    aug-cc-pVTZ, and none at aug-cc-pVQZ;
  * the feature damps by ~13x from DZ to TZ and shifts outward by
    ~0.53 A;
  * at aug-cc-pVQZ the curve still decelerates to a near-plateau near
    R = 3.34 A before re-accelerating, without ever turning over. The
    shallowest decrement there is 1.53e-05 kcal/mol = 2.43e-08 Ha,
    roughly eight orders of magnitude above the ~1e-16 Ha SCF energy floor
    at thresh 1.0e-8, so it is not numerical noise.

So the sequence across the basis ladder is present -> present ->
sub-threshold, NOT present -> present -> absent.

It does NOT establish why. Candidate explanations are recorded in the
handoff (30-Jul, 3C) and all three carry the caveat that they were drawn
from single retrieved passages rather than full reads.

`% TODO: pending PI discussion` — the QZ near-approach revises finding 3
of the 30-Jul handoff, which currently reads "absent" at QZ.


Resolution caveat
-----------------
Monotonicity is a statement about the SAMPLED curve at dR = 0.040816 A.
A feature narrower than the grid spacing would not be resolved. The DZ
feature spans 5 grid points and survives subsampling to 20 points over the
same window (29-Jul handoff, 6A), so the grid resolves the feature where
one is known to exist; that is evidence about DZ, not a guarantee about QZ.


Usage
-----
    cd bsse_db/data/Ne/2_new_v2/2b_bsse_scf/basis_study/scripts
    python3 plot_scf_basis_ladder.py                  # the figure
    python3 plot_scf_basis_ladder.py --yscale log     # log y on the top row
    python3 plot_scf_basis_ladder.py --title          # in-figure suptitle
    python3 plot_scf_basis_ladder.py --R-min 2.0 --R-max 3.5
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# LaTeX rendering for all text (project convention).
plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})


# ── Paths (option A anchoring: 3 levels below the study root) ────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
STUDY_ROOT = SCRIPT_DIR.parent.parent.parent
CSV_DIR    = STUDY_ROOT / 'data_frames'
FIG_DIR    = SCRIPT_DIR.parent / 'figures'

COLUMN = '2b_bsse_SCF'

# Ordered DZ -> TZ -> QZ; the figure columns follow this order.
BASES = [
    ('dz', 'ne_dimer_bsse_vs_R_aug-cc-pvdz.csv', 'aug-cc-pVDZ',  46, 'tab:blue'),
    ('tz', 'ne_dimer_bsse_vs_R_aug-cc-pvtz.csv', 'aug-cc-pVTZ',  92, 'tab:orange'),
    ('qz', 'ne_dimer_bsse_vs_R_aug-cc-pvqz.csv', 'aug-cc-pVQZ', 160, 'tab:green'),
]

HARTREE_PER_KCAL = 1.0 / 627.509474
SCF_ENERGY_FLOOR_HA = 1.0e-16      # thresh 1.0e-8, energy ~ thresh^2


def window_suffix(r_min, r_max):
    """Filename suffix encoding the applied R window; empty when unset."""
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace('.', 'p'))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace('.', 'p'))
    return ('_' + '_'.join(parts)) if parts else ''


def apply_window(df, r_min, r_max):
    """Restrict to r_min <= R <= r_max. Plot-time filter only."""
    out = df
    if r_min is not None:
        out = out[out['R'] >= r_min]
    if r_max is not None:
        out = out[out['R'] <= r_max]
    out = out.reset_index(drop=True)
    if len(out) < 5:
        raise ValueError(
            f"R window [{r_min}, {r_max}] leaves {len(out)} points; at least "
            f"5 are needed to speak about turning points."
        )
    return out


def load_basis(csv_name):
    """Load one basis, sorted by R, and check the sign assumption."""
    path = CSV_DIR / csv_name
    if not path.is_file():
        raise FileNotFoundError(
            f"No CSV at {path}. Run build_bsse_csv.py first."
        )
    df = pd.read_csv(path).sort_values('R').reset_index(drop=True)
    n_pos = int((df[COLUMN] > 0).sum())
    if n_pos:
        print(f"    WARNING: {COLUMN} is positive at {n_pos}/{len(df)} R in "
              f"{path.name}. This script plots |BSSE_SCF| and assumes a "
              f"single sign; check before using the figure.")
    return df


def turning_points(s):
    """
    Indices of interior turning points of the sequence s.

    Detected from sign changes in successive differences, so the result is
    independent of any derivative estimator. Endpoints cannot be turning
    points and are excluded.
    """
    return [i for i in range(1, len(s) - 1)
            if (s[i] - s[i - 1]) * (s[i + 1] - s[i]) < 0]


def analyse(R, s):
    """
    Quantities reported for one basis. Returns a dict; nothing here is
    interpreted, only measured.
    """
    idx  = turning_points(s)
    diff = np.diff(s)

    out = {
        'n_tp':      len(idx),
        'tp_R':      [float(R[i]) for i in idx],
        'first':     float(s[0]),
        'last':      float(s[-1]),
        'ratio':     float(s[0] / s[-1]) if s[-1] else float('nan'),
        'amp':       None,
        'midpoint':  None,
        'shallow_R': None,
        'shallow_d': None,
    }

    if idx:
        i0, i1 = idx[0], idx[-1]
        out['amp']      = float(abs(s[i0] - s[i1]))
        out['midpoint'] = float(0.5 * (R[i0] + R[i1]))
    else:
        # No turning point: report the shallowest decrement instead, i.e.
        # how close the curve comes to turning over. Interior only.
        j = int(np.argmin(np.abs(diff[1:-1])) + 1)
        out['shallow_R'] = float(R[j])
        out['shallow_d'] = float(diff[j])

    return out


def build_figure(data, out_path, show_title=False, yscale='linear'):
    """Draw the 2x3 grid and save it."""
    fig, axes = plt.subplots(2, 3, figsize=(13.5, 7.2), sharex=True)

    for col, (key, label, nbf, color, R, s, info) in enumerate(data):
        ax_top = axes[0, col]
        ax_bot = axes[1, col]

        # ── top: |BSSE_SCF| ──────────────────────────────────────────────
        ax_top.scatter(R, s, s=18, alpha=0.75, color=color)
        ax_top.set_yscale(yscale)
        # Column identity. This is a data label, not a description of the
        # figure, so it is drawn regardless of --title.
        ax_top.set_title(rf"{label} ({nbf} bf)", fontsize=12)
        if col == 0:
            ax_top.set_ylabel(r"$|\mathrm{BSSE}_{\mathrm{SCF}}|$ (kcal/mol)")
        ax_top.annotate(rf"max $= {info['first']:.4f}$",
                        xy=(0.97, 0.93), xycoords='axes fraction',
                        ha='right', va='top', fontsize=10)

        # ── bottom: derivative ───────────────────────────────────────────
        d = np.gradient(s, R)
        ax_bot.plot(R, d, lw=1.2, color=color)
        ax_bot.scatter(R, d, s=10, alpha=0.6, color=color)
        ax_bot.axhline(0.0, color='black', lw=0.9)
        if col == 0:
            ax_bot.set_ylabel(
                r"$\mathrm{d}|\mathrm{BSSE}_{\mathrm{SCF}}|/\mathrm{d}R$"
                r"\ (kcal\,mol$^{-1}$\,\AA$^{-1}$)")
        ax_bot.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")

        # Mark turning points where they exist; otherwise mark the closest
        # approach to zero, which is the QZ case.
        for rtp in info['tp_R']:
            ax_bot.axvline(rtp, color='grey', ls=':', lw=1.0, alpha=0.8)
        if info['n_tp']:
            ax_bot.annotate(rf"{info['n_tp']} zero crossings",
                            xy=(0.97, 0.08), xycoords='axes fraction',
                            ha='right', va='bottom', fontsize=10)
        else:
            ax_bot.axvline(info['shallow_R'], color='grey', ls=':', lw=1.0,
                           alpha=0.8)
            ax_bot.annotate(r"no zero crossing",
                            xy=(0.97, 0.08), xycoords='axes fraction',
                            ha='right', va='bottom', fontsize=10)

    if show_title:
        fig.suptitle(r"Ne dimer: $|\mathrm{BSSE}_{\mathrm{SCF}}|$ and its "
                     r"derivative across the basis ladder", fontsize=13)

    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"\n  Saved figure: {out_path.name}"
          f"{'  (log y, top row)' if yscale == 'log' else ''}")


def report(data, window_txt):
    """Console diagnostics. These are the numbers the paper text quotes."""
    print(f"\n  Monotonicity of |BSSE_SCF| over {window_txt}")
    print(f"  {'-' * 70}")
    print(f"  {'basis':<14}{'turning pts':<14}{'at R (A)':<22}"
          f"{'amplitude (kcal/mol)':<20}")
    print(f"  {'-' * 70}")
    for key, label, nbf, color, R, s, info in data:
        tp = ', '.join(f"{r:.4f}" for r in info['tp_R']) or '-'
        amp = f"{info['amp']:.3e}" if info['amp'] is not None else '-'
        print(f"  {label:<14}{info['n_tp']:<14}{tp:<22}{amp:<20}")
    print(f"  {'-' * 70}")

    for key, label, nbf, color, R, s, info in data:
        print(f"    {label}: |BSSE_SCF| {info['first']:.5f} -> "
              f"{info['last']:.5f} kcal/mol  (ratio {info['ratio']:.1f})")
    print(f"  {'-' * 70}")

    # Feature damping between consecutive bases that both have a feature.
    withf = [(lab, i) for _, lab, _, _, _, _, i in data if i['amp']]
    for (la, ia), (lb, ib) in zip(withf, withf[1:]):
        print(f"    {la} -> {lb}: amplitude ratio {ia['amp'] / ib['amp']:.1f}x"
              f"   midpoint shift {ib['midpoint'] - ia['midpoint']:+.3f} A")

    # Bases with no turning point: how close did they come, and is that
    # above the numerical floor?
    for key, label, nbf, color, R, s, info in data:
        if info['n_tp']:
            continue
        d_kcal = info['shallow_d']
        d_ha   = d_kcal * HARTREE_PER_KCAL
        print(f"  {'-' * 70}")
        print(f"    {label}: no turning point. Shallowest interior decrement")
        print(f"      {d_kcal:+.3e} kcal/mol = {d_ha:+.3e} Ha "
              f"at R = {info['shallow_R']:.4f} A")
        print(f"      SCF energy floor (thresh 1e-8) ~ "
              f"{SCF_ENERGY_FLOOR_HA:.0e} Ha  ->  margin "
              f"{abs(d_ha) / SCF_ENERGY_FLOOR_HA:.0e}x")
        print(f"      The curve decelerates and re-accelerates without "
              f"turning over.")
        print(f"      %% TODO: pending PI discussion")
    print(f"  {'-' * 70}")
    print("    Monotonicity is a statement about the sampled grid; a feature")
    print("    narrower than dR would not be resolved.")
    print(f"  {'-' * 70}")


def main():
    parser = argparse.ArgumentParser(
        description="Basis-ladder figure for |BSSE_SCF|(R): magnitude and "
                    "derivative, DZ / TZ / QZ.",
    )
    parser.add_argument(
        "--title", action="store_true",
        help="Draw an in-figure suptitle. Off by default: publication "
             "figures carry their description in the LaTeX caption. Column "
             "basis labels are drawn either way, since they identify the "
             "data rather than describe the figure.",
    )
    parser.add_argument(
        "--yscale", choices=["linear", "log"], default="linear",
        help="Y-axis scale for the TOP row only. The derivative row changes "
             "sign and cannot use a log axis. Default: linear.",
    )
    parser.add_argument(
        "--R-min", dest="r_min", type=float, default=None, metavar="R",
        help="Lower bound of the R window, in Angstrom. Plot-time filter "
             "only; the CSVs are never modified.",
    )
    parser.add_argument(
        "--R-max", dest="r_max", type=float, default=None, metavar="R",
        help="Upper bound of the R window, in Angstrom. Applying a window "
             "appends a suffix to the output filename.",
    )
    args = parser.parse_args()

    if (args.r_min is not None and args.r_max is not None
            and args.r_min > args.r_max):
        parser.error(f"--R-min ({args.r_min}) exceeds --R-max ({args.r_max}).")

    win = window_suffix(args.r_min, args.r_max)

    print(f"\n{'=' * 72}")
    print("  Ne/2_new_v2 — BSSE_SCF basis study")
    print(f"{'=' * 72}")
    print(f"  Study root : {STUDY_ROOT}")
    print(f"  CSV dir    : {CSV_DIR}")
    print(f"  Figure dir : {FIG_DIR}")
    print(f"  Column     : {COLUMN}")
    print(f"  Top row    : {'log' if args.yscale == 'log' else 'linear'} y, "
          f"independent per panel")
    print(f"{'=' * 72}\n")

    if not CSV_DIR.is_dir():
        sys.exit(f"No data_frames directory at {CSV_DIR}.\n"
                 f"Check that this script is in "
                 f"2b_bsse_scf/basis_study/scripts/.")

    FIG_DIR.mkdir(parents=True, exist_ok=True)

    data = []
    for key, csv_name, label, nbf, color in BASES:
        df_all = load_basis(csv_name)
        df     = apply_window(df_all, args.r_min, args.r_max)
        R = df['R'].to_numpy()
        s = np.abs(df[COLUMN].to_numpy())
        info = analyse(R, s)
        print(f"  {label:<12} {len(df):>3}/{len(df_all)} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A, "
              f"{info['n_tp']} interior turning point(s)")
        data.append((key, label, nbf, color, R, s, info))

    build_figure(
        data,
        FIG_DIR / f'scf_basis_ladder{win}'
                  f'{"_log" if args.yscale == "log" else ""}.png',
        show_title=args.title, yscale=args.yscale,
    )

    R0 = data[0][4]
    report(data, f"{len(R0)} R in [{R0.min():.3f}, {R0.max():.3f}] A")
    print()


if __name__ == '__main__':
    main()
