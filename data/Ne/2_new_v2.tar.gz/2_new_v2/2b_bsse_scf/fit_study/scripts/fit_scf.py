#!/usr/bin/env python3
"""
fit_scf.py — Ne/2_new_v2, 2b_bsse_scf fit study
===============================================

Fits the SCF component of the BSSE, `2b_bsse_SCF`, with the single-channel
family that the Gaussian Product Theorem and the Boys function motivate,
and evaluates it against the acceptance criteria that can actually fail.

    BSSE_SCF(R) = P(R) * exp(-b R^2)

with P a low-degree EVEN polynomial. The even restriction is not a
convenience: Szabo & Ostlund eq. A.11 gives the kinetic-energy integral
between 1s primitives as

    T_AB = ab/(a+b) * [3 - 2ab/(a+b) R^2] * [pi/p]^(3/2) * exp(-gamma R^2)

i.e. literally (a0 + a2 R^2) exp(-gamma R^2), with both coefficients fixed
by the primitive exponents and with no angular momentum required. There is
no linear term in the theory, and the fit reproduces that: including one
drives sigma/|p| above 5 and the condition number up three orders (see
--form poly1, retained only so the failure can be shown rather than
asserted).


THE ACCEPTANCE TEST IS ONE-SIDED
--------------------------------
GPT gives the Gaussian product exponent as gamma = alpha*beta/(alpha+beta)
for one primitive pair, which is monotonically increasing in both
arguments. The minimum over all pairs is therefore alpha_min/2, and no
additional primitive can lower it. At second order the exponents add, so

    2nd-order GPT floor = alpha_min = the most diffuse primitive exponent

The ceiling is vacuous: core primitives reach alpha ~ 1e5 bohr^-2 at
aug-cc-pVQZ, putting the ceiling at ~1.8e5 A^-2. So a fitted b BELOW the
floor falsifies the form; a fitted b above it passes, and no upper test is
applied.

The floor is a property of the BASIS, not of Ne, and must be recomputed for
each one (handoff 30-Jul, 7A). Floors are stored below as alpha_min in
bohr^-2 with their provenance, and converted here, so adding a basis means
adding one number read off an `A_AB.out` basis block.

NOTE the floor FALLS as the basis improves (DZ 0.380, QZ 0.292 A^-2),
because larger Dunning sets carry more diffuse primitives. Clearing the
floor at QZ is a weaker statement than clearing it at DZ. Say so wherever
a pass is reported.


WHAT IS FITTED
--------------
The SIGNED component, per handoff 29-Jul 11A. `2b_bsse_SCF` is negative at
all 50 R at all three bases, so the amplitude comes out negative. Absolute
values are taken at plot time only, never before fitting.

The fit target is the INCREMENTAL column, which for the SCF component is
also the cumulative one -- SCF is the first term in the decomposition, so
the two conventions coincide here and only here.


CRITERIA APPLIED (handoff 29-Jul, 3)
------------------------------------
  parameter constraint  b >= GPT floor                      can fail
  R -> infinity         model must vanish                   satisfied by
                                                            construction for
                                                            any polynomial x
                                                            Gaussian
  identifiability       sigma/|p| and cond(covariance)      can fail
  seed independence     same minimum from every start        can fail
  held-out interpolation  fit on a subset, predict the rest can fail

Residual randomisation is NOT used and does not appear here. These data are
deterministic; re-running a job returns the same number, so residuals are
model error, not noise, and smooth functions do not look random (handoff
29-Jul, 2A). Residuals are plotted for FALSIFICATION only -- structure in a
low-parameter fit shows the form is wrong -- and never as evidence that a
form is right.


Location:  bsse_db/data/Ne/2_new_v2/2b_bsse_scf/fit_study/scripts/
Input:     bsse_db/data/Ne/2_new_v2/data_frames/
Output:    bsse_db/data/Ne/2_new_v2/2b_bsse_scf/fit_study/figures/
           bsse_db/data/Ne/2_new_v2/2b_bsse_scf/fit_study/fit_csv/

Usage
-----
    cd bsse_db/data/Ne/2_new_v2/2b_bsse_scf/fit_study/scripts
    python3 fit_scf.py                       # all three bases, both forms
    python3 fit_scf.py --mode csv            # fit CSVs only; leave figures alone
    python3 fit_scf.py --basis QZ            # one basis; case-insensitive
    python3 fit_scf.py --only-missing        # skip bases already plotted
    python3 fit_scf.py --basis QZ --form poly2 --form hx    # vs Heindel-Xantheas
    python3 fit_scf.py --basis QZ --form gauss --form hx    # at equal npar
    python3 fit_scf.py --form poly1          # include the odd-polynomial form
    python3 fit_scf.py --R-min 2.0           # restricted window
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.special import erf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})

# ── Paths (option A anchoring: 3 levels below the study root) ────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
STUDY_ROOT = SCRIPT_DIR.parent.parent.parent
CSV_DIR    = STUDY_ROOT / 'data_frames'
FIG_DIR    = SCRIPT_DIR.parent / 'figures'
CSV_OUT_DIR = SCRIPT_DIR.parent / 'fit_csv'

COLUMN   = '2b_bsse_SCF'
BOHR2_TO_A2 = 3.5710          # gamma[A^-2] = gamma[bohr^-2] * 3.5710

# ── Basis registry ───────────────────────────────────────────────────────────
# alpha_min is the most diffuse primitive exponent, read from the `Basis
# "ao basis"` block of any A_AB.out for that basis. It IS the second-order
# GPT floor. Set to None for a basis whose block has not been read yet: the
# fit still runs, the acceptance verdict is withheld.
BASES = {
    'dz': {
        'tag': 'DZ', 'label': 'aug-cc-pVDZ', 'nbf': 46,
        'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvdz.csv',
        'alpha_min': 0.1064,
        'alpha_min_src': 'P shell, 17 distinct primitives (handoff 29-Jul, 5D)',
    },
    'tz': {
        'tag': 'TZ', 'label': 'aug-cc-pVTZ', 'nbf': 92,
        'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvtz.csv',
        'alpha_min': 0.09175,
        'alpha_min_src': 'P shell, 22 distinct primitives (S 11, P 6, D 3, F 2)',
    },
    'qz': {
        'tag': 'QZ', 'label': 'aug-cc-pVQZ', 'nbf': 160,
        'csv': 'ne_dimer_bsse_vs_R_aug-cc-pvqz.csv',
        'alpha_min': 0.08178,
        'alpha_min_src': 'P shell, 29 distinct primitives (S 13, P 7, D 4, F 3, G 2)',
    },
}


# ── Candidate forms ──────────────────────────────────────────────────────────
def _gauss(R, a0, b):
    return a0 * np.exp(-b * R**2)


def _poly2(R, a0, a2, b):
    return (a0 + a2 * R**2) * np.exp(-b * R**2)


def _poly1(R, a0, a1, a2, b):
    return (a0 + a1 * R + a2 * R**2) * np.exp(-b * R**2)


def _hx(R, a, b):
    # Heindel & Xantheas 2020, motivated by the overlap area of two Gaussian
    # charge distributions. Included for comparison, not as a candidate.
    return a * (1.0 + erf(-b * R))


def _boys(R, a0, a2, c, k, b):
    # Boys branch carried explicitly: erf(kR)/R on the SAME Gaussian.
    return (a0 + a2 * R**2 + c * erf(k * R) / R) * np.exp(-b * R**2)


FORMS = {
    'gauss': {
        'fn': _gauss, 'p0': [-2.0, 0.6],
        'seeds': [[-2.0, 0.6], [-0.2, 0.3], [-1.0, 1.0], [-5.0, 1.5]],
        'names': ['a0', 'b'],
        'tex': r"$a_0\,e^{-bR^2}$",
        'note': 'pure Gaussian, the one-channel null hypothesis',
    },
    'poly2': {
        'fn': _poly2, 'p0': [-2.0, 0.1, 0.6],
        'seeds': [[-2.0, 0.1, 0.6], [-0.2, -0.03, 0.4], [-1.0, 0.0, 1.0],
                  [-0.5, 0.05, 0.3], [-3.0, 0.5, 1.5], [10.0, -9.0, 1.1],
                  [-8.0, 2.0, 0.9]],
        'names': ['a0', 'a2', 'b'],
        'tex': r"$(a_0+a_2R^2)\,e^{-bR^2}$",
        'note': 'even polynomial prefactor, the form of S&O A.11',
    },
    'poly1': {
        'fn': _poly1, 'p0': [-2.0, 0.1, 0.1, 0.6],
        'seeds': [[-2.0, 0.1, 0.1, 0.6], [-0.2, 0.0, -0.03, 0.4],
                  [-1.0, 0.0, 0.0, 1.0], [10.0, 0.0, -9.0, 1.1]],
        'names': ['a0', 'a1', 'a2', 'b'],
        'tex': r"$(a_0+a_1R+a_2R^2)\,e^{-bR^2}$",
        'note': 'odd term included; A.11 has none, and it is unidentifiable',
    },
    'hx': {
        'fn': _hx, 'p0': [-2.0, 0.8],
        'seeds': [[-2.0, 0.8], [-0.4, 0.5], [-1.0, 1.0], [-8.0, 0.3]],
        'names': ['a', 'b'], 'b_unit': 'A^-1',
        'tex': r"$a\,[1+\mathrm{erf}(-bR)]$",
        'note': 'Heindel-Xantheas erf form (comparison; b is in A^-1, NOT A^-2 '
                'and is NOT comparable to the GPT floor)',
    },
    'boys': {
        'fn': _boys, 'p0': [-0.2, -0.03, -0.05, 0.4, 0.37],
        'seeds': [[-0.2, -0.03, -0.05, 0.4, 0.37],
                  [-2.0, 0.1, -0.5, 0.8, 0.6], [10.0, -9.0, -1.0, 0.5, 1.1]],
        'names': ['a0', 'a2', 'c', 'k', 'b'],
        'tex': r"$(a_0+a_2R^2+c\,\mathrm{erf}(\kappa R)/R)\,e^{-bR^2}$",
        'note': 'Boys branch carried explicitly; not identifiable on these data',
    },
}
# The reported form. gauss / poly1 / boys are retained so the three
# exclusions can be SHOWN on request rather than asserted:
#   gauss  -- drops the A.11 polynomial prefactor
#   poly1  -- adds a linear term A.11 does not have
#   boys   -- carries the erf(kR)/R branch explicitly
DEFAULT_FORMS = ['poly2']

COLORS = {'poly2': 'tab:blue', 'gauss': 'tab:red',
          'poly1': 'tab:green', 'boys': 'tab:purple',
          'hx': 'tab:orange'}


def rmse_tex(v, exp=-3):
    """RMSE as a mantissa times 10^exp, e.g. 2.476 x 10^{-3}."""
    return rf"{v / 10.0**exp:.3f}\times 10^{{{exp}}}"


def rmse_txt(v, exp=-3):
    return f"{v / 10.0**exp:.3f}e{exp:+03d}".replace(f'e{exp:+03d}',
                                                      f' x 10^{exp}')


def floor_A2(meta):
    """Second-order GPT floor in A^-2, or None if alpha_min is unknown."""
    a = meta['alpha_min']
    return None if a is None else a * BOHR2_TO_A2


def fit_one(f, R, y, seeds):
    """
    Least-squares fit from several starting points; the lowest-RMSE solution
    is returned.

    The starting guess is a numerical detail of the optimizer, not a model
    parameter: the form and its parameter count are identical from every
    seed. Multi-start is needed because the objective is not convex and can
    have more than one local minimum. At aug-cc-pVDZ the poly2 surface has
    two basins, and in one of them a2 is driven to exactly zero -- the
    polynomial term switches off and the fit silently degenerates to the
    pure Gaussian, with a WORSE RMSE. Reporting that solution would
    understate the form.

    Returns (params, 1-sigma errors, covariance, info) where info records
    how many distinct minima were reached and the spread in RMSE, so a split
    like the DZ one is visible rather than silent.
    """
    sols = []
    for p0 in seeds:
        try:
            with np.errstate(over='ignore', invalid='ignore'):
                p, cov = curve_fit(f, R, y, p0=p0, maxfev=200000)
        except (RuntimeError, TypeError, ValueError):
            continue
        pred = f(R, *p)
        if not np.all(np.isfinite(pred)):
            continue
        sols.append((float(np.sqrt(np.mean((y - pred)**2))), p, cov))
    if not sols:
        raise RuntimeError("no seed converged")
    sols.sort(key=lambda t: t[0])
    rmses = np.array([t[0] for t in sols])
    # distinct minima: RMSE differing by more than 1e-9 relative
    distinct = 1 + int(np.sum(np.abs(np.diff(rmses)) / max(rmses[0], 1e-30)
                              > 1e-6))
    best_rmse, p, cov = sols[0]
    info = {
        'n_seed': len(seeds), 'n_conv': len(sols), 'n_minima': distinct,
        'rmse_best': best_rmse, 'rmse_worst': float(rmses[-1]),
    }
    return p, np.sqrt(np.diag(cov)), cov, info


def held_out(f, R, y, seeds, ks=(3, 4, 5)):
    """
    Interpolation test. For each k and each offset, withhold every k-th
    point, refit on the rest, and compare RMSE on withheld vs fitted points.

    Endpoints are always retained so that every withheld point lies INSIDE
    the fitted range: this tests interpolation, not extrapolation.

    Returns (ratios, b values) across all splits.
    """
    ratios, bs = [], []
    for k in ks:
        for off in range(k):
            m = np.ones(len(R), bool)
            m[off::k] = False
            m[0] = m[-1] = True
            if (~m).sum() < 2:
                continue
            try:
                pk, _, _, _ = fit_one(f, R[m], y[m], seeds)
            except RuntimeError:
                continue
            r_in  = np.sqrt(np.mean((y[m]  - f(R[m],  *pk))**2))
            r_out = np.sqrt(np.mean((y[~m] - f(R[~m], *pk))**2))
            if r_in > 0:
                ratios.append(r_out / r_in)
                bs.append(pk[-1])
    return np.array(ratios), np.array(bs)


def analyse(key, R, y, meta):
    """Fit every requested form to one basis and collect the diagnostics."""
    out = {}
    fl = floor_A2(meta)
    for name in meta['_forms']:
        spec = FORMS[name]
        f  = spec['fn']
        p0 = spec['p0']
        seeds = spec.get('seeds', [p0])
        p, perr, cov, minfo = fit_one(f, R, y, seeds)
        pred  = f(R, *p)
        resid = y - pred
        ss_res = float(np.sum(resid**2))
        ss_tot = float(np.sum((y - y.mean())**2))
        ratios, bs = held_out(f, R, y, seeds)
        b = p[-1]
        # The GPT floor is a bound on a Gaussian exponent in A^-2. The HX
        # parameter is an erf rate in A^-1: comparing them is a unit error.
        floor_applies = (name != 'hx')
        out[name] = {
            'p': p, 'perr': perr,
            'rmse': float(np.sqrt(np.mean(resid**2))),
            'r2': (1.0 - ss_res / ss_tot) if ss_tot else float('nan'),
            'pred': pred, 'resid': resid,
            'cond': float(np.linalg.cond(cov)),
            'max_rel': float(max(abs(e / v) if v else np.inf
                                 for v, e in zip(p, perr))),
            'b': float(b), 'b_err': float(perr[-1]),
            'verdict': (None if (fl is None or not floor_applies)
                        else ('pass' if b >= fl else 'fail')),
            'floor_applies': floor_applies,
            'ratios': ratios, 'bs': bs, 'minfo': minfo,
            'n_below': (None if (fl is None or not floor_applies)
                        else int((bs < fl).sum())),
            'n_split': len(bs),
        }
    return out


def build_figure(R, y, res, meta, out_path, show_title=False):
    """
    Two panels, no residual panel.

      left   fit overlaid on the computed points, with RMSE, the fitted
             parameters, and b against this basis's GPT floor
      right  computed vs predicted with the 1:1 line and R^2

    The residual panel was removed deliberately. These data are
    deterministic, so residuals are model error rather than noise, and a
    residual panel invites the reading that structure there means the fit is
    bad in a way that more parameters would cure (handoff 29-Jul, 2A). Use
    --form gauss / poly1 / boys when a falsification needs showing.
    """
    fl = floor_A2(meta)
    fig, (ax, axc) = plt.subplots(1, 2, figsize=(12.4, 5.4))

    # ── left: the fit ────────────────────────────────────────────────────
    ax.scatter(R, y, s=30, color='black', alpha=0.8, zorder=3,
               label='computed')
    Rf = np.linspace(R.min(), R.max(), 500)
    for name, r in res.items():
        ax.plot(Rf, FORMS[name]['fn'](Rf, *r['p']), lw=1.7,
                color=COLORS[name], zorder=2, label=FORMS[name]['tex'])
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$\mathrm{BSSE}_{\mathrm{SCF}}$ (kcal/mol)")
    ax.legend(frameon=False, loc='lower right', fontsize=10)

    # Basis label and fit statistics in the upper-left, where BSSE_SCF is
    # most negative and the data are furthest from the corner. Headroom is
    # added so the text cannot sit on the points.
    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + 0.42 * (hi - lo))
    lines = [rf"{meta['label']} ({meta['nbf']} bf)"]
    for name, r in res.items():
        ps = r",\; ".join(
            rf"{n}={v:.4f}".replace('a0', 'a_0').replace('a2', 'a_2')
            for n, v in zip(FORMS[name]['names'], r['p']))
        lines.append(rf"${ps}$")
        lines.append(rf"RMSE $= {rmse_tex(r['rmse'])}$ kcal/mol")
    ax.annotate("\n".join(lines), xy=(0.035, 0.965),
                xycoords='axes fraction', ha='left', va='top', fontsize=10,
                linespacing=1.5)

    # ── right: computed vs predicted ─────────────────────────────────────
    allv = [y]
    for name, r in res.items():
        axc.scatter(y, r['pred'], s=30, alpha=0.75, color=COLORS[name],
                    label=rf"{FORMS[name]['tex']},  $R^2={r['r2']:.5f}$")
        allv.append(r['pred'])
    lo = float(min(v.min() for v in allv)); hi = float(max(v.max() for v in allv))
    pad = 0.05 * (hi - lo)
    axc.plot([lo - pad, hi + pad], [lo - pad, hi + pad],
             color='grey', ls='--', lw=1.0, zorder=1)
    axc.set_xlim(lo - pad, hi + pad); axc.set_ylim(lo - pad, hi + pad)
    axc.set_aspect('equal', adjustable='box')
    axc.set_xlabel(r"computed $\mathrm{BSSE}_{\mathrm{SCF}}$ (kcal/mol)")
    axc.set_ylabel(r"predicted $\mathrm{BSSE}_{\mathrm{SCF}}$ (kcal/mol)")
    axc.legend(frameon=False, loc='upper left', fontsize=9)

    if show_title:
        fig.suptitle(rf"Ne dimer: $\mathrm{{BSSE}}_{{\mathrm{{SCF}}}}$ fit, "
                     rf"{meta['label']}", fontsize=13)

    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"    Saved figure: {out_path.name}")


def write_fit_csv(res, meta, R, y, path):
    """
    Write one row per fitted PARAMETER to a per-basis CSV.

    Long format, not wide, because the parameter set differs between forms --
    poly2 has (a0, a2, b), hx has (a, b), boys has five. A wide layout would
    need a column per possible name, mostly blank, and would silently break
    the first time a form is added. Here every row names its own parameter,
    and the fit-level diagnostics repeat across the rows of one form so that
    a single row is self-contained and the file can be filtered on `form`
    alone.

    Full precision is written (%.17g). Rounding for display is the
    manuscript's job, not this file's -- a stored number that has already
    been rounded cannot be un-rounded.

    The window and the basis are stored as columns, not merely in the
    filename, because every statement of functional form must carry both.
    """
    fl = floor_A2(meta)
    rows = []
    for name, r in res.items():
        spec = FORMS[name]
        applies = r.get('floor_applies', True)
        b_unit = spec.get('b_unit', 'A^-2')
        mi = r['minfo']
        common = {
            'basis_tag':      meta['tag'],
            'basis_label':    meta['label'],
            'nbf':            meta['nbf'],
            'column':         COLUMN,
            'form':           name,
            'form_expr':      spec['tex'],
            'n_par':          len(spec['names']),
            'R_min':          float(R.min()),
            'R_max':          float(R.max()),
            'n_points':       int(len(R)),
            'y_min':          float(y.min()),
            'y_max':          float(y.max()),
            'rmse':           r['rmse'],
            'r2':             r['r2'],
            'max_sigma_rel':  r['max_rel'],
            'cond_cov':       r['cond'],
            'n_seed':         mi['n_seed'],
            'n_converged':    mi['n_conv'],
            'n_minima':       mi['n_minima'],
            'rmse_best':      mi['rmse_best'],
            'rmse_worst':     mi['rmse_worst'],
            'decay_value':    r['b'],
            'decay_sigma':    r['b_err'],
            'decay_unit':     b_unit,
            'gpt_floor_A2':   ('' if (fl is None or not applies) else fl),
            'gpt_margin':     ('' if (fl is None or not applies)
                               else r['b'] - fl),
            'gpt_verdict':    (r['verdict'] if applies else 'n/a'),
            'heldout_mean':   (r['ratios'].mean() if len(r['ratios']) else ''),
            'heldout_min':    (r['ratios'].min() if len(r['ratios']) else ''),
            'heldout_max':    (r['ratios'].max() if len(r['ratios']) else ''),
            'n_splits':       r['n_split'],
            'decay_split_mean': (r['bs'].mean() if len(r['bs']) else ''),
            'decay_split_std':  (r['bs'].std() if len(r['bs']) else ''),
            'n_below_floor':  ('' if r['n_below'] is None else r['n_below']),
        }
        for pname, val, err in zip(spec['names'], r['p'], r['perr']):
            rows.append({
                **common,
                'param':       pname,
                'value':       float(val),
                'sigma':       float(err),
                'sigma_rel':   (float(abs(err / val)) if val else float('inf')),
                'unit':        (b_unit if pname == spec['names'][-1]
                                else 'kcal/mol'),
            })

    cols = ['basis_tag', 'basis_label', 'nbf', 'column', 'form', 'form_expr',
            'n_par', 'param', 'value', 'sigma', 'sigma_rel', 'unit',
            'R_min', 'R_max', 'n_points', 'y_min', 'y_max',
            'rmse', 'r2', 'max_sigma_rel', 'cond_cov',
            'n_seed', 'n_converged', 'n_minima', 'rmse_best', 'rmse_worst',
            'decay_value', 'decay_sigma', 'decay_unit',
            'gpt_floor_A2', 'gpt_margin', 'gpt_verdict',
            'heldout_mean', 'heldout_min', 'heldout_max', 'n_splits',
            'decay_split_mean', 'decay_split_std', 'n_below_floor']
    out = pd.DataFrame(rows, columns=cols)

    hdr = (f"# Ne dimer {COLUMN} fit results, {meta['label']}\n"
           "# one row per fitted parameter; fit-level diagnostics repeat\n"
           f"# across the rows of a form. Window [{R.min():.6g}, "
           f"{R.max():.6g}] A, {len(R)} points.\n"
           "# Fitted from several starting points, the lowest-RMSE solution "
           "retained.\n"
           "# RMSE and R^2 are descriptive and do NOT discriminate between "
           "forms.\n"
           f"# generated by fit_scf.py from {meta['csv']}\n")
    with open(path, 'w') as fh:
        fh.write(hdr)
        out.to_csv(fh, index=False, float_format='%.17g')
    print(f"    Saved fit CSV: {path.name}")


def report(res, meta):
    fl = floor_A2(meta)
    print(f"\n  {meta['label']}  ({meta['nbf']} bf)")
    if fl is None:
        print(f"    GPT floor  : UNKNOWN -- {meta['alpha_min_src']}")
        print(f"    Fits are reported; the acceptance verdict is WITHHELD.")
    else:
        print(f"    alpha_min  : {meta['alpha_min']:.5f} bohr^-2   "
              f"({meta['alpha_min_src']})")
        print(f"    GPT floor  : {fl:.4f} A^-2  (2nd order = alpha_min); "
              f"one-sided, ceiling vacuous")
    print(f"    {'-' * 68}")
    for name, r in res.items():
        print(f"    {FORMS[name]['note']}")
        ps = '  '.join(f"{n}={v:+.5f}+-{e:.5f}"
                       for n, v, e in zip(FORMS[name]['names'],
                                          r['p'], r['perr']))
        print(f"      {ps}")
        v = {'pass': 'PASS', 'fail': 'FAIL', None: 'n/a'}[r['verdict']]
        if not r.get('floor_applies', True):
            v = 'n/a (erf rate, A^-1; floor is a Gaussian bound in A^-2)'
        margin = ('' if (fl is None or not r.get('floor_applies', True))
                  else f"   (floor {fl:.4f}, margin {r['b']-fl:+.4f})")
        unit = FORMS[name].get('b_unit', 'A^-2')
        print(f"      b     = {r['b']:.5f} +- {r['b_err']:.5f} {unit}  ->  "
              f"{v}{margin}")
        print(f"      RMSE  = {rmse_txt(r['rmse'])} kcal/mol   "
              f"R^2 = {r['r2']:.6f}")
        print(f"      ident : max sigma/|p| = {r['max_rel']:.3f}   "
              f"cond(cov) = {r['cond']:.2e}")
        mi = r['minfo']
        tag = ('single minimum' if mi['n_minima'] == 1
               else f"{mi['n_minima']} DISTINCT MINIMA -- best retained")
        print(f"      seeds : {mi['n_conv']}/{mi['n_seed']} converged, {tag}")
        if mi['n_minima'] > 1:
            print(f"              RMSE best {rmse_txt(mi['rmse_best'])} vs "
                  f"worst {rmse_txt(mi['rmse_worst'])} kcal/mol")
        if len(r['ratios']):
            print(f"      held-out ratio : mean {r['ratios'].mean():.3f}  "
                  f"range [{r['ratios'].min():.3f}, {r['ratios'].max():.3f}]  "
                  f"({r['n_split']} splits)")
            print(f"      b across splits: {r['bs'].mean():.5f} +- "
                  f"{r['bs'].std():.5f}", end='')
            if r['n_below'] is not None:
                print(f"   below floor in {r['n_below']}/{r['n_split']}")
            else:
                print()
        if name == 'hx':
            if r['p'][-1] > 0:
                print(f"      R -> inf : vanishes ({FORMS[name]['names'][-1]}"
                      f" > 0)")
            else:
                print(f"      R -> inf : FAILS -- tends to 2a = "
                      f"{2*r['p'][0]:+.5f} kcal/mol; BSSE must vanish "
                      f"(handoff 29-Jul, 2K)")
        else:
            print(f"      R -> inf : vanishes by construction")
        print()


def main():
    ap = argparse.ArgumentParser(
        description="Fit BSSE_SCF(R) with GPT/Boys-motivated single-channel "
                    "forms and apply the acceptance criteria.")
    ap.add_argument("--basis", type=str.lower, choices=list(BASES) + ["all"],
                    default="all", metavar="{dz,tz,qz,all}",
                    help="Basis to fit; case-insensitive, so --basis QZ works. "
                         "Default: all.")
    ap.add_argument("--mode", choices=["all", "csv", "fig"], default="all",
                    help="Which outputs to produce. 'all' (default) writes "
                         "both the figure and the fit CSV; 'csv' writes only "
                         "the CSV, which is what you want when the figures "
                         "are already on disk and unchanged; 'fig' writes "
                         "only the figure. The FIT ITSELF RUNS EITHER WAY -- "
                         "this selects what is written, not what is "
                         "computed, so the CSV and the figure always come "
                         "from the same numbers.")
    ap.add_argument("--only-missing", action="store_true",
                    help="Skip a basis whose output already exists. Which "
                         "output is checked follows --mode: the CSV under "
                         "--mode csv, otherwise the figure. OFF by "
                         "default: a stale figure left by an earlier CSV, "
                         "window, or form would be silently kept.")
    ap.add_argument("--form", choices=list(FORMS) + ["all"], action="append",
                    default=None,
                    help="Candidate form; repeatable. Default: gauss + poly2.")
    ap.add_argument("--title", action="store_true",
                    help="In-figure suptitle. Off by default.")
    ap.add_argument("--R-min", dest="r_min", type=float, default=None,
                    metavar="R", help="Lower bound of the fit window (A).")
    ap.add_argument("--R-max", dest="r_max", type=float, default=None,
                    metavar="R", help="Upper bound of the fit window (A).")
    args = ap.parse_args()

    if args.form is None:
        forms = list(DEFAULT_FORMS)
    elif "all" in args.form:
        forms = list(FORMS)
    else:
        forms = list(dict.fromkeys(args.form))

    keys = list(BASES) if args.basis == "all" else [args.basis]

    parts = []
    if args.r_min is not None:
        parts.append("Rmin" + f"{args.r_min:g}".replace('.', 'p'))
    if args.r_max is not None:
        parts.append("Rmax" + f"{args.r_max:g}".replace('.', 'p'))
    win = ('_' + '_'.join(parts)) if parts else ''

    print(f"\n{'=' * 72}")
    print("  Ne/2_new_v2 — BSSE_SCF fit study")
    print(f"{'=' * 72}")
    print(f"  Study root : {STUDY_ROOT}")
    print(f"  Column     : {COLUMN}   (signed; fitted as stored)")
    print(f"  Forms      : {', '.join(forms)}")
    print(f"  Bases      : {', '.join(BASES[k]['tag'] for k in keys)}")
    mode_desc = {'all': 'figure + fit CSV',
                 'csv': 'fit CSV only, figures untouched',
                 'fig': 'figure only, CSVs untouched'}[args.mode]
    print(f"  Mode       : {args.mode}   ({mode_desc})")
    print(f"{'=' * 72}")

    if not CSV_DIR.is_dir():
        sys.exit(f"\nNo data_frames directory at {CSV_DIR}.\n"
                 f"Check that this script is in 2b_bsse_scf/fit_study/scripts/.")
    if args.mode in ('all', 'fig'):
        FIG_DIR.mkdir(parents=True, exist_ok=True)
    if args.mode in ('all', 'csv'):
        CSV_OUT_DIR.mkdir(parents=True, exist_ok=True)

    for k in keys:
        meta = dict(BASES[k]); meta['_forms'] = forms
        ftag = ('' if forms == DEFAULT_FORMS
                else '_' + '-'.join(forms))
        fig_path = FIG_DIR / f"scf_fit_{meta['tag']}{win}{ftag}.png"
        csv_path = CSV_OUT_DIR / f"scf_fit_{meta['tag']}{win}{ftag}.csv"
        # --only-missing must test the artefact --mode will actually write.
        # Testing the figure under --mode csv would skip a basis whose CSV
        # does not yet exist, which is the opposite of what was asked for.
        guard = csv_path if args.mode == 'csv' else fig_path
        if args.only_missing and guard.is_file():
            print(f"\n  {meta['tag']}: {guard.name} exists, skipped "
                  f"(--only-missing). Delete it to force a rebuild.")
            continue
        path = CSV_DIR / meta['csv']
        if not path.is_file():
            sys.exit(f"No CSV at {path}. Run build_bsse_csv.py first.")
        df = pd.read_csv(path).sort_values('R').reset_index(drop=True)
        if args.r_min is not None:
            df = df[df['R'] >= args.r_min]
        if args.r_max is not None:
            df = df[df['R'] <= args.r_max]
        df = df.reset_index(drop=True)
        if len(df) < 8:
            sys.exit(f"Window leaves {len(df)} points; too few to fit.")

        R = df['R'].to_numpy(); y = df[COLUMN].to_numpy()
        print(f"\n  {meta['tag']}: {len(df)} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A, "
              f"y in [{y.min():+.5f}, {y.max():+.5f}] kcal/mol")

        res = analyse(k, R, y, meta)
        if args.mode in ('all', 'fig'):
            build_figure(R, y, res, meta, fig_path, show_title=args.title)
        if args.mode in ('all', 'csv'):
            write_fit_csv(res, meta, R, y, csv_path)
        report(res, meta)

    print("  R^2 and RMSE are reported as conventional descriptive statistics.")
    print("  They do NOT discriminate between candidate forms here: in v1, F3")
    print("  had the best RMSE and R^2 and the worst held-out ratio (3.08).")
    print("  The criteria that can fail are the GPT floor, identifiability,")
    print("  and held-out interpolation.")
    print()


if __name__ == '__main__':
    main()
