# Ne dimer BSSE — study v2

Supersedes `2_new_v1/`. See "Relationship to v1" below.

**Production status (30 July 2026): COMPLETE.** All 600 CCSD(T) jobs
(50 R × 3 bases × 4 job types) have run, converged, been parsed, and been
reduced to CSV. Zero failures. NOVA has been cleared of `.out` files and
batch logs; this directory is now the only copy.

## Directory convention

This is a **study directory**, not the canonical data store. Layout follows
`2_new_v1/`:

```
R_config/NNN_R_XpXXX/<level_of_theory>/<basis>/<real>_<basis-set>.{nw,out}
```

Outputs are kept uncompressed and are read directly by the scripts in
`scripts/`; there is no batch level and no tarball-based access.

## Geometries

All configurations are Ne–Ne dimers with monomer A fixed at the origin and
monomer B displaced along +z.

- **Grid**: 50 points, uniformly spaced, `R ∈ [1.5, 3.5] Å`, `ΔR = 0.040816 Å`
  (`R_i = 1.5 + i·(2.0/49)`, `i = 0..49`)
- **Directory labels**: `NNN_R_XpXXX`, `NNN` = 001..050 in order of increasing
  `R`; `XpXXX` is `R` in Å to three decimals with `.` replaced by `p`.

### Why this window

- **Upper bound (3.5 Å)** contains the Ne₂ equilibrium separation
  `R_e = 5.838–5.858 bohr = 3.089–3.100 Å` (Wüest & Merkt 2003; Ema *et al.*
  ChemPhysChem 2023, Table 1) with margin.
- **Lower bound (1.5 Å)** ≈ 0.48 `R_e`, well onto the repulsive wall, where
  orbital overlap and hence BSSE are largest.
- Iwata *et al.* (J. Comput. Chem. 2026) report Ne₂ curves from ≈3.0 Å outward;
  this window covers the short-range region their study does not resolve.

### Why uniform spacing

The study is exploratory with respect to the shape of `|BSSE|(R)`. A grid
refined around features seen in preliminary data would presuppose the result.
Spacing is therefore uniform, and resolution is set by the requirement that the
sampled curve be smooth on the scale of `ΔR` — verifiable *a posteriori* by
finite differences.

`ΔR = 0.0408 Å` places 5 points across the 2.25–2.46 Å interval, which is
sufficient to resolve the non-monotonic structure observed in v1 (verified by
subsampling the v1 data; the feature persists down to 20 points over the same
window).

**Post-run note.** The uniform grid turned out to matter more than anticipated:
the non-monotonic feature does not stay put across bases. It sits at 2.36 Å at
aug-cc-pVDZ, moves outward to 2.89 Å at aug-cc-pVTZ, and is absent at
aug-cc-pVQZ. A grid refined around the DZ feature would have under-sampled the
TZ one. See "Results summary" below.

## Levels of theory and basis sets

- `CCSD_T/` — SCF, MP2 and CCSD(T) energies are all extracted from this output.
  Directory named for the highest level present.
- Bases: `aug-cc-pvdz/`, `aug-cc-pvtz/`, `aug-cc-pvqz/` — the **same 50 R-values**
  for all three, so the basis comparison requires no interpolation.

## Job types per (R, basis)

| file | real monomers | basis set |
|---|---|---|
| `A_A` | A | A |
| `A_AB` | A | A ∪ B |
| `B_AB` | B | A ∪ B |
| `AB_AB` | AB | A ∪ B |

`A_A` is R-independent and `B_AB` equals `A_AB` by symmetry for homonuclear Ne₂;
both are computed anyway as consistency checks.

The `A_AB` / `B_AB` symmetry check proved its worth: it is the only measurement
of the numerical noise floor on each component, since the two are physically
identical and their difference is therefore pure numerical residual. Measured
values are in "Results summary".

## Convergence

SCF convergence tightened relative to v1, which used NWChem defaults.

NWChem's `thresh` is the norm of the orbital gradient, and the manual states
the energy converges to approximately the *square* of that value.

**Correction (30 July 2026).** An earlier version of this README stated the
default as `1.0e-4`, giving a v1 energy floor of ≈10⁻⁸ Ha. That is wrong. The
`1.0e-4` default on the Hartree–Fock manual page applies to a bare `task scf`.
For a post-HF task NWChem auto-tightens to **`1.0e-6`** — stated on the MP2
manual page, TIGHT section, which describes TIGHT as raising the SCF precision
"from 10⁻⁶ to 10⁻⁸". Confirmed directly: v1 inputs contain no `scf` block, yet
their outputs report `Convergence threshold : 1.000E-06`.

So:

| quantity | value |
|---|---|
| v1 `thresh` (implicit) | 1.0e-6 |
| v1 energy floor (≈ thresh²) | ≈10⁻¹² Ha |
| non-monotonic feature amplitude, DZ | 0.0072 kcal/mol = 1.15×10⁻⁵ Ha |
| margin above floor | ≈10⁷ |
| v2 `thresh` (explicit) | 1.0e-8 → floor ≈10⁻¹⁶ Ha |

**The tightening is therefore not needed to resolve the feature** — the
original conclusion stands, with a margin seven orders of magnitude rather
than three. v2's `thresh 1.0e-8` is a *two*-order tightening relative to v1,
not four.

The tightening follows instead the manual's guidance for this class of problem:
greater precision may be required for weakly interacting systems, with `1e-8`
"necessary for very high accuracy or very weak interactions" and regarded as
the best attainable in most circumstances. `tol2e 1.0e-12` is likewise the
manual's recommendation for very diffuse basis sets, which `aug-cc-pVxZ` is.

Note `tol2e` below `1e-10` switches integral storage from 32-bit to 64-bit,
roughly doubling it. Per the manual this applies to the **integral file** in
semidirect SCF calculations specifically, not to memory generally — narrower
than an earlier version of this note implied.

**Verified, not assumed:** the `scf` block is honoured inside a
`task ccsd(t) energy` run. All 600 outputs report
`Convergence threshold : 1.000E-08`. (This was an open TODO; it is closed.)

### Correlated-energy convergence

Left at NWChem's default. The CCSD manual page gives
`THRESH <real thresh default 1e-6>`, applied to both the amplitude RMS error
and the energy change. No `ccsd` block is present in any input, so all 600 jobs
used 1e-6 Ha.

This was a deliberate decision, justified by measurement rather than
assumption: the measured noise floor on the CCSD(T) component is at worst
**0.27%** of the smallest CCSD(T)c BSSE value on the grid. Tightening would
have cost runtime for no resolvable gain.

**Methods sentence:** *SCF converged to `thresh 1.0e-8` with `tol2e 1.0e-12`;
correlated energies at NWChem's default CCSD convergence threshold of 1e-6 Ha.*

Note also: no `freeze core` anywhere, so all 10 electrons per Ne are
correlated. Consistent with v1, which also ran all-electron.

## Analysis directories

| directory | contents |
|---|---|
| `2b_bsse_scf/fit_study/` | functional form for `BSSE_SCF(R)` derived from GPT / Boys |
| `2b_bsse_scf/basis_study/` | DZ/TZ/QZ ladder |
| `2b_bsse_mp2c/` | empirical form for the MP2-correlation component |
| `2b_bsse_ccsd_tc/` | empirical form for the CCSD(T)-correlation increment |
| `bsse_fits/` | sum of component fits vs. single forms fitted to the total |

Components are **incremental**: `SCF + MP2c + CCSD_Tc = total` exactly
(v2 exact-sum check: `max |Σ components − total| = 0.00e+00 kcal/mol` for all
three bases). Fitting them separately is justified by the distinct origins of
the HF and correlation BSSE — orbital basis inconsistency (OBI) and
configuration basis inconsistency (CBI) respectively — following Iwata *et al.*
2026, Remark 6.

**Caution on incremental columns.** `MP2c = BSSE(E_MP2) − BSSE(E_SCF)`, so a
change in the SCF component is absorbed by the MP2c increment. Going DZ→TZ the
incremental MP2c column rises 47.3%, but 86% of that rise is simply offsetting
the fall in SCF; only 14% is a genuine change in the cumulative MP2 BSSE.
**Always state which convention a quoted number uses.** Incremental columns are
the fitting targets; cumulative level totals are what compare to the
literature.

## `data_frames/`

One CSV per basis, 50 rows × 23 columns, locked schema:

```
ne_dimer_bsse_vs_R_aug-cc-pvdz.csv
ne_dimer_bsse_vs_R_aug-cc-pvtz.csv
ne_dimer_bsse_vs_R_aug-cc-pvqz.csv
```

Raw energy columns in Hartree, BSSE columns in kcal/mol, all **signed**.
Convention: `bsse = no_vmfc − vmfc`. Absolute values are applied at plot time
only and never stored.

## `scripts/` — code and run provenance

### Scripts

| file | runs on | purpose |
|---|---|---|
| `generate_nw_inputs.py` | laptop | writes the 600 `.nw` inputs |
| `submit_energy.sh` | NOVA | SLURM script for one NWChem job |
| `submit_all_jobs.sh` | NOVA | orchestrator; walks the tree, per-basis resources |
| `check_convergence.py` | laptop | five-field completeness + soft threshold check |
| `build_raw_data.py` | laptop | parses `.out` → `R_config_pickle_data/raw_data.pickle` |
| `build_bsse_csv.py` | laptop | pickle → `data_frames/*.csv` |
| `plot_bsse_vs_R.py` | laptop | **not yet written for v2** |

Only the two `.sh` scripts were ever copied to NOVA. Parsing and all analysis
are laptop-side by design; `submit_all_jobs.sh` derives its paths from its own
location, so `scripts/` and `R_config/` must remain siblings.

`submit_all_jobs.sh` carries the calibrated per-basis resources **and** the
aug-cc-pVQZ ScaLAPACK finding in its RESOURCES comment block. Read that block
before changing any resource value.

### Run provenance: `allgrid_*_logs/`

Retrieved from NOVA before it was cleaned. **605 files, ~189 KB.**

```
allgrid_dz_logs/   202 files   (200 job logs + 2 sentinels)
allgrid_tz_logs/   202 files   (200 job logs + 2 sentinels)
allgrid_qz_logs/   201 files   (199 job logs + 2 sentinels)
```

QZ has one fewer job log because `024_R_2p439/aug-cc-pvqz/A_AB` was already
complete from the manual single-job test and was skipped by the orchestrator's
skip-existing check.

**Why these are kept.** Each job log is the SLURM-side record written by
`submit_energy.sh`, and holds what the `.out` files do not:

- the compute node the job ran on
- the SLURM job ID
- `ntasks`, granted memory per node, and the walltime limit **as actually
  granted**, not as requested
- start and finish timestamps
- the NWChem exit status

That is the answer to "what hardware and what resources produced this number,"
which the `.out` files record only partially. It also ties every data point to
a SLURM job ID, so `sacct` records remain traceable for as long as NOVA keeps
them. Cheap insurance at 189 KB for a paper that will be refereed.

The two sentinel files per batch (`*_submitted.log`, `*_done.log`) are the
authoritative batch start/finish times — SLURM's email relay has been observed
to drop messages silently, so the log file is the signal, not the email.

### Diagnostic logs: `qz_*.log`

Four files, ~1.2 KB, from the manual single-job tests that diagnosed the
aug-cc-pVQZ crash. **These are the primary evidence for the `ntasks=1`
decision** and should not be deleted while that decision stands.

| file | job id | ntasks | node | outcome |
|---|---|---|---|---|
| `qz_test.log` | 11781452 | 2 | nova18-wide-4 | exit 139 |
| `qz_np1.log` | 11783676 | **1** | nova18-wide-4 | **exit 0, 18:15** |
| `qz_np2.log` | 11783915 | 2 | nova18-wide-9 | exit 139 |
| `qz_omp1.log` | 11783924 | 2 + `OMP_NUM_THREADS=1` | nova18-wide-9 | exit 139 |

Each records the granted memory alongside the outcome, which is what rules out
a memory explanation: the crashes occurred with 32768 MB granted and a peak RSS
of ~190 MB.

## aug-cc-pVQZ requires `ntasks=1`

At `ntasks=2` NWChem 7.2.0 segfaults (SLURM exit 139) after 10–13 s in

```
scf_ → scf_vectors_guess_ → scf_lindep_ → util_scalapack.F:31
```

the linear-dependence check on the initial guess, inside a ScaLAPACK call
(`use scalapack = T` in this build). Reproduced 3/3 times across two nodes;
the identical job at `ntasks=1` completes in 18 min.

Ruled out: **memory** (the overlap matrix is 160×160 ≈ 200 KB against a
4096 MB global allocation; peak RSS at crash 191 MB), **BLAS threading**
(`OMP_NUM_THREADS=1` gave the same crash), and **a bad node**.

Not established: why QZ and not DZ/TZ. The plausible hypothesis is a
matrix-size threshold (46 → 92 → 160 basis functions) above which NWChem
routes the diagonalisation through ScaLAPACK, but that threshold is not
documented and no runtime switch to disable ScaLAPACK was found. DZ and TZ ran
400 jobs at `ntasks=2` with zero failures, which rules out the compile-time
integer-size mismatch that the NWChem forums attribute such crashes to.

**Consequence for the methods section:** DZ and TZ ran at 2 MPI processes, QZ
at 1. This does not change converged energies beyond floating-point summation
order, far below the convergence thresholds — but it must be stated, and it is
a possible confound in the symmetry-diagnostic comparison below.

## Results summary

Numbers are grid means or extrema over `R ∈ [1.5, 3.5] Å` unless stated.
**All are properties of this R window, not of Ne₂.**

### Timings

| basis | nbf | ntasks | mean wall | max wall | total CPU |
|---|---|---|---|---|---|
| DZ | 46 | 2 | 9.7 s | 40.5 s | 0.54 h |
| TZ | 92 | 2 | 111.5 s | 231.0 s | 6.20 h |
| QZ | 160 | 1 | 725.7 s | 1577.6 s | 40.31 h |

### `total_bsse` range, kcal/mol

| basis | min | max |
|---|---|---|
| DZ | −2.167987 | −0.075748 |
| TZ | −1.916200 | −0.071221 |
| QZ | −0.822778 | −0.026838 |

The sharp basis-set reduction happens at **QZ**, not TZ: DZ→TZ is −11.6% on
`max |total_bsse|`, TZ→QZ is −57.1%. Two bases would have supported the wrong
conclusion.

At aug-cc-pVQZ the 2-body BSSE never reaches 1 kcal/mol anywhere on the grid.

### The non-monotonic feature in `|BSSE_SCF|` is a small-basis effect

| basis | interior turning points | midpoint | amplitude |
|---|---|---|---|
| DZ | 2 (2.2755, 2.4388 Å) | 2.357 Å | 1.16×10⁻⁵ Ha |
| TZ | 2 (2.8061, 2.9694 Å) | 2.888 Å | 8.61×10⁻⁷ Ha |
| QZ | **0**, strictly decreasing | — | absent |

DZ→TZ: amplitude falls 13.4×, midpoint moves outward 0.531 Å. Not noise — the
TZ amplitude is ≈10⁹ above the SCF energy floor.

**This bears directly on `2b_bsse_scf/fit_study/`.** The two-channel form
`P₁(R)exp(−B₁R²) + P₂(R)exp(−B₂R²)` was motivated by the DZ turning point. If
that turning point is a small-basis artifact, the form describes aug-cc-pVDZ
rather than Ne₂, and QZ may need only one channel. Pending PI discussion.

### CCSD(T)c BSSE reverses sign at QZ

Sign check (all three components negative at all 50 R): DZ ✓, TZ ✓, **QZ ✗**.

`2b_bsse_CCSD_Tc` is **positive at all 50 R** at QZ, 2.778×10⁻⁴ to
4.836×10⁻² kcal/mol — 76× the measured noise floor at the worst point, so not
numerical. Visible already at the monomer level: ghost functions make the (T)
increment *less* negative at QZ (Δ(T) = +3.853×10⁻⁵ Ha at R = 1.5 Å) while at
DZ and TZ they make it more negative.

Consequences: `|Σ| ≠ Σ|·|` at QZ, so the absolute value must be taken on the
**sum** (`abs(a0+a1+a2)`, never `abs(a0)+abs(a1)+abs(a2)`); cumulative CCSD(T)
BSSE is *smaller* than cumulative MP2 at QZ; and no single-sign ansatz can fit
CCSD(T)c across all three bases. Pending PI discussion.

### Measured noise floors (`A_AB` vs `B_AB`)

| basis | ntasks | ΔSCF | ΔMP2c | ΔCCSD_Tc |
|---|---|---|---|---|
| DZ | 2 | 9.948e-13 | 9.379e-13 | 6.358e-08 |
| TZ | 2 | 9.948e-13 | 7.674e-13 | 8.886e-08 |
| QZ | 1 | 1.023e-12 | 7.390e-13 | 5.833e-09 |

(Ha; all well under the 1e-6 CCSD stopping criterion.)

**Open confound:** QZ is the only basis that ran single-process, and its
CCSD_Tc gap is 15× *smaller* than TZ's despite having nearly twice the basis
functions. In a serial run the two jobs follow identical deterministic
summation paths; at 2 processes, Global Arrays reductions may combine partial
sums differently between otherwise-identical runs. Process count fits the
pattern better than basis size does. Testable by rerunning one DZ leaf at
`ntasks=1`. **Do not offer a physical explanation for "QZ looks cleaner" until
this is resolved.**

## Relationship to v1

`2_new_v1/` holds the superseded study: 100 points, `R ∈ [1.5, 4.5] Å`,
`ΔR = 0.0303 Å`, aug-cc-pVDZ only. It is retained because it extends to 4.5 Å
and is the only source of tail data. To be archived as `2_new_v1.tar.gz` once
v2 is complete.

v1 also holds `movecs_study/`, the source of the `P_AB` shell-pair SVD
analysis. **v2 writes no `.movecs`** — `generate_nw_inputs.py` emits no
`vectors output` line, and `submit_energy.sh`'s cleanup glob (`${BASE}.*`)
would delete one anyway. This is deliberate: each job starts from the atomic
guess in its own clean leaf, so no stale vectors are inherited and the SCF
genuinely iterates.

Recomputing the shell-pair SVD at TZ and QZ — the test that decides whether
the two-channel SCF form has support independent of the DZ turning point —
would therefore require a **new** movecs study at those bases, with
`vectors output` in the inputs and a cleanup script that protects `.movecs`.

v1 cross-check at `R = 1.5 Å`, aug-cc-pVDZ, passed:
`Δ 2b_no_vmfc_SCF = −2.24×10⁻⁸ Ha`, `Δ 2b_bsse_SCF = −3.16×10⁻⁷ kcal/mol`.
The shift is consistent with v2's tighter threshold (1e-8 vs v1's implicit
1e-6).

## Version control

This directory is `.gitignore`d in full. What gets pushed is a compressed
archive, once the analysis is complete.
