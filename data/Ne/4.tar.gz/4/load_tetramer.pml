load pymol_xyz_files/Ne_abcd.xyz, Ne_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw
