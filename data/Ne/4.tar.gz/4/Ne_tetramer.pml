load pymol_xyz_files/Ne_abcd.xyz, Ne_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white

# Ne atoms may appear white with util.cbaw — recolor for visibility on white
color teal, name Ne

# Ne-Ne connectivity by atom index (all 4 Ne atoms: 1, 2, 3, 4)
# Apex to base triangle: AB, AC, AD (~3.17 Ang)
# Base triangle pairs:   BC, BD, CD (~4.30 Ang)
distance NN_AB, index 1, index 2
distance NN_AC, index 1, index 3
distance NN_AD, index 1, index 4
distance NN_BC, index 2, index 3
distance NN_BD, index 2, index 4
distance NN_CD, index 3, index 4

# Black dashes — visible on white background
color black, NN_AB
color black, NN_AC
color black, NN_AD
color black, NN_BC
color black, NN_BD
color black, NN_CD

# Distance labels — black on white (keep visible)
set label_color, black, NN_AB
set label_color, black, NN_AC
set label_color, black, NN_AD
set label_color, black, NN_BC
set label_color, black, NN_BD
set label_color, black, NN_CD

# Distance label font size
set label_size, 16, NN_AB
set label_size, 16, NN_AC
set label_size, 16, NN_AD
set label_size, 16, NN_BC
set label_size, 16, NN_BD
set label_size, 16, NN_CD

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Labels on Ne atoms — A, B, C, D (confirmed from A_ABCD.nw)
label index 1, "A"
label index 2, "B"
label index 3, "C"
label index 4, "D"

# A/B/C/D label style
set label_size, 24
set label_color, blue
set label_font_id, 5

# Center and orient
zoom all
orient
