"""
verify_copy_Ne.py
------------------
Verifies that every file extracted from optimal_Ne_tetramer.tar was
copied correctly by comparing byte content between:
    - original backup in Ne/4/original_data/
    - renamed file in Ne/4/CCSD_T/aug-cc-pvdz/

Can be run from any directory, including Ne/4/scripts/.

Usage:
    python3 verify_copy_Ne.py
"""

from pathlib import Path

# Anchor paths relative to this script's location
SCRIPT_DIR = Path(__file__).resolve().parent          # .../Ne/4/scripts/
DEST_DIR   = SCRIPT_DIR.parent / "CCSD_T" / "aug-cc-pvdz"
BACKUP_DIR = SCRIPT_DIR.parent / "original_data"

ok_count      = 0
mismatch_count = 0

for orig_file in sorted(BACKUP_DIR.glob("*.txt")):
    fname = orig_file.name   # e.g. input_E_ABCD_ABC.txt

    # Reconstruct expected renamed filename
    if fname.startswith("input_E_") and fname.endswith(".txt"):
        stem = fname.removeprefix("input_E_").removesuffix(".txt")
        parts = stem.split("_", 1)
        if len(parts) != 2:
            print(f"  WARNING: cannot parse stem: {stem}")
            mismatch_count += 1
            continue
        basis, real = parts[0], parts[1]
        renamed = DEST_DIR / f"{real}_{basis}.nw"

    elif fname.startswith("output_E_") and fname.endswith(".txt"):
        stem = fname.removeprefix("output_E_").removesuffix(".txt")
        parts = stem.split("_", 1)
        if len(parts) != 2:
            print(f"  WARNING: cannot parse stem: {stem}")
            mismatch_count += 1
            continue
        basis, real = parts[0], parts[1]
        renamed = DEST_DIR / f"{real}_{basis}.out"

    else:
        print(f"  SKIPPED (unexpected name): {fname}")
        continue

    # Byte comparison
    if not renamed.exists():
        print(f"  MISSING: {renamed.name}")
        mismatch_count += 1
        continue

    if orig_file.read_bytes() == renamed.read_bytes():
        ok_count += 1
    else:
        print(f"  MISMATCH: {fname} vs {renamed.name}")
        mismatch_count += 1

print(f"\nVerification complete.")
print(f"  OK       : {ok_count}")
print(f"  Mismatch : {mismatch_count}")

if ok_count == 130 and mismatch_count == 0:
    print("\n✅ All 130 files verified OK.")
else:
    print("\n⚠️  Issues found — check output above.")