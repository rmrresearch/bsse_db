"""
reorganizing_tetramer_Ne.py
----------------------------
Creates the folder skeleton for Ne/4/.
Can be run from any directory, including Ne/4/scripts/.

Usage:
    python3 reorganizing_tetramer_Ne.py
"""

from pathlib import Path

# Anchor paths relative to this script's location
# Script lives at: bsse_db/data/Ne/4/scripts/reorganizing_tetramer_Ne.py
SCRIPT_DIR = Path(__file__).resolve().parent   # .../Ne/4/scripts/
BASE       = SCRIPT_DIR.parent                 # .../Ne/4/

dirs = [
    BASE / "CCSD_T" / "aug-cc-pvdz",
    BASE / "original_data",
    BASE / "pymol_xyz_files",
    BASE / "data_frames_plots",
    BASE / "scripts",
]

for d in dirs:
    d.mkdir(parents=True, exist_ok=True)
    print(f"Created: {d}")

print("\nNe/4/ folder skeleton ready.")