"""
copy_rename_files_Ne.py
------------------------
Extracts files from optimal_Ne_tetramer.tar, renames them from
    input_E_BASIS_REAL.txt  →  REAL_BASIS.nw
    output_E_BASIS_REAL.txt →  REAL_BASIS.out
and places them in:
    Ne/4/CCSD_T/aug-cc-pvdz/   (renamed files)
    Ne/4/original_data/         (original files, as backup)

Can be run from any directory, including Ne/4/scripts/.

Usage:
    python3 copy_rename_files_Ne.py
"""

import tarfile
from pathlib import Path

# Anchor paths relative to this script's location
# Script lives at: bsse_db/data/Ne/4/scripts/copy_rename_files_Ne.py
SCRIPT_DIR = Path(__file__).resolve().parent          # .../Ne/4/scripts/
NE_DIR     = SCRIPT_DIR.parent.parent                 # .../Ne/
TAR_PATH   = NE_DIR / "optimal_Ne_tetramer.tar"
DEST_DIR   = SCRIPT_DIR.parent / "CCSD_T" / "aug-cc-pvdz"
BACKUP_DIR = SCRIPT_DIR.parent / "original_data"

nw_count   = 0
out_count  = 0
skip_count = 0

with tarfile.open(TAR_PATH, "r") as tf:
    for member in tf.getmembers():
        if member.isdir():
            continue

        fname = Path(member.name).name   # e.g. input_E_ABCD_ABC.txt
        data  = tf.extractfile(member).read()

        # ── Backup: save original file as-is ──────────────────────────────
        (BACKUP_DIR / fname).write_bytes(data)

        # ── Rename: input_E_BASIS_REAL.txt → REAL_BASIS.nw ───────────────
        if fname.startswith("input_E_") and fname.endswith(".txt"):
            stem = fname.removeprefix("input_E_").removesuffix(".txt")
            parts = stem.split("_", 1)
            if len(parts) != 2:
                print(f"  WARNING: unexpected stem format: {stem}")
                skip_count += 1
                continue
            basis, real = parts[0], parts[1]
            (DEST_DIR / f"{real}_{basis}.nw").write_bytes(data)
            nw_count += 1

        elif fname.startswith("output_E_") and fname.endswith(".txt"):
            stem = fname.removeprefix("output_E_").removesuffix(".txt")
            parts = stem.split("_", 1)
            if len(parts) != 2:
                print(f"  WARNING: unexpected stem format: {stem}")
                skip_count += 1
                continue
            basis, real = parts[0], parts[1]
            (DEST_DIR / f"{real}_{basis}.out").write_bytes(data)
            out_count += 1

        else:
            print(f"  SKIPPED (unexpected name): {fname}")
            skip_count += 1

print(f"\nDone.")
print(f"  .nw  files written : {nw_count}")
print(f"  .out files written : {out_count}")
print(f"  skipped            : {skip_count}")
print(f"  total              : {nw_count + out_count + skip_count}")

if nw_count == 65 and out_count == 65 and skip_count == 0:
    print("\n✅ All 130 files processed correctly.")
else:
    print("\n⚠️  Unexpected counts — check warnings above.")