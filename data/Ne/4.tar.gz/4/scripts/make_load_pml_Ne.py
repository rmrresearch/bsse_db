"""
make_load_pml_Ne.py
--------------------
Generates Ne/4/load_tetramer.pml for visualizing the Ne tetramer
in PyMOL.

Can be run from any directory, including Ne/4/scripts/.

Usage:
    python3 make_load_pml_Ne.py
"""

from pathlib import Path

# Anchor paths relative to this script's location
SCRIPT_DIR = Path(__file__).resolve().parent
PML_FILE   = SCRIPT_DIR.parent / "load_tetramer.pml"
XYZ_FILE   = "pymol_xyz_files/Ne_abcd.xyz"   # relative path for PyMOL

pml_content = f"""\
load {XYZ_FILE}, Ne_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw
"""

PML_FILE.write_text(pml_content)
print(f"Written: {PML_FILE}")