"""
plot_tetramer_bsse.py
Location: bsse_db/data/{molecule}/4/data_frames_plots/
 
Reads tetramer CSVs and produces 7 plot modes.
 
Usage:
    python3 plot_tetramer_bsse.py --mol Ne --plot 1
    python3 plot_tetramer_bsse.py --mol Ne --plot 1 --abs
    python3 plot_tetramer_bsse.py --mol Ne --plot 2 --method MP2
    python3 plot_tetramer_bsse.py --mol Ne --plot 2 --sign
    python3 plot_tetramer_bsse.py --mol Ne --plot 3 --method all
    python3 plot_tetramer_bsse.py --mol Ne --plot 4 --method SCF --save
    python3 plot_tetramer_bsse.py --mol Ne --plot 5
    python3 plot_tetramer_bsse.py --mol Ne --plot 5 --abs
    python3 plot_tetramer_bsse.py --mol HF --plot 6 --save
    python3 plot_tetramer_bsse.py --mol HF --plot 7 --save --name v2
 
Plot modes:
    1 — Overview: Σ 2b_bsse, Σ 3b_bsse, 4b_bsse, total_bsse per method
    2 — 2b BSSE decomposition: total 2b + 12 × 1b-in-2b FORM(II) terms
    3 — 3b BSSE decomposition: total 3b + 1b-in-3b (−) and 2b-in-3b (+)
    4 — 4b BSSE decomposition: total 4b + 1b-in-4b (+), 2b-in-4b (−), 3b-in-4b (+)
    5 — Body-order series terms and ratio test (two panels):
           Left panel : signed or absolute (--abs) series terms a_0, a_1, a_2
                        a_0 = Σ 2b_bsse, a_1 = Σ 3b_bsse, a_2 = 4b_bsse
                        Bar labels tuned via LABEL_OFFSETS dict (fraction of y_range);
                        offsets are tuned per molecule — re-tune when switching mol
           Right panel: ratio test |a_1/a_0| and |a_2/a_1| (unaffected by --abs)
                        ratio < 1 and decreasing → series converges
    6 — |BSSE| partial sums |S_k| (absolute convergence view):
           S_0 = a_0              = Σ 2b_bsse         (note: |S_0| = |a_0|)
           S_1 = a_0 + a_1        = Σ 2b + Σ 3b
           S_2 = a_0 + a_1 + a_2  = total_bsse
           Plots |S_k| as connected dots; convergence of |S_k| implies
           absolute convergence of the BSSE series
    7 — Signed BSSE partial sums S_k (conditional convergence view):
           Same S_0, S_1, S_2 as mode 6 but without absolute value
           Dotted reference lines show S_2 = total_bsse per method
           Sign alternation between S_0 and S_1 (visible at MP2/CCSD_T
           for Ne and HF) reveals conditional convergence / oscillation
           around the series limit
 
Flags:
    --mol     Ne/HF/H2O            molecule (required)
    --plot    1-7                   plot mode (required)
    --method  SCF/MP2/CCSD_T/all   default: all
    --basis   aug-cc-pvdz           default: aug-cc-pvdz
    --abs                           plot absolute values (modes 1 and 5 left panel only;
                                    mode 5 right panel ratio test is always absolute)
    --sign                          negate all values: -BSSE (mode 2 only)
    --save                          save figure as PNG
    --name    STRING                custom suffix for saved filename
 
Saved filenames:
    tetramer_mode{N}_{desc}[_abs][_{name}]_{basis}.png
"""

import argparse
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import ScalarFormatter
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths and topology
# ---------------------------------------------------------------------------
here  = Path(__file__).resolve().parent
BASIS = "aug-cc-pvdz"

PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]
METHODS = ["SCF", "MP2", "CCSD_T"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]
DELTA_1B_IN_4B = ["A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD"]
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]
DELTA_3B_IN_4B = ["ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD"]

METHOD_COLORS = {"SCF": "steelblue", "MP2": "darkorange", "CCSD_T": "seagreen"}

# Molecule display labels for plot titles
MOL_LABELS = {"Ne": "Ne", "HF": "HF", "H2O": "H$_2$O"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_csv(method, basis):
    path = here / f"tetramer_{method}_{basis}.csv"
    return pd.read_csv(path)


def offset_formatter():
    """
    Returns a ScalarFormatter that shows the power as an offset label
    at the top of the axis (e.g. ×10⁻⁴) and plain numbers on ticks.
    Use for all Hartree y-axes.
    """
    fmt = ScalarFormatter(useMathText=True)
    fmt.set_scientific(True)
    fmt.set_powerlimits((0, 0))
    return fmt


def sum_2b_bsse(row):
    return sum(row[f"2b_bsse_{p}"] for p in PAIRS)


def sum_3b_bsse(row):
    return sum(row[f"3b_bsse_{t}"] for t in TRIPLES)


def mol_title(molecule):
    return MOL_LABELS.get(molecule, molecule)


# ---------------------------------------------------------------------------
# Mode 1 — Overview: Σ 2b, Σ 3b, 4b, total BSSE
# ---------------------------------------------------------------------------

def plot_mode1(molecule, methods, basis, save, abs_vals=False, name=None):
    """Bar chart: Σ 2b_bsse, Σ 3b_bsse, 4b_bsse, total_bsse per method."""
    labels    = ["Σ 2b_bsse", "Σ 3b_bsse", "4b_bsse", "total_bsse"]
    n_groups  = len(labels)
    n_methods = len(methods)
    x         = np.arange(n_groups)
    width     = 0.25

    fig, ax = plt.subplots(figsize=(12, 6))

    all_method_vals = []
    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        vals = [
            sum_2b_bsse(row),
            sum_3b_bsse(row),
            row["4b_bsse"],
            row["total_bsse"],
        ]
        if abs_vals:
            vals = [abs(v) for v in vals]
        all_method_vals.append((method, vals))

    all_flat = [v for _, vs in all_method_vals for v in vs]
    y_range  = max(all_flat) - min(all_flat)
    min_pad  = 0.025 * abs(y_range)

    for i, (method, vals) in enumerate(all_method_vals):
        offset = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, vals, width, label=method,
                      color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")
        for bar, v in zip(bars, vals):
            x_pos = bar.get_x() + bar.get_width() / 2
            y_tip = bar.get_height()
            pad   = max(0.03 * abs(y_tip), min_pad)
            y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
            va    = "bottom" if y_tip >= 0 else "top"
            ax.text(x_pos, y_pos, f"{v:.2e}",
                    ha="center", va=va, fontsize=7,
                    color=METHOD_COLORS[method], fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ylabel = "|BSSE| (Hartree)" if abs_vals else "BSSE (Hartree)"
    ax.set_ylabel(ylabel, fontsize=10)
    title_suffix = " — absolute values" if abs_vals else ""
    ax.set_title(
        f"{mol_title(molecule)} Tetramer — BSSE by Body Order ({basis}){title_suffix}",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(offset_formatter())
    if not abs_vals:
        ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left',
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    ymin, ymax = ax.get_ylim()
    ax.set_ylim(ymin * 1.15, ymax * 1.15 if ymax > 0 else ymax * 0.85)
    fig.tight_layout()

    if save:
        abs_suffix  = "_abs" if abs_vals else ""
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode1_overview{abs_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 2 — 2b BSSE decomposition: total 2b + 12 × 1b-in-2b terms
# ---------------------------------------------------------------------------

def plot_mode2(molecule, methods, basis, save, sign=False, name=None):
    """Bar chart of total 2b_bsse + 12 FORM(II) 1b-in-2b delta terms."""
    n_total   = 1 + len(DELTA_1B_IN_2B)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)

    fig, ax = plt.subplots(figsize=(18, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        all_vals = [sum_2b_bsse(row)] + [row[k] for k in DELTA_1B_IN_2B]
        if sign:
            all_vals = [-v for v in all_vals]
        offset = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, all_vals, width, label=method,
                      color=METHOD_COLORS[method], alpha=0.85,
                      edgecolor="k",
                      linewidth=[2.5] + [0.8] * len(DELTA_1B_IN_2B))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0]
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    # Shift label right of the dashed line so it doesn't overlap
    ax.text(x_pos - 0.35, y_pos, f"{total_val:.2e}",
            ha="right", va=va, fontsize=8,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5, color="black", linewidth=1.5, linestyle="--")

    all_labels = ["Total\nΣ 2b_bsse"] + \
                 [k.replace("_in_", "\nin ") for k in DELTA_1B_IN_2B]
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=8, ha="center")

    ylabel = "$-$BSSE contribution (Hartree)" if sign else "BSSE contribution (Hartree)"
    ax.set_ylabel(ylabel, fontsize=10)
    title_suffix = " — negated ($-$BSSE)" if sign else ""
    ax.set_title(
        f"{mol_title(molecule)} Tetramer — 2b BSSE: 1b-in-2b terms ({basis}){title_suffix}",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(offset_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left',
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        sign_suffix = "_sign" if sign else ""
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode2_2b_decomp{sign_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 3 — 3b BSSE decomposition: 1b-in-3b (−) and 2b-in-3b (+)
# ---------------------------------------------------------------------------

def plot_mode3(molecule, methods, basis, save, name=None):
    """Bar chart of total 3b_bsse + 24 FORM(II) 3b delta terms."""
    all_keys  = DELTA_1B_IN_3B + DELTA_2B_IN_3B
    n_total   = 1 + len(all_keys)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)
    split     = 1 + len(DELTA_1B_IN_3B)

    fig, ax = plt.subplots(figsize=(20, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        signed_vals = ([-row[k] for k in DELTA_1B_IN_3B]
                       + [row[k] for k in DELTA_2B_IN_3B])
        all_vals = [sum_3b_bsse(row)] + signed_vals
        offset   = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, all_vals, width, label=method,
                      color=METHOD_COLORS[method], alpha=0.85, edgecolor="k",
                      linewidth=[2.5] + [0.8] * len(all_keys))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0]
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    # Shift label left of the dashed line so it doesn't overlap
    ax.text(x_pos - 0.35, y_pos, f"{total_val:.2e}",
            ha="right", va=va, fontsize=8,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5,         color="black", linewidth=1.5, linestyle="--")
    ax.axvline(split - 0.5, color="gray",  linewidth=1,   linestyle=":")

    all_labels = ["Total\nΣ 3b_bsse"] + \
                 [k.replace("_in_", "\nin ") for k in all_keys]
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=7, ha="center")

    ymin, ymax = ax.get_ylim()
    ax.text((1 + split - 1) / 2,       ymin * 0.85, "← 1b-in-3b (−) →",
            ha="center", fontsize=9, color="crimson", fontweight="bold")
    ax.text((split + n_total - 1) / 2, ymax * 0.85, "← 2b-in-3b (+) →",
            ha="center", fontsize=9, color="purple",  fontweight="bold")

    ax.set_ylabel("Signed BSSE contribution (Hartree)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer — 3b BSSE Decomposition ({basis})",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(offset_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left',
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode3_3b_decomp{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 4 — 4b BSSE decomposition: 1b-in-4b (+), 2b-in-4b (−), 3b-in-4b (+)
# ---------------------------------------------------------------------------

def plot_mode4(molecule, methods, basis, save, name=None):
    """Bar chart of total 4b_bsse + 14 FORM(II) 4b delta terms in 3 signed groups."""
    all_keys  = DELTA_1B_IN_4B + DELTA_2B_IN_4B + DELTA_3B_IN_4B
    n_total   = 1 + len(all_keys)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)
    s1 = 1 + len(DELTA_1B_IN_4B)
    s2 = s1 + len(DELTA_2B_IN_4B)

    group_colors = (
        ["k"]
        + ["#2ca02c"] * len(DELTA_1B_IN_4B)
        + ["#9467bd"] * len(DELTA_2B_IN_4B)
        + ["#d62728"] * len(DELTA_3B_IN_4B)
    )

    fig, ax = plt.subplots(figsize=(18, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        signed_vals = (
            [row[k]  for k in DELTA_1B_IN_4B]
            + [-row[k] for k in DELTA_2B_IN_4B]
            + [row[k]  for k in DELTA_3B_IN_4B]
        )
        all_vals = [row["4b_bsse"]] + signed_vals
        offset   = (i - n_methods / 2 + 0.5) * width
        bars = ax.bar(x + offset, all_vals, width, label=method,
                      color=METHOD_COLORS[method], alpha=0.85,
                      edgecolor=group_colors,
                      linewidth=[2.5] + [1.5] * len(all_keys))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0]
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    # Shift label left of the dashed line so it doesn't overlap
    ax.text(x_pos - 0.35, y_pos, f"{total_val:.2e}",
            ha="right", va=va, fontsize=8,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5,      color="black", linewidth=1.5, linestyle="--")
    ax.axvline(s1 - 0.5, color="gray",  linewidth=1,   linestyle=":")
    ax.axvline(s2 - 0.5, color="gray",  linewidth=1,   linestyle=":")

    all_labels = ["Total\n4b_bsse"] + \
                 [k.replace("_in_", "\nin ") for k in all_keys]
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=8, ha="center")

    ymin, ymax = ax.get_ylim()
    label_y = ymin * 1.10
    ax.set_ylim(ymin * 1.28, ymax * 1.15)

    ax.text((1 + s1 - 1) / 2,       label_y, "← 1b-in-4b (+) →",
            ha="center", fontsize=9, color="#2ca02c", fontweight="bold")
    ax.text((s1 + s2 - 1) / 2,      label_y, "← 2b-in-4b (−) →",
            ha="center", fontsize=9, color="#9467bd", fontweight="bold")
    ax.text((s2 + n_total - 1) / 2, label_y, "← 3b-in-4b (+) →",
            ha="center", fontsize=9, color="#d62728", fontweight="bold")

    ax.set_ylabel("Signed BSSE contribution (Hartree)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer — 4b BSSE Decomposition ({basis})",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(offset_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc='upper left',
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode4_4b_decomp{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 5 — BSSE series: signed terms a_0, a_1, a_2 + ratio test
# ---------------------------------------------------------------------------

def plot_mode5(molecule, methods, basis, save, abs_vals=False, name=None):
    """
    Two-panel series analysis.

    Series terms (standard notation):
        a_0 = Σ 2b_bsse   (first term)
        a_1 = Σ 3b_bsse   (second term)
        a_2 = 4b_bsse     (third term)

    Left panel  — series terms a_0, a_1, a_2 per method
                  signed (default) or absolute (--abs)
    Right panel — ratio test |a_1/a_0|, |a_2/a_1| per method
                  if ratio < 1 and decreasing → converging
    """
    n_methods = len(methods)
    width     = 0.25

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

    # --- Left panel: series terms (signed or absolute) ---
    if abs_vals:
        term_labels = ["$|a_0|$ (|Σ 2b|)", "$|a_1|$ (|Σ 3b|)", "$|a_2|$ (|4b|)"]
    else:
        term_labels = ["$a_0$ (Σ 2b)", "$a_1$ (Σ 3b)", "$a_2$ (4b)"]
    x1 = np.arange(len(term_labels))

    # Per-bar label offsets as fraction of y_range.
    # Key: (method, term_index 0/1/2) → fraction of y_range added to bar tip.
    # Positive = label above tip, negative = label below tip (for negative bars).
    # Tune these independently if labels overlap bars.
    LABEL_OFFSETS = {
        ('SCF',    0): 0.07,   # a_0 SCF  (large negative bar)
        ('SCF',    1): 0.09,   # a_1 SCF  (small negative bar)
        ('SCF',    2): 0.09,   # a_2 SCF  (small negative bar)
        ('MP2',    0): 0.015,   # a_0 MP2  (large negative bar)
        ('MP2',    1): 0.012,   # a_1 MP2  (positive bar)
        ('MP2',    2): 0.020,   # a_2 MP2  (small negative bar)
        ('CCSD_T', 0): 0.015,   # a_0 CCSD_T
        ('CCSD_T', 1): 0.012,   # a_1 CCSD_T (positive bar)
        ('CCSD_T', 2): 0.020,   # a_2 CCSD_T
    }

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        terms = [
            sum_2b_bsse(row),
            sum_3b_bsse(row),
            row["4b_bsse"],
        ]
        if abs_vals:
            terms = [abs(t) for t in terms]
        offset = (i - n_methods / 2 + 0.5) * width
        bars   = ax1.bar(x1 + offset, terms, width, label=method,
                         color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")

        y_range = abs(ax1.get_ylim()[1] - ax1.get_ylim()[0])
        for j, (bar, v) in enumerate(zip(bars, terms)):
            x_pos   = bar.get_x() + bar.get_width() / 2
            y_tip   = bar.get_height()
            frac    = LABEL_OFFSETS.get((method, j), 0.020)
            pad     = frac * y_range
            y_pos   = y_tip + pad if y_tip >= 0 else y_tip - pad
            va      = "bottom" if y_tip >= 0 else "top"
            ax1.text(x_pos, y_pos, f"{v:.2e}",
                     ha="center", va=va, fontsize=7,
                     color=METHOD_COLORS[method], fontweight="bold")

    ax1.set_xticks(x1)
    ax1.set_xticklabels(term_labels, fontsize=11)
    ylabel = "|BSSE| series term (Hartree)" if abs_vals else "BSSE series term (Hartree)"
    ax1.set_ylabel(ylabel, fontsize=10)
    title_suffix = " — $|a_k|$" if abs_vals else " — $a_k$"
    ax1.set_title(
        f"{mol_title(molecule)} Tetramer — BSSE Series Terms{title_suffix} ({basis})",
        fontsize=11
    )
    ax1.yaxis.set_major_formatter(offset_formatter())
    if not abs_vals:
        ax1.axhline(0, color="black", linewidth=0.8, linestyle="--")
    legend_loc = 'upper right' if abs_vals else 'lower right'
    ax1.legend(fontsize=9, loc=legend_loc, frameon=False)
    if abs_vals:
        ax1.set_ylim(bottom=0)
        ax1.set_ylim(0, ax1.get_ylim()[1] * 1.25)
    else:
        ymin1, ymax1 = ax1.get_ylim()
        ax1.set_ylim(ymin1 * 1.20, ymax1 * 1.20)

    # --- Right panel: ratio test |a_1/a_0|, |a_2/a_1| ---
    ratio_labels = ["$|a_1/a_0|$", "$|a_2/a_1|$"]
    x2 = np.arange(len(ratio_labels))

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        a0  = sum_2b_bsse(row)
        a1  = sum_3b_bsse(row)
        a2  = row["4b_bsse"]

        r01 = abs(a1 / a0) if abs(a0) > 1e-30 else 0.0
        r12 = abs(a2 / a1) if abs(a1) > 1e-30 else 0.0

        ratios = [r01, r12]
        offset = (i - n_methods / 2 + 0.5) * width
        bars   = ax2.bar(x2 + offset, ratios, width, label=method,
                         color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")

        for bar, v in zip(bars, ratios):
            x_pos = bar.get_x() + bar.get_width() / 2
            y_tip = bar.get_height()
            ax2.text(x_pos, y_tip + 0.003, f"{v:.4f}",
                     ha="center", va="bottom", fontsize=9,
                     color=METHOD_COLORS[method], fontweight="bold")

    ax2.set_xticks(x2)
    ax2.set_xticklabels(ratio_labels, fontsize=12)
    ax2.set_ylabel("Ratio (dimensionless)", fontsize=10)
    ax2.set_title(
        f"{mol_title(molecule)} Tetramer — Ratio Test $|a_{{k+1}}/a_k|$ ({basis})",
        fontsize=11
    )
    ax2.axhline(1, color="red", linewidth=1.0, linestyle="--",
                label="ratio = 1 (convergence threshold)")
    ax2.legend(fontsize=9, loc='upper right', frameon=False)
    ax2.set_ylim(bottom=0)
    ymax2 = ax2.get_ylim()[1]
    ax2.set_ylim(0, max(ymax2 * 1.25, 1.3))

    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        abs_suffix  = "_abs" if abs_vals else ""
        fname = here / f"tetramer_mode5_series_terms{abs_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 6 — |BSSE| partial sums: |S_0|, |S_1|, |S_2| (absolute convergence)
# ---------------------------------------------------------------------------

def plot_mode6(molecule, methods, basis, save, name=None):
    """
    Partial sums of the |BSSE| series — plotted as dots (discrete sequence).

    Standard series notation:
        S_0 = a_0                 = Σ 2b_bsse
        S_1 = a_0 + a_1           = Σ 2b + Σ 3b
        S_2 = a_0 + a_1 + a_2     = total_bsse

    Plots |S_k| as a sequence of dots connected by lines.
    If |S_k| converges → absolute convergence → series converges unconditionally.
    """
    k_vals  = [0, 1, 2]
    k_labels = ["$k=0$\n(Σ 2b)", "$k=1$\n(Σ 2b+Σ 3b)", "$k=2$\n(total)"]

    fig, ax = plt.subplots(figsize=(8, 6))

    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        a0  = sum_2b_bsse(row)
        a1  = sum_3b_bsse(row)
        a2  = row["4b_bsse"]

        s0 = abs(a0)
        s1 = abs(a0 + a1)
        s2 = abs(a0 + a1 + a2)
        vals = [s0, s1, s2]

        ax.plot(k_vals, vals, color=METHOD_COLORS[method],
                linewidth=1.5, linestyle="-", alpha=0.7)
        ax.scatter(k_vals, vals, color=METHOD_COLORS[method],
                   s=80, zorder=5, label=method)

        for k, v in zip(k_vals, vals):
            ax.annotate(f"{v:.2e}", (k, v),
                        textcoords="offset points", xytext=(0, 10),
                        ha="center", fontsize=8,
                        color=METHOD_COLORS[method], fontweight="bold")

    ax.set_xticks(k_vals)
    ax.set_xticklabels(k_labels, fontsize=11)
    ax.set_ylabel("$|S_k|$ (Hartree)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer — $|$BSSE$|$ Partial Sums $|S_k|$ ({basis})",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(offset_formatter())
    ax.set_xlim(-0.3, 2.3)
    ax.set_ylim(bottom=0)
    ax.set_ylim(0, ax.get_ylim()[1] * 1.30)
    ax.legend(fontsize=9, loc='upper left',
              bbox_to_anchor=(1.02, 1), borderaxespad=0, frameon=False)
    ax.text(0.5, -0.15,
            "Dots show $|S_k|$ — convergence of $|$BSSE$|$ series "
            "(absolute convergence)",
            transform=ax.transAxes, ha="center", fontsize=8,
            style="italic", color="dimgray")

    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode6_abs_partial_sums{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 7 — Signed BSSE partial sums: S_0, S_1, S_2 (conditional convergence)
# ---------------------------------------------------------------------------

def plot_mode7(molecule, methods, basis, save, name=None):
    """
    Partial sums of the signed BSSE series — plotted as dots (discrete sequence).

    Standard series notation:
        S_0 = a_0                 = Σ 2b_bsse
        S_1 = a_0 + a_1           = Σ 2b + Σ 3b
        S_2 = a_0 + a_1 + a_2     = total_bsse  (limit of the series)

    Signed partial sums show how the series converges to total_bsse.
    Sign alternation between S_0 and S_1 suggests conditional convergence.
    Dotted reference lines at S_2 = total_bsse per method show the limit.
    """
    k_vals   = [0, 1, 2]
    k_labels = ["$k=0$\n(Σ 2b)", "$k=1$\n(Σ 2b+Σ 3b)", "$k=2$\n(total)"]

    fig, ax = plt.subplots(figsize=(8, 6))

    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        a0  = sum_2b_bsse(row)
        a1  = sum_3b_bsse(row)
        a2  = row["4b_bsse"]

        s0 = a0
        s1 = a0 + a1
        s2 = a0 + a1 + a2      # = total_bsse
        vals = [s0, s1, s2]

        # Reference line at S_2 per method
        ax.axhline(s2, color=METHOD_COLORS[method], linewidth=1.0,
                   linestyle=":", alpha=0.5)

        ax.plot(k_vals, vals, color=METHOD_COLORS[method],
                linewidth=1.5, linestyle="-", alpha=0.7)
        ax.scatter(k_vals, vals, color=METHOD_COLORS[method],
                   s=80, zorder=5, label=method)

        for k, v in zip(k_vals, vals):
            offset_y = 10 if v >= 0 else -14
            ax.annotate(f"{v:.2e}", (k, v),
                        textcoords="offset points", xytext=(0, offset_y),
                        ha="center", fontsize=8,
                        color=METHOD_COLORS[method], fontweight="bold")

    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.set_xticks(k_vals)
    ax.set_xticklabels(k_labels, fontsize=11)
    ax.set_ylabel("$S_k$ (Hartree)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer — Signed BSSE Partial Sums $S_k$ ({basis})",
        fontsize=11
    )
    ax.yaxis.set_major_formatter(offset_formatter())
    ax.set_xlim(-0.3, 2.3)
    ymin, ymax = ax.get_ylim()
    ax.set_ylim(ymin * 1.25, ymax * 1.25)
    ax.legend(fontsize=9, loc='upper left',
              bbox_to_anchor=(1.02, 1), borderaxespad=0, frameon=False)
    ax.text(0.5, -0.15,
            "Dotted lines: $S_2$ = total BSSE per method (series limit)",
            transform=ax.transAxes, ha="center", fontsize=8,
            style="italic", color="dimgray")

    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode7_signed_partial_sums{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches='tight')
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Tetramer BSSE plots")
    p.add_argument("--mol",    required=True, choices=["Ne", "HF"],
                   help="Molecule: Ne or HF")
    p.add_argument("--plot",   type=int, required=True, choices=[1, 2, 3, 4, 5, 6, 7],
                   help="Plot mode 1-7")
    p.add_argument("--method", default="all",
                   choices=["SCF", "MP2", "CCSD_T", "all"])
    p.add_argument("--basis",  default=BASIS)
    p.add_argument("--save",   action="store_true")
    p.add_argument("--abs",    action="store_true",
                   help="Plot absolute values (modes 1 and 5 left panel)")
    p.add_argument("--sign",   action="store_true",
                   help="Negate all values: plot -BSSE (mode 2 only)")
    p.add_argument("--name",   default=None,
                   help="Custom suffix for saved filename, e.g. --name v2")
    return p.parse_args()


if __name__ == "__main__":
    args    = parse_args()
    methods = METHODS if args.method == "all" else [args.method]

    dispatch = {
        1: lambda: plot_mode1(args.mol, methods, args.basis, args.save,
                              abs_vals=args.abs, name=args.name),
        2: lambda: plot_mode2(args.mol, methods, args.basis, args.save,
                              sign=args.sign, name=args.name),
        3: lambda: plot_mode3(args.mol, methods, args.basis, args.save,
                              name=args.name),
        4: lambda: plot_mode4(args.mol, methods, args.basis, args.save,
                              name=args.name),
        5: lambda: plot_mode5(args.mol, methods, args.basis, args.save,
                              abs_vals=args.abs, name=args.name),
        6: lambda: plot_mode6(args.mol, methods, args.basis, args.save,
                              name=args.name),
        7: lambda: plot_mode7(args.mol, methods, args.basis, args.save,
                              name=args.name),
    }
    dispatch[args.plot]()