# Ne/4/ — Ne Tetramer (CCSD(T)/aug-cc-pvdz)

## Overview

This folder contains the BSSE calculations for the optimal Ne tetramer
at the CCSD(T)/aug-cc-pvdz level of theory. There is a single geometry
(the optimal tetramer configuration — no distance scan).

---

## Folder Structure

```
Ne/4/
├── CCSD_T/aug-cc-pvdz/    ← 65 .nw (input) + 65 .out (output) files
├── original_data/
│   └── optimal_Ne_tetramer.tar   ← original raw files (authoritative backup)
├── pymol_xyz_files/
│   └── Ne_abcd.xyz               ← tetramer geometry for PyMOL
├── load_tetramer.pml             ← PyMOL loader script
├── data_frames_plots/            ← pipeline output (CSVs, plots)
├── README.md
└── scripts/
    ├── reorganizing_tetramer_Ne.py
    ├── copy_rename_files_Ne.py
    ├── verify_copy_Ne.py
    ├── nwchem_to_pymol_Ne.py
    └── make_load_pml_Ne.py
```

---

## Geometry

The Ne tetramer geometry is the optimal (minimum energy) configuration.
The four Ne atoms are placed at the following Cartesian coordinates (Angstroms):

```
Ne   0.00000000   0.00000000  -1.48101717
Ne   1.75556579   1.75556579   0.49367239
Ne   0.64258168  -2.39814747   0.49367239
Ne  -2.39814747   0.64258168   0.49367239
```

This is NOT an equilateral arrangement — it is the optimal tetramer
geometry as provided in the raw data. The geometry source is
`original_data/optimal_Ne_tetramer.tar` → `input_E_ABCD_ABCD.txt`.

---

## File Naming Convention

Files in `CCSD_T/aug-cc-pvdz/` follow the `REAL_BASIS` convention:

```
REAL_BASIS.nw   ← NWChem input file
REAL_BASIS.out  ← NWChem output file
```

Where:
- `REAL`  = the fragment whose energy is computed (e.g. `A`, `AB`, `ABC`)
- `BASIS` = the basis set used (ghost functions included, e.g. `ABCD`, `AB`)

Examples:
- `A_A.nw`       — monomer A in its own basis
- `A_ABCD.nw`    — monomer A in the full tetramer basis (ghost functions for B, C, D)
- `AB_ABCD.nw`   — dimer AB in the full tetramer basis
- `ABCD_ABCD.nw` — full tetramer in its own basis

Original files were named `input_E_BASIS_REAL.txt` / `output_E_BASIS_REAL.txt`
and renamed using `scripts/copy_rename_files_Ne.py`.

---

## File Key Count

For a 4-monomer VMFC calculation:

| Fragment type      | Count |
|--------------------|-------|
| Monomers (1b)      | 4 × 8 = 32  |
| Dimers (2b)        | 6 × 4 = 24  |
| Trimers (3b)       | 4 × 2 = 8   |
| Tetramer (4b)      | 1           |
| **Total**          | **65**      |

Total files: 65 `.nw` + 65 `.out` = **130 files**.

---

## Monomer Identity

All four Ne monomers (A, B, C, D) are identical Ne atoms.
Therefore `B_B = C_C = D_D = A_A` — only one monomer
calculation is strictly needed, but all four are present in the raw data.

---

## PyMOL Visualization

From `Ne/4/`:
```bash
pymol load_tetramer.pml
```

---

## Scripts

All scripts in `Ne/4/scripts/` can be run from any directory.

| Script | Description |
|--------|-------------|
| `reorganizing_tetramer_Ne.py` | Creates the folder skeleton |
| `copy_rename_files_Ne.py` | Extracts from tar, renames, copies files |
| `verify_copy_Ne.py` | Byte-level verification of all 130 files |
| `nwchem_to_pymol_Ne.py` | Generates `pymol_xyz_files/Ne_abcd.xyz` |
| `make_load_pml_Ne.py` | Generates `load_tetramer.pml` |

---

## Branch

`fcuantico` — part of `rmrresearch/bsse_db`, GitHub Issue #46.