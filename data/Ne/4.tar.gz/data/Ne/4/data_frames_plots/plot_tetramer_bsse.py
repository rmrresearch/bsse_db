"""
plot_tetramer_bsse.py
Location: bsse_db/data/{molecule}/4/data_frames_plots/

Reads tetramer CSVs and produces 7 plot modes.
All values in kcal/mol (1 Ha = 627.509474 kcal/mol).
All labels and titles use LaTeX rendering (text.usetex = True).

Usage:
    python3 plot_tetramer_bsse.py --mol Ne --plot 1
    python3 plot_tetramer_bsse.py --mol Ne --plot 1 --abs
    python3 plot_tetramer_bsse.py --mol Ne --plot 2 --method MP2
    python3 plot_tetramer_bsse.py --mol Ne --plot 2 --sign
    python3 plot_tetramer_bsse.py --mol HF --plot 3 --method all
    python3 plot_tetramer_bsse.py --mol Ne --plot 4 --method SCF --save
    python3 plot_tetramer_bsse.py --mol Ne --plot 5 --method all --save
    python3 plot_tetramer_bsse.py --mol HF --plot 6 --save
    python3 plot_tetramer_bsse.py --mol H2O --plot 7 --save --name v2

Plot modes:
    1 -- Overview: sum_2b, sum_3b, 4b, total BSSE per method (kcal/mol)
    2 -- 2b BSSE decomposition: total 2b + 12 x 1b-in-2b FORM(II) terms
    3 -- 3b BSSE decomposition: total 3b + 1b-in-3b (-) and 2b-in-3b (+)
    4 -- 4b BSSE decomposition: total 4b + 1b-in-4b (+), 2b-in-4b (-), 3b-in-4b (+)
    5 -- Three-panel series analysis (kcal/mol):
           Top-left  : partial sums S_0, S_1, S_2 per method
                         S_0 = a_0              = sum_2b
                         S_1 = a_0 + a_1        = sum_2b + sum_3b
                         S_2 = a_0 + a_1 + a_2  = total_bsse
           Top-right : individual terms a_0, a_1, a_2 per method
                         a_0 = sum_2b,  a_1 = sum_3b,  a_2 = 4b
           Bottom    : tail condition |a_1 + a_2| per method
                         vs 1 kcal/mol chemical accuracy threshold
    6 -- |S_k| partial sums as connected dots (kcal/mol):
           decreasing |S_k| confirms higher body-order terms
           bring the partial sum closer to the total BSSE
    7 -- Signed S_k partial sums as connected dots (kcal/mol):
           dotted reference lines at S_2 = total_bsse per method;
           sign alternation between S_0 and S_1 (MP2/CCSD_T for Ne, HF)
           indicates correlation introduces alternating corrections

Flags:
    --mol     Ne/HF/H2O            molecule (required)
    --plot    1-7                   plot mode (required)
    --method  SCF/MP2/CCSD_T/all   default: all
    --basis   aug-cc-pvdz           default: aug-cc-pvdz
    --abs                           plot absolute values (mode 1 only)
    --sign                          negate all values: -BSSE (mode 2 only)
    --save                          save figure as PNG
    --name    STRING                custom suffix for saved filename

Saved filenames:
    tetramer_mode{N}_{desc}[_abs][_{name}]_{basis}.png

Notes:
    - CCSD_T is displayed as CCSD(T) in all plot legends and labels.
    - LaTeX rendering requires a working TeX installation (pdflatex).
      Packages used: amsmath.
    - The --mol choices are Ne, HF, H2O. Copy this script unchanged to
      each molecule's data_frames_plots/ folder -- it reads CSVs from
      the same directory as the script (here/).
"""

import argparse
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
from matplotlib.ticker import ScalarFormatter
from pathlib import Path

matplotlib.rcParams.update({
    'text.usetex'        : True,
    'font.family'        : 'serif',
    'text.latex.preamble': r'\usepackage{amsmath}',
})

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------
here  = Path(__file__).resolve().parent
BASIS = "aug-cc-pvdz"
KCAL  = 627.509474    # Hartree -> kcal/mol

PAIRS   = ["AB", "AC", "AD", "BC", "BD", "CD"]
TRIPLES = ["ABC", "ABD", "ACD", "BCD"]
METHODS = ["SCF", "MP2", "CCSD_T"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "A_in_AD", "D_in_AD",
    "B_in_BC", "C_in_BC",
    "B_in_BD", "D_in_BD",
    "C_in_CD", "D_in_CD",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
    "A_in_ABD", "B_in_ABD", "D_in_ABD",
    "A_in_ACD", "C_in_ACD", "D_in_ACD",
    "B_in_BCD", "C_in_BCD", "D_in_BCD",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
    "AB_in_ABD", "AD_in_ABD", "BD_in_ABD",
    "AC_in_ACD", "AD_in_ACD", "CD_in_ACD",
    "BC_in_BCD", "BD_in_BCD", "CD_in_BCD",
]
DELTA_1B_IN_4B = ["A_in_ABCD", "B_in_ABCD", "C_in_ABCD", "D_in_ABCD"]
DELTA_2B_IN_4B = [
    "AB_in_ABCD", "AC_in_ABCD", "AD_in_ABCD",
    "BC_in_ABCD", "BD_in_ABCD", "CD_in_ABCD",
]
DELTA_3B_IN_4B = ["ABC_in_ABCD", "ABD_in_ABCD", "ACD_in_ABCD", "BCD_in_ABCD"]

METHOD_COLORS = {"SCF": "steelblue", "MP2": "darkorange", "CCSD_T": "seagreen"}

# Display labels: CCSD_T -> CCSD(T), used in all legends and tick labels
METHOD_LABELS = {
    "SCF"   : "SCF",
    "MP2"   : r"MP2$_\mathrm{comp}$",
    "CCSD_T": r"CCSD(T)$_\mathrm{comp}$",
}

# Molecule display labels for plot titles (LaTeX-safe)
MOL_LABELS = {
    "Ne" : "Ne",
    "HF" : "HF",
    "H2O": r"H$_2$O",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_csv(method, basis):
    path = here / f"tetramer_{method}_{basis}.csv"
    return pd.read_csv(path)


def sum_2b_bsse(row):
    return sum(row[f"2b_bsse_{p}"] for p in PAIRS)


def sum_3b_bsse(row):
    return sum(row[f"3b_bsse_{t}"] for t in TRIPLES)


def mol_title(molecule):
    return MOL_LABELS.get(molecule, molecule)


def delta_label(key):
    """Convert 'A_in_AB' to 'A\\nin AB' for two-line x-tick labels."""
    frag, sup = key.split("_in_")
    return f"{frag}\nin {sup}"


def fmt_kcal(v):
    """Adaptive format for kcal/mol bar annotations."""
    av = abs(v)
    if av == 0.0:
        return "0"
    elif av >= 0.1:
        return f"{v:.3f}"
    elif av >= 0.001:
        return f"{v:.4f}"
    else:
        return f"{v:.2e}"


def kcal_formatter():
    """ScalarFormatter for kcal/mol axes."""
    fmt = ScalarFormatter()
    fmt.set_scientific(True)
    fmt.set_powerlimits((-2, 3))
    return fmt


# ---------------------------------------------------------------------------
# Mode 1 -- Overview: sum_2b, sum_3b, 4b, total BSSE
# ---------------------------------------------------------------------------

def plot_mode1(molecule, methods, basis, save, abs_vals=False, name=None):
    """Bar chart: body-order BSSE terms in kcal/mol."""
    labels = [
    r"$\Sigma$ 2b",
    r"$\Sigma$ 3b",
    r"4b",
    r"total BSSE",
    ]
    n_groups  = len(labels)
    n_methods = len(methods)
    x         = np.arange(n_groups)
    width     = 0.25

    fig, ax = plt.subplots(figsize=(12, 6))

    all_method_vals = []
    for method in methods:
        df   = load_csv(method, basis)
        row  = df.iloc[0]
        vals = [
            sum_2b_bsse(row) * KCAL,
            sum_3b_bsse(row) * KCAL,
            row["4b_bsse"]   * KCAL,
            row["total_bsse"]* KCAL,
        ]
        if abs_vals:
            vals = [abs(v) for v in vals]
        all_method_vals.append((method, vals))

    all_flat = [v for _, vs in all_method_vals for v in vs]
    y_range  = max(all_flat) - min(all_flat)
    min_pad  = 0.025 * abs(y_range)

    for i, (method, vals) in enumerate(all_method_vals):
        offset = (i - n_methods / 2 + 0.5) * width
        bars   = ax.bar(x + offset, vals, width,
                        label=METHOD_LABELS[method],
                        color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")
        for bar, v in zip(bars, vals):
            xp  = bar.get_x() + bar.get_width() / 2
            yt  = bar.get_height()
            pad = max(0.03 * abs(yt), min_pad)
            yp  = yt + pad if yt >= 0 else yt - pad
            va  = "bottom" if yt >= 0 else "top"
            ax.text(xp, yp, fmt_kcal(v),
                    ha="center", va=va, fontsize=9,
                    color=METHOD_COLORS[method], fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=11)
    ylabel = r"$|\mathrm{BSSE}|$ (kcal/mol)" if abs_vals else r"BSSE (kcal/mol)"
    ax.set_ylabel(ylabel, fontsize=11)
    title_suffix = " -- absolute values" if abs_vals else ""
    ax.set_title(
        f"{mol_title(molecule)} Tetramer -- BSSE by Body Order ({basis}){title_suffix}",
        fontsize=11,
    )
    ax.yaxis.set_major_formatter(kcal_formatter())
    if not abs_vals:
        ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc="upper left",
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    ymin, ymax = ax.get_ylim()
    ax.set_ylim(ymin * 1.15, ymax * 1.15 if ymax > 0 else ymax * 0.85)
    fig.tight_layout()

    if save:
        abs_suffix  = "_abs" if abs_vals else ""
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode1_overview{abs_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 2 -- 2b BSSE decomposition: total 2b + 12 x 1b-in-2b terms
# ---------------------------------------------------------------------------

def plot_mode2(molecule, methods, basis, save, sign=False, name=None):
    """Bar chart: total 2b_bsse + 12 FORM(II) 1b-in-2b delta terms (kcal/mol)."""
    n_total   = 1 + len(DELTA_1B_IN_2B)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)

    fig, ax = plt.subplots(figsize=(18, 6))
    label_data = []

    for i, method in enumerate(methods):
        df       = load_csv(method, basis)
        row      = df.iloc[0]
        all_vals = ([sum_2b_bsse(row) * KCAL]
                    + [row[k] * KCAL for k in DELTA_1B_IN_2B])
        if sign:
            all_vals = [-v for v in all_vals]
        offset = (i - n_methods / 2 + 0.5) * width
        bars   = ax.bar(x + offset, all_vals, width,
                        label=METHOD_LABELS[method],
                        color=METHOD_COLORS[method], alpha=0.85,
                        edgecolor="k",
                        linewidth=[2.5] + [0.8] * len(DELTA_1B_IN_2B))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0],
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    ax.text(x_pos + 0.1, y_pos, fmt_kcal(total_val),
            ha="right", va=va, fontsize=8,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5, color="black", linewidth=1.5, linestyle="--")

    all_labels = (["Total\n" + r"$\Sigma\,\text{2b}$"]
                  + [delta_label(k) for k in DELTA_1B_IN_2B])
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=8, ha="center")

    ylabel = r"$-$BSSE contribution (kcal/mol)" if sign \
             else r"BSSE contribution (kcal/mol)"
    ax.set_ylabel(ylabel, fontsize=11)
    title_suffix = r" -- negated ($-$BSSE)" if sign else ""
    ax.set_title(
        f"{mol_title(molecule)} Tetramer -- "
        r"2-body BSSE: 1b-in-2b terms"
        f" ({basis}){title_suffix}",
        fontsize=11,
    )
    ax.yaxis.set_major_formatter(kcal_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc="upper left",
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        sign_suffix = "_sign" if sign else ""
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode2_2b_decomp{sign_suffix}{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 3 -- 3b BSSE decomposition: 1b-in-3b (-) and 2b-in-3b (+)
# ---------------------------------------------------------------------------

def plot_mode3(molecule, methods, basis, save, name=None):
    """Bar chart: total 3b_bsse + 24 FORM(II) 3b delta terms (kcal/mol)."""
    all_keys  = DELTA_1B_IN_3B + DELTA_2B_IN_3B
    n_total   = 1 + len(all_keys)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)
    split     = 1 + len(DELTA_1B_IN_3B)

    fig, ax = plt.subplots(figsize=(20, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        signed_vals = ([-row[k] * KCAL for k in DELTA_1B_IN_3B]
                       + [ row[k] * KCAL for k in DELTA_2B_IN_3B])
        all_vals = [sum_3b_bsse(row) * KCAL] + signed_vals
        offset   = (i - n_methods / 2 + 0.5) * width
        bars     = ax.bar(x + offset, all_vals, width,
                          label=METHOD_LABELS[method],
                          color=METHOD_COLORS[method], alpha=0.85, edgecolor="k",
                          linewidth=[2.5] + [0.8] * len(all_keys))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0],
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    ax.text(x_pos + 0.1, y_pos, fmt_kcal(total_val),
            ha="right", va=va, fontsize=8,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5,         color="black", linewidth=1.5, linestyle="--")
    ax.axvline(split - 0.5, color="gray",  linewidth=1,   linestyle=":")

    all_labels = (["Total\n" + r"$\Sigma\,\text{3b}$"]
                  + [delta_label(k) for k in all_keys])
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=7, ha="center")

    ymin, ymax = ax.get_ylim()
    ax.text((1 + split - 1) / 2,       ymin * 0.85,
            r"$\leftarrow$ 1b-in-3b ($-$) $\rightarrow$",
            ha="center", fontsize=9, color="crimson", fontweight="bold")
    ax.text((split + n_total - 1) / 2, ymax * 0.85,
            r"$\leftarrow$ 2b-in-3b ($+$) $\rightarrow$",
            ha="center", fontsize=9, color="purple",  fontweight="bold")

    ax.set_ylabel(r"Signed BSSE contribution (kcal/mol)", fontsize=11)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer -- 3-body BSSE Decomposition ({basis})",
        fontsize=11,
    )
    ax.yaxis.set_major_formatter(kcal_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc="upper left",
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode3_3b_decomp{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 4 -- 4b BSSE decomposition: 1b-in-4b (+), 2b-in-4b (-), 3b-in-4b (+)
# ---------------------------------------------------------------------------

def plot_mode4(molecule, methods, basis, save, name=None):
    """Bar chart: total 4b_bsse + 14 FORM(II) 4b delta terms (kcal/mol)."""
    all_keys  = DELTA_1B_IN_4B + DELTA_2B_IN_4B + DELTA_3B_IN_4B
    n_total   = 1 + len(all_keys)
    x         = np.arange(n_total)
    width     = 0.25
    n_methods = len(methods)
    s1 = 1 + len(DELTA_1B_IN_4B)
    s2 = s1 + len(DELTA_2B_IN_4B)

    group_colors = (
        ["k"]
        + ["#2ca02c"] * len(DELTA_1B_IN_4B)
        + ["#9467bd"] * len(DELTA_2B_IN_4B)
        + ["#d62728"] * len(DELTA_3B_IN_4B)
    )

    fig, ax = plt.subplots(figsize=(18, 6))
    label_data = []

    for i, method in enumerate(methods):
        df  = load_csv(method, basis)
        row = df.iloc[0]
        signed_vals = (
            [ row[k] * KCAL for k in DELTA_1B_IN_4B]
            + [-row[k] * KCAL for k in DELTA_2B_IN_4B]
            + [ row[k] * KCAL for k in DELTA_3B_IN_4B]
        )
        all_vals = [row["4b_bsse"] * KCAL] + signed_vals
        offset   = (i - n_methods / 2 + 0.5) * width
        bars     = ax.bar(x + offset, all_vals, width,
                          label=METHOD_LABELS[method],
                          color=METHOD_COLORS[method], alpha=0.85,
                          edgecolor=group_colors,
                          linewidth=[2.5] + [1.5] * len(all_keys))
        total_bar = bars[0]
        label_data.append((
            method,
            total_bar.get_x() + total_bar.get_width() / 2,
            total_bar.get_height(),
            all_vals[0],
        ))

    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    largest = max(label_data, key=lambda t: abs(t[3]))
    method, x_pos, y_tip, total_val = largest
    pad   = 0.02 * abs(y_range)
    y_pos = y_tip + pad if y_tip >= 0 else y_tip - pad
    va    = "bottom" if y_tip >= 0 else "top"
    ax.text(x_pos +0.1, y_pos, fmt_kcal(total_val),
            ha="right", va=va, fontsize=8,
            color=METHOD_COLORS[method], fontweight="bold")

    ax.axvline(0.5,      color="black", linewidth=1.5, linestyle="--")
    ax.axvline(s1 - 0.5, color="gray",  linewidth=1,   linestyle=":")
    ax.axvline(s2 - 0.5, color="gray",  linewidth=1,   linestyle=":")

    all_labels = (["Total\n" + r"$\text{4b}$"]
                  + [delta_label(k) for k in all_keys])
    ax.set_xticks(x)
    ax.set_xticklabels(all_labels, fontsize=8, ha="center")

    ymin, ymax = ax.get_ylim()
    label_y = ymin * 1.10
    ax.set_ylim(ymin * 1.28, ymax * 1.15)

    ax.text((1 + s1 - 1) / 2,       label_y,
            r"$\leftarrow$ 1b-in-4b ($+$) $\rightarrow$",
            ha="center", fontsize=9, color="#2ca02c", fontweight="bold")
    ax.text((s1 + s2 - 1) / 2,      label_y,
            r"$\leftarrow$ 2b-in-4b ($-$) $\rightarrow$",
            ha="center", fontsize=9, color="#9467bd", fontweight="bold")
    ax.text((s2 + n_total - 1) / 2, label_y,
            r"$\leftarrow$ 3b-in-4b ($+$) $\rightarrow$",
            ha="center", fontsize=9, color="#d62728", fontweight="bold")

    ax.set_ylabel(r"Signed BSSE contribution (kcal/mol)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer -- 4-body BSSE Decomposition ({basis})",
        fontsize=11,
    )
    ax.yaxis.set_major_formatter(kcal_formatter())
    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.legend(fontsize=9, loc="upper left",
              bbox_to_anchor=(1.01, 1), borderaxespad=0, frameon=False)
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode4_4b_decomp{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 5 -- Three-panel: partial sums | individual terms | tail condition
# ---------------------------------------------------------------------------

def plot_mode5(molecule, methods, basis, save, name=None):
    """
    Three-panel series analysis (all values in kcal/mol).

    Top-left  -- partial sums S_0, S_1, S_2 per method
    Top-right -- individual terms a_0, a_1, a_2 per method
    Bottom    -- tail condition |a_1+a_2| per method vs 1 kcal/mol

    Label offsets (LABEL_OFFSETS_PS and LABEL_OFFSETS_TERMS) control the
    vertical position of bar annotations independently per (method, term).
    Values are fractions of the global y-range for each panel.
    Tune these when switching molecule if labels overlap.
    """
    n_methods = len(methods)
    width     = 0.25

    fig = plt.figure(figsize=(16, 12))
    gs  = gridspec.GridSpec(
        2, 2,
        height_ratios=[1, 0.55],
        hspace=0.45,
        wspace=0.32,
    )
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[1, :])

    # ------------------------------------------------------------------
    # Collect data (kcal/mol)
    # ------------------------------------------------------------------
    data = {}
    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        a0  = sum_2b_bsse(row) * KCAL
        a1  = sum_3b_bsse(row) * KCAL
        a2  = row["4b_bsse"]   * KCAL
        data[method] = dict(
            a0=a0, a1=a1, a2=a2,
            S0=a0,
            S1=a0 + a1,
            S2=a0 + a1 + a2,
            tail=abs(a1 + a2),
        )

    # ------------------------------------------------------------------
    # Top-left: partial sums S_0, S_1, S_2
    # ------------------------------------------------------------------
    ps_labels = [
        r"$S_0$" + "\n" + r"$(\Sigma\,\mathrm{2b})$",
        r"$S_1$" + "\n" + r"$(\Sigma\,\mathrm{2b}+\Sigma\,\mathrm{3b})$",
        r"$S_2$" + "\n" + r"$(\Sigma\,\mathrm{2b}+\Sigma\,\mathrm{3b}+\mathrm{4b})$",
    ]
    x1 = np.arange(3)

    # Per-bar label offsets as fraction of global y-range.
    # Key: (method, term_index 0/1/2).
    # Tune independently if labels overlap bars or each other.
    all_S = [data[m][k] for m in methods for k in ("S0", "S1", "S2")]
    global_yrange_1 = abs(max(all_S) - min(all_S))

    LABEL_OFFSETS_PS = {
        ("SCF",    0): 0.03, ("SCF",    1): 0.03, ("SCF",    2): 0.03,
        ("MP2",    0): 0.03, ("MP2",    1): 0.03, ("MP2",    2): 0.03,
        ("CCSD_T", 0): 0.03, ("CCSD_T", 1): 0.03, ("CCSD_T", 2): 0.03,
    }

    for i, method in enumerate(methods):
        d      = data[method]
        vals   = [d["S0"], d["S1"], d["S2"]]
        offset = (i - n_methods / 2 + 0.5) * width
        bars   = ax1.bar(x1 + offset, vals, width,
                         label=METHOD_LABELS[method],
                         color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")
        for j, (bar, v) in enumerate(zip(bars, vals)):
            xp   = bar.get_x() + bar.get_width() / 2
            yt   = bar.get_height()
            frac = LABEL_OFFSETS_PS.get((method, j), 0.04)
            pad  = frac * global_yrange_1
            yp   = yt + pad if yt >= 0 else yt - pad
            va   = "bottom" if yt >= 0 else "top"
            ax1.text(xp, yp, fmt_kcal(v),
                     ha="center", va=va, fontsize=7,
                     color=METHOD_COLORS[method], fontweight="bold")

    ax1.set_xticks(x1)
    ax1.set_xticklabels(ps_labels, fontsize=9)
    ax1.set_ylabel(r"BSSE partial sum (kcal/mol)", fontsize=10)
    ax1.set_title(
        f"{mol_title(molecule)} Tetramer -- Partial Sums $S_k$ ({basis})",
        fontsize=11,
    )
    ax1.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax1.yaxis.set_major_formatter(kcal_formatter())
    ax1.legend(fontsize=9, loc="lower right", frameon=False)
    ymin1, ymax1 = ax1.get_ylim()
    ax1.set_ylim(ymin1 * 1.25, max(ymax1 * 1.25, abs(ymin1) * 0.15))

    # ------------------------------------------------------------------
    # Top-right: individual terms a_0, a_1, a_2
    # ------------------------------------------------------------------
    term_labels = [
        r"$a_0$" + "\n" + r"$(\Sigma\,\mathrm{2b})$",
        r"$a_1$" + "\n" + r"$(\Sigma\,\mathrm{3b})$",
        r"$a_2$" + "\n" + r"$(\mathrm{4b})$",
    ]
    x2 = np.arange(3)

    # Per-bar label offsets for the individual terms panel.
    # Tune independently per (method, term_index).
    all_T = [data[m][k] for m in methods for k in ("a0", "a1", "a2")]
    global_yrange_2 = abs(max(all_T) - min(all_T))

    LABEL_OFFSETS_TERMS = {
        ("SCF",    0): 0.03, ("SCF",    1): 0.03, ("SCF",    2): 0.03,
        ("MP2",    0): 0.03, ("MP2",    1): 0.03, ("MP2",    2): 0.03,
        ("CCSD_T", 0): 0.03, ("CCSD_T", 1): 0.03, ("CCSD_T", 2): 0.03,
    }

    for i, method in enumerate(methods):
        d      = data[method]
        vals   = [d["a0"], d["a1"], d["a2"]]
        offset = (i - n_methods / 2 + 0.5) * width
        bars   = ax2.bar(x2 + offset, vals, width,
                         label=METHOD_LABELS[method],
                         color=METHOD_COLORS[method], alpha=0.85, edgecolor="k")
        for j, (bar, v) in enumerate(zip(bars, vals)):
            xp   = bar.get_x() + bar.get_width() / 2
            yt   = bar.get_height()
            frac = LABEL_OFFSETS_TERMS.get((method, j), 0.04)
            pad  = frac * global_yrange_2
            yp   = yt + pad if yt >= 0 else yt - pad
            va   = "bottom" if yt >= 0 else "top"
            ax2.text(xp, yp, fmt_kcal(v),
                     ha="center", va=va, fontsize=7,
                     color=METHOD_COLORS[method], fontweight="bold")

    ax2.set_xticks(x2)
    ax2.set_xticklabels(term_labels, fontsize=9)
    ax2.set_ylabel(r"BSSE term (kcal/mol)", fontsize=10)
    ax2.set_title(
        f"{mol_title(molecule)} Tetramer -- Individual Terms $a_k$ ({basis})",
        fontsize=11,
    )
    ax2.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax2.yaxis.set_major_formatter(kcal_formatter())
    ax2.legend(fontsize=9, loc="lower right", frameon=False)
    ymin2, ymax2 = ax2.get_ylim()
    ax2.set_ylim(ymin2 * 1.25, max(ymax2 * 1.25, abs(ymin2) * 0.15))

    # ------------------------------------------------------------------
    # Bottom: tail condition |a_1 + a_2| per method
    # ------------------------------------------------------------------
    tail_x      = np.arange(n_methods)
    tail_width  = 0.35
    tail_vals   = [data[m]["tail"] for m in methods]
    tail_colors = [METHOD_COLORS[m] for m in methods]

    bars3 = ax3.bar(tail_x, tail_vals, tail_width,
                    color=tail_colors, alpha=0.85, edgecolor="k")

    for bar, v, method in zip(bars3, tail_vals, methods):
        xp = bar.get_x() + bar.get_width() / 2
        yt = bar.get_height()
        ax3.text(xp, yt + 0.01, fmt_kcal(v),
                 ha="center", va="bottom", fontsize=10,
                 color=METHOD_COLORS[method], fontweight="bold")

    ax3.axhline(1.0, color="crimson", linewidth=1.5, linestyle="--",
                label=r"1\,kcal/mol (chemical accuracy)")

    ax3.set_xticks(tail_x)
    ax3.set_xticklabels([METHOD_LABELS[m] for m in methods], fontsize=11)
    ax3.set_ylabel(
        r"$|a_1+a_2|=|\Sigma\,\mathrm{3b}+\mathrm{4b}|$ (kcal/mol)",
        fontsize=10,
    )
    ax3.set_title(
        f"{mol_title(molecule)} Tetramer -- Tail Condition: "
        r"$|a_1+a_2|$ vs 1\,kcal/mol threshold",
        fontsize=11,
    )
    ax3.set_ylim(0, max(max(tail_vals) * 1.40, 1.3))
    ax3.legend(fontsize=10, loc="upper right", frameon=False)
    ax3.yaxis.set_major_formatter(kcal_formatter())

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode5_series_terms{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 6 -- |S_k| partial sums as connected dots (kcal/mol)
# ---------------------------------------------------------------------------

def plot_mode6(molecule, methods, basis, save, name=None):
    """
    |BSSE| partial sums |S_k| as connected dots (kcal/mol).

    S_0 = a_0              = sum_2b
    S_1 = a_0 + a_1        = sum_2b + sum_3b
    S_2 = a_0 + a_1 + a_2  = total_bsse
    """
    k_vals   = [0, 1, 2]
    k_labels = [
    r"$k=0$" + "\n" + r"$(|\Sigma\,\mathrm{2b}|)$",
    r"$k=1$" + "\n" + r"$(|\Sigma\,\mathrm{2b}|+|\Sigma\,\mathrm{3b}|)$",
    r"$k=2$" + "\n" + r"$(|\Sigma\,\mathrm{2b}|+|\Sigma\,\mathrm{3b}|+|\Sigma\,\mathrm{4b}|)$",
]

    fig, ax = plt.subplots(figsize=(8, 6))

    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        a0  = sum_2b_bsse(row) * KCAL
        a1  = sum_3b_bsse(row) * KCAL
        a2  = row["4b_bsse"]   * KCAL

        vals = [abs(a0), abs(a0) + abs(a1), abs(a0) + abs(a1) + abs(a2)]

        ax.plot(k_vals, vals, color=METHOD_COLORS[method],
                linewidth=1.5, linestyle="-", alpha=0.7)
        ax.scatter(k_vals, vals, color=METHOD_COLORS[method],
                   s=80, zorder=5, label=METHOD_LABELS[method])

        for k, v in zip(k_vals, vals):
            ax.annotate(fmt_kcal(v), (k, v),
                        textcoords="offset points", xytext=(0, 10),
                        ha="center", fontsize=8,
                        color=METHOD_COLORS[method], fontweight="bold")

    ax.set_xticks(k_vals)
    ax.set_xticklabels(k_labels, fontsize=10)
    ax.set_ylabel(r"$\sum_{j=0}^{k}|a_j|$ (kcal/mol)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer -- "
        r"Cumulative $|a_k|$: $\sum_{j=0}^{k}|a_j|$"
        f" ({basis})",
        fontsize=11,
    )
    ax.yaxis.set_major_formatter(kcal_formatter())
    ax.set_xlim(-0.3, 2.3)
    ax.set_ylim(bottom=0)
    ax.set_ylim(0, ax.get_ylim()[1] * 1.30)
    ax.legend(fontsize=9, loc="upper left",
              bbox_to_anchor=(1.02, 1), borderaxespad=0, frameon=False)
    ax.text(
    0.5, -0.15,
    r"Dots show $\sum_{j=0}^{k}|a_j|$. The step from $k=0$ to $k=2$ is small, confirming" "\n"
    r"that 2-body already captures most of the BSSE and higher-body terms are minor corrections.",
    transform=ax.transAxes, ha="center", fontsize=8,
    style="italic", color="dimgray",    
    )
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode6_abs_partial_sums{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# Mode 7 -- Signed S_k partial sums as connected dots (kcal/mol)
# ---------------------------------------------------------------------------

def plot_mode7(molecule, methods, basis, save, name=None):
    """
    Signed BSSE partial sums S_k as connected dots (kcal/mol).

    S_0 = a_0              = sum_2b
    S_1 = a_0 + a_1        = sum_2b + sum_3b
    S_2 = a_0 + a_1 + a_2  = total_bsse (series limit)
    """
    k_vals   = [0, 1, 2]
    k_labels = [
    r"$k=0$" + "\n" + r"$(\Sigma\,\mathrm{2b})$",
    r"$k=1$" + "\n" + r"$(\Sigma\,\mathrm{2b}+\Sigma\,\mathrm{3b})$",
    r"$k=2$" + "\n" + r"$(\Sigma\,\mathrm{2b}+\Sigma\,\mathrm{3b}+\,\mathrm{4b})$",
]

    fig, ax = plt.subplots(figsize=(8, 6))

    for method in methods:
        df  = load_csv(method, basis)
        row = df.iloc[0]
        a0  = sum_2b_bsse(row) * KCAL
        a1  = sum_3b_bsse(row) * KCAL
        a2  = row["4b_bsse"]   * KCAL

        s0 = a0
        s1 = a0 + a1
        s2 = a0 + a1 + a2
        vals = [s0, s1, s2]

        ax.axhline(s2, color=METHOD_COLORS[method], linewidth=1.0,
                   linestyle=":", alpha=0.5)
        ax.plot(k_vals, vals, color=METHOD_COLORS[method],
                linewidth=1.5, linestyle="-", alpha=0.7)
        ax.scatter(k_vals, vals, color=METHOD_COLORS[method],
                   s=80, zorder=5, label=METHOD_LABELS[method])

        for k, v in zip(k_vals, vals):
            offset_y = 10 if v >= 0 else -14
            ax.annotate(fmt_kcal(v), (k, v),
                        textcoords="offset points", xytext=(0, offset_y),
                        ha="center", fontsize=8,
                        color=METHOD_COLORS[method], fontweight="bold")

    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.set_xticks(k_vals)
    ax.set_xticklabels(k_labels, fontsize=10)
    ax.set_ylabel(r"$S_k$ (kcal/mol)", fontsize=10)
    ax.set_title(
        f"{mol_title(molecule)} Tetramer -- "
        r"Signed BSSE Partial Sums $S_k$"
        f" ({basis})",
        fontsize=11,
    )
    ax.yaxis.set_major_formatter(kcal_formatter())
    ax.set_xlim(-0.3, 2.3)
    ymin, ymax = ax.get_ylim()
    ax.set_ylim(ymin * 1.25, ymax * 1.25)
    ax.legend(fontsize=9, loc="upper left",
              bbox_to_anchor=(1.02, 1), borderaxespad=0, frameon=False)
    ax.text(
        0.5, -0.15,
        r"Dotted lines: $S_2$ = total BSSE per method (series limit)",
        transform=ax.transAxes, ha="center", fontsize=8,
        style="italic", color="dimgray",
    )
    fig.tight_layout()

    if save:
        name_suffix = f"_{name}" if name else ""
        fname = here / f"tetramer_mode7_signed_partial_sums{name_suffix}_{basis}.png"
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        print(f"Saved: {fname.name}")
    plt.show()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Tetramer BSSE plots")
    p.add_argument("--mol",    required=True, choices=["Ne", "HF", "H2O"],
                   help="Molecule: Ne, HF, or H2O")
    p.add_argument("--plot",   type=int, required=True, choices=[1, 2, 3, 4, 5, 6, 7],
                   help="Plot mode 1-7")
    p.add_argument("--method", default="all",
                   choices=["SCF", "MP2", "CCSD_T", "all"])
    p.add_argument("--basis",  default=BASIS)
    p.add_argument("--save",   action="store_true")
    p.add_argument("--abs",    action="store_true",
                   help="Plot absolute values (mode 1 only)")
    p.add_argument("--sign",   action="store_true",
                   help="Negate all values: plot -BSSE (mode 2 only)")
    p.add_argument("--name",   default=None,
                   help="Custom suffix for saved filename, e.g. --name v2")
    return p.parse_args()


if __name__ == "__main__":
    args    = parse_args()
    methods = METHODS if args.method == "all" else [args.method]

    dispatch = {
        1: lambda: plot_mode1(args.mol, methods, args.basis, args.save,
                              abs_vals=args.abs, name=args.name),
        2: lambda: plot_mode2(args.mol, methods, args.basis, args.save,
                              sign=args.sign, name=args.name),
        3: lambda: plot_mode3(args.mol, methods, args.basis, args.save,
                              name=args.name),
        4: lambda: plot_mode4(args.mol, methods, args.basis, args.save,
                              name=args.name),
        5: lambda: plot_mode5(args.mol, methods, args.basis, args.save,
                              name=args.name),
        6: lambda: plot_mode6(args.mol, methods, args.basis, args.save,
                              name=args.name),
        7: lambda: plot_mode7(args.mol, methods, args.basis, args.save,
                              name=args.name),
    }
    dispatch[args.plot]()