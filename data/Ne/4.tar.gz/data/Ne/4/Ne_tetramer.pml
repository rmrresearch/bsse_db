# Ne_tetramer.pml — Ne Tetramer | Ne-Ne distances | C3v geometry
# Apex A (index 1) at z = -1.481 Å; base triangle B, C, D (indices 2, 3, 4) at z = +0.494 Å
# Apex-to-base: AB = AC = AD = 3.172 Å  (~3.2 Å)
# Base triangle: BC = BD = CD = 4.300 Å  (~4.3 Å)
# Atom order (from Ne_abcd.xyz): Ne_A=1 (apex), Ne_B=2, Ne_C=3, Ne_D=4

load pymol_xyz_files/Ne_abcd.xyz, Ne_tetramer
preset.ball_and_stick(selection='all', mode=1)
util.cbaw

# White background
bg_color white
set ray_opaque_background, 1

# Teal color for Ne atoms (util.cbaw makes Ne white on white bg)
# color teal, name Ne  # commented out: keep default ball_and_stick color (consistent with trimer)

# Ne-Ne connectivity — all 6 pairs
# Apex-to-base (3 pairs)
distance NN_AB, index 1, index 2
distance NN_AC, index 1, index 3
distance NN_AD, index 1, index 4
# Base triangle (3 pairs)
distance NN_BC, index 2, index 3
distance NN_BD, index 2, index 4
distance NN_CD, index 3, index 4

# Black dashes
color black, NN_AB
color black, NN_AC
color black, NN_AD
color black, NN_BC
color black, NN_BD
color black, NN_CD

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
set label_distance_digits, 2

# A/B/C/D atom labels — black (global settings BEFORE per-distance overrides)
set label_size, 24
set label_color, black
set label_font_id, 5

# Labels on Ne atoms
label index 1, "A"
label index 2, "B"
label index 3, "C"
label index 4, "D"

# Distance labels — black (must come AFTER global label_color)
set label_color, black, NN_AB
set label_color, black, NN_AC
set label_color, black, NN_AD
set label_color, black, NN_BC
set label_color, black, NN_BD
set label_color, black, NN_CD
set label_size, 16, NN_AB
set label_size, 16, NN_AC
set label_size, 16, NN_AD
set label_size, 16, NN_BC
set label_size, 16, NN_BD
set label_size, 16, NN_CD

# Orient and fit — let PyMOL choose the best axis alignment
orient
zoom all, 0.8

# Render
png Ne_tetramer.png, width=800, height=800, dpi=300, ray=1
