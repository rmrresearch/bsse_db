"""
move_ABC_Ne.py
--------------
Copies ABC_ABC.nw from each reorganized config folder into
Ne/3/pymol_files_xyz/, renaming each file to
{n}_Ne_trimer_{distance}.xyz for conversion by nwchem_to_pymol_Ne.py.
"""

import shutil
from pathlib import Path

here     = Path(__file__).resolve().parent        # 3/scripts/
base_dir = here.parent                             # 3/

destination_path = base_dir / "pymol_files_xyz"
destination_path.mkdir(exist_ok=True)

config_folders = [f for f in base_dir.iterdir()
                  if f.is_dir() and f.name[0].isdigit()]

for subfolder in sorted(config_folders,
                        key=lambda p: int(p.name.split("_")[0])):
    parts    = subfolder.name.split("_", 1)
    n        = parts[0]
    distance = parts[1]

    source_file = subfolder / "CCSD_T" / "aug-cc-pvdz" / "ABC_ABC.nw"
    if source_file.exists():
        new_name  = f"{n}_Ne_trimer_{distance}.xyz"
        dest_file = destination_path / new_name
        shutil.copy2(source_file, dest_file)
        print(f"Copied: {new_name}")
    else:
        print(f"WARNING: {source_file} not found in {subfolder.name}")