"""
nwchem_to_pymol_Ne.py
---------------------
Converts NWChem input files in pymol_files_xyz/ into clean .xyz files
readable by PyMOL. Extracts only coordinate lines (element x y z),
writes the proper .xyz header, then deletes the original NWChem files.

Input:  Ne/3/pymol_files_xyz/n_Ne_trimer_R.xyz  (NWChem format)
Output: Ne/3/pymol_files_xyz/n_R.xyz             (clean PyMOL format)
"""

from pathlib import Path
import re

here     = Path(__file__).resolve().parent        # 3/scripts/
base_dir = here.parent                             # 3/
work_dir = base_dir / "pymol_files_xyz"

# Matches coordinate lines: "element x y z"
coord_pattern = r"[A-Za-z]+\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+"

for file in work_dir.glob("*.xyz"):
    new_file = work_dir / file.name.replace("_Ne_trimer", "")

    with open(file, "r") as f:
        contents = f.readlines()

    coord_lines = [line for line in contents if re.match(coord_pattern, line)]

    with open(new_file, "w") as nw_f:
        number_atoms  = len(coord_lines)
        distance      = file.stem.split("_")[-1]
        title_section = f"pymol coord for Ne trimer with Ne-Ne distance: {distance} Angstroms"
        nw_f.write(f"{number_atoms}\n")
        nw_f.write(f"{title_section}\n")
        for line in coord_lines:
            parts = line.split()
            element = parts[0]
            x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
            nw_f.write(f"{element} {x:.8f} {y:.8f} {z:.8f}\n")

    print(f"Converted: {file.name} -> {new_file.name}")

# Delete original NWChem files
for old_file in work_dir.glob("*Ne_trimer*"):
    old_file.unlink()
    print(f"Deleted: {old_file.name}")