"""
copy_rename_files_Ne.py
-----------------------
Copies NWChem input/output files from the original Ne_trimers/ folder
into the reorganized Ne/3/ structure, renaming them following the
real_basis convention (e.g. input_E_AB_A.txt -> A_AB.nw).

Source:      Ne/Ne_trimers/Ne_trimer_R/
Destination: Ne/3/n_R/CCSD_T/aug-cc-pvdz/

Original naming: input_E_<basis>_<real>.txt / output_E_<basis>_<real>.txt
New naming:      <real>_<basis>.nw          / <real>_<basis>.out
"""

import shutil
from pathlib import Path

here       = Path(__file__).resolve().parent        # 3/scripts/
base_dir   = here.parent                             # 3/
source_dir = base_dir.parent / "Ne_trimers"          # Ne/Ne_trimers/

trimer_folders = [f for f in source_dir.iterdir()
                  if f.is_dir() and f.name.startswith("Ne_trimer")]

for n, subfolder in enumerate(sorted(trimer_folders,
                               key=lambda p: float(p.name.split("_")[-1]))):
    raw_distance = subfolder.name.split("_")[-1]
    distance = raw_distance if '.' in raw_distance else raw_distance + '.0'
    dest_dir = base_dir / f"{n}_{distance}/CCSD_T/aug-cc-pvdz"

    for file in subfolder.iterdir():
        if file.is_file():
            if file.name.startswith("input_E"):
                stem       = file.name.removeprefix("input_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name   = "_".join(name_parts) + ".nw"
                shutil.copy2(file, dest_dir / new_name)
            elif file.name.startswith("output_E"):
                stem       = file.name.removeprefix("output_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name   = "_".join(name_parts) + ".out"
                shutil.copy2(file, dest_dir / new_name)

    print(f"Copied: {n}_{distance}")