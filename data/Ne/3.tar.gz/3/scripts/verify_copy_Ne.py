"""
verify_copy_Ne.py
-----------------
Verifies that every file copied into the reorganized Ne/3/ structure
is identical to its original in Ne/Ne_trimers/.

Prints OK or MISMATCH for each file pair.
"""

import filecmp
from pathlib import Path

here       = Path(__file__).resolve().parent        # 3/scripts/
base_dir   = here.parent                             # 3/
source_dir = base_dir.parent / "Ne_trimers"          # Ne/Ne_trimers/

trimer_folders = [f for f in source_dir.iterdir()
                  if f.is_dir() and f.name.startswith("Ne_trimer")]

total   = 0
mismatches = 0

for n, subfolder in enumerate(sorted(trimer_folders,
                               key=lambda p: float(p.name.split("_")[-1]))):
    raw_distance = subfolder.name.split("_")[-1]
    distance = raw_distance if '.' in raw_distance else raw_distance + '.0'
    dest_dir = base_dir / f"{n}_{distance}/CCSD_T/aug-cc-pvdz"

    for file in subfolder.iterdir():
        if file.is_file():
            if file.name.startswith("input_E"):
                stem       = file.name.removeprefix("input_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name   = "_".join(name_parts) + ".nw"
            elif file.name.startswith("output_E"):
                stem       = file.name.removeprefix("output_E_").removesuffix(".txt")
                name_parts = stem.split("_")
                name_parts.reverse()
                new_name   = "_".join(name_parts) + ".out"
            else:
                continue

            dest_file = dest_dir / new_name
            total += 1
            if filecmp.cmp(file, dest_file, shallow=False):
                print(f"OK:       {n}_{distance}/{new_name}")
            else:
                print(f"MISMATCH: {n}_{distance}/{new_name}")
                mismatches += 1

print(f"\n{total} files checked, {mismatches} mismatches.")