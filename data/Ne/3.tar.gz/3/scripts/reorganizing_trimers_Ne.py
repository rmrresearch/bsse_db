from pathlib import Path

here     = Path(__file__).resolve().parent        # 3/scripts/
base_dir = here.parent                             # 3/
source_dir = base_dir.parent / "Ne_trimers"        # Ne/Ne_trimers/

trimer_folders = [f for f in source_dir.iterdir() 
                  if f.is_dir() and f.name.startswith("Ne_trimer")]

for n, subfolder in enumerate(sorted(trimer_folders, 
                               key=lambda p: float(p.name.split("_")[-1]))):
    raw_distance = subfolder.name.split("_")[-1]
    distance = raw_distance if '.' in raw_distance else raw_distance + '.0'
    new_folder = f"{n}_{distance}/CCSD_T/aug-cc-pvdz"
    dest_dir = base_dir / new_folder
    dest_dir.mkdir(parents=True, exist_ok=True)
    print(f"Created: {dest_dir}")