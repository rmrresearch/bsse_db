# Ne Trimer Data — `data/Ne/3/`

## Overview
This directory contains NWChem CCSD(T)/aug-cc-pvdz calculations for the Ne trimer
in an equilateral triangle arrangement. The Ne-Ne distance is varied systematically
from 1.5 to 3.75 Angstroms across 10 configurations.

## Monomer Geometry
Ne atom (no internal degrees of freedom).

## Configuration Table
| Config | Ne-Ne Distance (Å) |
|--------|-------------------|
| 0      | 1.5               |
| 1      | 1.75              |
| 2      | 2.0               |
| 3      | 2.25              |
| 4      | 2.5               |
| 5      | 2.75              |
| 6      | 3.0               |
| 7      | 3.25              |
| 8      | 3.5               |
| 9      | 3.75              |

Note: R=4.0 Å data was found to contain HF trimer geometry and was excluded.
The misplaced folder has been moved to `data/HF/Ne_trimer_4_misplaced/`.

## Folder Structure
```
3/
├── n_R/CCSD_T/aug-cc-pvdz/   ← 19 .nw and 19 .out files per config
├── data_frames_plots/         ← CSVs and plots (populated by pipeline)
├── load_trimers.pml           ← PyMOL loader script
├── original_data/
│   └── Ne_trimers.tar         ← backup of original raw data
├── pymol_files_xyz/           ← 10 clean .xyz files for visualization
├── README.md
└── scripts/                   ← reorganization and conversion scripts
```

## File Naming Convention
Files follow the `real_basis` convention:
- `real` = monomer(s) with real atoms
- `basis` = monomer(s) contributing basis functions
- `.nw` for NWChem input, `.out` for NWChem output

Examples: `A_A.out`, `AB_ABC.out`, `ABC_ABC.out`

## Scripts
| Script | Description |
|--------|-------------|
| `reorganizing_trimers_Ne.py` | Creates the `n_R/CCSD_T/aug-cc-pvdz/` folder skeleton |
| `copy_rename_files_Ne.py`    | Copies and renames files from `Ne_trimers/` |
| `verify_copy_Ne.py`          | Verifies all copied files are identical to originals |
| `move_ABC_Ne.py`             | Extracts `ABC_ABC.nw` geometry files for PyMOL |
| `nwchem_to_pymol_Ne.py`      | Converts NWChem input to clean `.xyz` format |
| `make_load_pml_Ne.py`        | Generates `load_trimers.pml` PyMOL loader |
| `tar_cluster_Ne.py`          | Creates `Ne/3.tar.gz` |

## PyMOL Visualization
From `Ne/3/`:
```bash
pymol load_trimers.pml
```