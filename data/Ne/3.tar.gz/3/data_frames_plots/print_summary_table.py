"""
print_summary_table.py
======================
Location: bsse_db/data/{molecule}/3/data_frames_plots/

Reads three_body_bsse_{molecule}.pickle and prints formatted terminal tables.
No files are written — use this for quick inspection and sharing with the PI.

Default output (--method CCSD_T, all configs)
----------------------------------------------
  Compact one-row-per-config table for the chosen method:
    Config  Σ2b (Ha)  3b (Ha)  total (Ha)  |3b/2b|  |FI-FII|

With --method all
-----------------
  Compact table for each of SCF, MP2, CCSD_T in sequence.

With --config <n>
-----------------
  Full FORM(I) + FORM(II) tables for that single config.

With --scaling-only
-------------------
  Body-order scaling summary across all methods (mean across configs).

Usage
-----
    python3 print_summary_table.py --mol H2O
    python3 print_summary_table.py --mol Ne --method CCSD_T
    python3 print_summary_table.py --mol HF --method all
    python3 print_summary_table.py --mol H2O --config 0
    python3 print_summary_table.py --mol Ne --scaling-only
    python3 print_summary_table.py --mol HF --method MP2 --config 3
"""

import pickle
import argparse
from pathlib import Path

# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------
CLUSTER = "3"
BASIS   = "aug-cc-pvdz"
METHODS = ["SCF", "MP2", "CCSD_T"]
PAIRS   = ["AB", "AC", "BC"]

DELTA_1B_IN_2B = [
    "A_in_AB", "B_in_AB",
    "A_in_AC", "C_in_AC",
    "B_in_BC", "C_in_BC",
]
DELTA_1B_IN_3B = [
    "A_in_ABC", "B_in_ABC", "C_in_ABC",
]
DELTA_2B_IN_3B = [
    "AB_in_ABC", "AC_in_ABC", "BC_in_ABC",
]

# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
SEP  = "-" * 76
SEP2 = "=" * 76
SEP3 = "·" * 76


def _match(val1, val2, tol=1e-10):
    diff = abs(val1 - val2)
    return f"{diff:.2e}  {'✅' if diff < tol else '⚠️  MISMATCH'}"


def _ratio(num, denom):
    """Safe ratio |num/denom| — returns '    N/A' if denom ≈ 0."""
    if abs(denom) < 1e-30:
        return "    N/A"
    return f"{abs(num / denom):>7.4f}"


# ---------------------------------------------------------------------------
# Compact table — all configs for one method
# ---------------------------------------------------------------------------

def print_compact_table(bsse_data, molecule, method):
    """
    One line per config: Config, Σ2b, 3b, total, |3b/2b|, |FI-FII|.
    """
    trimer_bsse = bsse_data[molecule][CLUSTER]
    configs     = sorted(trimer_bsse.keys(), key=int)

    print(f"\n{SEP2}")
    print(f"  Body-order summary — {molecule} Trimer  |  {BASIS}  |  {method}")
    print(SEP2)
    print(f"  {'Config':>6}  {'Σ 2b_bsse (Ha)':>18}  {'3b_bsse (Ha)':>16}"
          f"  {'total (Ha)':>16}  {'|3b/2b|':>8}  {'|FI−FII|':>12}")
    print(SEP)

    for cfg in configs:
        e      = trimer_bsse[cfg][method][BASIS]
        sum_2b = sum(e['2b'][p]['bsse'] for p in PAIRS)
        b3     = e['3b']['bsse']
        total  = e['total_bsse']
        form2  = e['total_bsse_form2']
        diff   = abs(total - form2)
        ratio  = _ratio(b3, sum_2b)
        flag   = "✅" if diff < 1e-10 else "⚠️"
        print(f"  {cfg:>6}  {sum_2b:>+18.6e}  {b3:>+16.6e}"
              f"  {total:>+16.6e}  {ratio:>8}  {diff:.2e} {flag}")

    print(SEP2)



# ---------------------------------------------------------------------------
# Full FORM(I) table for one config
# ---------------------------------------------------------------------------

def print_form1_table(e, method, cfg):
    """Print FORM(I) table for a single config. Returns (sum_2b, b3, total)."""
    print(f"\n  ── TABLE 1: FORM(I)  |  {method}  |  config {cfg} ──")
    print(SEP)
    print(f"  {'Term':<18}  {'no_vmfc (Ha)':>16}  {'vmfc (Ha)':>16}  {'bsse (Ha)':>16}")
    print(SEP)

    # 2b
    sum_2b = 0.0
    for pair in PAIRS:
        nv = e['2b'][pair]['no_vmfc']
        v  = e['2b'][pair]['vmfc']
        b  = e['2b'][pair]['bsse']
        sum_2b += b
        print(f"  2b_{pair:<14}  {nv:>+16.6e}  {v:>+16.6e}  {b:>+16.6e}")
    print(f"  {'Σ 2b':<18}  {'':>16}  {'':>16}  {sum_2b:>+16.6e}")
    print(SEP)

    # 3b
    nv = e['3b']['no_vmfc']
    v  = e['3b']['vmfc']
    b3 = e['3b']['bsse']
    print(f"  {'3b':<18}  {nv:>+16.6e}  {v:>+16.6e}  {b3:>+16.6e}")
    print(SEP)

    # Total
    total = e['total_bsse']
    print(f"  {'total_bsse':<18}  {'':>16}  {'':>16}  {total:>+16.6e}")
    print(SEP)

    return sum_2b, b3, total


# ---------------------------------------------------------------------------
# Full FORM(II) table for one config
# ---------------------------------------------------------------------------

def print_form2_table(e, method, cfg, sum_2b_f1, b3_f1, total_f1):
    """Print FORM(II) delta-group table for a single config."""
    deltas = e['delta_terms']

    print(f"\n  ── TABLE 2: FORM(II)  |  {method}  |  config {cfg} ──")

    # ------------------------------------------------------------------
    # 2b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 2b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-2b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_2b = 0.0
    for key in DELTA_1B_IN_2B:
        raw    = deltas[key]
        signed = +raw
        sum_1b_in_2b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-2b':<20}  {'':>16}  {sum_1b_in_2b:>+16.6e}")
    print(f"    {'Σ 2b  [FORM I]':<20}  {'':>16}  {sum_2b_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(sum_1b_in_2b, sum_2b_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # 3b level
    # ------------------------------------------------------------------
    print(f"\n  {'— 3b level —':^72}")
    print(SEP3)
    print(f"  Group: 1b-in-3b  (sign −)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_1b_in_3b = 0.0
    for key in DELTA_1B_IN_3B:
        raw    = deltas[key]
        signed = -raw
        sum_1b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 1b-in-3b':<20}  {'':>16}  {sum_1b_in_3b:>+16.6e}")
    print(SEP3)

    print(f"\n  Group: 2b-in-3b  (sign +)")
    print(SEP3)
    print(f"    {'Term':<20}  {'raw (Ha)':>16}  {'signed (Ha)':>16}")
    print(SEP3)
    sum_2b_in_3b = 0.0
    for key in DELTA_2B_IN_3B:
        raw    = deltas[key]
        signed = +raw
        sum_2b_in_3b += signed
        label  = key.replace("_in_", " in ")
        print(f"    {label:<20}  {raw:>+16.6e}  {signed:>+16.6e}")
    print(SEP3)
    print(f"    {'Σ 2b-in-3b':<20}  {'':>16}  {sum_2b_in_3b:>+16.6e}")
    print(SEP3)

    net_3b = sum_1b_in_3b + sum_2b_in_3b
    print(f"\n    {'net 3b (FORM II)':<20}  {'':>16}  {net_3b:>+16.6e}")
    print(f"    {'3b  [FORM I]':<20}  {'':>16}  {b3_f1:>+16.6e}")
    print(f"    {'|diff|':<20}  {'':>16}  {_match(net_3b, b3_f1):>32}")
    print(SEP)

    # ------------------------------------------------------------------
    # Grand total comparison
    # ------------------------------------------------------------------
    form2_total = e['total_bsse_form2']
    diff        = abs(form2_total - total_f1)
    print(f"\n  {'─ Grand Total ─':^72}")
    print(SEP)
    print(f"  {'total (FORM I)':<22}  {total_f1:>+16.6e}")
    print(f"  {'total (FORM II)':<22}  {form2_total:>+16.6e}")
    print(f"  {'|FORM I - FORM II|':<22}  {diff:.2e}  "
          f"{'✅' if diff < 1e-10 else '⚠️  MISMATCH'}")
    print(SEP)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Print BSSE summary tables for H2O, Ne, or HF trimer"
    )
    parser.add_argument(
        "--mol", required=True, choices=["H2O", "Ne", "HF"],
        help="Molecule: H2O, Ne, or HF"
    )
    parser.add_argument(
        "--method", default="CCSD_T", choices=["SCF", "MP2", "CCSD_T", "all"],
        help="Method to display (default: CCSD_T)"
    )
    parser.add_argument(
        "--config", default=None, type=str,
        help="Print full FORM(I)+FORM(II) tables for a single config index"
    )
    args = parser.parse_args()

    # --- paths ---
    here        = Path(__file__).resolve().parent
    data_dir    = here.parent.parent.parent
    pickle_path = data_dir / f'three_body_bsse_{args.mol}.pickle'

    with open(pickle_path, 'rb') as f:
        bsse_data = pickle.load(f)

    methods = METHODS if args.method == "all" else [args.method]

    print(f"\n{SEP2}")
    print(f"  BSSE Analysis — {args.mol} Trimer  |  {BASIS}")
    print(SEP2)

    if args.config is not None:
        # Full FORM(I) + FORM(II) for a single config, chosen methods
        cfg = args.config
        for method in methods:
            e = bsse_data[args.mol][CLUSTER][cfg][method][BASIS]
            sum_2b, b3, total = print_form1_table(e, method, cfg)
            print_form2_table(e, method, cfg, sum_2b, b3, total)

    else:
        # Compact table per method
        for method in methods:
            print_compact_table(bsse_data, args.mol, method)