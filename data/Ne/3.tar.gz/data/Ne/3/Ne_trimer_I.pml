# Ne_trimer_I.pml — Ne Trimer | Ne-Ne distances | Config 4 (R = 2.5 Å)
# Representative geometry: equilateral triangle, all Ne-Ne = 2.5 Å
# Atom order (from 4_2.5.xyz): Ne_A=1, Ne_B=2, Ne_C=3
# All atoms in z=0 plane — top-down view, no rotation needed

load pymol_files_xyz/4_2.5.xyz, Ne_trimer
preset.ball_and_stick(selection='all', mode=1)

# White background
bg_color white
set ray_opaque_background, 1

# Ne-Ne connectivity — all three pairs
distance NeNe_AB, index 1, index 2
distance NeNe_AC, index 1, index 3
distance NeNe_BC, index 2, index 3

# Black dashes
color black, NeNe_AB
color black, NeNe_AC
color black, NeNe_BC

# Dash style
set dash_radius, 0.01
set dash_gap, 0.3
set dash_length, 0.2
set dash_width, 0.25

# Distance label decimal places
set label_distance_digits, 2

# A/B/C atom labels — black
set label_size, 24
set label_color, black
set label_font_id, 5

# Labels on Ne atoms
label index 1, "A"
label index 2, "B"
label index 3, "C"

# Distance labels — black (must come AFTER global label_color)
set label_color, black, NeNe_AB
set label_color, black, NeNe_AC
set label_color, black, NeNe_BC
set label_size, 16, NeNe_AB
set label_size, 16, NeNe_AC
set label_size, 16, NeNe_BC

# Top-down view — all atoms in z=0 plane
zoom all, 3

# Render
png Ne_trimer_I.png, width=800, height=800, dpi=300, ray=1
