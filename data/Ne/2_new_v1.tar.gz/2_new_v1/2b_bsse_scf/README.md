# 2b_bsse_scf — deriving the functional form of BSSE_SCF(R), Ne dimer

Workspace for TASK 3 of handoff 05-28-july. Target: the column
`2b_bsse_SCF` of the parent CSV, on the R <= 3.5 A window (67 points).

## Why this folder exists
- `../data_frames_plots/`  holds the |BSSE|_total fit study. Different
  target, different purpose. UNCHANGED by this work.
- `../movecs_study/`       COMPLETE (68 verified jobs, 3 CSVs).
  READ-ONLY data source from here on. Nothing is run there.

## Inputs (all read-only, all already on disk — no new compute)
| path | contents |
|---|---|
| `../data_frames_plots/ne_dimer_bsse_vs_R.csv` | fit target, col `2b_bsse_SCF` |
| `../movecs_study/data_frames_plots/ne_dimer_P_AB_shells.csv` | signed P_AB, 110 ch x 67 R |
| `../movecs_study/data_frames_plots/ne_dimer_1e2e_vs_R.csv` | dE_1e / dE_2e split |
| handoff 05-28-july §3.2 | aug-cc-pVDZ Ne exponents, for GPT/Boys factors |

## Verified identities (checked against the CSV, not assumed)
- `A_A_SCF` constant over all 100 R (std 2.9e-14 Ha)
- `A_AB_SCF = B_AB_SCF` to 1.0e-12 Ha
- `2b_bsse_SCF = 2*[E_A(AB) - E_A(A)]*627.5095` to 6.4e-10 kcal/mol
  => BSSE(inf) = 0 is structural, not fitted.

## Conventions (carried over unchanged)
- `Path(__file__).resolve().parent` anchoring; scripts run from any cwd
- `--R-min` / `--R-max` window flags; windowed outputs get filename suffixes
  so they never overwrite full-range outputs
- signed values stored; absolute values applied at plot time only
- `%.15g` CSV precision
- acceptance judged on residual STRUCTURE (runs test, lag-1 acf), not RMSE
