#!/usr/bin/env python3
"""Plot E_A(AB)(R) -- the monomer-in-dimer-basis SCF energy -- with each
rung's fit drawn on it, on the HARTREE scale.

WHY A SEPARATE SCRIPT
---------------------
`fit_scf_ladder.py` fits and plots on the BSSE scale.  The quantity actually
being modelled, though, is E_A(AB)(R), and that curve is never shown.  This
script shows it, and walks the reconstruction chain explicitly:

    E_A(AB)(R)  --(fit)-->  E_A(A) + f(R)
                --(subtract E_A(A))-->  dE(R)
                --(abs, x2)-->  |BSSE_SCF(R)|

NO NEW FIT IS PERFORMED.  The model definitions and the fitting routine are
IMPORTED from fit_scf_ladder, so the parameters plotted here are the same
numbers that script reports -- they cannot drift apart.

ON THE EQUIVALENCE
------------------
Fitting E_A(AB) to [E_A(A) + f(R)] and fitting [E_A(AB) - E_A(A)] to f(R)
are the SAME minimisation:

    sum_i [ E_i - (E_A(A) + f(R_i)) ]^2  ==  sum_i [ (E_i - E_A(A)) - f(R_i) ]^2

term by term, exactly, because E_A(A) is a fixed constant (std 2.9e-14 Ha
across the grid).  Subtracting a known constant before the fit rather than
carrying it through cannot change the parameters or the residuals.  This
script therefore displays the first form while computing the second.

What must NOT be done is fitting the constant.  Measured: a free C lands at
-128.496364 instead of -128.496350, missing by 1.4e-5 Ha = 2.3% of the whole
6.1e-4 Ha swing, and dragging B from 0.610 to 0.653.

Usage
-----
    python plot_E_A_AB.py --R-max 3.5
    python plot_E_A_AB.py --R-max 3.5 --rung F0 --rung F6
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from fit_scf_ladder import (  # noqa: E402
    LADDER, HARTREE_TO_KCAL, load_data, fit_rung, window_suffix,
)

OUT_DIR = HERE.parent / "data_frames_plots" / "E_A_AB_SCF"

SUFFIX = ""


def plot_energy(R, E, E0, R_h, E_h, results):
    """E_A(AB) in Hartree, one row per rung, fit overlaid."""
    n = len(results)
    fig, axes = plt.subplots(n, 1, figsize=(7.8, 2.7 * n),
                             squeeze=False, sharex=True)
    axes = axes[:, 0]
    have_held = R_h is not None and len(R_h) > 0

    for ax, res in zip(axes, results):
        Rf = np.linspace(R.min(),
                         R_h.max() if have_held else R.max(), 500)
        Ef = E0 + res["func"](Rf, *res["popt"]) / HARTREE_TO_KCAL

        ax.axhline(E0, color="tab:green", ls="--", lw=1.2,
                   label=r"$E_A(A)$ = %.9f Ha (imposed)" % E0)
        ax.plot(R, E, "ko", ms=3.5, label=r"$E_A(AB)$ data (fitted)")
        if have_held:
            ax.plot(R_h, E_h, "o", ms=3.5, mfc="none", mec="tab:blue",
                    label=r"$E_A(AB)$ held out")
        ax.plot(Rf, Ef, "r-", lw=1.6,
                label=f"{res['rung']}: $E_A(A) + f(R)$")

        ax.set_ylabel(r"$E_A(AB)$ (Ha)", fontsize=9)
        ax.set_title(f"{res['rung']}   k={res['k']}   "
                     f"RMSE={res['rmse']/HARTREE_TO_KCAL:.3e} Ha",
                     fontsize=10, loc="left")
        ax.legend(fontsize=7, loc="lower right")
        ax.ticklabel_format(axis="y", useOffset=E0, style="plain")

    axes[-1].set_xlabel(r"$R_{\rm Ne-Ne}$ ($\AA$)")
    plt.tight_layout()
    p = OUT_DIR / f"E_A_AB_SCF_fits{SUFFIX}.png"
    plt.savefig(p, dpi=150)
    plt.close()
    print(f"  saved: {p.name}")


def plot_residuals(R, E, E0, R_h, E_h, results):
    """Residuals of the E_A(AB) fit, on the HARTREE scale.

    Identical in shape to the BSSE-scale residuals of fit_scf_ladder --
    resid_Ha = resid_kcal / (2 x 627.5095) -- only the units differ.  Shown
    here so the residual can be read against the energy plot directly.
    """
    n = len(results)
    fig, axes = plt.subplots(n, 1, figsize=(7.8, 2.3 * n),
                             squeeze=False, sharex=True)
    axes = axes[:, 0]
    have_held = R_h is not None and len(R_h) > 0

    for ax, res in zip(axes, results):
        r = E - (E0 + res["func"](R, *res["popt"]) / HARTREE_TO_KCAL)
        ax.plot(R, r, "ko", ms=3, label="fitted window")
        if have_held:
            r_h = E_h - (E0 + res["func"](R_h, *res["popt"])
                         / HARTREE_TO_KCAL)
            ax.plot(R_h, r_h, "o", ms=3, mfc="none", mec="tab:blue",
                    label="held out")
            ax.axvline(R.max(), color="gray", ls=":", lw=1)
        ax.axhline(0, color="gray", lw=1)
        ax.set_ylabel("residual (Ha)", fontsize=9)
        ttl = (f"{res['rung']}   k={res['k']}   "
               f"RMSE={res['rmse']/HARTREE_TO_KCAL:.3e} Ha   "
               f"max|r|={np.abs(r).max():.3e} Ha   "
               f"runs={res['runs']} (exp {res['exp_runs']:.0f})   "
               f"acf={res['acf']:.3f}")
        ax.set_title(ttl, fontsize=9, loc="left")
        ax.legend(fontsize=7, loc="upper right")

    axes[-1].set_xlabel(r"$R_{\rm Ne-Ne}$ ($\AA$)")
    plt.tight_layout()
    p = OUT_DIR / f"E_A_AB_SCF_residuals{SUFFIX}.png"
    plt.savefig(p, dpi=150)
    plt.close()
    print(f"  saved: {p.name}")


def plot_chain(R, E, E0, results):
    """The reconstruction chain, one column per stage, for each rung."""
    n = len(results)
    fig, axes = plt.subplots(n, 3, figsize=(13.5, 2.6 * n), squeeze=False)

    for row, res in zip(axes, results):
        f = res["func"](R, *res["popt"])              # kcal/mol
        E_fit = E0 + f / HARTREE_TO_KCAL              # Ha
        dE_fit = f                                    # kcal/mol
        bsse_fit = np.abs(2.0 * f)                    # kcal/mol

        a0, a1, a2 = row
        a0.plot(R, E, "ko", ms=3)
        a0.plot(R, E_fit, "r-", lw=1.5)
        a0.axhline(E0, color="tab:green", ls="--", lw=1)
        a0.set_ylabel(f"{res['rung']}\n" r"$E_A(AB)$ (Ha)", fontsize=9)
        a0.ticklabel_format(axis="y", useOffset=E0, style="plain")

        a1.plot(R, (E - E0) * HARTREE_TO_KCAL, "ko", ms=3)
        a1.plot(R, dE_fit, "r-", lw=1.5)
        a1.axhline(0, color="gray", lw=1)
        a1.set_ylabel(r"$\Delta E$ (kcal/mol)", fontsize=9)

        a2.plot(R, np.abs(2.0 * (E - E0) * HARTREE_TO_KCAL), "ko", ms=3)
        a2.plot(R, bsse_fit, "r-", lw=1.5)
        a2.set_ylabel(r"$|{\rm BSSE}_{\rm SCF}|$", fontsize=9)

    axes[0][0].set_title(r"1. $E_A(AB)$ and its fit", fontsize=10)
    axes[0][1].set_title(r"2. subtract $E_A(A)$", fontsize=10)
    axes[0][2].set_title(r"3. $\times 2$, absolute value", fontsize=10)
    for a in axes[-1]:
        a.set_xlabel(r"$R_{\rm Ne-Ne}$ ($\AA$)")
    plt.tight_layout()
    p = OUT_DIR / f"E_A_AB_SCF_chain{SUFFIX}.png"
    plt.savefig(p, dpi=150)
    plt.close()
    print(f"  saved: {p.name}")


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--R-min", dest="r_min", type=float, default=None)
    ap.add_argument("--R-max", dest="r_max", type=float, default=None)
    ap.add_argument("--rung", action="append", choices=list(LADDER),
                    default=None,
                    help="Repeatable. Default: every rung.")
    args = ap.parse_args()

    global SUFFIX
    SUFFIX = window_suffix(args.r_min, args.r_max)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    R, dE, bsse, R_h, dE_h, bsse_h, E0, n_all = load_data(args.r_min,
                                                          args.r_max)
    E = E0 + dE / HARTREE_TO_KCAL
    E_h = E0 + dE_h / HARTREE_TO_KCAL if len(R_h) else np.array([])

    print(f"  window        : {len(R)}/{n_all} points, "
          f"R in [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  E_A(AB) range : [{E.min():.12f}, {E.max():.12f}] Ha")
    print(f"  total swing   : {E.max()-E.min():.6e} Ha = "
          f"{(E.max()-E.min())*HARTREE_TO_KCAL:.6f} kcal/mol")
    print(f"  relative      : {(E.max()-E.min())/abs(E0):.3e}  "
          f"(the signal is ~5 ppm of the energy)")
    print(f"  output dir    : {OUT_DIR.relative_to(HERE.parent)}")
    print()

    rungs = args.rung or list(LADDER)
    print("Refitting (identical to fit_scf_ladder -- imported, not re-derived)")
    import io, contextlib
    results = []
    for nm in rungs:
        with contextlib.redirect_stdout(io.StringIO()):
            results.append(fit_rung(nm, R, dE, R_h, dE_h))
        print(f"  {nm}: RMSE = {results[-1]['rmse']/HARTREE_TO_KCAL:.6e} Ha")
    print()

    # CSV: E_A(AB) data and per-rung fitted energies, signed, Hartree
    out = {"R": R, "E_A_AB_Ha": E, "dE_kcal": dE, "bsse_scf_kcal": bsse}
    for res in results:
        f = res["func"](R, *res["popt"])
        out[f"E_A_AB_fit_{res['rung']}_Ha"] = E0 + f / HARTREE_TO_KCAL
        out[f"resid_{res['rung']}_Ha"] = E - (E0 + f / HARTREE_TO_KCAL)
    p = OUT_DIR / f"E_A_AB_SCF_fits{SUFFIX}.csv"
    pd.DataFrame(out).to_csv(p, index=False, float_format="%.15g")
    print(f"  saved: {p.name}")

    plot_energy(R, E, E0, R_h, E_h, results)
    plot_residuals(R, E, E0, R_h, E_h, results)
    plot_chain(R, E, E0, results)


if __name__ == "__main__":
    main()
