#!/usr/bin/env python3
"""Fit dE(R) = E_A(AB) - E_A(A) for the Ne dimer to a nested ladder of
poly x Gaussian + poly x erf/R forms, then reconstruct 2b_bsse_SCF.

TARGET AND IDENTITY
-------------------
For a homodimer the counterpoise BSSE is

    BSSE_SCF(R) = 2 * [ E_A(AB)(R) - E_A(A) ]

with E_A(A) an R-INDEPENDENT constant (verified: std 2.9e-14 Ha over the
grid).  The constant is therefore IMPOSED, not fitted -- fitting it costs a
degree of freedom on a known quantity and lets it absorb real signal
(measured: C misses E_A(A) by 1.4e-5 Ha = 2.3% of the total swing, and drags
B from 0.610 to 0.653).

Because the constant is removed before the fit, BSSE(inf) = 0 holds by
CONSTRUCTION rather than being something the fit has to discover.  This is
the condition the free gaussian+erf form of the |BSSE|_total study violates.

FUNCTIONAL FAMILY
-----------------
Two branches, from the integral structure of E_0 = sum P H^core + 1/2 sum P G:

  Gaussian branch   poly(R) * exp(-B R^2)
      Gaussian Product Theorem.  Szabo & Ostlund A.9 (overlap), A.11
      (kinetic).  The polynomial prefactor has two independent origins:
      the measured density shapes (handoff 05-28 3.3, both poly x Gaussian)
      and the GGPT angular expansion (Besalu & Carbo-Dorca 2011, eq. 42,
      whose binomial coefficients B_iq = P_q - A_iq are proportional to R).

  Boys branch       poly(R) * erf(kappa R) / R
      Every integral carrying the 1/r operator picks up the Boys function.
      Boys 1950 eq. (16)-(17); Szabo & Ostlund A.32-A.33, A.41.
          F_0(x) = (1/2) sqrt(pi/x) erf(sqrt(x))
      With x proportional to R^2 this is erf(kappa R)/R.  The 1/R is NOT
      cosmetic: it is what makes the branch decay rather than saturate.

CAVEAT TO CARRY (do not resolve here)
-------------------------------------
For Ne the undamped monopole Coulomb channels cancel exactly (Z_A = N_A,
handoff 05-28 7), and every higher multipole vanishes by sphericity.  A pure
1/R tail may therefore not physically survive for Ne.  If c comes out
consistent with zero, that is a RESULT -- the erf branch is not needed for
Ne -- not a failure of the fit.

ACCEPTANCE
----------
Judged on residual STRUCTURE, not RMSE or R^2.  Handoff 05-28 5.3 and 5.4
both show a fit reading RMSE 0.042 and R^2 0.994 with the wrong functional
family.  Two hard requirements:
  - residuals must lose their lobed structure, not merely shrink
  - the form must reproduce the turning point at R = 2.288-2.439 A;
    a monotone form cannot

Usage
-----
    python fit_scf_ladder.py
    python fit_scf_ladder.py --R-max 3.5
    python fit_scf_ladder.py --R-min 1.5 --R-max 3.5 --rung F2
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.special import erf

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# Paths -- anchored to this file, so the script runs from any directory
# ---------------------------------------------------------------------------
HERE = Path(__file__).resolve().parent            # .../2b_bsse_scf/scripts
# Base output directory.  main() appends a per-run subfolder, ladder_<sel>,
# so a single-rung run can never overwrite the full comparison.
OUT_BASE = HERE.parent / "data_frames_plots"      # .../2b_bsse_scf/data_frames_plots
OUT_DIR = OUT_BASE                                # rebound in main()
CSV_PATH = HERE.parent.parent / "data_frames_plots" / "ne_dimer_bsse_vs_R.csv"

HARTREE_TO_KCAL = 627.5094740631

# Set in main(); appended to every output filename.
SUFFIX = ""


# ---------------------------------------------------------------------------
# Model ladder
# ---------------------------------------------------------------------------
def _gauss(R, B):
    return np.exp(-B * R**2)


def _boys(R, kappa):
    """erf(kappa R)/R -- the Boys F_0 shape, up to constants.

    F_0(x) = (1/2) sqrt(pi/x) erf(sqrt(x)).  With x = kappa^2 R^2 this is
    proportional to erf(kappa R)/R.  Boys 1950 eq. (16); S&O eq. (A.32).
    """
    return erf(kappa * R) / R


def F0(R, a0, B):
    """Single Gaussian.  Baseline -- the form already established."""
    return a0 * _gauss(R, B)


def F1(R, a0, B, c0, kappa):
    """Gaussian + Boys."""
    return a0 * _gauss(R, B) + c0 * _boys(R, kappa)


def F2(R, a0, a2, B, c0, kappa):
    """(poly2) x Gaussian + Boys."""
    return (a0 + a2 * R**2) * _gauss(R, B) + c0 * _boys(R, kappa)


def F3(R, a0, a2, B, c0, c2, kappa):
    """(poly2) x Gaussian + (poly2) x Boys."""
    return (a0 + a2 * R**2) * _gauss(R, B) + (c0 + c2 * R**2) * _boys(R, kappa)


def F4(R, a0, a2, B, c0):
    """(poly2) x Gaussian + bare 1/R  -- the saturated limit of F2.

    F2 fits kappa = 8.14 with a SINGULAR covariance (sigma = 0, cond = inf).
    At that value erf(kappa R) = 1.0000000 across the whole window
    (erf(8.14 x 1.5) = erf(12.2)), so the Boys term has collapsed to c0/R
    and kappa carries no information -- any large kappa gives identical
    predictions.  F4 states that limit explicitly with one fewer parameter.

    If RMSE(F4) == RMSE(F2) and cond(F4) is finite, the collapse is
    confirmed and F4 is the correctly conditioned version of F2.  If RMSE
    degrades, kappa was doing real work after all.

    A surviving undamped 1/R channel for Ne is the term flagged as
    unresolved in handoff 05-28 7 (-Z_A q_B / R from V_BB, against
    +N_A q_B / R from the 2e Coulomb).  Interpretation PENDING PI
    DISCUSSION -- do not assert it from this fit alone.
    """
    return (a0 + a2 * R**2) * _gauss(R, B) + c0 / R


def F5(R, a0, a2, B, c0, gamma, kappa):
    """(poly2) x Gaussian + DAMPED Boys  exp(-gamma R^2) erf(kappa R)/R.

    Boys 1950 eq. (17) / S&O eq. (A.33) for the nuclear attraction integral:

        (aA|V_C|bB) = -(2 pi/(a+b)) Z_C exp(-[ab/(a+b)] R^2)
                                        x F_0((a+b) |R_P - R_C|^2)

    BOTH factors are present: the GPT damping AND the Boys function.  F2/F4
    dropped the damping, which is legitimate only for (AA|BB)-type integrals
    where both charge distributions are one-centre -- and for Ne those are
    exactly the ones that cancel (Z_A = N_A, handoff 05-28 7).  The held-out
    test confirmed it: F4's undamped 1/R overpredicts by 1554% at R = 4.5 A
    while a plain Gaussian is 8x better out of window.

    With a single nucleus (C = A) and |R_P - R_A| = beta R/(alpha+beta),
    the Boys argument is x = [beta^2/(alpha+beta)] R^2, so
    F_0(x) = (1/2) sqrt(pi/x) erf(sqrt(x)) is proportional to erf(kappa R)/R
    with kappa = beta/sqrt(alpha+beta).  The branch decays Gaussian-fast and
    therefore cannot install the false tail that killed F2/F4.
    """
    return ((a0 + a2 * R**2) * _gauss(R, B)
            + c0 * _gauss(R, gamma) * _boys(R, kappa))


def F6(R, a0, a2, B, c0, gamma):
    """(poly2) x Gaussian + exp(-gamma R^2)/R  -- saturated limit of F5.

    At large R, erf(kappa R) -> 1 and the F5 branch tends to
    exp(-gamma R^2)/R.  If F5's kappa saturates the way F2's did
    (kappa = 8.14, singular covariance), F6 is the properly conditioned
    statement of the same model and F5 should be discarded.  If kappa stays
    finite and constrained in F5, the erf is doing real work -- which is
    itself a result.
    """
    return (a0 + a2 * R**2) * _gauss(R, B) + c0 * _gauss(R, gamma) / R


def G1(R, a0, a2, B, c0, kappa):
    """DERIVED FORM: exp(-B R^2) [a0 + a2 R^2 + c0 erf(kappa R)/R].

    Derivation (task 3a, session 06-28-july).  The 23-function monomer
    solution is a valid trial function in the 46-function space but is NOT
    stationary there -- the gradient along ghost directions is F_ia != 0.
    Hence the energy lowering is SECOND order:

        dE_SCF ~ - sum_i^occ sum_a^ghost |F_ia|^2 / (eps_a - eps_i)

    so the object to enumerate is F_AB, not E_0, and everything is squared.

    Every term of F_AB = H_AB + G_AB[P_AA] has mu on A and nu on B, so every
    term carries a GPT damping factor exp(-gamma R^2):

        T_AB          poly x Gaussian
        V_AB          poly x Gaussian x Boys        (C = A, one nucleus)
        (AB|AA)       Coulomb,  bra pair two-centre -> damped, Boys
        (AA|AB)       exchange, same

    The undamped (AA|BB) integral has NO AB pair and therefore cannot enter
    F_AB at all.  Writing F_AB = exp(-gamma R^2)[p(R) + q(R) erf(kR)/R] and
    squaring:

        dE_SCF ~ exp(-2 gamma R^2)[P1 + P2 erf(kR)/R + P3 erf^2(kR)/R^2]

    Three consequences, all testable:
      (a) ONE shared exponent, not two.  F6 uses independent B and gamma;
          the derivation says they are the same envelope.
      (b) No undamped 1/R can survive.  V_BB and (AA|BB) ARE undamped, but
          they multiply P_BB = O(t^2), which carries exp(-2 gamma R^2)
          itself.  Physically: the ghost region holds no charge except what
          leaks there, and the leak is exponentially small.  This closes the
          handoff 05-28 §7 open item and matches the held-out result that
          the data has no 1/R tail.
      (c) The GPT floor DOUBLES: a second-order quantity must have
          B in [2 gamma_min, 2 gamma_max] = [0.380, 7.863] A^-2, not
          [0.190, 3.932].  F6's fitted gamma = 0.167 is excluded by this.

    Rigorously |sum_k c_k exp(-gamma_k R^2)|^2 is a SUM of Gaussians with
    exponents gamma_j + gamma_k; the single B here is an effective
    approximation to that sum.  The RANGE constraint is exact; the single
    exponent is not.
    """
    return np.exp(-B * R**2) * (a0 + a2 * R**2 + c0 * _boys(R, kappa))


def G2(R, a0, a2, B, c0):
    """Saturated limit of G1: exp(-B R^2) [a0 + a2 R^2 + c0/R].

    erf(kappa R) -> 1 on this window (see F2/F4/F5/F6).  Same structure,
    one fewer parameter, and the 1/R sits INSIDE the Gaussian envelope
    rather than beside it as in F4/F6.
    """
    return np.exp(-B * R**2) * (a0 + a2 * R**2 + c0 / R)


# Second-order GPT window, from the aug-cc-pVDZ Ne single-primitive shells
# (handoff 05-28 §3.2).  gamma_min = 7P x 7P = 0.190, gamma_max = 8D x 8D
# = 3.932 A^-2; doubled because dE_SCF is second order in F_AB.
B_FLOOR_2ND = 0.380
B_CEIL_2ND = 7.863

# Single-primitive shell exponents (bohr^-2), read from the .out, not assumed.
SHELL_EXPONENTS = {"3S": 0.4869, "4S": 0.1230, "5P": 1.695, "6P": 0.4317,
                   "7P": 0.1064, "8D": 2.202, "9D": 0.631}
BOHR2_TO_A2 = 1.0 / 0.52917721**2


def identify_shell_pair(B, tol=0.05):
    """Which primitive shell pairs give 2*gamma within tol of fitted B?

    CONJECTURE, not a result: 6P x 7P gives 2*gamma = 0.60966 against F0's
    fitted B = 0.61003 (0.06%).  This was found POST HOC among 28 candidate
    pairs, so it is suggestive only.  The falsifiable version is that the
    SAME pair should track B across aug-cc-pVxZ, where the exponents change.
    """
    import itertools
    out = []
    for (n1, a), (n2, b) in itertools.combinations_with_replacement(
            SHELL_EXPONENTS.items(), 2):
        tg = 2.0 * a * b / (a + b) * BOHR2_TO_A2
        if abs(tg - B) / B < tol:
            out.append((f"{n1}x{n2}", tg, 100 * (tg - B) / B))
    return sorted(out, key=lambda x: abs(x[2]))


# name -> (callable, parameter names, initial guess, lower bounds, upper bounds)
#
# a0/a2/c0/c2 in kcal/mol (free sign), B in A^-2, kappa in A^-1.
#
# B > 0 and kappa > 0 are REQUIRED, not conveniences.  B <= 0 makes the
# Gaussian branch grow with R; kappa <= 0 flips erf(kappa R) sign and makes
# the parameter degenerate with the amplitude, which is exactly the
# unidentifiability found in the |BSSE|_total study (handoff 05-28 5.4:
# b1 = -0.607 +/- 2.477).  Left free, kappa runs to -58 with a singular
# covariance and the fit is meaningless.
_INF = np.inf
LADDER = {
    "F0": (F0, ["a0", "B"], [-7.0, 0.61],
           [-_INF, 1e-6], [_INF, _INF]),
    "F1": (F1, ["a0", "B", "c0", "kappa"], [-7.0, 0.61, -0.05, 0.5],
           [-_INF, 1e-6, -_INF, 1e-6], [_INF, _INF, _INF, _INF]),
    "F2": (F2, ["a0", "a2", "B", "c0", "kappa"], [-7.0, 0.5, 0.61, -0.05, 0.5],
           [-_INF, -_INF, 1e-6, -_INF, 1e-6], [_INF, _INF, _INF, _INF, _INF]),
    "F3": (F3, ["a0", "a2", "B", "c0", "c2", "kappa"],
           [-7.0, 0.5, 0.61, -0.05, 0.0, 0.5],
           [-_INF, -_INF, 1e-6, -_INF, -_INF, 1e-6],
           [_INF, _INF, _INF, _INF, _INF, _INF]),
    "F4": (F4, ["a0", "a2", "B", "c0"], [-7.0, 0.5, 0.61, -0.05],
           [-_INF, -_INF, 1e-6, -_INF], [_INF, _INF, _INF, _INF]),
    "F5": (F5, ["a0", "a2", "B", "c0", "gamma", "kappa"],
           [-7.0, 0.5, 0.61, -0.05, 0.3, 0.5],
           [-_INF, -_INF, 1e-6, -_INF, 1e-6, 1e-6],
           [_INF, _INF, _INF, _INF, _INF, _INF]),
    "F6": (F6, ["a0", "a2", "B", "c0", "gamma"],
           [-7.0, 0.5, 0.61, -0.05, 0.3],
           [-_INF, -_INF, 1e-6, -_INF, 1e-6],
           [_INF, _INF, _INF, _INF, _INF]),
    # --- DERIVED forms (task 3a).  Single shared exponent.
    "G1": (G1, ["a0", "a2", "B", "c0", "kappa"], [-7.0, 0.5, 0.61, -0.05, 0.5],
           [-_INF, -_INF, 1e-6, -_INF, 1e-6],
           [_INF, _INF, _INF, _INF, _INF]),
    "G2": (G2, ["a0", "a2", "B", "c0"], [-7.0, 0.5, 0.61, -0.05],
           [-_INF, -_INF, 1e-6, -_INF], [_INF, _INF, _INF, _INF]),
}

# Multistart seeds for (B, kappa).  A single seed is not enough: the two
# branches are near-degenerate over a 2 A window, so the surface has several
# local minima.  Seed-independence of the winner is part of the acceptance
# test, not an implementation detail.
B_SEEDS = [0.30, 0.61, 0.90, 1.50]
KAPPA_SEEDS = [0.20, 0.50, 1.00, 2.00]
GAMMA_SEEDS = [0.15, 0.40, 0.90]


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
def window_suffix(r_min, r_max) -> str:
    parts = []
    if r_min is not None:
        parts.append(f"Rmin{r_min:g}".replace(".", "p"))
    if r_max is not None:
        parts.append(f"Rmax{r_max:g}".replace(".", "p"))
    return ("_" + "_".join(parts)) if parts else ""


def load_data(r_min, r_max):
    """Return R, dE (kcal/mol, SIGNED), bsse_scf (kcal/mol, SIGNED), E_A(A).

    Verifies the homodimer identity before returning, so a silent change to
    the upstream CSV cannot pass unnoticed.
    """
    d = pd.read_csv(CSV_PATH)
    n_all = len(d)

    E_AA = d["A_A_SCF"].to_numpy()
    if E_AA.std() > 1e-12:
        raise ValueError(f"E_A(A) is not constant: std = {E_AA.std():.3e} Ha")
    E0 = float(E_AA[0])

    sym = np.abs(d["A_AB_SCF"] - d["B_AB_SCF"]).max()
    if sym > 1e-10:
        raise ValueError(f"A_AB != B_AB (max {sym:.3e} Ha): not a homodimer")

    dE = (d["A_AB_SCF"].to_numpy() - E0) * HARTREE_TO_KCAL
    bsse = d["2b_bsse_SCF"].to_numpy()

    ident = np.abs(2.0 * dE - bsse).max()
    if ident > 1e-6:
        raise ValueError(f"identity 2*dE = 2b_bsse_SCF fails: {ident:.3e} kcal/mol")

    R = d["R"].to_numpy()
    mask = np.ones(len(R), dtype=bool)
    if r_min is not None:
        mask &= R >= r_min
    if r_max is not None:
        mask &= R <= r_max
    held = ~mask

    print(f"Loaded {n_all} points from {CSV_PATH.name}")
    print(f"  E_A(A)        = {E0:.12f} Ha  (IMPOSED, not fitted)")
    print(f"  identity 2*dE = 2b_bsse_SCF to {ident:.3e} kcal/mol")
    print(f"  A_AB = B_AB   to {sym:.3e} Ha")
    return (R[mask], dE[mask], bsse[mask],
            R[held], dE[held], bsse[held], E0, n_all)


# ---------------------------------------------------------------------------
# Residual structure
# ---------------------------------------------------------------------------
def runs_test(resid):
    s = np.sign(resid)
    s = s[s != 0]
    return int(1 + np.sum(s[1:] != s[:-1]))


def lag1_acf(resid):
    r = resid - resid.mean()
    denom = np.sum(r * r)
    return float(np.sum(r[1:] * r[:-1]) / denom) if denom > 0 else 0.0


def count_lobes(resid):
    """Number of sign-coherent runs -- the lobe count used in handoff 5.3."""
    return runs_test(resid)


def has_turning_point(R, pred):
    """Does the model reproduce a turning point in |dE| inside the window?

    Handoff 05-28 4: |2b_bsse_SCF| increases outward over R = 2.288-2.439 A.
    A monotone form cannot do this.
    """
    a = np.abs(pred)
    diff = np.diff(a)
    return bool(np.any(diff[:-1] * diff[1:] < 0))


# ---------------------------------------------------------------------------
# Fit one rung
# ---------------------------------------------------------------------------
def _seeds(name, pnames, p0):
    """Multistart seed list: vary B and kappa, leave amplitudes at p0."""
    out = []
    iB = pnames.index("B")
    iK = pnames.index("kappa") if "kappa" in pnames else None
    iG = pnames.index("gamma") if "gamma" in pnames else None
    for b in B_SEEDS:
        for k in (KAPPA_SEEDS if iK is not None else [None]):
            for g in (GAMMA_SEEDS if iG is not None else [None]):
                q = list(p0)
                q[iB] = b
                if iK is not None:
                    q[iK] = k
                if iG is not None:
                    q[iG] = g
                out.append(q)
    return out


def fit_rung(name, R, dE, R_h=None, dE_h=None):
    func, pnames, p0, lo, hi = LADDER[name]

    # ONE pass over the seed grid; results cached for the seed-independence
    # count.  (Refitting a second time is what made F5's 48-seed grid slow.)
    solutions = []
    for q in _seeds(name, pnames, p0):
        try:
            popt, pcov = curve_fit(func, R, dE, p0=q,
                                   bounds=(lo, hi), maxfev=2000)
        except Exception:
            continue
        rmse_q = float(np.sqrt(np.mean((dE - func(R, *popt)) ** 2)))
        solutions.append((rmse_q, popt, pcov))
    if not solutions:
        raise RuntimeError(f"rung {name}: no seed converged")
    n_ok = len(solutions)
    best_rmse = min(t[0] for t in solutions)
    _, popt, pcov = min(solutions, key=lambda t: t[0])

    # Seed-independence: how many seeds land within 1% of the best RMSE?
    n_same = sum(1 for t in solutions if t[0] <= best_rmse * 1.01)

    with np.errstate(invalid="ignore"):
        perr = np.sqrt(np.diag(pcov))

    pred = func(R, *popt)
    resid = dE - pred
    rmse = float(np.sqrt(np.mean(resid**2)))
    ss_res = float(np.sum(resid**2))
    ss_tot = float(np.sum((dE - dE.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot

    runs = runs_test(resid)
    exp_runs = len(R) / 2.0 + 1.0
    acf = lag1_acf(resid)
    cond = float(np.linalg.cond(pcov))

    print()
    print("=" * 68)
    print(f"RUNG {name}   k = {len(popt)}   ({func.__doc__.splitlines()[0]})")
    print("=" * 68)
    for nm, v, lb in zip(pnames, popt, lo):
        if np.isfinite(lb) and abs(v - lb) < 10 * abs(lb) + 1e-12:
            print(f"  NOTE: {nm} is PINNED at its lower bound ({lb:g}). "
                  f"Its sigma is not meaningful at an active constraint.")
    unconstrained = []
    for nm, v, e in zip(pnames, popt, perr):
        rel = e / abs(v) if v != 0 else np.inf
        flag = "  <- UNCONSTRAINED" if rel > 0.5 else ""
        if rel > 0.5:
            unconstrained.append(nm)
        print(f"  {nm:>6s} = {v: .6e} +/- {e:.3e}   (sigma/|p| = {rel:6.2f}){flag}")
    print(f"  seeds         = {n_same}/{n_ok} converge to this minimum "
          f"(within 1% RMSE)")
    print(f"  RMSE          = {rmse:.6e} kcal/mol")
    print(f"  R^2           = {r2:.6f}")
    print(f"  cond(pcov)    = {cond:.3e}")
    print(f"  sign runs     = {runs}   (expected ~{exp_runs:.0f} if independent)")
    print(f"  lag-1 acf     = {acf:.4f}")
    rmse_held = resid_held = None
    if R_h is not None and len(R_h) > 0:
        pred_h = func(R_h, *popt)
        resid_held = dE_h - pred_h
        rmse_held = float(np.sqrt(np.mean(resid_held**2)))
        ratio = rmse_held / rmse if rmse > 0 else np.inf
        print(f"  RMSE held-out = {rmse_held:.6e} kcal/mol   "
              f"({len(R_h)} pts, R in [{R_h.min():.3f}, {R_h.max():.3f}])")
        print(f"  ratio held/in = {ratio:.2f}"
              f"{'   <- EXTRAPOLATION FAILS' if ratio > 1.0 else ''}")
    print(f"  turning point reproduced: {has_turning_point(R, pred)}")

    # Second-order GPT window (task 3a).  dE_SCF is second order in F_AB,
    # so its Gaussian exponent must lie in [2 gamma_min, 2 gamma_max].
    if "B" in pnames:
        Bv = popt[pnames.index("B")]
        ok = B_FLOOR_2ND <= Bv <= B_CEIL_2ND
        print(f"  B in 2nd-order GPT window [{B_FLOOR_2ND}, {B_CEIL_2ND}]: "
              f"{ok}" + ("" if ok else "   <- EXCLUDED by the derivation"))
        hits = identify_shell_pair(Bv)
        if hits:
            nm_, tg, dev = hits[0]
            print(f"  nearest shell pair: {nm_}  2*gamma = {tg:.5f} "
                  f"({dev:+.2f}%)   [CONJECTURE, post hoc]")
    if "gamma" in pnames:
        gv = popt[pnames.index("gamma")]
        ok = B_FLOOR_2ND <= gv <= B_CEIL_2ND
        print(f"  gamma in 2nd-order window: {ok}"
              + ("" if ok else "   <- EXCLUDED by the derivation"))

    # Variational bound: E_A(AB) <= E_A(A)  <=>  f(R) <= 0 everywhere.
    # F3 passes every statistical test and fails this (handoff 06-28 §3.3).
    R_far = np.linspace(R.min(), max(6.0, R.max() * 1.5), 500)
    viol_in = int((pred > 0).sum())
    viol_far = int((func(R_far, *popt) > 0).sum())
    print(f"  variational f(R) <= 0 : in-window {viol_in} violations, "
          f"extrapolated to {R_far.max():.1f} A: {viol_far}"
          + ("   <- VIOLATES the variational bound"
             if (viol_in or viol_far) else ""))
    if runs < 0.5 * exp_runs or acf > 0.5:
        print("  VERDICT: residuals STRUCTURED -- functional family still wrong.")
    else:
        print("  VERDICT: residuals consistent with scatter.")

    return dict(rung=name, k=len(popt), pnames=pnames, popt=popt, perr=perr,
                pred=pred, resid=resid, rmse=rmse, r2=r2, cond=cond,
                runs=runs, exp_runs=exp_runs, acf=acf,
                n_seed_same=n_same, n_seed_ok=n_ok,
                rmse_held=rmse_held, resid_held=resid_held,
                unconstrained=",".join(unconstrained),
                turning=has_turning_point(R, pred), func=func)


# ---------------------------------------------------------------------------
# Plots
# ---------------------------------------------------------------------------
def plot_all(R, dE, bsse, results, R_h=None, bsse_h=None):
    """Vertical stack: one row per rung, shared x-axis."""
    n = len(results)
    have_held = R_h is not None and len(R_h) > 0

    # --- 1. fit overlay, on the BSSE scale (x2), absolute at plot time only
    fig, axes = plt.subplots(n, 1, figsize=(7.5, 2.6 * n),
                             squeeze=False, sharex=True)
    axes = axes[:, 0]
    for ax, res in zip(axes, results):
        if have_held:
            ax.plot(R_h, np.abs(bsse_h), "o", ms=3, mfc="none",
                    mec="tab:blue", label="held out (not fitted)")
            Rf = np.linspace(min(R.min(), R_h.min()),
                             max(R.max(), R_h.max()), 400)
            ax.plot(Rf, np.abs(2.0 * res["func"](Rf, *res["popt"])),
                    "r-", lw=1.4, alpha=0.45)
        ax.plot(R, np.abs(bsse), "ko", ms=3, label=r"data (fitted)")
        ax.plot(R, np.abs(2.0 * res["pred"]), "r-", lw=1.8,
                label=f"{res['rung']}  RMSE={2*res['rmse']:.4f}")
        ax.set_ylabel(r"$|{\rm BSSE}_{\rm SCF}|$" "\n(kcal/mol)", fontsize=9)
        ttl = f"{res['rung']}   k={res['k']}"
        if res.get("rmse_held") is not None:
            ttl += (f"   RMSE(in)={2*res['rmse']:.4f}   "
                    f"RMSE(held)={2*res['rmse_held']:.4f}   "
                    f"ratio={res['rmse_held']/res['rmse']:.2f}")
        ax.set_title(ttl, fontsize=10, loc="left")
        ax.legend(fontsize=7, loc="upper right")
    axes[-1].set_xlabel(r"$R_{\rm Ne-Ne}$ ($\AA$)")
    plt.tight_layout()
    p = OUT_DIR / f"ne_scf_ladder_fit{SUFFIX}.png"
    plt.savefig(p, dpi=150); plt.close()
    print(f"\n  saved: {p.name}")

    # --- 2. residuals, on the BSSE scale
    fig, axes = plt.subplots(n, 1, figsize=(7.5, 2.2 * n),
                             squeeze=False, sharex=True)
    axes = axes[:, 0]
    for ax, res in zip(axes, results):
        ax.plot(R, 2.0 * res["resid"], "ko", ms=3, label="fitted window")
        if have_held:
            ax.plot(R_h, 2.0 * res["resid_held"], "o", ms=3, mfc="none",
                    mec="tab:blue", label="held out")
            ax.axvline(R.max(), color="gray", ls=":", lw=1)
        ax.axhline(0, color="gray", lw=1)
        ax.set_ylabel("residual\n(kcal/mol)", fontsize=9)
        ax.set_title(f"{res['rung']}   runs={res['runs']} "
                     f"(exp {res['exp_runs']:.0f})   acf={res['acf']:.3f}",
                     fontsize=10, loc="left")
        if have_held:
            ax.legend(fontsize=7, loc="upper left")
    axes[-1].set_xlabel(r"$R_{\rm Ne-Ne}$ ($\AA$)")
    plt.tight_layout()
    p = OUT_DIR / f"ne_scf_ladder_residuals{SUFFIX}.png"
    plt.savefig(p, dpi=150); plt.close()
    print(f"  saved: {p.name}")

    # --- 3. linear correlation, measured vs predicted BSSE
    fig, axes = plt.subplots(n, 1, figsize=(5.0, 4.6 * n), squeeze=False)
    axes = axes[:, 0]
    for ax, res in zip(axes, results):
        meas = np.abs(bsse)
        prd = np.abs(2.0 * res["pred"])
        ax.plot(prd, meas, "ko", ms=4)
        lim = [0, max(meas.max(), prd.max()) * 1.05]
        ax.plot(lim, lim, "r--", lw=1.4)
        slope, icpt = np.polyfit(prd, meas, 1)
        ax.set_xlim(lim); ax.set_ylim(lim)
        ax.set_xlabel(r"predicted $|{\rm BSSE}_{\rm SCF}|$ (kcal/mol)")
        ax.set_ylabel(r"measured $|{\rm BSSE}_{\rm SCF}|$ (kcal/mol)")
        ax.set_title(f"{res['rung']}   $R^2$={res['r2']:.5f}   "
                     f"y = {slope:.4f}x + {icpt:.4f}", fontsize=10, loc="left")
        ax.set_aspect("equal", adjustable="box")
    plt.tight_layout()
    p = OUT_DIR / f"ne_scf_ladder_correlation{SUFFIX}.png"
    plt.savefig(p, dpi=150); plt.close()
    print(f"  saved: {p.name}")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--R-min", dest="r_min", type=float, default=None)
    ap.add_argument("--R-max", dest="r_max", type=float, default=None)
    ap.add_argument("--rung", choices=list(LADDER) + ["all"], default="all")
    args = ap.parse_args()

    global SUFFIX, OUT_DIR
    SUFFIX = window_suffix(args.r_min, args.r_max)

    # Per-run subfolder.  The filename suffix encodes only the R-window, so
    # without this a --rung G1 run would overwrite the full F0-G2 comparison.
    OUT_DIR = OUT_BASE / f"ladder_{args.rung}"
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    R, dE, bsse, R_h, dE_h, bsse_h, E0, n_all = load_data(args.r_min,
                                                          args.r_max)
    print(f"  window        : {len(R)}/{n_all} points, "
          f"R in [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  dE range      : [{dE.min():.6f}, {dE.max():.6f}] kcal/mol (signed)")
    print(f"  output suffix : {SUFFIX or '(none)'}")
    print(f"  output dir    : {OUT_DIR.relative_to(HERE.parent)}")

    if len(R_h):
        print(f"  held out      : {len(R_h)} points, "
              f"R in [{R_h.min():.3f}, {R_h.max():.3f}] A  "
              f"(NEVER fitted -- extrapolation test)")
    rungs = list(LADDER) if args.rung == "all" else [args.rung]
    results = [fit_rung(nm, R, dE, R_h, dE_h) for nm in rungs]

    # --- step 3: reconstruct E_A(AB) and compare against the measured BSSE
    print()
    print("=" * 68)
    print("RECONSTRUCTION CHECK   fit -> +E_A(A) -> x2 -> vs 2b_bsse_SCF")
    print("=" * 68)
    for res in results:
        E_pred = E0 + res["pred"] / HARTREE_TO_KCAL          # back to Ha
        bsse_pred = 2.0 * (E_pred - E0) * HARTREE_TO_KCAL    # round trip
        max_dev = np.abs(bsse_pred - bsse).max()
        print(f"  {res['rung']}: max |pred - data| = {max_dev:.6f} kcal/mol "
              f"({100*max_dev/np.abs(bsse).max():.2f}% of peak)")

    # --- summary table
    print()
    print("=" * 68)
    print("SUMMARY")
    print("=" * 68)
    print(f"  {'rung':<5} {'k':>2} {'RMSE_in':>10} {'RMSE_held':>10} "
          f"{'ratio':>6} {'R^2':>9} {'runs':>5} {'acf':>7} {'cond':>9} "
          f"{'turn':>5}  unconstrained")
    for res in results:
        rh = res["rmse_held"]
        rh_s = f"{2*rh:10.6f}" if rh is not None else f"{'-':>10}"
        rt_s = f"{rh/res['rmse']:6.2f}" if rh is not None else f"{'-':>6}"
        print(f"  {res['rung']:<5} {res['k']:>2} {2*res['rmse']:>10.6f} "
              f"{rh_s} {rt_s} {res['r2']:>9.6f} {res['runs']:>5} "
              f"{res['acf']:>7.4f} {res['cond']:>9.2e} "
              f"{str(res['turning']):>5}  {res['unconstrained'] or '-'}")
    print("\n  ratio = RMSE_held / RMSE_in.  > 1 means the form is worse "
          "outside\n  the fitted window than inside it -- the tail is wrong.")
    print(f"\n  (RMSE quoted on the BSSE scale, i.e. 2x the dE-fit RMSE.)")
    print(f"  Data turning point present: "
          f"{has_turning_point(R, dE)} (handoff 05-28 4)")

    # --- CSVs, signed, %.15g
    rows = []
    for res in results:
        for nm, v, e in zip(res["pnames"], res["popt"], res["perr"]):
            rows.append(dict(rung=res["rung"], k=res["k"], param=nm,
                             value=v, sigma=e,
                             rel_sigma=e / abs(v) if v else np.inf,
                             rmse_bsse=2 * res["rmse"],
                             rmse_held_bsse=(2 * res["rmse_held"]
                                             if res["rmse_held"] else None),
                             r2=res["r2"],
                             cond=res["cond"], runs=res["runs"],
                             exp_runs=res["exp_runs"], acf=res["acf"],
                             turning=res["turning"]))
    p = OUT_DIR / f"ne_scf_ladder_params{SUFFIX}.csv"
    pd.DataFrame(rows).to_csv(p, index=False, float_format="%.15g")
    print(f"\n  saved: {p.name}")

    curves = {"R": R, "dE_kcal": dE, "bsse_scf_kcal": bsse}
    for res in results:
        curves[f"pred_{res['rung']}"] = 2.0 * res["pred"]
        curves[f"resid_{res['rung']}"] = 2.0 * res["resid"]
    p = OUT_DIR / f"ne_scf_ladder_curves{SUFFIX}.csv"
    pd.DataFrame(curves).to_csv(p, index=False, float_format="%.15g")
    print(f"  saved: {p.name}")

    plot_all(R, dE, bsse, results, R_h, bsse_h)


if __name__ == "__main__":
    main()
