#!/usr/bin/env python3
"""
check_1e2e.py — Quick 1e/2e basis-enlargement check for one R.

Compares monomer A in its own basis (A_A.out) vs monomer A in the union
basis (A_AB.out): same real monomer, differing only by B's ghost functions.

Usage:
    python3 check_1e2e.py                 # default R (1p500, the benchmark)
    python3 check_1e2e.py --R 2p985       # mid-range
    python3 check_1e2e.py --R 4p500       # last R

--R takes the bare 3-decimal label; the NNN-prefixed folder is resolved by glob.
"""

import argparse
from pathlib import Path

HART2KCAL = 627.5094740631

SCRIPT_DIR = Path(__file__).resolve().parent          # Ne/2_new/scripts/
R_CONFIG   = SCRIPT_DIR.parent / "R_config"

# ── CLI ───────────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser(
    description="1e/2e basis-enlargement check (A_A vs A_AB) for one R."
)
parser.add_argument("--R", dest="r_label", default="1p500", metavar="LABEL",
                    help="Bare 3-decimal R label, e.g. 1p500, 2p985, 4p500. "
                         "Default: 1p500 (benchmark).")
args = parser.parse_args()

# ── resolve the NNN_R_<label> folder from the bare label ──────────────────────
matches = sorted(R_CONFIG.glob(f"*_R_{args.r_label}"))
if len(matches) == 0:
    raise SystemExit(f"Error: no folder matching *_R_{args.r_label} under {R_CONFIG}")
if len(matches) > 1:
    raise SystemExit(f"Error: label {args.r_label} is ambiguous: {[m.name for m in matches]}")
R_FOLDER = matches[0].name

# ── locate the two .out files ─────────────────────────────────────────────────
LEAF = matches[0] / "CCSD_T" / "aug-cc-pvdz"
AA  = LEAF / "A_A.out"
AAB = LEAF / "A_AB.out"


def grab(label: str, path: Path) -> float:
    """Return the last numeric field of the last line containing `label`."""
    val = None
    for line in path.read_text(errors="replace").splitlines():
        if label in line:
            val = float(line.split()[-1])
    if val is None:
        raise SystemExit(f"Error: '{label}' not found in {path}")
    return val


for f in (AA, AAB):
    if not f.exists():
        raise SystemExit(f"Error: file not found: {f}")

e1a  = grab("One-electron energy =", AA)
e2a  = grab("Two-electron energy =", AA)
esa  = grab("Total SCF energy =",    AA)
e1ab = grab("One-electron energy =", AAB)
e2ab = grab("Two-electron energy =", AAB)
esab = grab("Total SCF energy =",    AAB)

d1 = e1ab - e1a
d2 = e2ab - e2a
ds = esab - esa

print(f"R folder: {R_FOLDER}")
print("── One-electron (Ha) ─────────────────────────────")
print(f"  E_1e(A)   = {e1a:.12f}")
print(f"  E_1e(AB)  = {e1ab:.12f}")
print(f"  dE_1e     = {d1:+.12f}  ({d1*HART2KCAL:+.6f} kcal/mol)")
print("── Two-electron (Ha) ─────────────────────────────")
print(f"  E_2e(A)   = {e2a:.12f}")
print(f"  E_2e(AB)  = {e2ab:.12f}")
print(f"  dE_2e     = {d2:+.12f}  ({d2*HART2KCAL:+.6f} kcal/mol)")
print("── SCF total (Ha) ────────────────────────────────")
print(f"  E_scf(A)  = {esa:.12f}")
print(f"  E_scf(AB) = {esab:.12f}")
print(f"  dE_scf    = {ds:+.12f}  ({ds*HART2KCAL:+.6f} kcal/mol)")
print(f"  check dE_1e+dE_2e = {d1+d2:+.12f}  (residual: {ds-(d1+d2):+.2e})")
print("── Metric ────────────────────────────────────────")
denom = abs(d1) + abs(d2)
frac1 = abs(d1) / denom if denom else float("nan")
print(f"  |dE_1e| / (|dE_1e| + |dE_2e|) = {frac1:.4f}")
print(f"  |dE_2e| / (|dE_1e| + |dE_2e|) = {1 - frac1:.4f}")
