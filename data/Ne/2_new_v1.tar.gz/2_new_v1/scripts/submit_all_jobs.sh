#!/bin/bash
# submit_all_jobs.sh
# Orchestrator for Ne/2_new CCSD(T)/aug-cc-pVDZ VMFC jobs on NOVA.
#
# Layout walked:
#   ~/BSSE/Ne/2_new/R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/*.nw
#
# Unlike the HF/H2O studies, Ne is spherical: there is NO orientation layer.
# Each R folder has exactly one CCSD_T/aug-cc-pvdz/ leaf with 4 .nw files.
#
# For each .nw file with no matching .out, calls:
#   sbatch --export=ALL submit_energy.sh <full_path_to.nw>
#
# Two sentinel jobs bookend each batch and send email notifications:
#   1. "submitted" sentinel fires as soon as it runs (~instantly after submission)
#   2. "done"      sentinel fires only after ALL jobs in the batch finish
#      (uses --dependency=afterany:<comma-separated job IDs>)
#
# Two modes (mutually exclusive, exactly one required):
#   --R <label>   submit the 4 jobs for a single R (e.g. the benchmark).
#                 <label> is the bare 3-decimal label, e.g. 1p500, 1p530.
#                 Resolved to the NNN-prefixed folder R_config/*_R_<label>.
#   --all         submit all 400 jobs across the 100 R folders, under ONE
#                 sentinel pair (one "submitted" email, one "done" email when
#                 the whole grid finishes).
#
# Usage:
#   ./submit_all_jobs.sh --R 1p500    # benchmark one R (4 jobs)
#   ./submit_all_jobs.sh --all        # full grid (400 jobs, one done-email)
#
# Skip-existing: any .nw with a matching .out is skipped, so a partial rerun
# after failures only submits the missing jobs.
#
# Logs: ~/BSSE/Ne/2_new/scripts/<batch_label>_logs/

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
EMAIL="frojas32@iastate.edu"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"                     # ~/BSSE/Ne/2_new
R_CONFIG_DIR="${BASE_DIR}/R_config"
SUBMIT_ENERGY="${SCRIPT_DIR}/submit_energy.sh"

# ── Parse CLI ─────────────────────────────────────────────────────────────────
R_LABEL=""
ALL=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --R)   R_LABEL="$2"; shift 2 ;;
        --all) ALL=1;        shift 1 ;;
        -h|--help)
            echo "Usage: $0 (--R <label> | --all)"
            echo "  --R <label>   submit 4 jobs for one R, e.g. 1p500, 1p530"
            echo "  --all         submit all 400 jobs across the 100 R folders"
            exit 0
            ;;
        *) echo "Error: unknown arg $1"; exit 1 ;;
    esac
done

# Exactly one of --R / --all is required.
if [[ -n "$R_LABEL" && "$ALL" -eq 1 ]]; then
    echo "Error: --R and --all are mutually exclusive."
    exit 1
fi
if [[ -z "$R_LABEL" && "$ALL" -eq 0 ]]; then
    echo "Error: one of --R <label> or --all is required."
    echo "Usage: $0 (--R <label> | --all)"
    exit 1
fi

if [[ ! -d "$R_CONFIG_DIR" ]]; then
    echo "Error: R_config folder not found: $R_CONFIG_DIR"
    exit 1
fi

# ── Determine which R folders to walk ─────────────────────────────────────────
if [[ "$ALL" -eq 1 ]]; then
    mapfile -t R_DIRS < <(find "$R_CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d | sort)
    if [[ ${#R_DIRS[@]} -eq 0 ]]; then
        echo "Error: no R folders found under $R_CONFIG_DIR"
        exit 1
    fi
    BATCH_LABEL="all_grid"
else
    # Resolve the bare label to its NNN-prefixed folder via glob.
    mapfile -t MATCHES < <(find "$R_CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d \
                           -name "*_R_${R_LABEL}" | sort)
    if [[ ${#MATCHES[@]} -eq 0 ]]; then
        echo "Error: no R folder matching *_R_${R_LABEL} under $R_CONFIG_DIR"
        exit 1
    fi
    if [[ ${#MATCHES[@]} -gt 1 ]]; then
        echo "Error: label ${R_LABEL} is ambiguous, matched ${#MATCHES[@]} folders:"
        printf '   %s\n' "${MATCHES[@]}"
        exit 1
    fi
    R_DIRS=("${MATCHES[0]}")
    BATCH_LABEL="R_${R_LABEL}"
fi

# ── Prepare log folder ────────────────────────────────────────────────────────
LOG_DIR="${SCRIPT_DIR}/${BATCH_LABEL}_logs"
mkdir -p "$LOG_DIR"

echo "═══════════════════════════════════════════════════════════════════"
echo "  Ne/2_new batch submission"
echo "  Mode:       $([[ "$ALL" -eq 1 ]] && echo '--all' || echo "--R ${R_LABEL}")"
echo "  R folders:  ${#R_DIRS[@]}"
echo "  Log dir:    ${LOG_DIR}"
echo "═══════════════════════════════════════════════════════════════════"

# ── Submit sentinel #1: "submitted" ──────────────────────────────────────────
SENTINEL_START=$(sbatch --parsable \
    --job-name="job ${BATCH_LABEL} submitted" \
    --output="${LOG_DIR}/${BATCH_LABEL}_submitted.log" \
    --time=00:01:00 --mem=100M --ntasks=1 \
    --mail-type=END --mail-user="${EMAIL}" \
    --wrap="echo '${BATCH_LABEL} batch submitted at' \$(date)")

echo "Submitted 'batch-submitted' sentinel (jobid=${SENTINEL_START})"

# ── Walk R folders and submit jobs ────────────────────────────────────────────
JOB_IDS=()
N_SUBMITTED=0
N_SKIPPED=0
N_TOTAL=0

for RDIR in "${R_DIRS[@]}"; do
    NW_DIR="${RDIR}/CCSD_T/aug-cc-pvdz"
    if [[ ! -d "$NW_DIR" ]]; then
        echo "Warning: expected input dir missing, skipping: $NW_DIR"
        continue
    fi

    R_FOLDER=$(basename "$RDIR")          # e.g. 001_R_1p500

    for NW_FILE in "$NW_DIR"/*.nw; do
        [[ -e "$NW_FILE" ]] || continue
        N_TOTAL=$((N_TOTAL + 1))

        OUT_FILE="${NW_FILE%.nw}.out"
        if [[ -f "$OUT_FILE" ]]; then
            N_SKIPPED=$((N_SKIPPED + 1))
            continue
        fi

        NW_BASE=$(basename "$NW_FILE")
        JOB_NAME="${R_FOLDER}_${NW_BASE%.nw}"   # e.g. 001_R_1p500_AB_AB

        JID=$(sbatch --parsable --export=ALL \
            --job-name="${JOB_NAME}" \
            --output="${LOG_DIR}/${JOB_NAME}.log" \
            "${SUBMIT_ENERGY}" "${NW_FILE}")

        JOB_IDS+=("$JID")
        N_SUBMITTED=$((N_SUBMITTED + 1))
    done
done

echo "───────────────────────────────────────────────────────────────────"
echo "  Total .nw files scanned : ${N_TOTAL}"
echo "  Skipped (out exists)    : ${N_SKIPPED}"
echo "  Submitted this run      : ${N_SUBMITTED}"
echo "───────────────────────────────────────────────────────────────────"

# ── Submit sentinel #2: "done" (depends on all jobs) ─────────────────────────
if [[ ${N_SUBMITTED} -gt 0 ]]; then
    DEP_LIST=$(IFS=,; echo "${JOB_IDS[*]}")
    SENTINEL_END=$(sbatch --parsable \
        --job-name="job ${BATCH_LABEL} finished" \
        --output="${LOG_DIR}/${BATCH_LABEL}_done.log" \
        --time=00:01:00 --mem=100M --ntasks=1 \
        --dependency=afterany:"${DEP_LIST}" \
        --mail-type=END --mail-user="${EMAIL}" \
        --wrap="echo '${BATCH_LABEL} batch done at' \$(date)")
    echo "Submitted 'batch-done' sentinel (jobid=${SENTINEL_END}), depends on ${N_SUBMITTED} jobs"
else
    echo "No jobs submitted (all outputs already exist). No 'done' sentinel needed."
fi

echo "═══════════════════════════════════════════════════════════════════"
echo "  Emails will be sent to: ${EMAIL}"
echo "  Monitor with: squeue -u \$USER"
echo "  Batch-complete signal: ${LOG_DIR}/${BATCH_LABEL}_done.log"
echo "═══════════════════════════════════════════════════════════════════"
