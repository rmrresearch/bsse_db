#!/usr/bin/env python3
"""
check_convergence.py — Verify Ne/2_new radial-scan NWChem output files
                      converged AND carry every field the downstream parsers
                      need, then report wallclock timing.

Location:  bsse_db/data/Ne/2_new/scripts/
Input:     bsse_db/data/Ne/2_new/R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/*.out

Per .out file, five label lines must be present and parseable. These are
exactly the quantities the two downstream parsers consume — nothing more:

  BSSE fit-study parser (this project):
    1. "Total SCF energy ="        → SCF component
    2. "Total MP2 energy:"         → MP2_comp = MP2 - SCF
    3. "Total CCSD(T) energy:"     → CCSD_T_comp = CCSD(T) - MP2   (also the
                                     completion signal: it prints only after
                                     SCF -> MP2 -> CCSD -> (T) all finish)
  Parent-chat 1e/2e study (handoff Sec. 5 dependency):
    4. "One-electron energy ="     → E_1e
    5. "Two-electron energy ="     → E_2e

Nuclear repulsion is intentionally NOT checked: the 1e/2e metric
|dE_1e| / (|dE_1e| + |dE_2e|) does not use it, and for A_A it is identically
zero. We gate only on fields a parser actually reads.

Status buckets (per file):
    ok         : all five fields present
    incomplete : CCSD(T) present (run finished) but >=1 of the other four
                 fields missing — the exact missing field(s) are named so the
                 next session can trust: if this script is all-green, the
                 parser has everything.
    failed     : CCSD(T) energy absent (crash/kill) or an NWChem task-failure
                 marker present.
    missing    : no .out file on disk.

A file is marked with a leading ✅ only when all five fields are present;
otherwise ✗, with the specific missing field(s) shown.

Usage:
    python check_convergence.py                    # all 100 R (400 files)
    python check_convergence.py --R 1p500          # one R (4 files)
    python check_convergence.py --summary          # counts + timing only
    python check_convergence.py --failed           # only non-ok files

Expected file counts:
    per R  :   4  (A_A, AB_AB, A_AB, B_AB)
    total  : 400  (100 R × 4)
"""

import re
import sys
import argparse
from pathlib import Path

import numpy as np

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR   = SCRIPT_DIR.parent / 'R_config'

# ── Grid (single source of truth, matches generate_nw_inputs.py) ──────────────
R_VALUES = np.linspace(1.5, 4.5, 100)


def r_to_label(r: float) -> str:
    """1.5303030303 -> '1p530' (3-decimal folder label)."""
    return f'{r:.3f}'.replace('.', 'p')


R_LABELS = [r_to_label(r) for r in R_VALUES]

# Expected file keys per R
NW_KEYS = ['A_A', 'AB_AB', 'A_AB', 'B_AB']

# The five required label lines (verbatim NWChem 7.2.0 strings). Order matters
# only for display. "Total CCSD(T) energy:" is matched exactly so it is not
# confused with "Total CCSD energy:" or "Total CCSD+T(CCSD) energy:".
FIELD_CCSDT = 'Total CCSD(T) energy:'
FIELD_SCF   = 'Total SCF energy ='
FIELD_MP2   = 'Total MP2 energy:'
FIELD_1E    = 'One-electron energy ='
FIELD_2E    = 'Two-electron energy ='

# The four non-CCSD(T) fields, checked once CCSD(T) confirms the run finished.
OTHER_FIELDS = [
    ('SCF', FIELD_SCF),
    ('MP2', FIELD_MP2),
    ('1e',  FIELD_1E),
    ('2e',  FIELD_2E),
]

# NWChem timing regex: "Total times  cpu:  0.5s  wall:  0.6s"
WALL_RE = re.compile(r'Total times\s+cpu:\s+([\d.]+)s\s+wall:\s+([\d.]+)s')


def _has(content: str, label: str) -> bool:
    """Presence test for a verbatim label line."""
    return label in content


# ── Per-file check ────────────────────────────────────────────────────────────
def check_output_file(filepath: Path):
    """
    Returns (status, missing_fields, wall_time, message):
        status         : 'ok' | 'incomplete' | 'failed' | 'missing'
        missing_fields : list[str] short names of absent fields (for incomplete)
        wall_time      : float seconds or None
        message        : description for failed
    """
    if not filepath.exists():
        return 'missing', [], None, 'output file not found'

    content = filepath.read_text(errors='replace')

    # Wall time (independent of status; report whatever we can extract)
    m = WALL_RE.search(content)
    wall = float(m.group(2)) if m else None

    # Hard failure: explicit NWChem task-failure marker.
    if 'task  ccsd(t)  energy  failed' in content.lower():
        return 'failed', [], wall, 'NWChem task failed'

    # Completion signal: the CCSD(T) total energy line.
    if not _has(content, FIELD_CCSDT):
        if 'ccsd(t)' in content.lower():
            return 'failed', [], wall, 'job likely killed (no CCSD(T) energy)'
        return 'failed', [], wall, 'no CCSD(T) energy found'

    # CCSD(T) present -> run finished. Now confirm the other four fields the
    # parsers read are individually present (not merely inferred).
    missing = [short for short, label in OTHER_FIELDS if not _has(content, label)]
    if missing:
        return 'incomplete', missing, wall, ''

    return 'ok', [], wall, ''


# ── Resolve which R folders to walk ───────────────────────────────────────────
def resolve_r_dir(r_label: str):
    """Glob the bare label to its NNN-prefixed folder. Returns Path or None."""
    matches = sorted(BASE_DIR.glob(f'*_R_{r_label}'))
    if len(matches) == 1:
        return matches[0]
    return None


def iter_expected_files(r_label: str):
    """Yield (r_label, nw_key, out_path) for one R's four files."""
    r_dir = resolve_r_dir(r_label)
    if r_dir is None:
        # Folder missing entirely: yield the 4 expected-but-absent paths so
        # they register as 'missing'.
        for key in NW_KEYS:
            yield r_label, key, BASE_DIR / f'???_R_{r_label}' / 'CCSD_T' / 'aug-cc-pvdz' / f'{key}.out'
        return
    nw_dir = r_dir / 'CCSD_T' / 'aug-cc-pvdz'
    for key in NW_KEYS:
        yield r_label, key, nw_dir / f'{key}.out'


# ── Check one R ───────────────────────────────────────────────────────────────
def check_R(r_label: str, show_ok: bool, show_problem: bool):
    results = {'ok': [], 'incomplete': [], 'failed': [], 'missing': []}
    wall_times = []
    total = 0

    for _, nw_key, out_path in iter_expected_files(r_label):
        total += 1
        status, missing, wall, message = check_output_file(out_path)
        results[status].append((nw_key, missing, wall, message))
        if wall is not None:
            wall_times.append(wall)

        label = f'R_{r_label}/{nw_key}'
        if status == 'ok':
            if show_ok:
                wall_str = f'{wall:6.1f}s' if wall is not None else '   —   '
                print(f'  ✅  {label:<22s}  CCSD(T)✓ SCF✓ MP2✓ 1e✓ 2e✓   wall={wall_str}')
        elif status == 'incomplete':
            if show_problem:
                miss = ' '.join(f'{s}✗' for s in missing)
                print(f'  ✗   {label:<22s}  converged but MISSING: {miss}')
        elif status == 'failed':
            if show_problem:
                print(f'  ❌  {label:<22s}  FAILED — {message}')
        elif status == 'missing':
            if show_problem:
                print(f'  ⏳  {label:<22s}  missing (.out not found)')

    return results, total, wall_times


# ── Per-R summary ─────────────────────────────────────────────────────────────
def print_R_summary(r_label, results, total, wall_times, expected, summary_only):
    n_ok   = len(results['ok'])
    n_inc  = len(results['incomplete'])
    n_fail = len(results['failed'])
    n_miss = len(results['missing'])
    clean  = (n_ok == expected and n_inc == 0 and n_fail == 0 and n_miss == 0)
    flag   = '✅' if clean else '✗'

    print(f"{'─' * 68}")
    print(f"  R_{r_label}   {flag}")
    print(f"  ✅  ok (all 5 fields) : {n_ok:>4}   (expected {expected})")
    print(f"  ✗   incomplete        : {n_inc:>4}")
    print(f"  ❌  failed            : {n_fail:>4}")
    print(f"  ⏳  missing           : {n_miss:>4}")

    if wall_times:
        print(f"  ⏱  walls (n={len(wall_times)}): "
              f"mean={sum(wall_times)/len(wall_times):.1f}s  "
              f"min={min(wall_times):.1f}s  max={max(wall_times):.1f}s")

    if results['incomplete']:
        print(f"\n  Incomplete (converged, missing parser fields):")
        for nw_key, missing, _, _ in results['incomplete']:
            miss = ', '.join(missing)
            print(f"    R_{r_label}/{nw_key}.out  — missing: {miss}")

    if results['failed']:
        print(f"\n  Failed files (need resubmission):")
        for nw_key, _, _, message in results['failed']:
            print(f"    R_{r_label}/{nw_key}.nw  — {message}")

    if results['missing']:
        print(f"\n  Missing .out (still running or not submitted):")
        for nw_key, _, _, _ in results['missing']:
            print(f"    R_{r_label}/{nw_key}.nw")


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description='Check convergence + required parser fields + timing for '
                    'Ne/2_new NWChem outputs.'
    )
    parser.add_argument('--R', type=str, default=None, choices=R_LABELS,
                        metavar='LABEL',
                        help='R folder to check (e.g. 1p500). Omit for all 100.')
    parser.add_argument('--summary', action='store_true',
                        help='Show only summary counts + timing.')
    parser.add_argument('--failed', action='store_true',
                        help='Show only non-ok files (incomplete/failed/missing).')
    args = parser.parse_args()

    show_ok      = not args.summary and not args.failed
    show_problem = not args.summary

    labels = [args.R] if args.R is not None else R_LABELS
    expected = len(NW_KEYS)  # 4 per R

    g = {'ok': 0, 'incomplete': 0, 'failed': 0, 'missing': 0}
    grand_total = 0
    grand_walls = []
    any_problem = False

    for r_label in labels:
        if not args.summary:
            print(f"\nChecking R_{r_label}")
            print(f"{'─' * 68}")

        results, total, wall_times = check_R(r_label, show_ok, show_problem)
        print_R_summary(r_label, results, total, wall_times, expected, args.summary)

        g['ok']         += len(results['ok'])
        g['incomplete'] += len(results['incomplete'])
        g['failed']     += len(results['failed'])
        g['missing']    += len(results['missing'])
        grand_total     += total
        grand_walls.extend(wall_times)

        if results['incomplete'] or results['failed'] or results['missing']:
            any_problem = True

    if args.R is None:
        grand_expected = len(R_LABELS) * len(NW_KEYS)  # 400
        flag = '✅' if not any_problem else '✗'
        print(f"\n{'═' * 68}")
        print(f"  GRAND TOTAL   {flag}")
        print(f"  ✅  ok (all 5 fields) : {g['ok']:>5}   (expected {grand_expected})")
        print(f"  ✗   incomplete        : {g['incomplete']:>5}")
        print(f"  ❌  failed            : {g['failed']:>5}")
        print(f"  ⏳  missing           : {g['missing']:>5}")
        print(f"      total             : {grand_total:>5}")
        if grand_walls:
            w_sum = sum(grand_walls)
            print(f"  ⏱  walls (n={len(grand_walls)}): "
                  f"sum={w_sum:.1f}s ({w_sum/60:.1f} min)  "
                  f"mean={w_sum/len(grand_walls):.1f}s  "
                  f"min={min(grand_walls):.1f}s  max={max(grand_walls):.1f}s")
        print(f"{'═' * 68}")

    if not any_problem:
        print("\nAll files converged with all five parser fields present ✅")
        sys.exit(0)
    else:
        print("\nSome files need attention (see ✗ / ❌ / ⏳ above)")
        sys.exit(1)


if __name__ == '__main__':
    main()
