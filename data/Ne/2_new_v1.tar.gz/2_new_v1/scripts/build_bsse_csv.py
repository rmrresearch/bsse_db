#!/usr/bin/env python3
"""
build_bsse_csv.py — Ne/2_new (dimer radial-scan study)
======================================================

Reads the study-wide raw_data pickle, computes the 2-body BSSE (PI
convention), and writes ONE consolidated CSV: 100 rows, one per grid R.

Location:  bsse_db/data/Ne/2_new/scripts/
Input:     bsse_db/data/Ne/2_new/R_config_pickle_data/raw_data.pickle
Output:    bsse_db/data/Ne/2_new/data_frames_plots/ne_dimer_bsse_vs_R.csv

Difference from HF/2_new and H2O/2_new
--------------------------------------
Those studies write one CSV per R, each holding 100 orientations, with an
`orient_id` column. Ne has no orientation layer: R is the only axis and the
natural key, so the study collapses to a single CSV with no `orient_id`
column and no per-R sharding.

Difference from the old Ne/2 build_bsse_vs_R.py
-----------------------------------------------
The old script read three per-method CSVs that already carried no_vmfc /
vmfc / bsse columns, recovered R as sqrt(x^2+y^2+z^2) from a translational
grid, and then COLLAPSED 268 grid configurations onto 50 distinct R by
groupby-mean (with an n_grid column recording the multiplicity).

None of that applies here. The Ne/2_new grid samples each R exactly once, so
there is no collapse step, no n_grid column, and no R-rounding: R comes from
the pickle at full precision (recovered from the linspace grid by index, see
build_raw_data.py).

BSSE definition (PI Task List 5 convention)
--------------------------------------------
Per component c in {SCF, MP2c, CCSD_Tc}:

    2b_no_vmfc(c) = E_AB(AB,c) - E_A(A,c)  - E_B(B,c)          # signed, Ha
    2b_vmfc(c)    = E_AB(AB,c) - E_A(AB,c) - E_B(AB,c)         # signed, Ha
    2b_bsse(c)    = ( 2b_no_vmfc(c) - 2b_vmfc(c) ) * 627.5094740631

For the homonuclear Ne dimer, monomer B is not computed in its own basis;
per the convention used throughout this project:

    E_B(B,c) = E_A(A,c)

i.e. the isolated-monomer energy for B equals that of A (same species, same
basis on a single monomer — equivalent by symmetry of the file setup).

    total_bsse = 2b_bsse_SCF + 2b_bsse_MP2c + 2b_bsse_CCSD_Tc

Locked 23-column schema
-----------------------
    R                                                   (Angstrom)
    A_A_{SCF,MP2c,CCSD_Tc}                              (Ha, signed)
    AB_AB_{SCF,MP2c,CCSD_Tc}                            (Ha, signed)
    A_AB_{SCF,MP2c,CCSD_Tc}                             (Ha, signed)
    B_AB_{SCF,MP2c,CCSD_Tc}                             (Ha, signed)
    2b_no_vmfc_{SCF,MP2c,CCSD_Tc}                       (Ha, signed)
    2b_vmfc_{SCF,MP2c,CCSD_Tc}                          (Ha, signed)
    2b_bsse_{SCF,MP2c,CCSD_Tc}                          (kcal/mol, signed)
    total_bsse                                          (kcal/mol, signed)

Raw and intermediate columns stay in Hartree, signed. BSSE columns are in
kcal/mol, signed. Absolute values are applied only at plot/fit time, never
stored.

Numeric precision
-----------------
Written with float_format='%.15g', NOT the '%.10g' used by the HF and H2O
CSV builders. Rationale: the raw component columns are ~1e2 Ha in magnitude
while the BSSE derived from them is ~1e-3 Ha. At 10 significant figures the
stored raw energies are truncated near 1e-7 Ha, which is LARGER than the
quantity of interest — the BSSE could not be recomputed from the archived
CSV. 15 significant figures preserves every digit NWChem prints and keeps R
exact to ~1e-16 A. The BSSE columns themselves are unaffected either way,
since they are computed in full double precision before writing.

Benchmark
---------
At R = 1.5 A the first row must reproduce:
    2b_no_vmfc_SCF =  0.143654259666 Ha
    2b_vmfc_SCF    =  0.144879891105 Ha
    2b_bsse_SCF    = -0.769095       kcal/mol
This is checked automatically and reported at the end of the run.

Usage
-----
    cd bsse_db/data/Ne/2_new/scripts
    python3 build_bsse_csv.py
"""

import pickle
import argparse
from pathlib import Path

import pandas as pd


# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR  = Path(__file__).resolve().parent
PICKLE_PATH = SCRIPT_DIR.parent / 'R_config_pickle_data' / 'raw_data.pickle'
CSV_DIR     = SCRIPT_DIR.parent / 'data_frames_plots'
CSV_NAME    = 'ne_dimer_bsse_vs_R.csv'

# ── Keys (must match build_raw_data.py) ───────────────────────────────────────
CONFIG_KEY = 'R_config'
METHOD_KEY = 'CCSD_T'
BASIS_KEY  = 'aug-cc-pvdz'
FILE_KEYS  = ['A_A', 'AB_AB', 'A_AB', 'B_AB']
COMP_KEYS  = ['SCF', 'MP2_corcomp', 'CCSD_T_corcomp']

# Short tags used in CSV column names (HF/H2O-consistent).
COMP_SHORT = {'SCF': 'SCF', 'MP2_corcomp': 'MP2c', 'CCSD_T_corcomp': 'CCSD_Tc'}

# CODATA 2018
HA_TO_KCAL = 627.5094740631

# Benchmark expectations at R = 1.5 A (handoff Sec. 6).
BENCH_R        = 1.5
BENCH_NO_VMFC  = 0.143654259666
BENCH_VMFC     = 0.144879891105
BENCH_BSSE_SCF = -0.769095
BENCH_TOL      = 1e-6


# ── Column construction ───────────────────────────────────────────────────────
def build_column_order():
    """
    Return the locked 23-column order.

    Grouped by file (all components of A_A, then AB_AB, ...), then the
    intermediate BSSE quantities per component, then the 4 kcal/mol columns.
    Mirrors HF/2_new's build_column_order minus the `orient_id` column.
    """
    cols = ['R']

    # Raw energies, grouped by file, cycling components   (12 cols, Ha)
    for fk in FILE_KEYS:
        for c in COMP_KEYS:
            cols.append(f'{fk}_{COMP_SHORT[c]}')

    # 2b_no_vmfc per component                            (3 cols, Ha)
    for c in COMP_KEYS:
        cols.append(f'2b_no_vmfc_{COMP_SHORT[c]}')

    # 2b_vmfc per component                               (3 cols, Ha)
    for c in COMP_KEYS:
        cols.append(f'2b_vmfc_{COMP_SHORT[c]}')

    # 2b_bsse per component                               (3 cols, kcal/mol)
    for c in COMP_KEYS:
        cols.append(f'2b_bsse_{COMP_SHORT[c]}')

    # Total BSSE                                          (1 col,  kcal/mol)
    cols.append('total_bsse')

    return cols


# ── Row assembly for one R ────────────────────────────────────────────────────
def compute_row(entry, params):
    """
    Compute one CSV row for a single R.

    Parameters
    ----------
    entry : dict
        raw_data['R_config']['R_<label>']['CCSD_T']['aug-cc-pvdz']
        i.e. dict keyed by file_key, each value a dict of the 3 components (Ha).
    params : dict
        parameters['R_config']['R_<label>'] -> {'R': float, 'grid_index': int}
    """
    row = {'R': params['R']}

    # Raw energies (Ha)
    for fk in FILE_KEYS:
        for c in COMP_KEYS:
            row[f'{fk}_{COMP_SHORT[c]}'] = entry[fk][c]

    # Per-component BSSE math (Ha for intermediates, kcal/mol for final BSSE)
    total_bsse_kcal = 0.0
    for c in COMP_KEYS:
        E_A_A   = entry['A_A'][c]
        E_AB_AB = entry['AB_AB'][c]
        E_A_AB  = entry['A_AB'][c]
        E_B_AB  = entry['B_AB'][c]

        # E_B(B,c) is not computed for this dimer; per project convention,
        # use E_A(A,c) as the isolated-B reference (monomers are equivalent
        # in their own basis).
        E_B_B = E_A_A

        no_vmfc = E_AB_AB - E_A_A  - E_B_B
        vmfc    = E_AB_AB - E_A_AB - E_B_AB
        bsse_ha = no_vmfc - vmfc

        row[f'2b_no_vmfc_{COMP_SHORT[c]}'] = no_vmfc                  # Ha
        row[f'2b_vmfc_{COMP_SHORT[c]}']    = vmfc                     # Ha
        row[f'2b_bsse_{COMP_SHORT[c]}']    = bsse_ha * HA_TO_KCAL     # kcal/mol
        total_bsse_kcal += bsse_ha * HA_TO_KCAL

    row['total_bsse'] = total_bsse_kcal                               # kcal/mol
    return row


# ── Benchmark check ───────────────────────────────────────────────────────────
def check_benchmark(df, verbose=True):
    """
    Verify the R = 1.5 A row against the values locked in the handoff.

    Returns True if the row is present and all three quantities match to
    BENCH_TOL, False otherwise. Reports rather than raises: a benchmark
    mismatch is something the user must see and judge, not something this
    script should decide to abort on.
    """
    match = df[(df['R'] - BENCH_R).abs() < 1e-12]
    if match.empty:
        if verbose:
            print(f"  ⚠️   benchmark row R = {BENCH_R} A not present in CSV")
        return False

    r = match.iloc[0]
    checks = [
        ('2b_no_vmfc_SCF', r['2b_no_vmfc_SCF'], BENCH_NO_VMFC, 'Ha'),
        ('2b_vmfc_SCF',    r['2b_vmfc_SCF'],    BENCH_VMFC,    'Ha'),
        ('2b_bsse_SCF',    r['2b_bsse_SCF'],    BENCH_BSSE_SCF, 'kcal/mol'),
    ]

    all_ok = True
    if verbose:
        print(f"\n  Benchmark check  (R = {BENCH_R} A)")
        print(f"  {'─' * 62}")
    for name, got, want, unit in checks:
        ok = abs(got - want) < BENCH_TOL
        all_ok &= ok
        if verbose:
            flag = '✅' if ok else '❌'
            print(f"    {flag}  {name:<16s} = {got:>16.12f}  "
                  f"(expected {want:.12g} {unit})")
    if verbose:
        print(f"  {'─' * 62}")

    return all_ok


# ── Pipeline ──────────────────────────────────────────────────────────────────
def build_csv(verbose=True):
    """Read the pickle, build the 100-row CSV, write it, return the DataFrame."""
    if not PICKLE_PATH.is_file():
        raise FileNotFoundError(
            f"No pickle at {PICKLE_PATH}. Run build_raw_data.py first."
        )

    with open(PICKLE_PATH, 'rb') as fh:
        payload = pickle.load(fh)

    raw  = payload['raw_data'].get(CONFIG_KEY, {})
    pars = payload['parameters'].get(CONFIG_KEY, {})
    bad  = payload['raw_data_noconv'].get(CONFIG_KEY, {})

    if not raw:
        raise ValueError(f"Pickle at {PICKLE_PATH} contains no parsed R.")

    if bad and verbose:
        print(f"  ⚠️   {len(bad)} R excluded by the parser, absent from the CSV:")
        for r_key in sorted(bad):
            print(f"         {r_key}")

    rows = []
    for r_key, node in raw.items():
        entry = node[METHOD_KEY][BASIS_KEY]
        rows.append(compute_row(entry, pars[r_key]))

    df = pd.DataFrame(rows, columns=build_column_order())
    df = df.sort_values('R').reset_index(drop=True)

    CSV_DIR.mkdir(parents=True, exist_ok=True)
    out_path = CSV_DIR / CSV_NAME
    df.to_csv(out_path, index=False, float_format='%.15g')

    if verbose:
        print(f"\n  ✅  {len(df)} rows x {len(df.columns)} columns "
              f"→ {out_path.name}")
        print(f"      R range : [{df['R'].min():.6f}, {df['R'].max():.6f}] A")
        print(f"      total_bsse range : "
              f"[{df['total_bsse'].min():.6f}, "
              f"{df['total_bsse'].max():.6f}] kcal/mol")

    return df, out_path


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    argparse.ArgumentParser(
        description='Build the consolidated Ne/2_new BSSE CSV from the '
                    'study-wide raw_data pickle.'
    ).parse_args()

    print(f"\n{'═' * 68}")
    print("  Ne/2_new BSSE CSV build")
    print(f"{'═' * 68}")
    print(f"  Pickle  : {PICKLE_PATH}")
    print(f"  CSV dir : {CSV_DIR}")
    print(f"{'═' * 68}\n")

    df, out_path = build_csv(verbose=True)
    ok = check_benchmark(df, verbose=True)

    print(f"\n{'═' * 68}")
    print(f"  💾  {out_path}")
    if not ok:
        print("  ⚠️   BENCHMARK MISMATCH — inspect before using this CSV.")
    print(f"{'═' * 68}\n")
