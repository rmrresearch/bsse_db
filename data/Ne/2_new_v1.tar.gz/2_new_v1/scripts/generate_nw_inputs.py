"""
generate_nw_inputs.py — Generate NWChem input files for the Ne dimer radial
scan study (Ne/2_new).

This is the denser-grid rebuild of the Ne-Ne dimer |BSSE| vs R study. Unlike
the HF/2_new and H2O/2_new studies, Ne is a single spherically symmetric atom
per monomer, so there is NO orientation sampling: BSSE depends only on the
scalar inter-atomic distance R. The grid is a pure radial scan.

For each of the 100 R values on a uniform linspace(1.5, 4.5, 100) grid, this
script writes 4 NWChem input files (A_A.nw, AB_AB.nw, A_AB.nw, B_AB.nw) into
    R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/

Geometry construction (per R):
    Two Ne atoms on the z-axis: Ne at (0, 0, 0) and the partner at (0, 0, R).
    Direction is irrelevant for spherical Ne, so an on-axis z-displacement is
    the simplest choice. R is the full Ne-Ne distance (no sphere-surface /
    sphere-gap convention as in the HF/H2O studies, which have multi-atom
    monomers).

Precision convention (locked with PI-facing rationale):
    - .nw geometry coordinate : FULL precision R (e.g. 1.530303030303...),
      the true grid point.
    - Folder label            : 3 decimals, '.' -> 'p' (e.g. '1p530'). This is
      only a human-readable tag identifying which R is being studied; verified
      collision-free across the 100-point grid.
    - Zero-padded index NNN   : 001..100, so the folder listing itself shows
      there are 100 R-configurations.

Input form (locked): identical to the proven minimal Ne/2 dimer inputs — no
    `memory` line, no `geometry noautoz`, no `symmetry c1`. Those directives
    were introduced only for larger clusters (memory at the tetramer,
    `symmetry c1` at the Ne6 hexamer to avoid the autosym/ScaLAPACK/MPI
    deadlock) and are not warranted for the 2-atom dimer.

Clean-run guarantee (handoff Sec. 5): correctness of the SCF (so the
    One-electron / Two-electron breakdown prints in every .out for the later
    parent-chat 1e/2e study) comes from running each job in its own clean leaf
    directory (submit_energy.sh does `cd "$NW_DIR"`), NOT from any input
    directive. No `.nw` here contains a `restart` directive. Raw .out files
    must be PRESERVED downstream (do not run the HF/H2O NOVA cleanup step).

Skip logic (per R):
    If all 4 .nw files exist for an R, that R is skipped. Otherwise all 4 are
    (re)written.

Usage:
    python3 generate_nw_inputs.py               # generate all 100 R folders
    python3 generate_nw_inputs.py --R 1p530     # only that R folder

CLI:
    --R <label>   Restrict generation to a single R folder, where <label> is
                  the 3-decimal 'p' label of one of the 100 grid points
                  (e.g. 1p500, 1p530, ..., 4p500).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np


# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

# The R grid (locked): 100 uniform points, inclusive endpoints, step ~0.0303 A.
# Range [1.5, 4.5] A spans the repulsive wall, the equilibrium (R_e ~ 2.9-3.1
# A per Wuest & Merkt 2003), and a real dispersion tail out to 4.5 A.
R_MIN = 1.5
R_MAX = 4.5
N_POINTS = 100
R_VALUES = np.linspace(R_MIN, R_MAX, N_POINTS)

# Basis / method folder path component (matches all prior Ne work).
METHOD_DIR = "CCSD_T"
BASIS_DIR = "aug-cc-pvdz"

# The four NWChem input keys per R (homodimer convention). For homonuclear
# Ne-Ne, A_A == B_B and A_AB == B_AB by symmetry, but all four are kept for
# pipeline uniformity and as a symmetry sanity check.
FILE_KEYS = ("A_A", "AB_AB", "A_AB", "B_AB")


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def r_to_label(r: float) -> str:
    """Convert a numeric R value to its 3-decimal folder label.

    1.5303030303 -> '1p530'. This is a human-readable tag only; the actual
    geometry written to the .nw file uses full precision (see build_*).
    """
    return f"{r:.3f}".replace(".", "p")


def all_labels() -> list[str]:
    """The 3-decimal labels for all 100 grid points, in grid order."""
    return [r_to_label(r) for r in R_VALUES]


def folder_name(index0: int, r: float) -> str:
    """Return the R-folder name '<NNN>_R_<label>' for a 0-based grid index.

    index0 = 0 -> '001_R_1p500', index0 = 99 -> '100_R_4p500'.
    """
    return f"{index0 + 1:03d}_R_{r_to_label(r)}"


# -----------------------------------------------------------------------------
# NWChem template renderers
# -----------------------------------------------------------------------------
# Coordinates are written at full float precision (repr-grade) so the geometry
# is the exact grid point, independent of the 3-decimal folder label.

def _coord(r: float) -> str:
    """Full-precision string for the z-coordinate of the partner atom."""
    return repr(float(r))


def render_A_A() -> str:
    """A alone in the A basis (single Ne at the origin, no ghost)."""
    return (
        "geometry\n"
        "  Ne 0 0 0\n"
        "end\n"
        "basis spherical\n"
        "  Ne library aug-cc-pvdz\n"
        "end\n"
        "task ccsd(t) energy\n"
    )


def render_AB_AB(r: float) -> str:
    """Full dimer AB in the AB basis (two real Ne)."""
    return (
        "geometry\n"
        "  Ne 0 0 0\n"
        f"  Ne 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        "  Ne library aug-cc-pvdz\n"
        "end\n"
        "task ccsd(t) energy\n"
    )


def render_A_AB(r: float) -> str:
    """A real at origin, B as a ghost at (0,0,R), in the AB (union) basis."""
    return (
        "geometry\n"
        "  Ne 0 0 0\n"
        f"  bqNe 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        "  Ne library aug-cc-pvdz\n"
        "  bqNe library Ne aug-cc-pvdz\n"
        "end\n"
        "task ccsd(t) energy\n"
    )


def render_B_AB(r: float) -> str:
    """B real at (0,0,R), A as a ghost at the origin, in the AB (union) basis."""
    return (
        "geometry\n"
        "  bqNe 0 0 0\n"
        f"  Ne 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        "  bqNe library Ne aug-cc-pvdz\n"
        "  Ne library aug-cc-pvdz\n"
        "end\n"
        "task ccsd(t) energy\n"
    )


def render_for_key(key: str, r: float) -> str:
    """Dispatch to the correct renderer for a file key."""
    if key == "A_A":
        return render_A_A()
    if key == "AB_AB":
        return render_AB_AB(r)
    if key == "A_AB":
        return render_A_AB(r)
    if key == "B_AB":
        return render_B_AB(r)
    raise ValueError(f"Unknown file key: {key!r}")


# -----------------------------------------------------------------------------
# Per-R generation and skip logic
# -----------------------------------------------------------------------------

def r_paths(root: Path, index0: int, r: float) -> dict[str, Path]:
    """Return {file_key -> .nw path} for one R value."""
    nw_dir = root / "R_config" / folder_name(index0, r) / METHOD_DIR / BASIS_DIR
    return {key: nw_dir / f"{key}.nw" for key in FILE_KEYS}


def r_complete(nw_paths: dict[str, Path]) -> bool:
    """True iff all 4 .nw files exist for this R."""
    return all(p.exists() for p in nw_paths.values())


def write_r(root: Path, index0: int, r: float) -> None:
    """Generate and write all 4 .nw files for one R value."""
    nw_paths = r_paths(root, index0, r)
    for p in nw_paths.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    for key, path in nw_paths.items():
        path.write_text(render_for_key(key, r))


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate NWChem input files for the Ne dimer radial scan study "
            "(Ne/2_new). Without --R, generates all 100 R folders, skipping "
            "any that are already complete."
        )
    )
    parser.add_argument(
        "--R", dest="r_label", default=None, metavar="LABEL",
        help=(
            "Restrict generation to a single R folder. LABEL is the 3-decimal "
            "'p' label of a grid point, e.g. 1p500, 1p530, ..., 4p500."
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # Path anchoring: this script lives in Ne/2_new/scripts/.
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent  # Ne/2_new/
    if not (root / "R_config").is_dir():
        print(f"ERROR: expected 'R_config/' inside {root}, not found.",
              file=sys.stderr)
        sys.exit(1)

    labels = all_labels()

    if args.r_label is None:
        targets = list(enumerate(R_VALUES))
    else:
        if args.r_label not in labels:
            print(f"ERROR: --R {args.r_label!r} is not a grid label.",
                  file=sys.stderr)
            print(f"Valid labels: {labels[0]}, {labels[1]}, ..., {labels[-1]}",
                  file=sys.stderr)
            sys.exit(1)
        idx = labels.index(args.r_label)
        targets = [(idx, R_VALUES[idx])]

    n_written = 0
    n_skipped = 0
    for index0, r in targets:
        nw_paths = r_paths(root, index0, r)
        if r_complete(nw_paths):
            n_skipped += 1
            continue
        write_r(root, index0, r)
        n_written += 1

    print(f"R folders written : {n_written}")
    print(f"R folders skipped : {n_skipped}  (already complete)")
    print(f"grid              : linspace({R_MIN}, {R_MAX}, {N_POINTS}), "
          f"step = {(R_MAX - R_MIN) / (N_POINTS - 1):.6f} A")
    print("Done.")


if __name__ == "__main__":
    main()
