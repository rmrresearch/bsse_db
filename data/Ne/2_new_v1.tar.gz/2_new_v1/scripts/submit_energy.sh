#!/bin/bash
# submit_energy.sh
# Slurm batch script for a single NWChem CCSD(T)/aug-cc-pVDZ calculation
# for the Ne/2_new dimer radial-scan BSSE study.
#
# Layout of jobs on NOVA:
#   ~/BSSE/Ne/2_new/R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/*.nw
#
# Default resources:
#   2 MPI tasks, 20G, 1hr
# Rationale:
#   - Ne dimer at aug-cc-pVDZ is a tiny system (2 atoms max in AB_AB).
#   - The .nw files carry no `memory` directive (matching the proven minimal
#     Ne/2 dimer inputs); --mem=20G is simply the ceiling NWChem may use.
#   - 1hr is very generous for a 2-atom CCSD(T); tighten after the benchmark.
#
# Clean-run guarantee (handoff Sec. 5): each job runs in its own clean leaf
# directory via `cd "$NW_DIR"` below, so no stale .movecs is inherited and the
# SCF genuinely iterates (One-electron / Two-electron breakdown prints in every
# .out for the later parent-chat 1e/2e study). The raw .out is preserved; only
# NWChem scratch files are removed.
#
# Usage (direct):
#   sbatch submit_energy.sh /full/path/to/file.nw
# Usage (via submit_all_jobs.sh):
#   submit_all_jobs.sh handles walking the tree and calling sbatch

#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --mem=20G
#SBATCH --time=01:00:00

# ── Load NWChem ───────────────────────────────────────────────────────────────
module load nwchem/7.2.0-py39-py310-openmpi4-oxtctbu

# ── Resolve paths ─────────────────────────────────────────────────────────────
NW_FILE=$1

if [[ -z "$NW_FILE" ]]; then
    echo "Error: no .nw file provided."
    echo "Usage: sbatch submit_energy.sh /full/path/to/file.nw"
    exit 1
fi

if [[ ! -f "$NW_FILE" ]]; then
    echo "Error: file not found: $NW_FILE"
    exit 1
fi

NW_DIR=$(dirname  "$NW_FILE")
NW_BASE=$(basename "$NW_FILE")
OUT_BASE="${NW_BASE%.nw}.out"

# ── Run NWChem ────────────────────────────────────────────────────────────────
cd "$NW_DIR" || { echo "Error: cannot cd to $NW_DIR"; exit 1; }

mpirun -np "$SLURM_NTASKS" nwchem "$NW_BASE" > "$OUT_BASE" 2>&1

# ── Clean up NWChem scratch files (keep only .nw and .out) ───────────────────
BASE="${NW_BASE%.nw}"
for f in "${BASE}".*; do
    if [[ "$f" != "${BASE}.nw" && "$f" != "${BASE}.out" ]]; then
        rm -f "$f"
    fi
done
