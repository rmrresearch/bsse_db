#!/usr/bin/env python3
"""
plot_bsse_vs_R.py — Ne/2_new (dimer radial-scan study)
======================================================

Generates the two Ne dimer figures from the consolidated BSSE CSV:

  1. ne_dimer_bsse_vs_R.png
     |BSSE| (kcal/mol) vs R (A) for the three components and the total
     (full CCSD(T)), with the 1 and 0.5 kcal/mol reference thresholds.

  2. ne_dimer_component_breakdown.png
     Bar plot of the mean fractional contribution of each component to
     the total mean |BSSE|.

Location:  bsse_db/data/Ne/2_new/scripts/
Input:     bsse_db/data/Ne/2_new/data_frames_plots/ne_dimer_bsse_vs_R.csv
Output:    bsse_db/data/Ne/2_new/data_frames_plots/*.png

Relationship to the old Ne/2 script
-----------------------------------
The plotting code is carried over from Ne/2/data_frames_plots/
build_bsse_vs_R.py (same colors, marker sizes, threshold lines, and bar
annotations), with three changes:

  1. Plotting is SPLIT OUT of the CSV builder, matching how HF/2_new and
     H2O/2_new separate `build_bsse_csv.py` from their plotting scripts.
  2. Column names follow the locked 23-column schema
     (2b_bsse_SCF / 2b_bsse_MP2c / 2b_bsse_CCSD_Tc / total_bsse) rather
     than the old bsse_scf / bsse_mp2c / bsse_ccsdtc / bsse_total.
  3. Internal figure titles are OFF by default (--title to re-enable).
     Publication figures carry their description in the LaTeX caption;
     an in-figure title duplicates it. --title is for on-screen checking.

Sign convention
---------------
The CSV stores signed BSSE (no_vmfc - vmfc), typically negative. Absolute
values are taken here, at plot time only — never stored.

Usage
-----
    cd bsse_db/data/Ne/2_new/scripts
    python3 plot_bsse_vs_R.py                      # both figures
    python3 plot_bsse_vs_R.py --plot bsse_vs_R     # just figure 1
    python3 plot_bsse_vs_R.py --plot breakdown     # just figure 2
    python3 plot_bsse_vs_R.py --title              # with in-figure titles
    python3 plot_bsse_vs_R.py --yscale log         # log y-axis on figure 1
    python3 plot_bsse_vs_R.py --R-max 3.5          # restrict to R <= 3.5 A
    python3 plot_bsse_vs_R.py --R-min 2.0 --R-max 3.5

R window
--------
--R-min / --R-max restrict the analysis to a sub-range of the 100-point
grid. This is a PLOT-TIME filter only: the CSV always holds all 100 R and
is never modified.

The window changes the component-breakdown percentages, because those are
means over whichever R are included. Extending the grid to larger R adds
points where |BSSE| is near zero, which lowers every component mean and
reweights the percentages toward whichever component decays most slowly.
The quoted percentages are therefore a property of the chosen R window, not
of the Ne dimer alone, and any figure or number derived from them must state
its window.

To keep that traceable, applying a window appends a suffix to the output
filenames (e.g. ne_dimer_bsse_vs_R_Rmax3p5.png), so a windowed figure can
never silently overwrite the full-range one.
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# LaTeX rendering for all text (project convention).
plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})


# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
PLOT_DIR   = SCRIPT_DIR.parent / 'data_frames_plots'
CSV_PATH   = PLOT_DIR / 'ne_dimer_bsse_vs_R.csv'

# ── Traces: (CSV column, legend label, color, marker alpha) ───────────────────
COMPONENTS = [
    ('2b_bsse_SCF',     'SCF',            'tab:blue',   0.65),
    ('2b_bsse_MP2c',    'MP2 corr.',      'tab:orange', 0.65),
    ('2b_bsse_CCSD_Tc', 'CCSD(T) corr.',  'tab:green',  0.65),
]
TOTAL = ('total_bsse', 'Total (full CCSD(T))', 'black', 0.85)


def _ytick_fmt(x, pos):
    """Y-axis tick formatter: '1.0','10.0',... for x>=1, else '%g'."""
    return f"{x:.1f}" if x >= 1 else f"{x:g}"


def window_suffix(r_min, r_max):
    """
    Filename suffix encoding the applied R window. Empty when no window is
    set, so full-range output keeps the canonical filename.
    """
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace('.', 'p'))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace('.', 'p'))
    return ('_' + '_'.join(parts)) if parts else ''


def apply_window(df, r_min, r_max):
    """Restrict the dataframe to r_min <= R <= r_max. Returns a new frame."""
    out = df
    if r_min is not None:
        out = out[out['R'] >= r_min]
    if r_max is not None:
        out = out[out['R'] <= r_max]
    out = out.reset_index(drop=True)
    if out.empty:
        raise ValueError(
            f"R window [{r_min}, {r_max}] selects no rows "
            f"(CSV spans [{df['R'].min():.3f}, {df['R'].max():.3f}] A)."
        )
    return out


def load_csv():
    if not CSV_PATH.is_file():
        raise FileNotFoundError(
            f"No CSV at {CSV_PATH}. Run build_bsse_csv.py first."
        )
    return pd.read_csv(CSV_PATH).sort_values('R').reset_index(drop=True)


# ── Figure 1: |BSSE| vs R ─────────────────────────────────────────────────────
def plot_bsse_vs_R(df, out_path, show_title=False, yscale='linear'):
    """
    Scatter |BSSE| vs R for the three components and the total.

    Parameters
    ----------
    df : pandas.DataFrame
        Consolidated CSV, sorted by R.
    out_path : pathlib.Path
        Destination PNG.
    show_title : bool
        Draw an in-figure title. Off for publication output.
    yscale : {'linear', 'log'}
        Y-axis scale.
    """
    fig, ax = plt.subplots(figsize=(8, 6))

    for col, label, color, alpha in COMPONENTS:
        ax.scatter(df['R'], np.abs(df[col]),
                   s=22, alpha=alpha, label=label, color=color)

    col, label, color, alpha = TOTAL
    ax.scatter(df['R'], np.abs(df[col]),
               s=22, alpha=alpha, label=label, color=color)

    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")

    ax.set_yscale(yscale)
    if yscale == 'linear':
        ax.yaxis.set_major_formatter(FuncFormatter(_ytick_fmt))

    ax.axhline(y=1.0, color="red", linestyle="--", linewidth=1.0,
               alpha=0.7, label="1 kcal/mol threshold")
    ax.axhline(y=0.5, color="grey", linestyle="--", linewidth=1.0,
               alpha=0.7)

    if show_title:
        ax.set_title("Ne dimer: BSSE vs inter-monomer distance "
                     "(aug-cc-pVDZ)")

    ax.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"  Saved plot: {out_path.name}"
          f"{'  (log y)' if yscale == 'log' else ''}")


# ── Figure 2: component breakdown ─────────────────────────────────────────────
def plot_component_breakdown(df, out_path, show_title=False):
    """
    Bar plot of the mean fractional contribution of each component to the
    total mean |BSSE|, averaged over all R in the CSV.

    Note the denominator is the SUM OF THE THREE COMPONENT MEANS, not the
    mean of the total column. These differ whenever the components do not
    all share a sign at every R, since
        mean|a| + mean|b| + mean|c|  !=  mean|a+b+c|.
    The component-sum denominator is what the old Ne/2 script used and what
    the percentages quoted in the paper refer to; it is kept for continuity.
    Both denominators are reported in the console output so the difference
    is visible rather than hidden.
    """
    means = {col: float(np.mean(np.abs(df[col])))
             for col, _, _, _ in COMPONENTS}
    denom = sum(means.values())

    labels      = [lab for _, lab, _, _ in COMPONENTS]
    percentages = [100 * means[col] / denom for col, _, _, _ in COMPONENTS]
    colors      = [c for _, _, c, _ in COMPONENTS]

    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(labels, percentages, color=colors, alpha=0.8)
    for bar, pct in zip(bars, percentages):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 0.8,
                f"{pct:.1f}\\%", ha="center", va="bottom", fontsize=11)

    ax.set_ylabel(r"Mean fractional contribution to $|\mathrm{BSSE}|$ (\%)")
    ax.set_ylim(0, max(percentages) * 1.18)

    if show_title:
        ax.set_title("Ne dimer: BSSE component breakdown (aug-cc-pVDZ)")

    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"  Saved plot: {out_path.name}")

    # Console report — these are the numbers the paper text quotes.
    mean_total = float(np.mean(np.abs(df[TOTAL[0]])))
    print(f"\n  Component breakdown — mean |BSSE| over {len(df)} R "
          f"in [{df['R'].min():.3f}, {df['R'].max():.3f}] A")
    print("  (percentages are a property of THIS R window)")
    print(f"  {'─' * 62}")
    for (col, lab, _, _), pct in zip(COMPONENTS, percentages):
        print(f"    {lab:<15s} : {means[col]:.4f} kcal/mol   ({pct:.2f}%)")
    print(f"  {'─' * 62}")
    print(f"    sum of component means : {denom:.4f} kcal/mol  "
          f"(percentage denominator)")
    print(f"    mean |total_bsse|      : {mean_total:.4f} kcal/mol")
    print(f"  {'─' * 62}")


# ── CLI ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Generate the Ne/2_new dimer BSSE figures from the "
                    "consolidated CSV."
    )
    parser.add_argument(
        "--plot", choices=["bsse_vs_R", "breakdown", "all"], default="all",
        help="Which figure(s) to generate. Default: all.",
    )
    parser.add_argument(
        "--title", action="store_true",
        help="Draw in-figure titles. Off by default: publication figures "
             "carry their description in the LaTeX caption.",
    )
    parser.add_argument(
        "--yscale", choices=["linear", "log"], default="linear",
        help="Y-axis scale for the |BSSE| vs R figure. Default: linear.",
    )
    parser.add_argument(
        "--R-min", dest="r_min", type=float, default=None, metavar="R",
        help="Lower bound of the R window, in Angstrom. Plot-time filter "
             "only; the CSV is never modified.",
    )
    parser.add_argument(
        "--R-max", dest="r_max", type=float, default=None, metavar="R",
        help="Upper bound of the R window, in Angstrom. Applying a window "
             "appends a suffix to the output filenames.",
    )
    args = parser.parse_args()

    print(f"\n{'═' * 68}")
    print("  Ne/2_new figures")
    print(f"{'═' * 68}")
    print(f"  CSV      : {CSV_PATH}")
    print(f"  Out dir  : {PLOT_DIR}")
    print(f"  Titles   : {'on' if args.title else 'off (publication)'}")
    print(f"{'═' * 68}\n")

    df_all = load_csv()
    print(f"  Loaded {len(df_all)} rows, "
          f"R in [{df_all['R'].min():.3f}, {df_all['R'].max():.3f}] A")

    df = apply_window(df_all, args.r_min, args.r_max)
    win = window_suffix(args.r_min, args.r_max)
    if win:
        print(f"  Window applied: {len(df)}/{len(df_all)} rows, "
              f"R in [{df['R'].min():.3f}, {df['R'].max():.3f}] A")
    print()

    if args.plot in ("bsse_vs_R", "all"):
        scale = '_log' if args.yscale == 'log' else ''
        plot_bsse_vs_R(df, PLOT_DIR / f'ne_dimer_bsse_vs_R{win}{scale}.png',
                       show_title=args.title, yscale=args.yscale)

    if args.plot in ("breakdown", "all"):
        plot_component_breakdown(
            df, PLOT_DIR / f'ne_dimer_component_breakdown{win}.png',
            show_title=args.title,
        )

    print()


if __name__ == '__main__':
    main()
