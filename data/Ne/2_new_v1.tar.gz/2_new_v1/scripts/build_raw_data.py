#!/usr/bin/env python3
"""
build_raw_data.py — Ne/2_new (dimer radial-scan study)
======================================================

Parser for NWChem CCSD(T)/aug-cc-pVDZ output files produced by the Ne/2_new
study (uniform radial scan of the Ne-Ne separation R).

Purpose
-------
Implements Task 3 of the PI task list (Issue #46), adapted for Ne/2_new:
dynamically discover all NWChem .out files under R_config/, extract SCF,
MP2, and CCSD(T) total energies, and store them in a nested dict that
mirrors the on-disk structure. Pickle the result for downstream use.

Difference from HF/2_new and H2O/2_new
--------------------------------------
Ne is a single spherically symmetric atom per monomer, so the BSSE depends
only on the scalar separation R. There is NO orientation layer: the
<orient> level present in the HF and H2O parsers is absent here, and the
failure/exclusion unit is the R value itself rather than an orientation.

Directory structure expected
----------------------------
Run this script from bsse_db/data/Ne/2_new/scripts/. The parser walks:

    data/Ne/2_new/R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/*.out

where:
    <NNN>      — zero-padded 1-based grid index, "001" through "100"
    <label>    — 3-decimal 'p' label of the grid point (e.g. 1p500, 2p985)
    file key   — one of A_A, AB_AB, A_AB, B_AB

R precision (IMPORTANT — differs from HF/H2O)
---------------------------------------------
The HF and H2O parsers recover R from the folder label via
float(label.replace('p','.')). That is exact for those studies because their
grids were chosen as round decimal values. It is NOT exact here: the Ne grid
is np.linspace(1.5, 4.5, 100) with step 0.030303..., so the 3-decimal folder
label is a ROUNDED human-readable tag, not the computed geometry. For
example, folder '002_R_1p530' has true R = 1.5303030303030303 A.

Therefore R is recovered from the grid itself, indexed by the <NNN> folder
prefix, which IS the 1-based grid index by construction (see
generate_nw_inputs.py, which defines the same grid and writes full-precision
coordinates into the .nw files). The label is used only to locate folders.

Energies extracted per .out file
--------------------------------
For each .out file, using the LAST occurrence of each pattern:
    E_scf   : total SCF energy      (Ha)
    E_mp2   : total MP2 energy      (Ha)
    E_ccsdt : total CCSD(T) energy  (Ha)

Then stored per PI Task List (incremental convention):
    SCF             = E_scf
    MP2_corcomp     = E_mp2   - E_scf     (MP2 correlation energy)
    CCSD_T_corcomp  = E_ccsdt - E_mp2     (CCSD(T) correlation component)

Note the CCSD(T) pattern matches the literal string "CCSD(T)" and therefore
does not collide with the "Total CCSD energy:" and "Total CCSD+T(CCSD)
energy:" lines that also appear in every output file.

Output data structures
----------------------
raw_data['R_config']['R_<label>']['CCSD_T']['aug-cc-pvdz'][file_key]
    -> {'SCF': float, 'MP2_corcomp': float, 'CCSD_T_corcomp': float}   (Ha)

raw_data_noconv['R_config']['R_<label>']['failures']
    -> list of dicts, each recording which components were missing from
       which file. An R with ANY missing energy in ANY of its 4 files is
       EXCLUDED from raw_data entirely.

parameters['R_config']['R_<label>']
    -> {'R': float, 'grid_index': int}
       R is the full-precision grid value; grid_index is the 1-based <NNN>.
       Only populated for R values that parsed completely.

Output pickle
-------------
ONE pickle for the whole study (Ne has no orientation ensemble to shard on;
each R holds only 4 .out files), saved to:
    Ne/2_new/R_config_pickle_data/raw_data.pickle

The pickle contains a single dict:
    {'raw_data': ..., 'raw_data_noconv': ..., 'parameters': ...}

Symmetry diagnostic
-------------------
For the homonuclear Ne-Ne dimer, A_AB and B_AB are the same calculation up
to labelling, so their energies should agree to numerical precision. This
script REPORTS the per-component deviation (max over all R) but never fails
on it: the tolerance at which a deviation becomes meaningful has not been
locked, and reporting keeps that decision with the user rather than burying
it in an assertion.

Usage
-----
    cd bsse_db/data/Ne/2_new/scripts
    python3 build_raw_data.py               # parse all 100 R, write the pickle
    python3 build_raw_data.py --R 1p500     # re-parse one R, merge into the
                                            # existing pickle (rest preserved)
    python3 build_raw_data.py --force       # re-parse all, overwrite pickle

Notes
-----
- Raw .out files are PRESERVED (handoff Sec. 9): they are the input to a
  separate 1e/2e decomposition study. This script only reads them.
- Re-runnable at any time; new .out files are picked up automatically.
- Adapted from H2O/2_new/scripts/build_raw_data.py — parsing logic is
  unchanged; the orientation layer is removed and R recovery is corrected
  for the linspace grid.
"""

import re
import pickle
import argparse
from pathlib import Path

import numpy as np


# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR   = SCRIPT_DIR.parent / 'R_config'
PICKLE_DIR = SCRIPT_DIR.parent / 'R_config_pickle_data'
PICKLE_NAME = 'raw_data.pickle'

# ── Grid (single source of truth, matches generate_nw_inputs.py) ──────────────
R_MIN = 1.5
R_MAX = 4.5
N_POINTS = 100
R_VALUES = np.linspace(R_MIN, R_MAX, N_POINTS)

# Top-level key mirrors the on-disk folder name, as 'rot_config' does for
# HF/2_new and H2O/2_new.
CONFIG_KEY = 'R_config'

# 4 expected file keys per R
FILE_KEYS = ['A_A', 'AB_AB', 'A_AB', 'B_AB']

# Component keys (naming locked to match HF/2_new and H2O/2_new)
COMP_KEYS = ['SCF', 'MP2_corcomp', 'CCSD_T_corcomp']

# Fixed method and basis (only one combination in this study)
METHOD_KEY = 'CCSD_T'
BASIS_KEY  = 'aug-cc-pvdz'


# ── Regex patterns (reused verbatim from HF/2_new and H2O/2_new parsers) ──────
SCF_PATTERN   = re.compile(r"Total\s+SCF\s+energy\s*[:=]\s*([\-0-9.+Ee]+)")
MP2_PATTERN   = re.compile(r"Total\s+MP2\s+energy\s*[:=]\s*([\-0-9.+Ee]+)")
CCSDT_PATTERN = re.compile(r"Total\s+CCSD\(T\)\s+energy\s*[:=]\s*([\-0-9.+Ee]+)")


# ── Grid helpers ──────────────────────────────────────────────────────────────
def r_to_label(r: float) -> str:
    """1.5303030303 -> '1p530' (3-decimal folder label)."""
    return f'{r:.3f}'.replace('.', 'p')


ALL_R_LABELS = [r_to_label(r) for r in R_VALUES]


def folder_name(index0: int) -> str:
    """0-based grid index -> '<NNN>_R_<label>'. 0 -> '001_R_1p500'."""
    return f'{index0 + 1:03d}_R_{r_to_label(R_VALUES[index0])}'


def index_of_label(r_label: str) -> int:
    """0-based grid index for a 3-decimal label. Raises if not a grid point."""
    return ALL_R_LABELS.index(r_label)


# ── Parsing helpers (unchanged from HF/H2O parsers) ───────────────────────────
def extract_last(pattern, text):
    """
    Return the last float matched by `pattern` in `text`, or None.

    Using the LAST occurrence handles NWChem output files where energies are
    printed multiple times during iterative convergence; the final printed
    value is always the converged result.
    """
    value = None
    for line in text.splitlines():
        m = pattern.search(line)
        if m:
            try:
                value = float(m.group(1))
            except ValueError:
                pass
    return value


def ensure_path(d, keys):
    """Ensure a chain of nested dicts exists and return the deepest one."""
    cur = d
    for k in keys:
        cur = cur.setdefault(k, {})
    return cur


def missing_energies(E_scf, E_mp2, E_ccsdt):
    """Return a list of labels for missing energy components."""
    missing = []
    if E_scf   is None: missing.append('SCF')
    if E_mp2   is None: missing.append('MP2')
    if E_ccsdt is None: missing.append('CCSD(T)')
    return missing


# ── Core builder (per-R) ──────────────────────────────────────────────────────
def build_raw_data_for_R(r_label, verbose=True):
    """
    Parse the 4 .out files for a single R and return the three dicts scoped
    to that R.

    Returns
    -------
    raw_data, raw_data_noconv, parameters : dict
        Same shapes as documented in the module docstring, but containing
        entries only for the requested R.
    """
    raw_data        = {}
    raw_data_noconv = {}
    parameters      = {}

    index0 = index_of_label(r_label)
    r_key  = f'R_{r_label}'
    r_dir  = BASE_DIR / folder_name(index0)

    def log_failure(entry):
        node = ensure_path(raw_data_noconv, (CONFIG_KEY, r_key))
        node.setdefault('failures', []).append(entry)

    if not r_dir.is_dir():
        log_failure({
            'missing':  ['directory'],
            'file_key': None,
            'path':     str(r_dir),
            'reason':   'expected R folder missing',
        })
        if verbose:
            print(f"  ⏳  {r_key}: folder missing, skipping")
        return raw_data, raw_data_noconv, parameters

    nw_dir = r_dir / METHOD_KEY / BASIS_KEY
    if not nw_dir.is_dir():
        log_failure({
            'missing':  ['directory'],
            'file_key': None,
            'path':     str(nw_dir),
            'reason':   f'expected {METHOD_KEY}/{BASIS_KEY} directory missing',
        })
        if verbose:
            print(f"  ⏳  {r_key}: {METHOD_KEY}/{BASIS_KEY} missing, skipping")
        return raw_data, raw_data_noconv, parameters

    bucket = {}   # {file_key: components_dict}
    bad    = False

    for file_key in FILE_KEYS:
        out_path = nw_dir / f'{file_key}.out'

        if not out_path.is_file():
            bad = True
            log_failure({
                'missing':  ['file'],
                'file_key': file_key,
                'path':     str(out_path),
                'reason':   '.out file not found',
            })
            continue

        text    = out_path.read_text(errors='replace')
        E_scf   = extract_last(SCF_PATTERN,   text)
        E_mp2   = extract_last(MP2_PATTERN,   text)
        E_ccsdt = extract_last(CCSDT_PATTERN, text)

        if (E_scf is None) or (E_mp2 is None) or (E_ccsdt is None):
            bad = True
            log_failure({
                'missing':  missing_energies(E_scf, E_mp2, E_ccsdt),
                'file_key': file_key,
                'path':     str(out_path),
                'reason':   'missing energy component(s)',
            })
            continue

        bucket[file_key] = {
            'SCF':            E_scf,
            'MP2_corcomp':    E_mp2   - E_scf,
            'CCSD_T_corcomp': E_ccsdt - E_mp2,
        }

    # Commit only if the R parsed completely.
    if bad or set(bucket.keys()) != set(FILE_KEYS):
        if not bad:
            missing_files = sorted(set(FILE_KEYS) - set(bucket.keys()))
            log_failure({
                'missing':  ['file(s)'],
                'file_key': missing_files,
                'path':     None,
                'reason':   f'incomplete file set (missing: {missing_files})',
            })
        if verbose:
            n_fail = len(raw_data_noconv[CONFIG_KEY][r_key]['failures'])
            print(f"  ⚠️   {r_key}: EXCLUDED ({n_fail} failure(s))")
        return raw_data, raw_data_noconv, parameters

    node = ensure_path(raw_data, (CONFIG_KEY, r_key, METHOD_KEY, BASIS_KEY))
    for file_key, components in bucket.items():
        node[file_key] = components

    ensure_path(parameters, (CONFIG_KEY,))[r_key] = {
        'R':          float(R_VALUES[index0]),
        'grid_index': index0 + 1,
    }

    if verbose:
        print(f"  ✅  {r_key}: R = {R_VALUES[index0]:.10f} A, 4/4 files parsed")

    return raw_data, raw_data_noconv, parameters


# ── Symmetry diagnostic ───────────────────────────────────────────────────────
def report_symmetry(raw_data, verbose=True):
    """
    Report the max |A_AB - B_AB| deviation per component across all parsed R.

    For the homonuclear Ne-Ne dimer these are the same calculation up to
    labelling. This is a DIAGNOSTIC only — it never fails the parse. The
    tolerance at which a deviation becomes meaningful is a decision for the
    user, not this script.
    """
    entries = raw_data.get(CONFIG_KEY, {})
    if not entries:
        return {}

    worst = {c: (0.0, None) for c in COMP_KEYS}
    for r_key, node in entries.items():
        leaf = node[METHOD_KEY][BASIS_KEY]
        for c in COMP_KEYS:
            dev = abs(leaf['A_AB'][c] - leaf['B_AB'][c])
            if dev > worst[c][0]:
                worst[c] = (dev, r_key)

    if verbose:
        print(f"\n  Symmetry diagnostic  A_AB vs B_AB  (n = {len(entries)} R)")
        print(f"  {'─' * 62}")
        for c in COMP_KEYS:
            dev, r_key = worst[c]
            print(f"    max |Δ{c:<15s}| = {dev:.3e} Ha   at {r_key}")
        print(f"  {'─' * 62}")
        print("    Diagnostic only — no tolerance is enforced.")

    return worst


# ── Pickle I/O ────────────────────────────────────────────────────────────────
def pickle_path():
    return PICKLE_DIR / PICKLE_NAME


def load_pickle():
    """Load the existing study pickle, or return empty containers."""
    p = pickle_path()
    if not p.is_file():
        return {'raw_data': {}, 'raw_data_noconv': {}, 'parameters': {}}
    with open(p, 'rb') as fh:
        return pickle.load(fh)


def save_pickle(payload):
    """Write the single study-wide pickle."""
    PICKLE_DIR.mkdir(parents=True, exist_ok=True)
    p = pickle_path()
    with open(p, 'wb') as fh:
        pickle.dump(payload, fh)
    return p


def merge_R(payload, r_key, raw_data, raw_data_noconv, parameters):
    """
    Merge one R's results into the study payload, replacing any prior entry
    for that R in all three containers.
    """
    for container, incoming in (
        ('raw_data',        raw_data),
        ('raw_data_noconv', raw_data_noconv),
        ('parameters',      parameters),
    ):
        dest = ensure_path(payload[container], (CONFIG_KEY,))
        dest.pop(r_key, None)
        src = incoming.get(CONFIG_KEY, {})
        if r_key in src:
            dest[r_key] = src[r_key]


def sort_payload(payload):
    """Reorder every container by ascending grid index for readability."""
    order = {f'R_{lab}': i for i, lab in enumerate(ALL_R_LABELS)}
    for container in ('raw_data', 'raw_data_noconv', 'parameters'):
        node = payload[container].get(CONFIG_KEY)
        if not node:
            continue
        payload[container][CONFIG_KEY] = {
            k: node[k] for k in sorted(node, key=lambda k: order.get(k, 1e9))
        }


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Parse Ne/2_new NWChem .out files. One pickle for the '
                    'whole study.'
    )
    parser.add_argument(
        '--R', type=str, default=None, choices=ALL_R_LABELS, metavar='LABEL',
        help='Single R to (re)parse, e.g. 1p500. Merged into the existing '
             'pickle; all other R are preserved. Omit to parse all 100.'
    )
    parser.add_argument(
        '--force', action='store_true',
        help='With no --R: discard the existing pickle and re-parse all 100 R '
             'from scratch.'
    )
    args = parser.parse_args()

    print(f"\n{'═' * 68}")
    print("  Ne/2_new raw_data build")
    print(f"{'═' * 68}")
    print(f"  Base dir     : {BASE_DIR}")
    print(f"  Pickle       : {pickle_path()}")
    print(f"  Grid         : linspace({R_MIN}, {R_MAX}, {N_POINTS}), "
          f"step = {(R_MAX - R_MIN) / (N_POINTS - 1):.10f} A")
    print(f"{'═' * 68}")

    if args.R is not None:
        targets = [args.R]
        payload = load_pickle()
        reason  = 'explicit --R (merge into existing pickle)'
    else:
        targets = list(ALL_R_LABELS)
        payload = ({'raw_data': {}, 'raw_data_noconv': {}, 'parameters': {}}
                   if args.force else load_pickle())
        reason  = 'all R ' + ('(--force, from scratch)' if args.force
                              else '(merge into existing pickle)')

    print(f"\n  Targets: {len(targets)} R — {reason}\n")

    n_ok = 0
    for r_label in targets:
        rd, rn, pm = build_raw_data_for_R(r_label, verbose=True)
        merge_R(payload, f'R_{r_label}', rd, rn, pm)
        if rd:
            n_ok += 1

    sort_payload(payload)

    n_parsed = len(payload['raw_data'].get(CONFIG_KEY, {}))
    n_failed = len(payload['raw_data_noconv'].get(CONFIG_KEY, {}))

    report_symmetry(payload['raw_data'], verbose=True)

    out_path = save_pickle(payload)

    print(f"\n{'═' * 68}")
    print(f"  This run   : {n_ok}/{len(targets)} R parsed")
    print(f"  In pickle  : {n_parsed} R parsed, {n_failed} R excluded")
    print(f"  💾  {out_path}")
    print(f"{'═' * 68}\n")
