"""
fit_two_gaussian.py
-------------------
Fit the total CCSD(T) Ne dimer BSSE to a two-channel Gaussian form:

    |BSSE(R)| = a1 * exp(-b1 R^2) + a2 * exp(-b2 R^2)

with the convention b1 < b2, i.e. channel 1 is the SLOW (long-range)
channel and channel 2 is the FAST (short-range) channel.

Structural motivation
---------------------
By the Gaussian product theorem (Boys 1950; Besalu & Carbo-Dorca 2011),
the product of two 1s GTOs centred at A and B is a single Gaussian at an
intermediate point, scaled by

    kappa = exp[ -alpha*beta/(alpha+beta) * |A-B|^2 ]

so EVERY two-centre integral -- overlap, kinetic, nuclear attraction and
two-electron alike -- carries a Gaussian damping in the inter-centre
distance R. In the Coulomb integrals the Boys function F_0 multiplies this
factor; because its argument is the distance from the GTO product centre to
the nucleus (also proportional to R), it contributes an erf(cR)/(cR)
modulation but never a decay slower than Gaussian.

The BSSE of monomer A is the energy lowering produced by adding ghost
functions on B. That lowering runs over every pair (i on A, j on B), and
each pair carries its own GPT constant

    gamma_ij  propto  alpha_i * alpha_j / (alpha_i + alpha_j)

so the BSSE is a weighted SUM of Gaussians spanning as many decay scales as
the basis has exponent combinations. For Ne/aug-cc-pVDZ (4s3p2d, 23
functions) that is 529 pairs with gamma spanning roughly 0.19 to 3.9 A^-2 --
a factor of 20, with a well-separated slow group (diffuse s, p) and fast
group (valence s, p).

A single Gaussian cannot represent that spread; the two-term form used here
is the MINIMAL TRUNCATION that carries one fast and one slow scale. It is
not a claim that exactly two channels exist.

Relation to the Heindel-Xantheas erf form
-----------------------------------------
Heindel & Xantheas (JCTC 2020, Appendix) fit 2-body BSSE to
a[1 + erf(-bR)], derived from the overlapping AREA of two Gaussian
distributions. That form is NOT an alternative to a Gaussian: since

    a[1 + erf(-bR)] = a*erfc(bR) -> (a/(b*sqrt(pi))) * exp(-b^2 R^2) / R

it is asymptotically a SINGLE Gaussian channel carrying a 1/R prefactor.
The two-Gaussian form therefore generalises their result to more than one
decay scale rather than contradicting it.

Caveats (stated in the write-up, not hidden here)
-------------------------------------------------
- BSSE is an energy DIFFERENCE, not a single integral. The GPT fixes the
  decay SCALES; the amplitudes a1, a2 remain empirical.
- The 1/R factors carried by the Coulomb integrals are not represented.
- The GPT argument applies most directly to the SCF component (41.6% of the
  total here). MP2 and CCSD(T) are built on the same integrals and are
  expected to inherit the structure, but indirectly.

Workflow
--------
  1. Fit stage: nonlinear least squares over the analysis window, from a
     GPT-informed seed. Reports (a1, b1, a2, b2) +/- uncertainties, RMSE,
     a conditioning check, a MULTI-START seed-robustness check, and a
     comparison of the fitted b against the GPT gamma values computed from
     the actual Ne aug-cc-pVDZ exponents.

  2. Correlation stage: predicted vs measured |BSSE| with OLS line for
     visual bias check and R^2_fit (linear space) as the metric comparable
     across functional forms.

Analysis window (--R-min / --R-max)
-----------------------------------
Must match the window used by plot_bsse_vs_R.py, fit_gaussian.py, fit_erf.py
and fit_gaussian_erf.py, or the RMSE comparison across forms is meaningless.
The current agreed window is R <= 3.5 A (67 points):

    python3 fit_two_gaussian.py --R-max 3.5

Reads:  ne_dimer_bsse_vs_R.csv  (uses |total_bsse| only)
Output: PNG files in the same directory as this script.

Usage:
    python3 fit_two_gaussian.py --R-max 3.5
    python3 fit_two_gaussian.py --R-max 3.5 --stage fit
    python3 fit_two_gaussian.py --stage all      # full 100-point grid
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

# ---------------------------------------------------------------------------
# LaTeX rendering settings (consistent with the other fit scripts)
# ---------------------------------------------------------------------------
plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
#   Script lives in:  .../data_frames_plots/two_gaussian_fit/
#   CSV (read-only):  .../data_frames_plots/ne_dimer_bsse_vs_R.csv
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
PARENT_DIR = SCRIPT_DIR.parent
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

# Set from the CLI in main(); appended to every output filename.
SUFFIX = ""

# ---------------------------------------------------------------------------
# Initial guess, seeded from the GPT analysis (see module docstring)
#   slow channel  ~ diffuse-diffuse pairs, gamma ~ 0.19-0.22 A^-2
#   fast channel  ~ valence-valence pairs, gamma ~ 0.77-0.87 A^-2
# ---------------------------------------------------------------------------
A1_INIT = 1.0     # kcal/mol  (slow amplitude)
B1_INIT = 0.20    # A^-2      (slow decay,  GPT: diffuse pairs)
A2_INIT = 15.0    # kcal/mol  (fast amplitude)
B2_INIT = 0.85    # A^-2      (fast decay,  GPT: valence pairs)

# ---------------------------------------------------------------------------
# GPT reference constants, computed from the Ne aug-cc-pVDZ exponents printed
# by NWChem in every .out file of this study (4s3p2d, 23 functions).
#
#   gamma = alpha_i * alpha_j / (alpha_i + alpha_j),  converted bohr^-2 -> A^-2
#
# These are NOT fit parameters. They come from Dunning's published basis and
# are listed here purely as a reference scale to compare the fit against.
# ---------------------------------------------------------------------------
BOHR2_TO_ANG2 = 1.0 / 0.52917721**2

NE_AVDZ_EXPONENTS = {          # uncontracted / outermost primitives, bohr^-2
    "8D  tight d":     2.2020,
    "9D  diffuse d":   0.6310,
    "3S  valence s":   0.4869,
    "6P  valence p":   0.4317,
    "4S  diffuse s":   0.1230,
    "7P  diffuse p":   0.1064,
}


def gpt_gamma(alpha: float, beta: float) -> float:
    """GPT decay constant alpha*beta/(alpha+beta), in A^-2."""
    return alpha * beta / (alpha + beta) * BOHR2_TO_ANG2


def print_gpt_reference(b1: float, b2: float) -> None:
    """Print the GPT gamma scales next to the fitted decay constants."""
    same = {k: gpt_gamma(a, a) for k, a in NE_AVDZ_EXPONENTS.items()}

    print("=" * 68)
    print("GPT REFERENCE SCALES (Ne aug-cc-pVDZ, from the .out basis table)")
    print("=" * 68)
    print("  Same-exponent pairs, gamma = alpha/2  (A^-2):")
    for k, g in sorted(same.items(), key=lambda kv: -kv[1]):
        print(f"    {k:<16} alpha = {NE_AVDZ_EXPONENTS[k]:>8.4f}   "
              f"gamma = {g:>7.3f}")

    all_g = [gpt_gamma(a, b) for a, b in
             itertools.combinations_with_replacement(
                 NE_AVDZ_EXPONENTS.values(), 2)]
    print(f"\n  Full pair range over these exponents: "
          f"gamma in [{min(all_g):.3f}, {max(all_g):.3f}] A^-2 "
          f"(factor {max(all_g)/min(all_g):.0f})")

    print("\n  FITTED decay constants for comparison:")
    print(f"    b1 (slow) = {b1:.3f} A^-2")
    print(f"    b2 (fast) = {b2:.3f} A^-2")
    print("\n  NOTE: this is a CONSISTENCY CHECK, not a derivation. The GPT")
    print("  fixes decay scales, not amplitudes, and the mapping from a")
    print("  pair-coupling to an energy lowering carries a power ambiguity")
    print("  (one GPT factor vs its square) that this comparison cannot")
    print("  settle on its own.")
    print()


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def two_gaussian(R: np.ndarray, a1: float, b1: float,
                 a2: float, b2: float) -> np.ndarray:
    """|BSSE|(R) = a1 * exp(-b1 R^2) + a2 * exp(-b2 R^2)."""
    return a1 * np.exp(-b1 * R**2) + a2 * np.exp(-b2 * R**2)


def order_channels(popt: np.ndarray, perr: np.ndarray):
    """
    Return parameters with channel 1 = SLOW (smaller b), channel 2 = FAST.

    The model is symmetric under exchange of the two channels, so the
    optimizer may return them in either order. Sorting makes b1/b2 mean the
    same thing on every run and across every seed.
    """
    a1, b1, a2, b2 = popt
    sa1, sb1, sa2, sb2 = perr
    if b1 <= b2:
        return (a1, b1, a2, b2), (sa1, sb1, sa2, sb2)
    return (a2, b2, a1, b1), (sa2, sb2, sa1, sb1)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def window_suffix(r_min: float | None, r_max: float | None) -> str:
    """Filename suffix encoding the analysis window; empty when unrestricted."""
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace(".", "p"))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace(".", "p"))
    return ("_" + "_".join(parts)) if parts else ""


def load_data(r_min: float | None = None,
              r_max: float | None = None) -> tuple[np.ndarray, np.ndarray, int]:
    """Return (R, |total_bsse|, n_all) in (A, kcal/mol), within the window."""
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    n_all = len(df)
    if r_min is not None:
        df = df[df["R"] >= r_min]
    if r_max is not None:
        df = df[df["R"] <= r_max]
    if df.empty:
        raise ValueError(f"R window [{r_min}, {r_max}] selects no rows.")
    R = df["R"].to_numpy()
    bsse_total_abs = np.abs(df["total_bsse"].to_numpy())
    return R, bsse_total_abs, n_all


# ---------------------------------------------------------------------------
# Conditioning check
# ---------------------------------------------------------------------------
def check_conditioning(params: dict[str, tuple[float, float]]) -> list[str]:
    """Flag parameters where sigma >= |p| (data does not constrain them)."""
    warnings = []
    for name, (p, sigma) in params.items():
        ratio = float("inf") if abs(p) < 1e-12 else sigma / abs(p)
        if ratio >= 1.0:
            warnings.append(
                f"    {name}: sigma/|p| = {ratio:.2f}  "
                f"(p = {p:.4f}, sigma = {sigma:.4f}) — UNCONSTRAINED"
            )
    return warnings


# ---------------------------------------------------------------------------
# Seed robustness
# ---------------------------------------------------------------------------
def seed_robustness(R: np.ndarray, bsse: np.ndarray) -> None:
    """
    Refit from a spread of starting points and report the minima found.

    A two-Gaussian form with poorly separated channels can have several
    local minima. This is the check that says whether the reported fit is
    THE minimum or just the one nearest the chosen seed. It is reported,
    never enforced.
    """
    seeds = [
        (1.0, 0.20, 15.0, 0.85),    # GPT-informed (the default)
        (0.5, 0.10, 10.0, 0.70),
        (2.0, 0.35, 20.0, 1.00),
        (5.0, 0.05, 5.0, 0.50),
        (0.1, 0.50, 30.0, 1.50),
        (3.0, 0.25, 8.0, 0.60),
    ]
    print("=" * 68)
    print("SEED ROBUSTNESS — refit from 6 starting points")
    print("=" * 68)
    print(f"  {'seed (a1,b1,a2,b2)':<32}{'-> b1':>9}{'b2':>9}{'RMSE':>12}")
    results = []
    for s in seeds:
        try:
            popt, pcov = curve_fit(two_gaussian, R, bsse, p0=list(s),
                                   maxfev=20000)
            perr = np.sqrt(np.diag(pcov))
            (a1, b1, a2, b2), _ = order_channels(popt, perr)
            rmse = float(np.sqrt(np.mean(
                (bsse - two_gaussian(R, a1, b1, a2, b2))**2)))
            results.append((b1, b2, rmse))
            tag = f"({s[0]:g},{s[1]:g},{s[2]:g},{s[3]:g})"
            print(f"  {tag:<32}{b1:>9.4f}{b2:>9.4f}{rmse:>12.6f}")
        except Exception as exc:
            tag = f"({s[0]:g},{s[1]:g},{s[2]:g},{s[3]:g})"
            print(f"  {tag:<32}{'FAILED':>9}   {exc}")

    if results:
        b1s = [r[0] for r in results]
        b2s = [r[1] for r in results]
        rms = [r[2] for r in results]
        spread_b1 = max(b1s) - min(b1s)
        spread_b2 = max(b2s) - min(b2s)
        spread_rmse = max(rms) - min(rms)
        print(f"\n  spread across seeds:  b1 {spread_b1:.2e}   "
              f"b2 {spread_b2:.2e}   RMSE {spread_rmse:.2e}")
        if spread_rmse < 1e-6 and spread_b1 < 1e-3 and spread_b2 < 1e-3:
            print("  -> all seeds converged to the SAME minimum.")
        else:
            print("  -> seeds did NOT all converge to the same minimum. "
                  "The reported fit is seed-dependent; inspect before use.")
    print()


# ---------------------------------------------------------------------------
# Stage 1: nonlinear least squares
# ---------------------------------------------------------------------------
def run_fit(R: np.ndarray, bsse: np.ndarray,
            a1_0: float, b1_0: float, a2_0: float, b2_0: float):
    """Nonlinear LS on the two-Gaussian form. Returns ordered parameters."""
    popt, pcov = curve_fit(two_gaussian, R, bsse,
                           p0=[a1_0, b1_0, a2_0, b2_0], maxfev=20000)
    perr = np.sqrt(np.diag(pcov))
    (a1, b1, a2, b2), (sa1, sb1, sa2, sb2) = order_channels(popt, perr)

    pred = two_gaussian(R, a1, b1, a2, b2)
    rmse = float(np.sqrt(np.mean((bsse - pred) ** 2)))

    print("=" * 68)
    print("STAGE 1 — NONLINEAR LS FIT (two Gaussians):")
    print("  |BSSE| = a1 * exp(-b1 R^2) + a2 * exp(-b2 R^2)")
    print("=" * 68)
    print("  Initial guess (GPT-informed):")
    print(f"    a1_0 = {a1_0:.4f} kcal/mol,  b1_0 = {b1_0:.4f} A^-2")
    print(f"    a2_0 = {a2_0:.4f} kcal/mol,  b2_0 = {b2_0:.4f} A^-2")
    print(f"  Points used: {len(R)} (no filter)")
    print()
    print("  SLOW channel (long-range):")
    print(f"    a1         = {a1: .6f} +/- {sa1: .6f}  kcal/mol")
    print(f"    b1         = {b1: .6f} +/- {sb1: .6f}  A^-2")
    print("  FAST channel (short-range):")
    print(f"    a2         = {a2: .6f} +/- {sa2: .6f}  kcal/mol")
    print(f"    b2         = {b2: .6f} +/- {sb2: .6f}  A^-2")
    print(f"  RMSE         = {rmse: .6f}  kcal/mol")
    print(f"  channel separation b2/b1 = {b2/b1:.2f}")
    print()

    cond = check_conditioning({
        "a1": (a1, sa1), "b1": (b1, sb1),
        "a2": (a2, sa2), "b2": (b2, sb2),
    })
    if cond:
        print("  CONDITIONING WARNING — parameter(s) not constrained by data:")
        for w in cond:
            print(w)
    else:
        print("  All parameters well-conditioned (sigma/|p| < 1).")
    print()
    print(f"  Note: fit is valid over R in [{R.min():.3f}, {R.max():.3f}] A.")
    print(f"        At R = 0 the form gives a1 + a2; R = 0 is outside the")
    print(f"        data range and physically inaccessible.")
    print(f"        Unlike the combined Gaussian+erf form, this fit decays")
    print(f"        to ZERO as R -> infinity, as BSSE must.")
    print()

    # Channel decomposition across the window
    print("  Channel decomposition:")
    print(f"    {'R (A)':>8}{'slow':>12}{'fast':>12}{'total':>12}"
          f"{'data':>12}")
    for Rq in np.linspace(R.min(), R.max(), 6):
        slow = a1 * np.exp(-b1 * Rq**2)
        fast = a2 * np.exp(-b2 * Rq**2)
        near = bsse[np.argmin(np.abs(R - Rq))]
        print(f"    {Rq:>8.3f}{slow:>12.6f}{fast:>12.6f}"
              f"{slow+fast:>12.6f}{near:>12.6f}")
    print()

    # Overlay plot: data, total fit, and the two channels
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, alpha=1.0, color="black",
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    ax.plot(R_line, two_gaussian(R_line, a1, b1, a2, b2), "r-", lw=2,
            label=(fr"fit: $|\mathrm{{BSSE}}| = {a1:.3f}\,e^{{-{b1:.3f}R^2}}"
                   fr" + {a2:.3f}\,e^{{-{b2:.3f}R^2}}$"
                   "\n"
                   fr"RMSE $= {rmse:.4f}$ kcal/mol"))
    ax.plot(R_line, a2 * np.exp(-b2 * R_line**2), "-", color="tab:blue",
            lw=1.2, alpha=0.9,
            label=fr"fast channel ($b_2 = {b2:.3f}\,$\AA$^{{-2}}$)")
    ax.plot(R_line, a1 * np.exp(-b1 * R_line**2), "-", color="tab:orange",
            lw=1.2, alpha=0.9,
            label=fr"slow channel ($b_1 = {b1:.3f}\,$\AA$^{{-2}}$)")
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.5,
               label=r"1 kcal/mol threshold")
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_two_gaussian_fit{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()

    return a1, sa1, b1, sb1, a2, sa2, b2, sb2, rmse


# ---------------------------------------------------------------------------
# Stage 2: correlation plot
# ---------------------------------------------------------------------------
def run_correlation(R: np.ndarray, bsse: np.ndarray,
                    a1: float, b1: float, a2: float, b2: float) -> float:
    """Predicted vs measured |BSSE|. Returns R^2_fit (linear-space)."""
    pred = two_gaussian(R, a1, b1, a2, b2)
    ss_res = np.sum((bsse - pred) ** 2)
    ss_tot = np.sum((bsse - bsse.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    m, c = np.polyfit(pred, bsse, 1)
    c_sign = "-" if c < 0 else "+"
    c_abs = abs(c)

    print("=" * 68)
    print("STAGE 2 — CORRELATION: measured vs predicted |BSSE|")
    print("=" * 68)
    print(f"  R^2_fit (linear space) = {r2: .6f}")
    print(f"  OLS regression line (visual only):"
          f"  measured = {m:.4f} * predicted + {c:.4f}")
    print()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(pred, bsse, s=25, alpha=1.0, color="black")
    lo = 0.0
    hi = max(bsse.max(), pred.max()) * 1.05

    x_line = np.linspace(lo, hi, 200)
    ax.plot(x_line, m * x_line + c, "r--", lw=1.5,
            label=fr"$y = {m:.4f}\,x {c_sign} {c_abs:.4f}$")
    ax.plot([], [], " ", label=fr"$R^2_\mathrm{{fit}} = {r2:.4f}$")

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(r"predicted $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_ylabel(r"measured $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_aspect("equal", "box")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_two_gaussian_correlation{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return r2


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=["fit", "correlation", "all"],
                        default="all", help="Which stage to run")
    parser.add_argument("--R-min", dest="r_min", type=float, default=None,
                        metavar="R",
                        help="Lower bound of the analysis window (A).")
    parser.add_argument("--R-max", dest="r_max", type=float, default=None,
                        metavar="R",
                        help="Upper bound of the analysis window (A). Must "
                             "match the window used by the other fits.")
    parser.add_argument("--no-seed-check", action="store_true",
                        help="Skip the multi-start seed-robustness check.")
    args = parser.parse_args()

    global SUFFIX
    SUFFIX = window_suffix(args.r_min, args.r_max)

    R, bsse, n_all = load_data(args.r_min, args.r_max)
    print(f"Loaded {n_all} points from {CSV_PATH.name}")
    if SUFFIX:
        print(f"  Analysis window: {len(R)}/{n_all} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A")
    else:
        print(f"  Analysis window: FULL GRID ({len(R)} points)")
    print(f"  R range:      [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print(f"  Output suffix: {SUFFIX or '(none)'}")
    print()

    a1 = b1 = a2 = b2 = None

    if args.stage in ("fit", "all"):
        a1, _, b1, _, a2, _, b2, _, _ = run_fit(
            R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT
        )
        if not args.no_seed_check:
            seed_robustness(R, bsse)
        print_gpt_reference(b1, b2)

    if args.stage in ("correlation", "all"):
        if a1 is None:
            a1, _, b1, _, a2, _, b2, _, _ = run_fit(
                R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT
            )
        run_correlation(R, bsse, a1, b1, a2, b2)


if __name__ == "__main__":
    main()
