"""
fit_n_gaussian.py
-----------------
MODEL SELECTION: how many Gaussian channels does the Ne dimer |BSSE|(R)
data actually support?

Fits

    |BSSE(R)| = sum_{k=1}^{N} a_k * exp(-b_k R^2)

for N = 1, 2, 3, ... and reports, for each N, four independent diagnostics.
The point of this script is NOT to find the lowest RMSE -- RMSE always
improves with more parameters. The point is to find where the data STOPS
supporting additional channels.

Why this question arises
------------------------
By the Gaussian product theorem, every two-centre coupling between a basis
function on A (exponent alpha_i) and one on B (exponent alpha_j) carries a
factor exp[-gamma_ij R^2] with gamma_ij = alpha_i*alpha_j/(alpha_i+alpha_j).
The BSSE is a sum over ALL such pairs. For Ne/aug-cc-pVDZ that is 23 x 23 =
529 pair terms with gamma spanning roughly 0.19 to 3.9 A^-2.

So the structural argument predicts MANY channels, not two. Any small N is a
truncation, and the truncation order must be justified by the data rather
than assumed. That is what this script measures.

The four diagnostics
--------------------
1. CONDITIONING  (the sharpest one)
   sigma/|p| for every fitted parameter. A channel the data cannot
   determine shows sigma/|p| >= 1. This is a statement about
   IDENTIFIABILITY, not about fit quality: it says the data does not
   contain enough independent information to place that parameter, no
   matter how good the residual looks.

2. CHANNEL COLLAPSE
   If two fitted b_k converge to within COLLAPSE_TOL (relative), they are
   one channel represented twice, and the extra term is redundant however
   much it lowers RMSE.

3. RMSE PLATEAU
   Where additional channels stop buying accuracy. Reported as the
   fractional improvement over N-1.

4. AIC / BIC
   Parameter-count-penalised criteria.

   CAVEAT, stated plainly: AIC and BIC assume independent, identically
   distributed residuals. The residuals here are visibly STRUCTURED (the
   two-Gaussian residual changes sign systematically across the window), so
   these numbers are indicative only. They are printed because they are
   conventional, not because they settle anything. Diagnostics 1 and 2 are
   the trustworthy ones.

None of these four decides on its own. If they agree, the truncation order
is defensible. If they disagree, THAT is the finding, and the fit should be
presented as an empirical description rather than as support for the GPT
picture.

Multi-start
-----------
Every N is fitted from many starting points, because the number of local
minima grows quickly with N. A result reachable from only one seed is not
reported as the answer; the best minimum and the number of seeds reaching
it are both printed.

Analysis window (--R-min / --R-max)
-----------------------------------
Must match the window used by the other fit scripts for RMSE values to be
comparable. The agreed window is R <= 3.5 A (67 points):

    python3 fit_n_gaussian.py --R-max 3.5

Running WITHOUT --R-max uses all 100 points out to 4.5 A. That is a
DIAGNOSTIC run, useful for asking whether the long-range channel becomes
identifiable when the tail is included -- but its RMSE is not comparable to
the windowed fits of the other forms.

Reads:  ne_dimer_bsse_vs_R.csv  (uses |total_bsse| only)
Output: PNG + a summary table printed to stdout.

Usage:
    python3 fit_n_gaussian.py --R-max 3.5
    python3 fit_n_gaussian.py --R-max 3.5 --N-max 5
    python3 fit_n_gaussian.py                    # full grid, diagnostic
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
PARENT_DIR = SCRIPT_DIR.parent
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

SUFFIX = ""

# ---------------------------------------------------------------------------
# Thresholds (explicit, so they can be argued with)
# ---------------------------------------------------------------------------
COND_TOL = 1.0        # sigma/|p| >= this  -> parameter unconstrained
COLLAPSE_TOL = 0.10   # |b_i - b_j|/max(b) < this -> channels collapsed
SEED_MATCH_TOL = 1e-6 # RMSE within this of the best -> "same minimum"

# GPT reference range from the Ne aug-cc-pVDZ exponents (see fit_two_gaussian)
BOHR2_TO_ANG2 = 1.0 / 0.52917721**2
NE_AVDZ_EXPONENTS = {
    "8D  tight d":   2.2020,
    "9D  diffuse d": 0.6310,
    "3S  valence s": 0.4869,
    "6P  valence p": 0.4317,
    "4S  diffuse s": 0.1230,
    "7P  diffuse p": 0.1064,
}


def gpt_gamma(alpha: float, beta: float) -> float:
    return alpha * beta / (alpha + beta) * BOHR2_TO_ANG2


GPT_GAMMAS = sorted(
    gpt_gamma(a, b) for a, b in
    itertools.combinations_with_replacement(NE_AVDZ_EXPONENTS.values(), 2)
)


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def n_gaussian(R: np.ndarray, *params) -> np.ndarray:
    """sum_k a_k exp(-b_k R^2); params = (a1,b1,a2,b2,...)."""
    out = np.zeros_like(R, dtype=float)
    for k in range(0, len(params), 2):
        out = out + params[k] * np.exp(-params[k + 1] * R**2)
    return out


def sort_channels(popt: np.ndarray, perr: np.ndarray):
    """Return channels ordered by ascending b (slow first)."""
    a = np.asarray(popt[0::2], dtype=float)
    b = np.asarray(popt[1::2], dtype=float)
    sa = np.asarray(perr[0::2], dtype=float)
    sb = np.asarray(perr[1::2], dtype=float)
    order = np.argsort(b)
    return a[order], b[order], sa[order], sb[order]


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
def window_suffix(r_min, r_max) -> str:
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace(".", "p"))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace(".", "p"))
    return ("_" + "_".join(parts)) if parts else ""


def load_data(r_min=None, r_max=None):
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    n_all = len(df)
    if r_min is not None:
        df = df[df["R"] >= r_min]
    if r_max is not None:
        df = df[df["R"] <= r_max]
    if df.empty:
        raise ValueError(f"R window [{r_min}, {r_max}] selects no rows.")
    return (df["R"].to_numpy(),
            np.abs(df["total_bsse"].to_numpy()),
            n_all)


# ---------------------------------------------------------------------------
# Seeds
# ---------------------------------------------------------------------------
def make_seeds(N: int, bsse_max: float, n_seeds: int = 40) -> list[list[float]]:
    """
    Build starting points for an N-channel fit.

    Decay constants are seeded log-uniformly across the GPT range
    [0.05, 4.0] A^-2, which brackets every pair value the Ne aug-cc-pVDZ
    basis can produce. Amplitudes are seeded from the data scale.
    Deterministic (fixed RNG seed) so runs are reproducible.
    """
    rng = np.random.default_rng(20260725)
    seeds = []

    # One structured seed: channels evenly log-spaced across the GPT range.
    b_struct = np.logspace(np.log10(0.05), np.log10(4.0), N)
    seeds.append([v for b in b_struct
                  for v in (bsse_max / N, float(b))])

    # Remainder random within the same brackets.
    for _ in range(n_seeds - 1):
        b = np.sort(10 ** rng.uniform(np.log10(0.05), np.log10(4.0), N))
        a = rng.uniform(0.05, 3.0, N) * bsse_max
        seeds.append([v for pair in zip(a, b) for v in map(float, pair)])
    return seeds


# ---------------------------------------------------------------------------
# Fit one N
# ---------------------------------------------------------------------------
def fit_N(R: np.ndarray, bsse: np.ndarray, N: int, verbose: bool = True):
    """Multi-start fit of the N-channel model. Returns a result dict or None."""
    seeds = make_seeds(N, float(bsse.max()))
    best = None
    rmses = []

    for p0 in seeds:
        try:
            popt, pcov = curve_fit(n_gaussian, R, bsse, p0=p0, maxfev=100000)
        except Exception:
            continue
        if not np.all(np.isfinite(pcov)):
            perr = np.full(len(popt), np.inf)
        else:
            perr = np.sqrt(np.abs(np.diag(pcov)))
        pred = n_gaussian(R, *popt)
        if not np.all(np.isfinite(pred)):
            continue
        rmse = float(np.sqrt(np.mean((bsse - pred) ** 2)))
        rmses.append(rmse)
        if best is None or rmse < best["rmse"]:
            best = {"popt": popt, "perr": perr, "rmse": rmse}

    if best is None:
        if verbose:
            print(f"  N = {N}: ALL SEEDS FAILED TO CONVERGE")
        return None

    a, b, sa, sb = sort_channels(best["popt"], best["perr"])
    n = len(R)
    k = 2 * N
    rss = float(np.sum((bsse - n_gaussian(R, *best["popt"])) ** 2))
    aic = n * np.log(rss / n) + 2 * k
    bic = n * np.log(rss / n) + k * np.log(n)
    ss_tot = float(np.sum((bsse - bsse.mean()) ** 2))
    r2 = 1.0 - rss / ss_tot

    # Diagnostic 1: conditioning
    ratios_a = [sa[i] / abs(a[i]) if abs(a[i]) > 1e-12 else np.inf
                for i in range(N)]
    ratios_b = [sb[i] / abs(b[i]) if abs(b[i]) > 1e-12 else np.inf
                for i in range(N)]
    unconstrained = [f"a{i+1}" for i in range(N) if ratios_a[i] >= COND_TOL]
    unconstrained += [f"b{i+1}" for i in range(N) if ratios_b[i] >= COND_TOL]

    # Diagnostic 2: channel collapse
    collapsed = []
    for i in range(N):
        for j in range(i + 1, N):
            denom = max(abs(b[i]), abs(b[j]), 1e-12)
            if abs(b[i] - b[j]) / denom < COLLAPSE_TOL:
                collapsed.append((i + 1, j + 1, b[i], b[j]))

    n_at_best = sum(1 for r in rmses if abs(r - best["rmse"]) < SEED_MATCH_TOL)

    return {
        "N": N, "a": a, "b": b, "sa": sa, "sb": sb,
        "rmse": best["rmse"], "r2": r2, "aic": aic, "bic": bic,
        "unconstrained": unconstrained, "collapsed": collapsed,
        "n_seeds": len(seeds), "n_converged": len(rmses),
        "n_at_best": n_at_best,
        "ratios_a": ratios_a, "ratios_b": ratios_b,
        "popt": best["popt"],
    }


def report_N(res: dict, prev_rmse: float | None) -> None:
    N = res["N"]
    print("=" * 72)
    print(f"  N = {N} CHANNEL{'S' if N > 1 else ''}"
          f"   ({2*N} free parameters)")
    print("=" * 72)
    print(f"  seeds: {res['n_converged']}/{res['n_seeds']} converged, "
          f"{res['n_at_best']} reached the best minimum")
    print()
    print(f"  {'ch':>3}{'a_k (kcal/mol)':>20}{'sigma/|a|':>12}"
          f"{'b_k (A^-2)':>16}{'sigma/|b|':>12}")
    for i in range(N):
        print(f"  {i+1:>3}{res['a'][i]:>20.6f}{res['ratios_a'][i]:>12.3f}"
              f"{res['b'][i]:>16.6f}{res['ratios_b'][i]:>12.3f}")
    print()
    print(f"  RMSE = {res['rmse']:.6f} kcal/mol", end="")
    if prev_rmse is not None:
        impr = 100 * (prev_rmse - res["rmse"]) / prev_rmse
        print(f"   ({impr:+.1f}% vs N = {N-1})")
    else:
        print()
    print(f"  R^2  = {res['r2']:.6f}")
    print(f"  AIC  = {res['aic']:.2f}      BIC = {res['bic']:.2f}")
    print()

    # Diagnostic verdicts
    print("  DIAGNOSTIC 1 — conditioning:")
    if res["unconstrained"]:
        print(f"    ✗  UNCONSTRAINED (sigma/|p| >= {COND_TOL}): "
              f"{', '.join(res['unconstrained'])}")
    else:
        print(f"    ✓  all parameters constrained (sigma/|p| < {COND_TOL})")

    print("  DIAGNOSTIC 2 — channel collapse:")
    if res["collapsed"]:
        for i, j, bi, bj in res["collapsed"]:
            print(f"    ✗  channels {i} and {j} collapsed: "
                  f"b = {bi:.4f} vs {bj:.4f} "
                  f"(within {COLLAPSE_TOL*100:.0f}%)")
    else:
        print(f"    ✓  all channels distinct (>{COLLAPSE_TOL*100:.0f}% apart)")
    print()


def print_gpt_context(results: list[dict]) -> None:
    print("=" * 72)
    print("  GPT REFERENCE (Ne aug-cc-pVDZ)")
    print("=" * 72)
    print("  Same-exponent pair scales gamma = alpha/2  (A^-2):")
    for k, alpha in sorted(NE_AVDZ_EXPONENTS.items(),
                           key=lambda kv: -kv[1]):
        print(f"    {k:<16} gamma = {gpt_gamma(alpha, alpha):>7.3f}")
    print(f"\n  Full pair range: gamma in "
          f"[{GPT_GAMMAS[0]:.3f}, {GPT_GAMMAS[-1]:.3f}] A^-2 "
          f"over {len(GPT_GAMMAS)} distinct same-type pairs")
    print("\n  Fitted b_k by model order:")
    for res in results:
        bs = "  ".join(f"{v:.3f}" for v in res["b"])
        print(f"    N = {res['N']}:  {bs}")
    print()
    print("  Reminder: agreement here is a CONSISTENCY CHECK, not a")
    print("  derivation. The GPT fixes decay scales, not amplitudes, and the")
    print("  mapping from pair coupling to energy lowering carries an")
    print("  unresolved power ambiguity (one GPT factor vs its square).")
    print()


def print_summary(results: list[dict]) -> None:
    print("=" * 72)
    print("  SUMMARY")
    print("=" * 72)
    print(f"  {'N':>3}{'params':>8}{'RMSE':>12}{'R^2':>10}"
          f"{'AIC':>10}{'BIC':>10}{'cond':>7}{'collapse':>10}")
    for res in results:
        cond = "ok" if not res["unconstrained"] else "FAIL"
        coll = "ok" if not res["collapsed"] else "FAIL"
        print(f"  {res['N']:>3}{2*res['N']:>8}{res['rmse']:>12.6f}"
              f"{res['r2']:>10.6f}{res['aic']:>10.1f}{res['bic']:>10.1f}"
              f"{cond:>7}{coll:>10}")
    print()

    passing = [r for r in results
               if not r["unconstrained"] and not r["collapsed"]]
    print("  Largest N passing BOTH conditioning and collapse: ", end="")
    print(f"N = {max(r['N'] for r in passing)}" if passing else "NONE")
    if results:
        print(f"  Lowest AIC: N = {min(results, key=lambda r: r['aic'])['N']}"
              f"      Lowest BIC: "
              f"N = {min(results, key=lambda r: r['bic'])['N']}")
    print()
    print("  These are four signals, not a decision procedure. Conditioning")
    print("  and collapse are the trustworthy ones; AIC/BIC assume iid")
    print("  residuals, which these are not. If the signals disagree, that")
    print("  disagreement is the result and should be reported as such.")
    print()


# ---------------------------------------------------------------------------
# Plots
# ---------------------------------------------------------------------------
def plot_overlays(R, bsse, results) -> None:
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, color="black", zorder=5,
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    colors = ["tab:blue", "tab:orange", "tab:green", "tab:red",
              "tab:purple", "tab:brown"]
    for res, c in zip(results, colors):
        ax.plot(R_line, n_gaussian(R_line, *res["popt"]), "-", color=c, lw=1.6,
                label=fr"$N = {res['N']}$ (RMSE $= {res['rmse']:.4f}$)")
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.4)
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.4)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_n_gaussian_overlay{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")


def plot_residuals(R, bsse, results) -> None:
    n = len(results)
    fig, axes = plt.subplots(n, 1, figsize=(8, 2.2 * n), sharex=True)
    if n == 1:
        axes = [axes]
    for ax, res in zip(axes, results):
        resid = bsse - n_gaussian(R, *res["popt"])
        ax.axhline(0.0, color="grey", lw=0.8)
        ax.scatter(R, resid, s=14, color="black")
        ax.set_ylabel(fr"$N = {res['N']}$")
    axes[-1].set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    fig.supylabel(r"residual (kcal/mol)")
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_n_gaussian_residuals{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")


def plot_rmse_vs_N(results) -> None:
    fig, ax = plt.subplots(figsize=(6, 4.5))
    Ns = [r["N"] for r in results]
    ax.plot(Ns, [r["rmse"] for r in results], "o-", color="black")
    for r in results:
        if r["unconstrained"] or r["collapsed"]:
            ax.plot(r["N"], r["rmse"], "x", color="red", ms=12, mew=2)
    ax.plot([], [], "x", color="red", mew=2,
            label="fails conditioning or collapse")
    ax.set_xlabel(r"number of Gaussian channels $N$")
    ax.set_ylabel(r"RMSE (kcal/mol)")
    ax.set_xticks(Ns)
    ax.legend(frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_n_gaussian_rmse{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--N-max", dest="n_max", type=int, default=4,
                        help="Largest number of channels to try (default 4).")
    parser.add_argument("--R-min", dest="r_min", type=float, default=None,
                        metavar="R", help="Lower bound of the window (A).")
    parser.add_argument("--R-max", dest="r_max", type=float, default=None,
                        metavar="R", help="Upper bound of the window (A).")
    args = parser.parse_args()

    global SUFFIX
    SUFFIX = window_suffix(args.r_min, args.r_max)

    R, bsse, n_all = load_data(args.r_min, args.r_max)
    print(f"\nLoaded {n_all} points from {CSV_PATH.name}")
    if SUFFIX:
        print(f"  Analysis window: {len(R)}/{n_all} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A")
    else:
        print(f"  Analysis window: FULL GRID ({len(R)} points) — "
              f"DIAGNOSTIC, RMSE not comparable to the windowed fits")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print(f"  Output suffix: {SUFFIX or '(none)'}\n")

    results = []
    prev_rmse = None
    for N in range(1, args.n_max + 1):
        res = fit_N(R, bsse, N)
        if res is None:
            continue
        report_N(res, prev_rmse)
        prev_rmse = res["rmse"]
        results.append(res)

    if not results:
        print("No model order converged. Nothing to report.\n")
        return

    print_gpt_context(results)
    print_summary(results)
    plot_overlays(R, bsse, results)
    plot_residuals(R, bsse, results)
    plot_rmse_vs_N(results)
    print()


if __name__ == "__main__":
    main()
