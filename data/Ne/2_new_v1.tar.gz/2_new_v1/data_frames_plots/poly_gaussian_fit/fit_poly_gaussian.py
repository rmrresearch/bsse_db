"""
fit_poly_gaussian.py
--------------------
MODEL SELECTION within the POLYNOMIAL x GAUSSIAN family, applied to the SCF
component of the Ne dimer BSSE.

    BSSE_SCF(R) = P_1(R) exp(-B_1 R^2) + P_2(R) exp(-B_2 R^2)

with P_k quadratic. Fitted as a NESTED LADDER so the smallest member the data
supports can be identified, rather than assuming the full form.

WHERE THIS FORM COMES FROM (it is derived, not guessed)
-------------------------------------------------------
From the movecs sub-study (Ne/2_new/movecs_study) the signed, shell-pair
resolved density block P_AB was extracted on the same 67-point R grid, giving
110 channels. An SVD of that 110 x 67 matrix shows:

    rank-1 explains 74.0% of the amplitude-weighted variance
    rank-2 explains 89.6%   (94.2% over the 10 largest channels)

so the density coefficients are NOT a single common shape times constants, but
are well described by TWO universal shapes with channel-specific weights:

    P_ij(R) ~ c1_ij f_1(R) + c2_ij f_2(R)

Each shape was then tested against candidate forms:

    shape   pure Gaussian      poly2 x Gaussian
    f_1     R^2 = 0.933        R^2 = 0.989
    f_2     R^2 = 0.050        R^2 = 0.973

f_2 is essentially unfittable as a pure Gaussian. Both are quadratic
polynomial times Gaussian, with exponents 0.738 and 0.882 A^-2.

Contracting the density against the integrals,

    Delta E_SCF = f_1(R) [sum_ij c1_ij I_ij(R)] + f_2(R) [sum_ij c2_ij I_ij(R)]

and each bracket is a sum of Gaussians (the integrals carry exp(-gamma_ij R^2)
by the Gaussian product theorem). Gaussian x Gaussian adds exponents;
polynomial x polynomial stays polynomial. Hence the form above.

The POLYNOMIAL PREFACTOR IS REQUIRED BY THE MEASURED DENSITY. This is the
substantive difference from the pure N-Gaussian ladder, and it explains that
ladder's behaviour without any new assumption: a sum of pure Gaussians cannot
represent a polynomial prefactor, so extra channels subdivide the residual
into more ripples instead of removing it.

WHAT IS BEING FITTED
--------------------
Column 2b_bsse_SCF, SIGNED, in kcal/mol. NOT total_bsse.

The SCF component is the only one the block/GPT argument reaches; the MP2 and
CCSD(T) increments are separate empirical fits (steps 3 and 4 of the protocol).
Signed values are fitted per project convention -- absolute values are applied
at plot time only. Over this window 2b_bsse_SCF is single-signed, so the choice
does not change the fit, but it keeps the convention uniform for HF and H2O
where a component may cross zero.

THE LADDER
----------
    M1  a0 exp(-B R^2)                                    2 params
    M2  (a0 + a2 R^2) exp(-B R^2)                         3
    M3  (a0 + a1 R + a2 R^2) exp(-B R^2)                  4
    M4  (a0 + a2 R^2) e(-B1) + (c0 + c2 R^2) e(-B2)       6
    M5  full quadratic in both terms                      8

M1 is the pure Gaussian, included as the baseline the earlier study used.

THE DIAGNOSTICS
---------------
1. CONDITIONING          sigma/|p| per parameter. >= COND_TOL means the data
                         cannot place that parameter. A statement about
                         IDENTIFIABILITY, not fit quality.

2. RESIDUAL STRUCTURE    THE PRIMARY DIAGNOSTIC HERE, and the one that
                         separates the two possible failure modes:

                           - wrong FAMILY   -> residuals stay structured
                                               however many terms are added
                           - too many PARAMS -> residuals become structureless
                                               scatter, but error bars widen

                         The earlier N-Gaussian ladder showed smooth
                         sign-coherent ripples at every N: wrong family. If
                         this family is right, residual structure should
                         collapse even where parameters are poorly determined.

                         Measured two ways:
                           (a) Wald-Wolfowitz runs test on residual signs.
                               Structured residuals give far fewer runs than
                               the ~n/2 expected by chance; z is reported.
                           (b) lag-1 autocorrelation. Scatter gives ~0;
                               smooth ripples give values approaching 1.

3. CHANNEL COLLAPSE      For the two-term models, |B1 - B2| relative. Two
                         exponents converging means one channel written twice.

4. RMSE / R^2 / AIC / BIC
                         AIC and BIC assume independent identically
                         distributed residuals. Diagnostic 2 exists precisely
                         to test that assumption, so where it fails these
                         numbers are indicative only. Printed because they are
                         conventional, not because they settle anything.

No single diagnostic decides. If they agree, the truncation is defensible. If
they disagree, THAT is the finding and should be reported as such.

MULTI-START
-----------
Every model is fitted from many starting points; the number of local minima
grows with parameter count. Exponent seeds are drawn around the measured shape
exponents (0.738, 0.882 A^-2) and above -- B_k = gamma_k + Gamma_k where
Gamma_k comes from the integrals, so B_k > gamma_k is expected. Deterministic
RNG so runs reproduce.

Usage:
    python3 fit_poly_gaussian.py                     # R <= 3.5 window (67 pts)
    python3 fit_poly_gaussian.py --R-max 4.5         # full grid, diagnostic
    python3 fit_poly_gaussian.py --target total_bsse # compare on the total
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

SCRIPT_DIR = Path(__file__).resolve().parent
CSV_PATH = SCRIPT_DIR.parent / "ne_dimer_bsse_vs_R.csv"
SUFFIX = ""

# Thresholds, explicit so they can be argued with.
COND_TOL = 1.0          # sigma/|p| >= this -> parameter unconstrained
COLLAPSE_TOL = 0.10     # |B1-B2|/max(B) < this -> exponents collapsed
SEED_MATCH_TOL = 1e-9
RUNS_Z_TOL = 3.0        # |z| >= this -> residuals significantly non-random
ACF_TOL = 0.5           # lag-1 autocorrelation >= this -> smooth structure

# Shape exponents measured from the density SVD (movecs_study), A^-2.
# Used only to seed the optimiser; nothing is fixed to them.
SHAPE_GAMMA = (0.738, 0.882)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
def m1(R, a0, B):
    return a0 * np.exp(-B * R**2)


def m2(R, a0, a2, B):
    return (a0 + a2 * R**2) * np.exp(-B * R**2)


def m3(R, a0, a1, a2, B):
    return (a0 + a1 * R + a2 * R**2) * np.exp(-B * R**2)


def m4(R, a0, a2, B1, c0, c2, B2):
    return ((a0 + a2 * R**2) * np.exp(-B1 * R**2)
            + (c0 + c2 * R**2) * np.exp(-B2 * R**2))


def m5(R, a0, a1, a2, B1, c0, c1, c2, B2):
    return ((a0 + a1 * R + a2 * R**2) * np.exp(-B1 * R**2)
            + (c0 + c1 * R + c2 * R**2) * np.exp(-B2 * R**2))


MODELS = [
    ("M1", m1, ["a0", "B"],
     r"$a_0\,e^{-BR^2}$", 1),
    ("M2", m2, ["a0", "a2", "B"],
     r"$(a_0+a_2R^2)\,e^{-BR^2}$", 1),
    ("M3", m3, ["a0", "a1", "a2", "B"],
     r"$(a_0+a_1R+a_2R^2)\,e^{-BR^2}$", 1),
    ("M4", m4, ["a0", "a2", "B1", "c0", "c2", "B2"],
     r"$(a_0+a_2R^2)e^{-B_1R^2}+(c_0+c_2R^2)e^{-B_2R^2}$", 2),
    ("M5", m5, ["a0", "a1", "a2", "B1", "c0", "c1", "c2", "B2"],
     r"full quadratic, two terms", 2),
]


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
def window_suffix(r_min, r_max, target):
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace(".", "p"))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace(".", "p"))
    if target != "2b_bsse_SCF":
        parts.append(target)
    return ("_" + "_".join(parts)) if parts else ""


def load_data(target, r_min=None, r_max=None):
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    if target not in df.columns:
        raise SystemExit(f"Column {target!r} not in {CSV_PATH.name}. "
                         f"Available: {[c for c in df.columns if 'bsse' in c]}")
    n_all = len(df)
    if r_min is not None:
        df = df[df["R"] >= r_min]
    if r_max is not None:
        df = df[df["R"] <= r_max]
    if df.empty:
        raise ValueError(f"R window [{r_min}, {r_max}] selects no rows.")
    return df["R"].to_numpy(), df[target].to_numpy(), n_all


# ---------------------------------------------------------------------------
# Residual structure (diagnostic 2)
# ---------------------------------------------------------------------------
def runs_test(resid):
    """Wald-Wolfowitz runs test on residual signs.

    Returns (n_runs, expected, z). Under the null of independent residuals the
    number of sign runs is ~ 2*n_pos*n_neg/n + 1. Smooth, systematically
    signed residuals give far fewer runs, hence a large negative z.
    """
    s = np.sign(resid)
    s = s[s != 0]
    n = len(s)
    n_pos = int((s > 0).sum())
    n_neg = n - n_pos
    if n_pos == 0 or n_neg == 0:
        return 1, 1.0, -np.inf
    runs = 1 + int((np.diff(s) != 0).sum())
    mu = 2 * n_pos * n_neg / n + 1
    var = (2 * n_pos * n_neg * (2 * n_pos * n_neg - n)) / (n**2 * (n - 1))
    z = (runs - mu) / np.sqrt(var) if var > 0 else -np.inf
    return runs, mu, z


def lag1_acf(resid):
    """Lag-1 autocorrelation of the residuals. ~0 = scatter, ->1 = smooth."""
    r = resid - resid.mean()
    denom = np.sum(r * r)
    return float(np.sum(r[:-1] * r[1:]) / denom) if denom > 0 else 0.0


# ---------------------------------------------------------------------------
# Seeds
# ---------------------------------------------------------------------------
def make_seeds(names, scale, n_terms, n_seeds=60):
    """Starting points. Exponents seeded around the measured shape exponents
    and above; polynomial coefficients from the data scale."""
    rng = np.random.default_rng(20260727)
    seeds = []

    def one(structured):
        p = []
        term = 0
        for nm in names:
            if nm.startswith("B"):
                g = SHAPE_GAMMA[min(term, 1)]
                p.append(g if structured else float(10 ** rng.uniform(
                    np.log10(0.15), np.log10(4.0))))
                term += 1
            else:
                p.append(scale if structured else
                         float(rng.uniform(-3, 3) * scale))
        return p

    seeds.append(one(True))
    for _ in range(n_seeds - 1):
        seeds.append(one(False))
    return seeds


# ---------------------------------------------------------------------------
# Fit one model
# ---------------------------------------------------------------------------
def fit_model(R, y, name, fn, names, label, n_terms):
    seeds = make_seeds(names, float(np.abs(y).max()), n_terms)
    best, rmses = None, []

    for p0 in seeds:
        try:
            popt, pcov = curve_fit(fn, R, y, p0=p0, maxfev=400000)
        except Exception:
            continue
        pred = fn(R, *popt)
        if not np.all(np.isfinite(pred)):
            continue
        perr = (np.sqrt(np.abs(np.diag(pcov)))
                if np.all(np.isfinite(pcov)) else np.full(len(popt), np.inf))
        rmse = float(np.sqrt(np.mean((y - pred) ** 2)))
        rmses.append(rmse)
        if best is None or rmse < best["rmse"]:
            best = {"popt": popt, "perr": perr, "rmse": rmse}

    if best is None:
        return None

    popt, perr = best["popt"], best["perr"]
    resid = y - fn(R, *popt)
    n, k = len(R), len(popt)
    rss = float(np.sum(resid**2))
    aic = n * np.log(rss / n) + 2 * k
    bic = n * np.log(rss / n) + k * np.log(n)
    r2 = 1.0 - rss / float(np.sum((y - y.mean()) ** 2))

    ratios = [perr[i] / abs(popt[i]) if abs(popt[i]) > 1e-14 else np.inf
              for i in range(k)]
    unconstrained = [names[i] for i in range(k) if ratios[i] >= COND_TOL]

    collapsed = None
    if n_terms == 2:
        iB = [i for i, nm in enumerate(names) if nm.startswith("B")]
        B1, B2 = popt[iB[0]], popt[iB[1]]
        if abs(B1 - B2) / max(abs(B1), abs(B2), 1e-12) < COLLAPSE_TOL:
            collapsed = (B1, B2)

    runs, mu_runs, z = runs_test(resid)
    acf = lag1_acf(resid)

    return {"name": name, "fn": fn, "names": names, "label": label,
            "popt": popt, "perr": perr, "ratios": ratios, "k": k,
            "rmse": best["rmse"], "r2": r2, "aic": aic, "bic": bic,
            "unconstrained": unconstrained, "collapsed": collapsed,
            "runs": runs, "mu_runs": mu_runs, "z": z, "acf": acf,
            "resid": resid, "n_seeds": len(seeds), "n_conv": len(rmses),
            "n_at_best": sum(1 for r in rmses
                             if abs(r - best["rmse"]) < SEED_MATCH_TOL)}


def report(res, prev_rmse):
    print("=" * 74)
    print(f"  {res['name']}   {res['k']} free parameters")
    print("=" * 74)
    print(f"  seeds: {res['n_conv']}/{res['n_seeds']} converged, "
          f"{res['n_at_best']} reached the best minimum")
    print()
    print(f"  {'param':>6}{'value':>18}{'sigma':>16}{'sigma/|p|':>12}")
    for i, nm in enumerate(res["names"]):
        print(f"  {nm:>6}{res['popt'][i]:>18.6f}{res['perr'][i]:>16.6f}"
              f"{res['ratios'][i]:>12.3f}")
    print()
    print(f"  RMSE = {res['rmse']:.6f} kcal/mol", end="")
    if prev_rmse is not None:
        print(f"   ({100*(prev_rmse-res['rmse'])/prev_rmse:+.1f}% vs previous)")
    else:
        print()
    print(f"  R^2  = {res['r2']:.6f}")
    print(f"  AIC  = {res['aic']:.2f}      BIC = {res['bic']:.2f}")
    print()
    print("  DIAGNOSTIC 1 - conditioning:")
    if res["unconstrained"]:
        print(f"    x  UNCONSTRAINED (sigma/|p| >= {COND_TOL}): "
              f"{', '.join(res['unconstrained'])}")
    else:
        print(f"    ok all parameters constrained (sigma/|p| < {COND_TOL})")

    print("  DIAGNOSTIC 2 - residual structure  [PRIMARY]:")
    print(f"       runs = {res['runs']} vs {res['mu_runs']:.1f} expected, "
          f"z = {res['z']:+.2f}   lag-1 acf = {res['acf']:+.3f}")
    structured = abs(res["z"]) >= RUNS_Z_TOL or res["acf"] >= ACF_TOL
    if structured:
        print("    x  residuals STRUCTURED - the family does not capture "
              "the shape")
    else:
        print("    ok residuals consistent with scatter - family captures "
              "the shape")

    if res["collapsed"] is not None:
        print("  DIAGNOSTIC 3 - channel collapse:")
        print(f"    x  B1 = {res['collapsed'][0]:.4f} and "
              f"B2 = {res['collapsed'][1]:.4f} collapsed "
              f"(within {COLLAPSE_TOL*100:.0f}%)")
    print()


def summary(results):
    print("=" * 74)
    print("  SUMMARY")
    print("=" * 74)
    print(f"  {'model':>6}{'k':>4}{'RMSE':>12}{'R^2':>10}{'AIC':>9}{'BIC':>9}"
          f"{'cond':>7}{'resid':>12}")
    for r in results:
        cond = "ok" if not r["unconstrained"] else "FAIL"
        st = "STRUCTURED" if (abs(r["z"]) >= RUNS_Z_TOL or r["acf"] >= ACF_TOL) \
            else "scatter"
        print(f"  {r['name']:>6}{r['k']:>4}{r['rmse']:>12.6f}{r['r2']:>10.6f}"
              f"{r['aic']:>9.1f}{r['bic']:>9.1f}{cond:>7}{st:>12}")
    print()
    ok = [r for r in results
          if not r["unconstrained"]
          and abs(r["z"]) < RUNS_Z_TOL and r["acf"] < ACF_TOL
          and r["collapsed"] is None]
    if ok:
        best = min(ok, key=lambda r: r["k"])
        print(f"  Smallest model passing BOTH conditioning and residual "
              f"structure: {best['name']} ({best['k']} parameters)")
    else:
        print("  NO model passes both conditioning and residual structure.")
        print("  If residuals stay structured at every order, the family is")
        print("  wrong and the form must be revisited rather than patched.")
    print()
    print("  Read diagnostic 2 first. Structured residuals at every order")
    print("  indicate the wrong functional FAMILY; unconstrained parameters")
    print("  with unstructured residuals indicate the right family fitted")
    print("  with more terms than 67 points can place. These are different")
    print("  problems with different remedies.")
    print()


# ---------------------------------------------------------------------------
# Plots
# ---------------------------------------------------------------------------
def plot_overlay(R, y, results):
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, np.abs(y), s=20, color="black", zorder=5, label=r"data")
    Rl = np.linspace(R.min(), R.max(), 500)
    for r, c in zip(results, ["tab:blue", "tab:orange", "tab:green",
                              "tab:red", "tab:purple"]):
        ax.plot(Rl, np.abs(r["fn"](Rl, *r["popt"])), "-", color=c, lw=1.6,
                label=fr"{r['name']} (RMSE $= {r['rmse']:.4f}$)")
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}_{\mathrm{SCF}}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_poly_gaussian_overlay{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")


def plot_residuals(R, results):
    n = len(results)
    fig, axes = plt.subplots(n, 1, figsize=(8, 2.2 * n), sharex=True)
    if n == 1:
        axes = [axes]
    for ax, r in zip(axes, results):
        ax.axhline(0.0, color="grey", lw=0.8)
        ax.scatter(R, r["resid"], s=14, color="black")
        ax.set_ylabel(r["name"])
    axes[-1].set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    fig.supylabel(r"residual (kcal/mol)")
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_poly_gaussian_residuals{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")


def plot_rmse(results):
    fig, ax = plt.subplots(figsize=(6, 4.5))
    ks = [r["k"] for r in results]
    ax.plot(ks, [r["rmse"] for r in results], "o-", color="black")
    for r in results:
        bad = (r["unconstrained"] or abs(r["z"]) >= RUNS_Z_TOL
               or r["acf"] >= ACF_TOL or r["collapsed"] is not None)
        if bad:
            ax.plot(r["k"], r["rmse"], "x", color="red", ms=12, mew=2)
        ax.annotate(r["name"], (r["k"], r["rmse"]),
                    textcoords="offset points", xytext=(6, 6))
    ax.plot([], [], "x", color="red", mew=2,
            label="fails conditioning, structure or collapse")
    ax.set_xlabel(r"number of free parameters")
    ax.set_ylabel(r"RMSE (kcal/mol)")
    ax.legend(frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_poly_gaussian_rmse{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--R-min", dest="r_min", type=float, default=None)
    ap.add_argument("--R-max", dest="r_max", type=float, default=3.5,
                    help="Upper bound of the window (default 3.5 A).")
    ap.add_argument("--target", default="2b_bsse_SCF",
                    help="CSV column to fit (default 2b_bsse_SCF).")
    args = ap.parse_args()

    global SUFFIX
    SUFFIX = window_suffix(args.r_min, args.r_max, args.target)

    R, y, n_all = load_data(args.target, args.r_min, args.r_max)
    print(f"\nLoaded {n_all} points from {CSV_PATH.name}")
    print(f"  target : {args.target} (signed, kcal/mol)")
    print(f"  window : {len(R)}/{n_all} points, "
          f"R in [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  range  : [{y.min():.6f}, {y.max():.6f}] kcal/mol")
    print(f"  suffix : {SUFFIX or '(none)'}\n")

    results, prev = [], None
    for name, fn, names, label, nt in MODELS:
        res = fit_model(R, y, name, fn, names, label, nt)
        if res is None:
            print(f"  {name}: ALL SEEDS FAILED\n")
            continue
        report(res, prev)
        prev = res["rmse"]
        results.append(res)

    if not results:
        print("No model converged.\n")
        return

    summary(results)
    plot_overlay(R, y, results)
    plot_residuals(R, results)
    plot_rmse(results)
    print()


if __name__ == "__main__":
    main()
