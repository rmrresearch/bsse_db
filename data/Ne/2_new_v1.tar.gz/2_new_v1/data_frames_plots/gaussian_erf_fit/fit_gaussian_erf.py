"""
fit_gaussian_erf.py
-------------------
Fit the total CCSD(T) Ne dimer BSSE to a two-channel combined form:
|BSSE(R)| = a1 * [1 + erf(-b1 R)] + a2 * exp(-b2 R^2).

Physical motivation (handoff 011):
  - erf channel  -> Coulomb-type integrals via Boys function F_0(t)
    (V_ne, J, K)
  - Gaussian channel -> kinetic/overlap integrals (S_AB, T_AB)
  This is the "channel-mixing" empirical form; it is heuristic, not a
  first-principles derivation of BSSE.

Initial guess (Strategy B — physical channels):
  a1 = 1.0 kcal/mol, b1 = 0.3 A^-1    (erf handles long-R tail)
  a2 = 12.0 kcal/mol, b2 = 0.75 A^-2  (Gaussian handles steep bulk)

Workflow:
  1. Fit stage: nonlinear least squares on every point in the analysis
     window (no further filtering).
     Reports (a1, b1, a2, b2) +/- uncertainties, RMSE.
     Flags any ill-conditioning explicitly: if sigma(p) > |p| for any
     parameter, the data does not constrain it and the result must be
     interpreted with care.

  2. Correlation stage: predicted vs measured |BSSE| with OLS line for
     visual bias check and R^2_fit (linear space) as the comparison
     metric across forms.

  3. Residual stage: residual vs R, plus two quantitative tests of whether
     the residual is STRUCTURED or SCATTERED.

     This stage exists because RMSE and R^2_fit cannot distinguish the two
     ways a fit can be imperfect:

       - imprecise but correct family -> residuals scatter about zero
       - wrong family                 -> residuals form a smooth systematic
                                         shape, and adding terms subdivides
                                         that shape into more lobes rather
                                         than removing it

     A correlation plot near y = x with R^2_fit ~ 0.99 is compatible with
     BOTH. The residual is what separates them, which is why it is reported
     here alongside the other two stages rather than left to inspection.

     Two tests:
       runs      Wald-Wolfowitz count of residual sign runs. For n
                 independent residuals the expectation is ~n/2. A count in
                 the single digits means the residual holds its sign over
                 long stretches of R.
       lag-1 acf autocorrelation of consecutive residuals; ~0 for scatter,
                 approaching 1 for a smooth curve.

     Also reported is max|residual|, which can stay flat while RMSE falls.
     When that happens the extra channel is improving the tail and leaving
     the worst-case (peak) error untouched.

Note on the fit parameters:
  At R = 0 the form gives BSSE(0) = a1 + a2 (since erf(0) = 0 and
  exp(0) = 1). R = 0 lies far outside the sampled range, so any such
  extrapolation has no physical meaning. The fit is valid only within the
  sampled R range. See Ne dimer write-up.

Analysis window (--R-min / --R-max)
-----------------------------------
The consolidated CSV holds all 100 grid points over R in [1.5, 4.5] A.
The ANALYSIS WINDOW is a subset of that grid, and it MUST match the window
used by plot_bsse_vs_R.py, fit_gaussian.py and fit_erf.py. The headline
claim of this script is a RMSE COMPARISON against the two single-form
fits, and that comparison is only meaningful when all three forms were
fitted to exactly the same points.

The current agreed window is R <= 3.5 A (67 points):

    python3 fit_gaussian_erf.py --R-max 3.5

Applying a window appends a suffix to the output filenames
(e.g. ne_dimer_gaussian_erf_fit_Rmax3p5.png).

Reads:  ne_dimer_bsse_vs_R.csv  (uses |total_bsse| only)
Output: PNG files in the same directory as this script.

Usage:
    python3 fit_gaussian_erf.py --R-max 3.5
    python3 fit_gaussian_erf.py --R-max 3.5 --stage fit
    python3 fit_gaussian_erf.py --R-max 3.5 --stage residual
    python3 fit_gaussian_erf.py --stage all     # full 100-point grid
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.special import erf

# ---------------------------------------------------------------------------
# LaTeX rendering settings (consistent with build_bsse_vs_R.py / fit_erf.py)
# ---------------------------------------------------------------------------
plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
#   Script lives in:  .../data_frames_plots/gaussian_erf_fit/
#   CSV (read-only):  .../data_frames_plots/ne_dimer_bsse_vs_R.csv
#   Plots (output):   .../data_frames_plots/gaussian_erf_fit/
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent          # gaussian_erf_fit/
PARENT_DIR = SCRIPT_DIR.parent                        # data_frames_plots/
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

# Initial guesses (Strategy B — physical channels)
# erf handles long-R Coulomb-like tail; Gaussian handles short-R bulk.
# Verified seed-insensitive: multiple seeds converged to the same minimum.
A1_INIT = 1.0    # kcal/mol  (erf amplitude)
B1_INIT = 0.3    # A^-1      (erf decay)
A2_INIT = 12.0   # kcal/mol  (Gaussian amplitude)
B2_INIT = 0.75   # A^-2      (Gaussian decay)

# Set from the CLI in main(); appended to every output filename.
SUFFIX = ""


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def gaussian_erf(R: np.ndarray, a1: float, b1: float,
                 a2: float, b2: float) -> np.ndarray:
    """|BSSE|(R) = a1 * [1 + erf(-b1 R)] + a2 * exp(-b2 R^2).

    Two-channel combined form (Heindel erf + Gaussian).
    """
    return a1 * (1.0 + erf(-b1 * R)) + a2 * np.exp(-b2 * R**2)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def window_suffix(r_min: float | None, r_max: float | None) -> str:
    """Filename suffix encoding the analysis window; empty when unrestricted."""
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace(".", "p"))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace(".", "p"))
    return ("_" + "_".join(parts)) if parts else ""


def load_data(r_min: float | None = None,
              r_max: float | None = None) -> tuple[np.ndarray, np.ndarray, int]:
    """Return (R, |total_bsse|, n_all) in (A, kcal/mol), within the window."""
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    n_all = len(df)
    if r_min is not None:
        df = df[df["R"] >= r_min]
    if r_max is not None:
        df = df[df["R"] <= r_max]
    if df.empty:
        raise ValueError(f"R window [{r_min}, {r_max}] selects no rows.")
    R = df["R"].to_numpy()
    bsse_total_abs = np.abs(df["total_bsse"].to_numpy())
    return R, bsse_total_abs, n_all


# ---------------------------------------------------------------------------
# Conditioning check
# ---------------------------------------------------------------------------
def check_conditioning(params: dict[str, tuple[float, float]]) -> list[str]:
    """Flag parameters where sigma >= |p| (data does not constrain them).

    Returns list of warning strings; empty list if all parameters are
    well-conditioned.
    """
    warnings = []
    for name, (p, sigma) in params.items():
        if abs(p) < 1e-12:
            ratio = float("inf") if sigma > 0 else 0.0
        else:
            ratio = sigma / abs(p)
        if ratio >= 1.0:
            warnings.append(
                f"    {name}: sigma/|p| = {ratio:.2f}  "
                f"(p = {p:.4f}, sigma = {sigma:.4f}) — UNCONSTRAINED"
            )
    return warnings


# ---------------------------------------------------------------------------
# Stage 1: nonlinear least squares
# ---------------------------------------------------------------------------
def run_fit(R: np.ndarray, bsse: np.ndarray,
            a1_0: float, b1_0: float,
            a2_0: float, b2_0: float,
            bounded: bool = False
            ) -> tuple[float, float, float, float,
                       float, float, float, float, float]:
    """Nonlinear LS on |BSSE| = a1*[1+erf(-b1 R)] + a2*exp(-b2 R^2).

    Returns (a1, sigma_a1, b1, sigma_b1, a2, sigma_a2, b2, sigma_b2, rmse).
    """
    if bounded:
        # b1 > 0 forces erf(-b1 R) to DECAY, as the Heindel-Xantheas
        # derivation intends. The other three parameters stay free.
        lo = [-np.inf, 1.0e-8, -np.inf, -np.inf]
        hi = [np.inf, np.inf, np.inf, np.inf]
        b1_0 = max(b1_0, 1.0e-3)      # p0 must lie strictly inside bounds
        popt, pcov = curve_fit(gaussian_erf, R, bsse,
                               p0=[a1_0, b1_0, a2_0, b2_0],
                               bounds=(lo, hi), maxfev=20000)
    else:
        popt, pcov = curve_fit(gaussian_erf, R, bsse,
                               p0=[a1_0, b1_0, a2_0, b2_0],
                               maxfev=5000)
    a1, b1, a2, b2 = popt
    sigma_a1, sigma_b1, sigma_a2, sigma_b2 = np.sqrt(np.diag(pcov))

    pred = gaussian_erf(R, a1, b1, a2, b2)
    residuals = bsse - pred
    rmse = float(np.sqrt(np.mean(residuals**2)))

    print("=" * 60)
    mode = "BOUNDED b1 > 0" if bounded else "FREE"
    print(f"STAGE 1 — NONLINEAR LS FIT (combined Gaussian + erf) [{mode}]:")
    print("  |BSSE| = a1 * [1 + erf(-b1 R)] + a2 * exp(-b2 R^2)")
    print("=" * 60)
    print(f"  Initial guess (Strategy B):")
    print(f"    a1_0 = {a1_0:.4f} kcal/mol,  b1_0 = {b1_0:.4f} A^-1")
    print(f"    a2_0 = {a2_0:.4f} kcal/mol,  b2_0 = {b2_0:.4f} A^-2")
    print(f"  Points used: {len(R)} (no filter)")
    print()
    print(f"  a1           = {a1: .6f} +/- {sigma_a1: .6f}  kcal/mol")
    print(f"  b1           = {b1: .6f} +/- {sigma_b1: .6f}  A^-1")
    print(f"  a2           = {a2: .6f} +/- {sigma_a2: .6f}  kcal/mol")
    print(f"  b2           = {b2: .6f} +/- {sigma_b2: .6f}  A^-2")
    print(f"  RMSE         = {rmse: .6f}  kcal/mol")
    if bounded and b1 < 1.0e-6:
        print()
        print("  NOTE: b1 is PINNED at the lower bound. The covariance is")
        print("        not meaningful at an active constraint. The form")
        print("        wants b1 <= 0 and is being prevented from getting")
        print("        there — this is the result, not a numerical fault.")
    print()

    # Conditioning check
    cond = check_conditioning({
        "a1": (a1, sigma_a1),
        "b1": (b1, sigma_b1),
        "a2": (a2, sigma_a2),
        "b2": (b2, sigma_b2),
    })
    if cond:
        print("  CONDITIONING WARNING — parameter(s) not constrained by data:")
        for w in cond:
            print(w)
        print("    Interpretation: the data may not contain enough")
        print("    independent information to distinguish both channels.")
        print("    See Ne dimer write-up; consider polynomial-corrected")
        print("    Gaussian as alternative refinement.")
    else:
        print("  All parameters well-conditioned (sigma/|p| < 1).")
    print()
    print(f"  Note: fit is valid over R in [{R.min():.3f}, {R.max():.3f}] A.")
    print(f"        At R = 0 the form gives a1 + a2, but R = 0 is outside")
    print(f"        the data range and physically inaccessible. See write-up.")
    print()

    # Overlay plot
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, alpha=1.0, color="black",
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    ax.plot(R_line, gaussian_erf(R_line, a1, b1, a2, b2), "r-", lw=2,
            label=(fr"fit: $|\mathrm{{BSSE}}| = {a1:.3f}\,[1 + \mathrm{{erf}}({-b1:.3f}\,R)]"
                   fr" + {a2:.3f}\,\exp(-{b2:.3f}\,R^2)$"
                   "\n"
                   fr"($a_1 = {a1:.3f}$ kcal/mol, $b_1 = {b1:.3f}\,$\AA$^{{-1}}$,"
                   "\n"
                   fr"\ \ $a_2 = {a2:.3f}$ kcal/mol, $b_2 = {b2:.3f}\,$\AA$^{{-2}}$)"
                   "\n"
                   fr"RMSE $= {rmse:.4f}$ kcal/mol"))
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.5,
               label=r"1 kcal/mol threshold")
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_gaussian_erf_fit{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()

    return a1, sigma_a1, b1, sigma_b1, a2, sigma_a2, b2, sigma_b2, rmse


# ---------------------------------------------------------------------------
# Stage 2: correlation plot
# ---------------------------------------------------------------------------
def run_correlation(R: np.ndarray, bsse: np.ndarray,
                    a1: float, b1: float,
                    a2: float, b2: float) -> float:
    """Predicted vs measured |BSSE|. Returns R^2_fit (linear-space)."""
    pred = gaussian_erf(R, a1, b1, a2, b2)
    ss_res = np.sum((bsse - pred) ** 2)
    ss_tot = np.sum((bsse - bsse.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    # OLS regression line for visual bias check
    m, c = np.polyfit(pred, bsse, 1)
    c_sign = "-" if c < 0 else "+"
    c_abs = abs(c)

    print("=" * 60)
    print("STAGE 2 — CORRELATION: measured vs predicted |BSSE|")
    print("=" * 60)
    print(f"  R^2_fit (linear space) = {r2: .6f}")
    print(f"  OLS regression line (visual only):"
          f"  measured = {m:.4f} * predicted + {c:.4f}")
    print()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(pred, bsse, s=25, alpha=1.0, color="black")
    lo = 0.0
    hi = max(bsse.max(), pred.max()) * 1.05

    x_line = np.linspace(lo, hi, 200)
    ax.plot(x_line, m * x_line + c, "r--", lw=1.5,
            label=fr"$y = {m:.4f}\,x {c_sign} {c_abs:.4f}$")
    ax.plot([], [], " ", label=fr"$R^2_\mathrm{{fit}} = {r2:.4f}$")

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(r"predicted $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_ylabel(r"measured $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_aspect("equal", "box")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_gaussian_erf_correlation{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return r2


# ---------------------------------------------------------------------------
# Stage 3: residual structure
# ---------------------------------------------------------------------------
def runs_test(resid: np.ndarray) -> tuple[int, float]:
    """Wald-Wolfowitz runs test on residual signs.

    Returns (observed runs, expected runs under independence). Zero-valued
    residuals are dropped; they carry no sign information.
    """
    s = np.sign(resid)
    s = s[s != 0]
    n = len(s)
    n_pos = int((s > 0).sum())
    n_neg = n - n_pos
    runs = 1 + int((np.diff(s) != 0).sum())
    if n_pos == 0 or n_neg == 0:
        return runs, 1.0
    return runs, 2.0 * n_pos * n_neg / n + 1.0


def run_residual(R: np.ndarray, bsse: np.ndarray,
                 a1: float, b1: float, a2: float, b2: float) -> float:
    """Residual vs R, with structure diagnostics. Returns RMSE."""
    pred = gaussian_erf(R, a1, b1, a2, b2)
    resid = bsse - pred
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    runs, exp_runs = runs_test(resid)
    acf = float(np.corrcoef(resid[:-1], resid[1:])[0, 1])
    i_max = int(np.abs(resid).argmax())

    print("=" * 60)
    print("STAGE 3 — RESIDUAL STRUCTURE")
    print("=" * 60)
    print(f"  RMSE            = {rmse: .6f}  kcal/mol")
    print(f"  max |residual|  = {np.abs(resid).max(): .6f}  kcal/mol"
          f"   at R = {R[i_max]:.3f} A")
    print(f"  mean residual   = {resid.mean(): .6f}  kcal/mol")
    print()
    print(f"  sign runs       = {runs:d}   (expected ~{exp_runs:.0f} "
          f"if residuals were independent)")
    print(f"  lag-1 acf       = {acf: .4f}   (~0 scatter, ->1 smooth)")
    print()
    if runs < 0.5 * exp_runs or acf > 0.5:
        print("  VERDICT: residuals are STRUCTURED, not scatter.")
        print("    The form is missing a systematic shape rather than being")
        print("    merely imprecise. RMSE and R^2_fit cannot see this, so")
        print("    they should not be quoted alone as evidence the form is")
        print("    adequate.")
    else:
        print("  VERDICT: residuals consistent with scatter.")
        print("    No systematic shape detected at this resolution.")
    print()

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.axhline(0.0, color="grey", lw=0.8)
    ax.scatter(R, resid, s=20, color="black")
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"residual (kcal/mol)")
    ax.text(0.98, 0.95,
            fr"RMSE $= {rmse:.4f}$" "\n"
            fr"runs $= {runs}$ (exp.\ ${exp_runs:.0f}$)" "\n"
            fr"lag-1 acf $= {acf:.3f}$",
            transform=ax.transAxes, ha="right", va="top", fontsize=9)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_gaussian_erf_residuals{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return rmse


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",
                        choices=["fit", "correlation", "residual", "all"],
                        default="all",
                        help="Which stage to run")
    parser.add_argument("--R-min", dest="r_min", type=float, default=None,
                        metavar="R",
                        help="Lower bound of the analysis window (A).")
    parser.add_argument("--R-max", dest="r_max", type=float, default=None,
                        metavar="R",
                        help="Upper bound of the analysis window (A). Must "
                             "match the window used by the other two fits, "
                             "or the RMSE comparison is meaningless.")
    parser.add_argument("--bounded", action="store_true",
                        help="Constrain b1 > 0 so the erf term decays "
                             "instead of saturating (handoff 05-28 5.4).")
    args = parser.parse_args()

    global SUFFIX
    SUFFIX = window_suffix(args.r_min, args.r_max)
    if args.bounded:
        SUFFIX += "_b1pos"

    R, bsse, n_all = load_data(args.r_min, args.r_max)
    print(f"Loaded {n_all} points from {CSV_PATH.name}")
    if SUFFIX:
        print(f"  Analysis window: {len(R)}/{n_all} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A")
    else:
        print(f"  Analysis window: FULL GRID ({len(R)} points)")
    print(f"  R range:      [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print(f"  Output suffix: {SUFFIX or '(none)'}")
    print()

    a1 = b1 = a2 = b2 = None

    if args.stage in ("fit", "all"):
        a1, _, b1, _, a2, _, b2, _, _ = run_fit(
            R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT,
            bounded=args.bounded
        )

    if args.stage in ("correlation", "all"):
        if a1 is None:
            a1, _, b1, _, a2, _, b2, _, _ = run_fit(
                R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT,
                bounded=args.bounded
            )
        run_correlation(R, bsse, a1, b1, a2, b2)

    if args.stage in ("residual", "all"):
        if a1 is None:
            a1, _, b1, _, a2, _, b2, _, _ = run_fit(
                R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT,
                bounded=args.bounded
            )
        run_residual(R, bsse, a1, b1, a2, b2)


if __name__ == "__main__":
    main()
