"""
fit_gaussian.py
---------------
Test whether the total CCSD(T) Ne dimer BSSE follows a Gaussian
in R: |BSSE(R)| = a * exp(-b R^2).

Workflow:
  1. Diagnostic stage: ln|BSSE| vs R^2 with OLS linear fit.
     Filter |BSSE| > 0.01 kcal/mol so log is well-defined.
     Criterion: R^2 >= 0.9 supports Gaussian form strongly,
     0.8 <= R^2 < 0.9 acceptable with caveat, < 0.8 stop.

  2. Fit stage: nonlinear least squares |BSSE| = a * exp(-b R^2)
     on every point in the analysis window (no further filtering).
     Initial guess from the diagnostic OLS slope/intercept.

  3. Correlation stage: predicted vs. measured |BSSE| with y = x
     reference and R^2 reported in the panel.

Analysis window (--R-min / --R-max)
-----------------------------------
The consolidated CSV holds all 100 grid points over R in [1.5, 4.5] A.
The ANALYSIS WINDOW is a subset of that grid, and it MUST match the window
used for the figures produced by plot_bsse_vs_R.py. If the two differ, the
RMSE quoted in the text will not correspond to the curve shown in the
figure.

The current agreed window is R <= 3.5 A (67 points):

    python3 fit_gaussian.py --R-max 3.5

Applying a window appends a suffix to the output filenames
(e.g. ne_dimer_gaussian_fit_Rmax3p5.png) so a windowed figure can never
silently overwrite a full-range one.

Reads:  ne_dimer_bsse_vs_R.csv  (uses |total_bsse| only)
Output: PNG files in the same directory.

Usage:
    python3 fit_gaussian.py --R-max 3.5
    python3 fit_gaussian.py --R-max 3.5 --stage diagnostic
    python3 fit_gaussian.py --stage all          # full 100-point grid
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

# ---------------------------------------------------------------------------
# LaTeX rendering settings (consistent with build_bsse_vs_R.py)
# ---------------------------------------------------------------------------
plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
#   Script lives in:  .../data_frames_plots/gaussian_fit/
#   CSV (read-only):  .../data_frames_plots/ne_dimer_bsse_vs_R.csv
#   Plots (output):   .../data_frames_plots/gaussian_fit/
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent          # gaussian_fit/
PARENT_DIR = SCRIPT_DIR.parent                        # data_frames_plots/
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

# Diagnostic filter for log-space safety
LOG_FILTER_THRESHOLD = 0.01  # kcal/mol

# Set from the CLI in main(); appended to every output filename.
SUFFIX = ""

# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def gaussian(R: np.ndarray, a: float, b: float) -> np.ndarray:
    """|BSSE|(R) = a * exp(-b R^2)."""
    return a * np.exp(-b * R**2)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def window_suffix(r_min: float | None, r_max: float | None) -> str:
    """Filename suffix encoding the analysis window; empty when unrestricted."""
    parts = []
    if r_min is not None:
        parts.append("Rmin" + f"{r_min:g}".replace(".", "p"))
    if r_max is not None:
        parts.append("Rmax" + f"{r_max:g}".replace(".", "p"))
    return ("_" + "_".join(parts)) if parts else ""


def load_data(r_min: float | None = None,
              r_max: float | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Return (R, |total_bsse|) in (A, kcal/mol), restricted to the window."""
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    n_all = len(df)
    if r_min is not None:
        df = df[df["R"] >= r_min]
    if r_max is not None:
        df = df[df["R"] <= r_max]
    if df.empty:
        raise ValueError(f"R window [{r_min}, {r_max}] selects no rows.")
    R = df["R"].to_numpy()
    bsse_total_abs = np.abs(df["total_bsse"].to_numpy())
    return R, bsse_total_abs, n_all


# ---------------------------------------------------------------------------
# Stage 1: diagnostic (log-linear)
# ---------------------------------------------------------------------------
def run_diagnostic(R: np.ndarray, bsse: np.ndarray) -> tuple[float, float, float]:
    """OLS fit of ln|BSSE| vs R^2. Returns (slope, intercept, R^2)."""
    mask = bsse > LOG_FILTER_THRESHOLD
    R_f = R[mask]
    bsse_f = bsse[mask]
    n_dropped = (~mask).sum()

    x = R_f**2
    y = np.log(bsse_f)

    # OLS via numpy
    slope, intercept = np.polyfit(x, y, 1)
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    # Implied Gaussian params
    a0 = float(np.exp(intercept))
    b0 = float(-slope)

    print("=" * 60)
    print("STAGE 1 — DIAGNOSTIC: ln|BSSE_total| vs R^2")
    print("=" * 60)
    print(f"  Points used:        {len(R_f)} / {len(R)}  (dropped {n_dropped}"
          f" with |BSSE| <= {LOG_FILTER_THRESHOLD} kcal/mol)")
    print(f"  slope            = {slope: .6f}")
    print(f"  intercept        = {intercept: .6f}")
    print(f"  R^2 (log space)  = {r2: .6f}")
    print(f"  implied a (kcal/mol) = {a0: .6f}")
    print(f"  implied b (A^-2)     = {b0: .6f}")
    print()
    if r2 >= 0.9:
        verdict = "STRONG support for Gaussian form (R^2 >= 0.9)."
    elif r2 >= 0.8:
        verdict = "ACCEPTABLE support for Gaussian form (0.8 <= R^2 < 0.9)."
    else:
        verdict = "WEAK support for Gaussian form (R^2 < 0.8). STOP and discuss."
    print(f"  Verdict: {verdict}")
    print()

    # Plot
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(x, y, s=25, alpha=0.7, label="data")
    x_line = np.linspace(x.min(), x.max(), 200)
    ax.plot(x_line, slope * x_line + intercept, "r-", lw=2,
            label=fr"OLS: slope $= {slope:.3f}$, $R^2 = {r2:.4f}$")
    ax.set_xlabel(r"$R^2_{\ce{Ne-Ne}}$ (\AA$^2$)")
    ax.set_ylabel(r"$\ln |\mathrm{BSSE}_\mathrm{total}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_gaussian_diagnostic{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return a0, b0, r2


# ---------------------------------------------------------------------------
# Stage 2: nonlinear least squares
# ---------------------------------------------------------------------------
def run_fit(R: np.ndarray, bsse: np.ndarray,
            a0: float, b0: float) -> tuple[float, float, float, float, float]:
    """Nonlinear LS on |BSSE| = a*exp(-b R^2).
    Returns (a, sigma_a, b, sigma_b, rmse)."""
    popt, pcov = curve_fit(gaussian, R, bsse, p0=[a0, b0])
    a, b = popt
    sigma_a, sigma_b = np.sqrt(np.diag(pcov))
    pred = gaussian(R, a, b)
    residuals = bsse - pred
    rmse = float(np.sqrt(np.mean(residuals**2)))

    print("=" * 60)
    print("STAGE 2 — NONLINEAR LS FIT: |BSSE| = a * exp(-b R^2)")
    print("=" * 60)
    print(f"  Initial guess: a0 = {a0:.6f}, b0 = {b0:.6f}")
    print(f"  Points used:   {len(R)} (no filter)")
    print(f"  a            = {a: .6f} +/- {sigma_a: .6f}  kcal/mol")
    print(f"  b            = {b: .6f} +/- {sigma_b: .6f}  A^-2")
    print(f"  RMSE         = {rmse: .6f}  kcal/mol")
    print()

    # Overlay plot: data + fitted curve
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, alpha=1.0, color="black",
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    ax.plot(R_line, gaussian(R_line, a, b), "r-", lw=2,
            label=(fr"fit: $|\mathrm{{BSSE}}| = {a:.3f}\,\exp(-{b:.3f}\,R^2)$"
                   "\n"
                   fr"($a = {a:.3f}$ kcal/mol, $b = {b:.3f}\,$\AA$^{{-2}}$)"
                   "\n"
                   fr"RMSE $= {rmse:.4f}$ kcal/mol"))
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.5,
               label=r"1 kcal/mol threshold")
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    #ax.set_title(r"Gaussian fit to total CCSD(T) Ne dimer BSSE")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_gaussian_fit{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()

    return a, sigma_a, b, sigma_b, rmse


# ---------------------------------------------------------------------------
# Stage 3: correlation plot
# ---------------------------------------------------------------------------
def run_correlation(R: np.ndarray, bsse: np.ndarray,
                    a: float, b: float) -> float:
    """Predicted vs measured |BSSE|. Returns R^2 (linear-space)."""
    pred = gaussian(R, a, b)
    ss_res = np.sum((bsse - pred) ** 2)
    ss_tot = np.sum((bsse - bsse.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    # OLS regression line: measured = m * predicted + c
    # Shown for visual bias check only; its R^2 is NOT reported (R^2_fit is).
    m, c = np.polyfit(pred, bsse, 1)

    print("=" * 60)
    print("STAGE 3 — CORRELATION: measured vs predicted |BSSE|")
    print("=" * 60)
    print(f"  R^2_fit (linear space) = {r2: .6f}")
    print(f"  OLS regression line (visual only):"
          f"  measured = {m:.4f} * predicted + {c:.4f}")
    print()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(pred, bsse, s=25, alpha=1.0, color="black")
    lo = 0.0
    hi = max(bsse.max(), pred.max()) * 1.05

    # OLS regression line through the points (red dashed)
    x_line = np.linspace(lo, hi, 200)
    ax.plot(x_line, m * x_line + c, "r--", lw=1.5,
            label=fr"$y = {m:.3f}\,x + {c:.3f}$")

    # R^2_fit as a non-line legend entry
    ax.plot([], [], " ", label=fr"$R^2_\mathrm{{fit}} = {r2:.4f}$")

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(r"predicted $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_ylabel(r"measured $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_aspect("equal", "box")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / f"ne_dimer_gaussian_correlation{SUFFIX}.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return r2


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",
                        choices=["diagnostic", "fit", "correlation", "all"],
                        default="all",
                        help="Which stage to run")
    parser.add_argument("--R-min", dest="r_min", type=float, default=None,
                        metavar="R",
                        help="Lower bound of the analysis window (A).")
    parser.add_argument("--R-max", dest="r_max", type=float, default=None,
                        metavar="R",
                        help="Upper bound of the analysis window (A). Must "
                             "match the window used for the figures.")
    args = parser.parse_args()

    global SUFFIX
    SUFFIX = window_suffix(args.r_min, args.r_max)

    R, bsse, n_all = load_data(args.r_min, args.r_max)
    print(f"Loaded {n_all} points from {CSV_PATH.name}")
    if SUFFIX:
        print(f"  Analysis window: {len(R)}/{n_all} points, "
              f"R in [{R.min():.3f}, {R.max():.3f}] A")
    else:
        print(f"  Analysis window: FULL GRID ({len(R)} points)")
    print(f"  R range:      [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print(f"  Output suffix: {SUFFIX or '(none)'}")
    print()

    a0 = b0 = None
    a = b = None

    if args.stage in ("diagnostic", "all"):
        a0, b0, _ = run_diagnostic(R, bsse)

    if args.stage in ("fit", "all"):
        if a0 is None:
            # If running 'fit' alone, generate seed from diagnostic silently
            a0, b0, _ = run_diagnostic(R, bsse)
        a, _, b, _, _ = run_fit(R, bsse, a0, b0)

    if args.stage in ("correlation", "all"):
        if a is None:
            if a0 is None:
                a0, b0, _ = run_diagnostic(R, bsse)
            a, _, b, _, _ = run_fit(R, bsse, a0, b0)
        run_correlation(R, bsse, a, b)


if __name__ == "__main__":
    main()
