#!/usr/bin/env python3
"""
parse_scf_convergence.py — one-shot plausibility parser (Ne/2_new).

Question this addresses
-----------------------
The one-shot hypothesis: E_A(AB) at the SCF level can be obtained from a
single Fock build + diagonalization (no SCF self-consistency loop), because
the SCF relaxation WITHIN the A∪B basis is negligible.

The direct evidence is the ghost-basis SCF (A_AB): how much does the energy
move from the FIRST iteration to the CONVERGED value? If that "relaxation"
is far below the 1 kcal/mol accuracy target across all R, iterating buys
almost nothing and the one-shot is plausible.

NOTE (scope): this is about the SCF part of BSSE only. It does NOT address
the correlation (MP2c / CCSD(T)c) BSSE — a separate mechanism (CBI) not
touched by an SCF one-shot. That is a deliberate, agreed scope boundary.

What it extracts, per R
-----------------------
From A_AB.out (the one-shot target — monomer A in the union basis):
  n_iter_AB       : number of SCF iterations to convergence
  E_iter1_AB      : SCF energy after the first Fock build/diagonalization (Ha)
  E_conv_AB       : converged SCF energy (Ha)
  relaxation_kcal : (E_conv_AB - E_iter1_AB) * 627.509  [kcal/mol]
                    ← the headline one-shot-error proxy

From A_A.out (sanity only — monomer A in its own basis):
  n_iter_A        : should be ~1 (monomer trivially converged from SAD guess)

Interpretation guidance (agreed with parent chat)
-------------------------------------------------
- relaxation_kcal is the honest measure, NOT n_iter. NWChem needs a couple
  of cycles just to VERIFY convergence against its threshold even when it is
  already there, so n_iter overstates the necessary work.
- If max |relaxation_kcal| stays well under ~0.01 kcal/mol across all 100 R,
  the one-shot is plausible on this evidence. Any R exceeding that is flagged.
- This is EVIDENCE for discussion, NOT a conclusion. No claim is drawn here.

Layout
------
  Ne/2_new/one_shot_study/scripts/parse_scf_convergence.py   (this file)
  Ne/2_new/R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/{A_A,A_AB}.out
  Ne/2_new/one_shot_study/scf_convergence/scf_convergence.csv (output)

Usage
-----
  python3 parse_scf_convergence.py            # all 100 R -> CSV + summary
  python3 parse_scf_convergence.py --summary  # summary only, no CSV write
"""

import argparse
import csv
from pathlib import Path

import numpy as np

HART2KCAL = 627.5094740631

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent               # one_shot_study/scripts/
STUDY_DIR  = SCRIPT_DIR.parent                             # one_shot_study/
R_CONFIG   = STUDY_DIR.parent / "R_config"                 # Ne/2_new/R_config/
OUT_DIR    = STUDY_DIR / "scf_convergence"
OUT_CSV    = OUT_DIR / "scf_convergence.csv"

# ── Grid (matches generate_nw_inputs.py / check_convergence.py) ───────────────
R_VALUES = np.linspace(1.5, 4.5, 100)


def r_to_label(r: float) -> str:
    """1.5303030303 -> '1p530' (3-decimal folder label)."""
    return f"{r:.3f}".replace(".", "p")


def parse_scf_table(path: Path):
    """
    Return the list of per-iteration SCF energies (Ha) from an NWChem RHF
    iteration table, or None if the table is absent.

    Reads rows after the 'iter energy gnorm gmax time' header (skipping the
    dashed separator) until the first non-data line. Handles a variable
    number of iteration rows.
    """
    if not path.exists():
        return None
    lines = path.read_text(errors="replace").splitlines()

    hdr = None
    for i, ln in enumerate(lines):
        if "iter" in ln and "energy" in ln and "gnorm" in ln:
            hdr = i
            break
    if hdr is None:
        return None

    energies = []
    j = hdr + 2  # skip header + dashed line
    while j < len(lines):
        row = lines[j].split()
        if len(row) >= 2 and row[0].isdigit():
            try:
                energies.append(float(row[1]))
            except ValueError:
                break
            j += 1
        else:
            break
    return energies if energies else None


def resolve_folder(label: str):
    """Glob the bare R label to its NNN-prefixed folder. Returns Path or None."""
    matches = sorted(R_CONFIG.glob(f"*_R_{label}"))
    return matches[0] if len(matches) == 1 else None


def process_R(r_value: float):
    """Return a result dict for one R, or a dict with error set."""
    label = r_to_label(r_value)
    folder = resolve_folder(label)
    row = {
        "R": round(r_value, 4), "label": label,
        "n_iter_AB": None, "E_iter1_AB": None, "E_conv_AB": None,
        "relaxation_kcal": None, "n_iter_A": None, "note": "",
    }
    if folder is None:
        row["note"] = "folder not found"
        return row

    leaf = folder / "CCSD_T" / "aug-cc-pvdz"
    e_ab = parse_scf_table(leaf / "A_AB.out")
    e_a  = parse_scf_table(leaf / "A_A.out")

    if e_ab is None:
        row["note"] = "A_AB iteration table missing"
        return row

    row["n_iter_AB"]  = len(e_ab)
    row["E_iter1_AB"] = e_ab[0]
    row["E_conv_AB"]  = e_ab[-1]
    row["relaxation_kcal"] = (e_ab[-1] - e_ab[0]) * HART2KCAL
    row["n_iter_A"] = len(e_a) if e_a is not None else None
    return row


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--summary", action="store_true",
                    help="Print summary only; do not write the CSV.")
    args = ap.parse_args()

    rows = [process_R(r) for r in R_VALUES]

    good = [r for r in rows if r["relaxation_kcal"] is not None]
    bad  = [r for r in rows if r["relaxation_kcal"] is None]

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"Parsed {len(good)}/{len(rows)} R values with an A_AB iteration table.")
    if bad:
        print(f"  {len(bad)} problem file(s):")
        for r in bad:
            print(f"    R={r['R']:.4f} ({r['label']}): {r['note']}")

    if good:
        relax = np.array([r["relaxation_kcal"] for r in good])
        niter = np.array([r["n_iter_AB"] for r in good])
        absrelax = np.abs(relax)

        print("\n── Relaxation (E_conv − E_iter1), the one-shot-error proxy ──")
        print(f"  max |relaxation| : {absrelax.max():.6f} kcal/mol"
              f"  (at R={good[int(absrelax.argmax())]['R']:.4f})")
        print(f"  mean |relaxation|: {absrelax.mean():.6f} kcal/mol")
        print(f"  min  |relaxation|: {absrelax.min():.6f} kcal/mol")

        print("\n── SCF iteration count (A_AB) ──")
        print(f"  range: {niter.min()}–{niter.max()} iterations")
        vals, counts = np.unique(niter, return_counts=True)
        for v, c in zip(vals, counts):
            print(f"    {v} iters: {c} R values")

        thr = 0.01
        over = [r for r in good if abs(r["relaxation_kcal"]) > thr]
        print(f"\n── R with |relaxation| > {thr} kcal/mol ──")
        if not over:
            print(f"  none — all {len(good)} R relax by < {thr} kcal/mol after iter 1.")
        else:
            for r in over:
                print(f"    R={r['R']:.4f}: {r['relaxation_kcal']:+.6f} kcal/mol"
                      f"  ({r['n_iter_AB']} iters)")

        # sanity: A_A should be ~1 iteration
        na = [r["n_iter_A"] for r in good if r["n_iter_A"] is not None]
        if na:
            print(f"\n── Sanity: A_A iteration count ──")
            va, ca = np.unique(np.array(na), return_counts=True)
            for v, c in zip(va, ca):
                print(f"    {v} iters: {c} R values"
                      + ("   (expected ~1)" if v == 1 else "   (unexpected)"))

    # ── Write CSV ─────────────────────────────────────────────────────────────
    if not args.summary and good:
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        fields = ["R", "label", "n_iter_AB", "E_iter1_AB", "E_conv_AB",
                  "relaxation_kcal", "n_iter_A", "note"]
        with OUT_CSV.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print(f"\nWrote {OUT_CSV}  ({len(rows)} rows)")


if __name__ == "__main__":
    main()
