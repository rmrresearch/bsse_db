#!/usr/bin/env python3
"""
parse_energy_decomp.py — combined energy-decomposition parser (Ne/2_new).

Produces ONE CSV per R holding two related decompositions, for the one-shot
research-proposal analysis (SCF part scope).

Scope note
----------
The one-shot / cheap-BSSE idea targets the SCF part of the BSSE. This parser
also records the correlation (MP2c, CCSD(T)c) BSSE components purely for
CONTEXT — to see the full energy picture alongside the SCF result. It does
NOT claim the one-shot addresses the correlation BSSE (a separate mechanism,
CBI per Iwata et al. 2026). No conclusions are drawn here — this is data for
discussion.

Two decompositions in the output
--------------------------------
(1) Per-monomer SCF basis-enlargement (the 1e/2e study), monomer A only:
      dE_1e  = E_1e(AB) − E_1e(A)
      dE_2e  = E_2e(AB) − E_2e(A)
      dE_scf = E_scf(AB) − E_scf(A)   (= dE_1e + dE_2e; residual reported)
      frac_1e = |dE_1e| / (|dE_1e| + |dE_2e|)   [gross-motion fraction, 0–1]
    Uses A_A.out and A_AB.out.

(2) Dimer BSSE component decomposition (all monomer terms), per level:
      BSSE_level = [E_A(AB) − E_A(A)] + [E_B(AB) − E_B(B)]
    For homonuclear Ne, B_B = A_A and B_AB ≈ A_AB (verified ~1e-13 Ha), so
    BSSE_level = [E_A(AB) − E_A(A)] + [E_B(AB) − E_B(B)] using A_A, A_AB, B_AB.
      SCF level     : uses Total SCF energy
      MP2c level     : MP2c = Total MP2 − Total SCF   (correlation increment)
      CCSD(T)c level : CCSD(T)c = Total CCSD(T) − Total MP2
      bsse_total    = bsse_scf + bsse_mp2c + bsse_ccsdtc
    All BSSE columns in kcal/mol, signed (no_vmfc − vmfc convention → negative).

Keys read: A_A, A_AB, B_AB  (AB_AB not needed for BSSE; binding energy is a
separate later script).

Layout
------
  Ne/2_new/one_shot_study/scripts/parse_energy_decomp.py   (this file)
  Ne/2_new/R_config/<NNN>_R_<label>/CCSD_T/aug-cc-pvdz/{A_A,A_AB,B_AB}.out
  Ne/2_new/one_shot_study/energy_decomp/energy_decomp.csv  (output)

Usage
-----
  python3 parse_energy_decomp.py
  python3 parse_energy_decomp.py --summary
"""

import argparse
import csv
from pathlib import Path

import numpy as np

HART2KCAL = 627.5094740631

SCRIPT_DIR = Path(__file__).resolve().parent
STUDY_DIR  = SCRIPT_DIR.parent
R_CONFIG   = STUDY_DIR.parent / "R_config"
OUT_DIR    = STUDY_DIR / "energy_decomp"
OUT_CSV    = OUT_DIR / "energy_decomp.csv"

R_VALUES = np.linspace(1.5, 4.5, 100)

# verbatim NWChem 7.2.0 label strings (value is the last whitespace field)
L_SCF = "Total SCF energy ="
L_1E  = "One-electron energy ="
L_2E  = "Two-electron energy ="
L_MP2 = "Total MP2 energy:"
L_CC  = "Total CCSD(T) energy:"


def r_to_label(r):
    return f"{r:.3f}".replace(".", "p")


def grab(label, path):
    """Last numeric field of the last line containing `label`, or None."""
    val = None
    if not path.exists():
        return None
    for line in path.read_text(errors="replace").splitlines():
        if label in line:
            try:
                val = float(line.split()[-1])
            except ValueError:
                pass
    return val


def read_keys(leaf):
    """Return dict of all energies for the three keys, or None if any missing."""
    out = {}
    for key in ("A_A", "A_AB", "B_AB"):
        p = leaf / f"{key}.out"
        if not p.exists():
            return None, f"{key}.out missing"
        scf = grab(L_SCF, p)
        e1  = grab(L_1E, p)
        e2  = grab(L_2E, p)
        mp2 = grab(L_MP2, p)
        cc  = grab(L_CC, p)
        if None in (scf, mp2, cc):
            return None, f"{key}.out missing SCF/MP2/CCSD(T)"
        # 1e/2e only strictly needed for A_A and A_AB
        out[key] = dict(scf=scf, e1=e1, e2=e2, mp2=mp2, cc=cc)
    return out, ""


def resolve_folder(label):
    m = sorted(R_CONFIG.glob(f"*_R_{label}"))
    return m[0] if len(m) == 1 else None


def process_R(r):
    label = r_to_label(r)
    row = {k: None for k in (
        "R", "label",
        # (1) per-monomer SCF enlargement (A)
        "e1_A", "e2_A", "scf_A", "e1_AB", "e2_AB", "scf_AB",
        "dE_1e_kcal", "dE_2e_kcal", "dE_scf_kcal", "resid_kcal", "frac_1e",
        # (2) dimer BSSE components
        "bsse_scf", "bsse_mp2c", "bsse_ccsdtc", "bsse_total",
        "note",
    )}
    row["R"] = round(r, 4)
    row["label"] = label
    row["note"] = ""  # cleared on success; set to a message on any failure path

    folder = resolve_folder(label)
    if folder is None:
        row["note"] = "folder not found"
        return row
    leaf = folder / "CCSD_T" / "aug-cc-pvdz"
    data, err = read_keys(leaf)
    if data is None:
        row["note"] = err
        return row

    A, AB, BAB = data["A_A"], data["A_AB"], data["B_AB"]

    # ── (1) per-monomer SCF basis enlargement (A → A∪B) ──
    d1  = (AB["e1"] - A["e1"]) * HART2KCAL
    d2  = (AB["e2"] - A["e2"]) * HART2KCAL
    dsc = (AB["scf"] - A["scf"]) * HART2KCAL
    row.update(
        e1_A=A["e1"], e2_A=A["e2"], scf_A=A["scf"],
        e1_AB=AB["e1"], e2_AB=AB["e2"], scf_AB=AB["scf"],
        dE_1e_kcal=d1, dE_2e_kcal=d2, dE_scf_kcal=dsc,
        resid_kcal=dsc - (d1 + d2),
        frac_1e=abs(d1) / (abs(d1) + abs(d2)) if (abs(d1) + abs(d2)) else float("nan"),
    )

    # ── (2) dimer BSSE component decomposition ──
    # per-level monomer term for A: E_A(AB) − E_A(A); for B: E_B(AB) − E_B(B)
    # B_B = A_A by symmetry (homonuclear); B term uses B_AB and A_A.
    def level(mon_key):  # returns (scf, mp2c, ccsdtc) energy at that endpoint
        d = data[mon_key]
        return d["scf"], (d["mp2"] - d["scf"]), (d["cc"] - d["mp2"])

    scf_A_A,  mp2c_A_A,  cc_A_A  = level("A_A")
    scf_A_AB, mp2c_A_AB, cc_A_AB = level("A_AB")
    scf_B_AB, mp2c_B_AB, cc_B_AB = level("B_AB")
    # B_B == A_A (symmetry)
    scf_B_B,  mp2c_B_B,  cc_B_B  = scf_A_A, mp2c_A_A, cc_A_A

    bsse_scf = ((scf_A_AB - scf_A_A) + (scf_B_AB - scf_B_B)) * HART2KCAL
    bsse_mp2c = ((mp2c_A_AB - mp2c_A_A) + (mp2c_B_AB - mp2c_B_B)) * HART2KCAL
    bsse_ccsdtc = ((cc_A_AB - cc_A_A) + (cc_B_AB - cc_B_B)) * HART2KCAL
    row.update(
        bsse_scf=bsse_scf, bsse_mp2c=bsse_mp2c, bsse_ccsdtc=bsse_ccsdtc,
        bsse_total=bsse_scf + bsse_mp2c + bsse_ccsdtc,
    )
    return row


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--summary", action="store_true")
    args = ap.parse_args()

    rows = [process_R(r) for r in R_VALUES]
    good = [r for r in rows if r["note"] == "" and r["frac_1e"] is not None]
    bad  = [r for r in rows if r["note"] != ""]

    print(f"Parsed {len(good)}/{len(rows)} R values.")
    for r in bad:
        print(f"  problem R={r['R']} ({r['label']}): {r['note']}")

    if good:
        frac = np.array([r["frac_1e"] for r in good])
        resid = np.abs([r["resid_kcal"] for r in good])
        bscf = np.array([abs(r["bsse_scf"]) for r in good])
        bmp2 = np.array([abs(r["bsse_mp2c"]) for r in good])
        bcc  = np.array([abs(r["bsse_ccsdtc"]) for r in good])

        print("\n── (1) SCF 1e/2e enlargement: frac_1e = |dE_1e|/(|dE_1e|+|dE_2e|) ──")
        print(f"  mean : {frac.mean():.4f}")
        print(f"  std  : {frac.std():.4f}")
        print(f"  range: [{frac.min():.4f}, {frac.max():.4f}]")
        print(f"  max |resid| (dE_scf − (dE_1e+dE_2e)): {resid.max():.2e} kcal/mol")

        print("\n── (2) Dimer BSSE component means (|kcal/mol|, over 100 R) ──")
        tot = bscf.mean() + bmp2.mean() + bcc.mean()
        print(f"  SCF     : {bscf.mean():.4f}  ({100*bscf.mean()/tot:.1f}%)")
        print(f"  MP2c    : {bmp2.mean():.4f}  ({100*bmp2.mean()/tot:.1f}%)")
        print(f"  CCSD(T)c: {bcc.mean():.4f}  ({100*bcc.mean()/tot:.1f}%)")

    if not args.summary and good:
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        fields = list(rows[0].keys())
        with OUT_CSV.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print(f"\nWrote {OUT_CSV}  ({len(rows)} rows)")


if __name__ == "__main__":
    main()
