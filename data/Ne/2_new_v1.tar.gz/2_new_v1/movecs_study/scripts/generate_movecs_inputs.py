"""
generate_movecs_inputs.py — Generate NWChem inputs for the Ne/2_new density-matrix
sub-study (movecs_study).

PURPOSE
-------
The parent Ne/2_new study computes energies. This sub-study computes the same
monomer-in-dimer-basis SCF but PRESERVES the MO coefficient file (.movecs), so
the AO density matrix

    P = 2 C_occ C_occ^T

can be reconstructed and split into blocks

    P_AA  (rows/cols  1-23, real Ne)
    P_AB  (rows 1-23, cols 24-46)
    P_BB  (rows/cols 24-46, ghost centre)

from which the ghost-mixing amplitude t(R) ~ ||P_AB(R)||_F is measured.

WHY A RE-RUN IS NEEDED
----------------------
The parent study's submit_energy.sh deletes every file except .nw and .out:

    for f in "${BASE}".*; do
        if [[ "$f" != "${BASE}.nw" && "$f" != "${BASE}.out" ]]; then rm -f "$f"; fi
    done

NWChem DID write A_AB.movecs on all 400 parent jobs; the cleanup removed it.
The raw .out files are untouched by this sub-study (handoff Sec. 9 / Sec. 11.6
preservation requirement).

SCOPE (differs from the parent study — deliberate)
--------------------------------------------------
1. R grid  : indices 001-067 only, i.e. R <= 3.5 A. Grid point 067 is exactly
             3.500000 A (1.5 + 66*(3/99)). This is the locked analysis window
             (handoff Sec. 4) and avoids the region where the SCF BSSE sits at
             the numerical floor (~3e-6 Ha at R = 4.5).
2. File key: A_AB only. t(R) is measured from monomer A in the union basis.
             A_A is R-INDEPENDENT (single Ne, own basis, no partner), so it is
             written ONCE into monomer/ rather than 67 times.
             B_AB is redundant: A_AB vs B_AB agree to ~1e-12 Ha (handoff Sec. 3).
             AB_AB is not needed: BSSE requires no dimer density.
3. Task    : `task scf energy`, NOT ccsd(t). The density matrix is an RHF
             object; the correlated steps add nothing and cost time.
4. Thresh  : tightened to 1e-8 (orbital gradient) with tol2e 1e-12. Per the
             NWChem manual, thresh 1e-8 is "the best that can be attained in
             most circumstances" and tol2e 1e-12 is its recommendation for
             diffuse basis sets. The parent study ran at the 1e-4 default,
             which converges the energy to only ~1e-8 Ha -- the same order as
             the SCF BSSE beyond R ~ 4 A. Since this study measures a density
             rather than reproducing a published energy, tight is correct.

INPUT FORM
----------
Otherwise identical to the parent's render_A_AB(): no `memory`, no
`geometry noautoz`, no `symmetry c1`. Those were introduced for larger
clusters and are not warranted for the 2-atom dimer. Symmetry auto-detection
(C4V) is harmless here: P is invariant under any unitary rotation within the
occupied space, so symmetry adaptation and the "symmetry fudging" of
degenerate orbitals cannot change P.

The only additions to the parent template are:
    scf
      thresh 1e-8
      tol2e  1e-12
      vectors output <key>.movecs
    end

`vectors output` is documented NWChem syntax (Hartree-Fock manual, VECTORS
directive). Naming the file explicitly means the movecs lands at a predictable
path rather than relying on the default file-prefix rule.

FOLDER LAYOUT (mirrors the parent, and one_shot_study/ as a sibling)
---------------------------------------------------------------------
    Ne/2_new/movecs_study/
    |-- R_config/<NNN>_R_<label>/SCF/aug-cc-pvdz/A_AB.{nw,out,movecs}
    |-- monomer/SCF/aug-cc-pvdz/A_A.{nw,out,movecs}
    |-- scripts/
    `-- data_frames_plots/

The NNN index and 3-decimal <label> are IDENTICAL to the parent R_config, so
t(R) joins ne_dimer_bsse_vs_R.csv on R with no matching logic and no
interpolation.

Usage:
    python3 generate_movecs_inputs.py               # all 67 R + the monomer
    python3 generate_movecs_inputs.py --R 1p500     # one R only
    python3 generate_movecs_inputs.py --force       # overwrite existing .nw
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np


# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

# The PARENT grid, unchanged. Do not redefine it -- t(R) must land on exactly
# the same R values as the parent CSV.
R_MIN = 1.5
R_MAX = 4.5
N_POINTS = 100
R_VALUES = np.linspace(R_MIN, R_MAX, N_POINTS)

# Analysis window: indices 0..66 inclusive (67 points, R <= 3.5 A).
# 1.5 + 66*(3/99) = 3.5 exactly -- the window closes on a real grid point.
N_WINDOW = 67

METHOD_DIR = "SCF"          # parent uses CCSD_T; this study is SCF-only
BASIS_DIR = "aug-cc-pvdz"

# SCF block appended to every input. Shared so the monomer and the dimer-basis
# runs are converged identically -- a difference in threshold between them
# would contaminate Delta P_AA = P_AA - P^A.
SCF_BLOCK = (
    "scf\n"
    "  thresh 1e-8\n"
    "  tol2e  1e-12\n"
    "  vectors output {key}.movecs\n"
    "end\n"
)


# -----------------------------------------------------------------------------
# Utilities (identical conventions to generate_nw_inputs.py)
# -----------------------------------------------------------------------------

def r_to_label(r: float) -> str:
    """1.5303030303 -> '1p530' (3-decimal folder label, human tag only)."""
    return f"{r:.3f}".replace(".", "p")


def window_labels() -> list[str]:
    """3-decimal labels for the 67 in-window grid points, in grid order."""
    return [r_to_label(r) for r in R_VALUES[:N_WINDOW]]


def folder_name(index0: int, r: float) -> str:
    """'<NNN>_R_<label>' for a 0-based grid index. Matches the parent exactly."""
    return f"{index0 + 1:03d}_R_{r_to_label(r)}"


def _coord(r: float) -> str:
    """Full-precision z-coordinate, so the geometry is the exact grid point."""
    return repr(float(r))


# -----------------------------------------------------------------------------
# NWChem template renderers
# -----------------------------------------------------------------------------

def render_A_A() -> str:
    """A alone in the A basis. R-independent: written once, not per R."""
    return (
        "geometry\n"
        "  Ne 0 0 0\n"
        "end\n"
        "basis spherical\n"
        "  Ne library aug-cc-pvdz\n"
        "end\n"
        + SCF_BLOCK.format(key="A_A") +
        "task scf energy\n"
    )


def render_A_AB(r: float) -> str:
    """A real at origin, B as a ghost at (0,0,R), in the AB (union) basis.

    Basis-function ordering follows geometry order, so functions 1-23 belong to
    the real Ne and 24-46 to the ghost. The block split in the reader depends on
    this ordering; do not reorder the geometry.
    """
    return (
        "geometry\n"
        "  Ne 0 0 0\n"
        f"  bqNe 0 0 {_coord(r)}\n"
        "end\n"
        "basis spherical\n"
        "  Ne library aug-cc-pvdz\n"
        "  bqNe library Ne aug-cc-pvdz\n"
        "end\n"
        + SCF_BLOCK.format(key="A_AB") +
        "task scf energy\n"
    )


# -----------------------------------------------------------------------------
# Paths and writing
# -----------------------------------------------------------------------------

def dimer_path(root: Path, index0: int, r: float) -> Path:
    """.nw path for the A_AB job at one R."""
    return (root / "R_config" / folder_name(index0, r)
            / METHOD_DIR / BASIS_DIR / "A_AB.nw")


def monomer_path(root: Path) -> Path:
    """.nw path for the single R-independent A_A job."""
    return root / "monomer" / METHOD_DIR / BASIS_DIR / "A_A.nw"


def write_input(path: Path, text: str, force: bool) -> bool:
    """Write one .nw. Returns True if written, False if skipped."""
    if path.exists() and not force:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return True


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "Generate SCF-only NWChem inputs that preserve .movecs, for the "
            "Ne/2_new density-matrix sub-study. Without --R, generates all 67 "
            "in-window R plus the single monomer job."
        )
    )
    p.add_argument(
        "--R", dest="r_label", default=None, metavar="LABEL",
        help=("Restrict to a single R folder. LABEL is the 3-decimal 'p' label "
              "of an in-window grid point, e.g. 1p500, 1p530, ..., 3p500."),
    )
    p.add_argument(
        "--force", action="store_true",
        help="Overwrite existing .nw files instead of skipping them.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()

    # Path anchoring: this script lives in Ne/2_new/movecs_study/scripts/.
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent                      # Ne/2_new/movecs_study/

    labels = window_labels()

    if args.r_label is None:
        targets = list(enumerate(R_VALUES[:N_WINDOW]))
        do_monomer = True
    else:
        if args.r_label not in labels:
            print(f"ERROR: --R {args.r_label!r} is not an in-window grid label.",
                  file=sys.stderr)
            print(f"Valid labels: {labels[0]}, {labels[1]}, ..., {labels[-1]} "
                  f"({N_WINDOW} points, R <= {R_VALUES[N_WINDOW-1]:.6f} A)",
                  file=sys.stderr)
            sys.exit(1)
        idx = labels.index(args.r_label)
        targets = [(idx, R_VALUES[idx])]
        do_monomer = False

    n_written = n_skipped = 0
    for index0, r in targets:
        if write_input(dimer_path(root, index0, r), render_A_AB(r), args.force):
            n_written += 1
        else:
            n_skipped += 1

    n_mono = 0
    if do_monomer:
        if write_input(monomer_path(root), render_A_A(), args.force):
            n_mono = 1

    print(f"A_AB inputs written : {n_written}")
    print(f"A_AB inputs skipped : {n_skipped}  (already exist; use --force)")
    print(f"A_A  monomer written: {n_mono}     (R-independent, single job)")
    print(f"window              : indices 001-{N_WINDOW:03d}, "
          f"R in [{R_VALUES[0]:.6f}, {R_VALUES[N_WINDOW-1]:.6f}] A")
    print(f"parent grid         : linspace({R_MIN}, {R_MAX}, {N_POINTS}), "
          f"step = {(R_MAX - R_MIN) / (N_POINTS - 1):.6f} A")
    print("Done.")


if __name__ == "__main__":
    main()
