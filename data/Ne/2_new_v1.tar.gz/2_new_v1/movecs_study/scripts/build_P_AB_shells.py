"""
build_P_AB_shells.py — Signed, shell-pair-resolved extraction of the P_AB block.

WHY NOT THE NORM
----------------
build_t_of_R.py reports t(R) = ||P_AB||_F. That is a useful magnitude diagnostic
but it is the WRONG object for modelling the energy. The AB-block contribution is
a SIGNED CONTRACTION,

    Delta E_AB  =  2 Sum_{mu nu} P_AB[mu,nu] H_BA[nu,mu]

in which each density element multiplies its own integral, and each integral
carries its own GPT exponent

    gamma_{mu nu} = alpha_mu * alpha_nu / (alpha_mu + alpha_nu)

The Frobenius norm collapses 529 signed products into one positive number, which
destroys exactly that pairing. It also makes sign cancellation between elements
invisible -- and cancellation is one of the candidate explanations for the
observed sub-GPT-floor decay of ||P_AB|| (local gamma reaching 0.101 A^-2 against
a floor of 0.190 A^-2). This script keeps the signs.

BASIS LAYOUT (read from the NWChem output, not assumed)
--------------------------------------------------------
aug-cc-pVDZ Ne, spherical: 9 contracted shells, 23 functions per centre.

  shell  L  n_prim  exponents (bohr^-2)              functions
  1S     0  8       17880 ... 1.653 (contracted)     1
  2S     0  8       17880 ... 1.653 (contracted)     1
  3S     0  1       0.4869                           1
  4S     0  1       0.1230        <- diffuse s       1
  5P     1  3       28.39, 6.27, 1.695               3
  6P     1  1       0.4317                           3
  7P     1  1       0.1064        <- diffuse p       3
  8D     2  1       2.202                            5
  9D     2  1       0.631                            5

Function ordering, verified against the .out 'Final Molecular Orbital Analysis':
  - shells in the order above
  - within a p shell : px, py, pz   (Bfn 13 = 'Ne pz' of 7P, 36 = 'bq pz')
  - within a d shell : m = -2, -1, 0, +1, +2   (Bfn 21 = 'Ne d  0', 22 = 'd  1')
  - AO 0..22 = real Ne (A), 23..45 = ghost (B), per geometry order

SYMMETRY LABELS
---------------
The dimer axis is z, so m is conserved: an element of P_AB is nonzero only when
the two functions share |m| AND the same cos/sin real-harmonic character. Each
function is tagged (|m|, 'c' or 's'):

  L=0 : m=0                                     -> (0,c)
  L=1 : px (0,c-type of |m|=1), py (|m|=1,s), pz (0,c)
        i.e. px -> (1,c),  py -> (1,s),  pz -> (0,c)
  L=2 : indices m=-2,-1,0,+1,+2
        -> (2,s), (1,s), (0,c), (1,c), (2,c)

Channels: |m| = 0 sigma, 1 pi, 2 delta.

For |m| >= 1 the c and s partners are degenerate by symmetry, so the script
records their MEAN as the channel value and their absolute difference as
'degeneracy_spread'. That spread is a symmetry check: it should be ~0. A large
spread means the C4v assumption or the ordering map is wrong.

OUTPUT (long format)
--------------------
One row per (R, shell_i, shell_j, |m|):

    R, grid_index, R_label, shell_i, shell_j, L_i, L_j, abs_m, channel,
    value, degeneracy_spread, n_pairs

  value              SIGNED channel value of P_AB. Never absolute-valued.
  degeneracy_spread  |c-partner - s-partner|, 0 for |m|=0
  n_pairs            how many degenerate elements were averaged (1 or 2)

Long format rather than 110 wide columns: it filters and plots cleanly, and the
downstream GPT test consumes it directly.

Usage:
    python3 build_P_AB_shells.py
    python3 build_P_AB_shells.py --out somewhere.csv
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from read_movecs import read_movecs, density_matrix, N_A


R_VALUES = np.linspace(1.5, 4.5, 100)
METHOD_DIR, BASIS_DIR = "SCF", "aug-cc-pvdz"

# (name, L, [(exponent, contraction coefficient), ...])
# Transcribed from the 'Basis "ao basis" -> "" (spherical)' block of the .out.
SHELLS = [
    ("1S", 0, [(1.7880e4, 0.000738), (2.6830e3, 0.005677), (6.1150e2, 0.028883),
               (1.7350e2, 0.108540), (5.6640e1, 0.290907), (2.0420e1, 0.448324),
               (7.8100e0, 0.258026), (1.6530e0, 0.015063)]),
    ("2S", 0, [(1.7880e4, -0.000172), (2.6830e3, -0.001357), (6.1150e2, -0.006737),
               (1.7350e2, -0.027663), (5.6640e1, -0.076208), (2.0420e1, -0.175227),
               (7.8100e0, -0.107038), (1.6530e0, 0.567050)]),
    ("3S", 0, [(0.4869, 1.0)]),
    ("4S", 0, [(0.1230, 1.0)]),
    ("5P", 1, [(28.39, 0.046087), (6.27, 0.240181), (1.695, 0.508744)]),
    ("6P", 1, [(0.4317, 1.0)]),
    ("7P", 1, [(0.1064, 1.0)]),
    ("8D", 2, [(2.202, 1.0)]),
    ("9D", 2, [(0.631, 1.0)]),
]

# Within-shell function tags: index -> (|m|, 'c'|'s').
TAGS = {
    0: [(0, "c")],                                            # s
    1: [(1, "c"), (1, "s"), (0, "c")],                        # px, py, pz
    2: [(2, "s"), (1, "s"), (0, "c"), (1, "c"), (2, "c")],    # m = -2..+2
}

CHANNEL = {0: "sigma", 1: "pi", 2: "delta"}


def shell_offsets() -> list[int]:
    """Starting AO index of each shell within one centre."""
    off, acc = [], 0
    for _, L, _ in SHELLS:
        off.append(acc)
        acc += 2 * L + 1
    if acc != N_A:
        raise SystemExit(f"Shell table sums to {acc} functions, expected {N_A}")
    return off


OFFSETS = shell_offsets()


def r_to_label(r: float) -> str:
    return f"{r:.3f}".replace(".", "p")


def extract_rows(P_AB: np.ndarray, r: float, index0: int) -> list[dict]:
    """Pull every symmetry-allowed shell-pair channel out of P_AB, with signs."""
    rows = []
    for i, (name_i, L_i, _) in enumerate(SHELLS):
        for j, (name_j, L_j, _) in enumerate(SHELLS):
            block = P_AB[OFFSETS[i]:OFFSETS[i] + 2 * L_i + 1,
                         OFFSETS[j]:OFFSETS[j] + 2 * L_j + 1]

            # Collect elements by |m|, keeping the (tag_i, tag_j) labels.
            # For |m| >= 1 there are two degenerate partners, but the real-
            # harmonic PHASE convention linking p(+-1) to d(+-1) is not fixed a
            # priori: pairing (c,c)+(s,s) and (c,s)+(s,c) differ by a sign, and
            # for p-d blocks NWChem's convention makes the first vanish while
            # the second does not. Rather than hardcode a convention, both
            # pairings are formed and the non-vanishing one is used. Which one
            # applied is recorded in the 'pairing' column so nothing is hidden.
            by_m: dict[int, dict[tuple[str, str], float]] = {}
            for a, (m_a, t_a) in enumerate(TAGS[L_i]):
                for b, (m_b, t_b) in enumerate(TAGS[L_j]):
                    if m_a == m_b:
                        by_m.setdefault(m_a, {})[(t_a, t_b)] = float(block[a, b])

            for abs_m, elems in sorted(by_m.items()):
                if abs_m == 0:
                    vals = [elems[("c", "c")]]
                    value, spread, conv = vals[0], 0.0, "m0"
                else:
                    # Two degenerate partners. Which index pair carries them
                    # depends on NWChem's real-harmonic phase convention, and
                    # the partners may come out EQUAL or EQUAL-AND-OPPOSITE
                    # (the latter happens for p-d, where the p(+-1) and d(+-1)
                    # phase conventions differ). Both cases describe the same
                    # physical channel: the sign flip cancels in the energy
                    # contraction Sum P H, because H carries the same
                    # convention. So take whichever of (a+b)/2 or (a-b)/2 is
                    # non-vanishing and record which in 'pairing'.
                    cand = [elems[k] for k in (("c", "c"), ("s", "s")) if k in elems]
                    if len(cand) < 2:
                        cand = [elems[k] for k in (("c", "s"), ("s", "c")) if k in elems]
                    a, b = cand[0], cand[1]
                    if abs(a + b) >= abs(a - b):
                        value, spread, conv = (a + b) / 2, abs(a - b), "sym"
                    else:
                        value, spread, conv = (a - b) / 2, abs(a + b), "anti"

                rows.append({
                    "R": r,
                    "grid_index": index0 + 1,
                    "R_label": r_to_label(r),
                    "shell_i": name_i,
                    "shell_j": name_j,
                    "L_i": L_i,
                    "L_j": L_j,
                    "abs_m": abs_m,
                    "channel": CHANNEL[abs_m],
                    "pairing": conv,
                    # SIGNED channel value. Never absolute-valued.
                    "value": float(value),
                    "degeneracy_spread": float(spread),
                    "n_pairs": 1 if abs_m == 0 else 2,
                })
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Signed shell-pair-resolved extraction of P_AB across R."
    )
    ap.add_argument("--out", default=None, help="Output CSV path.")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent.parent
    r_config = root / "R_config"
    if not r_config.is_dir():
        raise SystemExit(f"ERROR: expected 'R_config/' inside {root}")

    rows, n_files = [], 0
    for folder in sorted(r_config.iterdir()):
        if not folder.is_dir():
            continue
        try:
            index0 = int(folder.name.split("_")[0]) - 1
        except ValueError:
            continue
        movecs = folder / METHOD_DIR / BASIS_DIR / "A_AB.movecs"
        if not movecs.exists():
            continue

        mv = read_movecs(movecs)
        if mv.nbf != 2 * N_A:
            raise SystemExit(f"ERROR: {movecs} has nbf = {mv.nbf}, expected {2 * N_A}")
        P = density_matrix(mv)
        rows += extract_rows(P[:N_A, N_A:], float(R_VALUES[index0]), index0)
        n_files += 1

    if not rows:
        raise SystemExit("ERROR: no .movecs files found.")

    df = pd.DataFrame(rows).sort_values(
        ["grid_index", "shell_i", "shell_j", "abs_m"]).reset_index(drop=True)

    out = Path(args.out) if args.out else \
        root / "data_frames_plots" / "ne_dimer_P_AB_shells.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False, float_format="%.15g")

    n_ch = df.groupby(["shell_i", "shell_j", "abs_m"]).ngroups
    print(f"movecs read   : {n_files}")
    print(f"channels      : {n_ch}   (shell_i x shell_j x |m|)")
    print(f"rows written  : {len(df)}")
    print(f"output        : {out}")
    print()
    print(f"degeneracy_spread max : {df['degeneracy_spread'].abs().max():.3e}   "
          f"(symmetry check; should be ~0)")
    print(f"signed range          : [{df['value'].min():.6e}, {df['value'].max():.6e}]")
    n_neg = int((df['value'] < 0).sum())
    print(f"negative elements     : {n_neg} of {len(df)} "
          f"({100 * n_neg / len(df):.1f}%)  <- sign structure the norm hid")
    print()
    print("largest |value| channels (at the shortest R):")
    first = df[df["grid_index"] == df["grid_index"].min()].copy()
    first["mag"] = first["value"].abs()
    for _, row in first.nlargest(8, "mag").iterrows():
        print(f"  {row['shell_i']}-{row['shell_j']:<3s} {row['channel']:<6s} "
              f"value = {row['value']:+.6e}")


if __name__ == "__main__":
    main()
