"""
read_movecs.py — Reader for NWChem 7.2.0 binary .movecs files.

WHY THIS EXISTS
---------------
NWChem ships a Fortran utility `mov2asc` (contrib/mov2asc) that converts .movecs
to text, but the Spack build installed on NOVA
    /opt/rit/el9/20230413/app/linux-rhel9-x86_64_v3/gcc-11.2.1/
        nwchem-7.2.0-oxtctbuhfuzyfaoziquq6bki22grib3g/bin/
contains only the `nwchem` binary -- Spack does not build contrib/. Rather than
depend on a third-party converter, this module reads the binary directly.

The .out file is NOT an alternative: NWChem's "Final Molecular Orbital Analysis"
prints only coefficients above a threshold, and at R = 1.5 A no ghost-centre
coefficient clears it for any occupied vector. The .out cannot give us P.

RECORD LAYOUT (verified byte-for-byte against a real 7.2.0 file, not assumed)
-----------------------------------------------------------------------------
Fortran sequential unformatted: every record is
    [int32 length][payload][int32 length]
Little-endian; Fortran INTEGERs in the payload are 8-byte (int64).

  rec  0  142 B  basissum(32) + geomsum(32) + bqsum(32) + scftype(20) + date(26)
  rec  1   20 B  scftype, e.g. 'scf'
  rec  2    8 B  int64  title length
  rec  3    n B  title
  rec  4    8 B  int64  basis-name length
  rec  5    n B  basis name, e.g. 'ao basis'
  rec  6    8 B  int64  nsets   (1 for RHF)
  rec  7    8 B  int64  nbf     (46 for Ne + ghost Ne, aug-cc-pVDZ spherical)
  rec  8    8 B  int64  nmo
  rec  9  8*nbf  occupation numbers
  rec 10  8*nbf  orbital eigenvalues
  rec 11+ 8*nbf  one record per MO: the AO coefficients of that MO
  last     16 B  [total energy, nuclear repulsion]

Note rec 2 and rec 4 are the LENGTHS of the two following character records;
mov2asc.F writes them the same way. The trailing energy record is a convenient
cross-check against the .out.

Validation performed on
  movecs_study/R_config/001_R_1p500/SCF/aug-cc-pvdz/A_AB.movecs (18355 bytes):
  - all record trailers match their headers (structure is self-consistent)
  - nsets/nbf/nmo = 1/46/46
  - occupations = five 2.0 then zeros; sum = 10 = Z(Ne)
  - eigenvalues -32.795, -1.940, -0.852878, -0.852378, -0.852378 (1s, 2s, 2p);
    the 2p set is split by the ghost, p_z distinct from p_x/p_y (C4v)
  - trailing energy record = -128.49696255, matching 'Total SCF energy =' in the
    .out to printed precision
  - P = 2 C_occ C_occ^T is symmetric to 1e-14
  - every byte of the file is consumed (18331 + 24 = 18355)

BLOCK CONVENTION
----------------
NWChem orders basis functions by atom in geometry order. The A_AB geometry is

    Ne   0 0 0        <- real monomer A
    bqNe 0 0 R        <- ghost centre B

so AO indices 0..22 are A and 23..45 are B (23 functions each: aug-cc-pVDZ on
Ne is 4s3p2d spherical = 4 + 9 + 10 = 23). Do NOT reorder the geometry in the
.nw files without changing N_A here.

Usage as a module:
    from read_movecs import read_movecs, density_matrix, blocks
    mv = read_movecs(path)
    P  = density_matrix(mv)
    b  = blocks(P)

Usage as a CLI (single-file inspection / spot check):
    python3 read_movecs.py <path/to/A_AB.movecs>
"""

from __future__ import annotations

import struct
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np


# Number of aug-cc-pVDZ spherical basis functions on one Ne centre:
# 4s + 3p (x3) + 2d (x5) = 4 + 9 + 10 = 23.
N_A = 23


@dataclass
class MoVecs:
    """Contents of one .movecs file."""
    scftype: str
    title: str
    basis_name: str
    nsets: int
    nbf: int
    nmo: int
    occ: np.ndarray        # (nbf,)  occupation numbers
    eps: np.ndarray        # (nbf,)  orbital eigenvalues, Hartree
    C: np.ndarray          # (nbf, nmo)  AO x MO coefficient matrix
    energy: float          # total SCF energy, Hartree
    enrep: float           # nuclear repulsion, Hartree

    @property
    def n_occ(self) -> int:
        """Number of doubly occupied orbitals (RHF)."""
        return int(round(self.occ.sum() / 2))


class _RecordReader:
    """Sequential Fortran-unformatted record reader with trailer validation."""

    def __init__(self, data: bytes, path: Path):
        self._d = data
        self._off = 0
        self._path = path
        self._n = 0

    def next(self) -> bytes:
        """Return the payload of the next record; verify the trailing marker."""
        d, off = self._d, self._off
        if off + 4 > len(d):
            raise ValueError(f"{self._path}: truncated at record {self._n}")
        (length,) = struct.unpack("<i", d[off:off + 4])
        end = off + 4 + length
        if end + 4 > len(d):
            raise ValueError(
                f"{self._path}: record {self._n} claims {length} bytes but the "
                f"file ends first (corrupt or non-little-endian?)"
            )
        (trailer,) = struct.unpack("<i", d[end:end + 4])
        if trailer != length:
            raise ValueError(
                f"{self._path}: record {self._n} marker mismatch "
                f"(head {length}, tail {trailer}). The file is not "
                f"little-endian 4-byte-marker Fortran unformatted."
            )
        self._off = end + 4
        self._n += 1
        return d[off + 4:end]

    @property
    def consumed(self) -> int:
        return self._off


def _i8(payload: bytes) -> int:
    """Decode one 8-byte little-endian Fortran INTEGER."""
    return struct.unpack("<q", payload)[0]


def _f8(payload: bytes) -> np.ndarray:
    """Decode a run of 8-byte little-endian doubles."""
    return np.frombuffer(payload, dtype="<f8").copy()


def read_movecs(path: str | Path) -> MoVecs:
    """Parse an NWChem .movecs file. Raises ValueError on any inconsistency."""
    path = Path(path)
    r = _RecordReader(path.read_bytes(), path)

    r.next()                                   # checksums + date blob
    scftype = r.next().decode(errors="replace").strip()

    ltit = _i8(r.next())
    title = r.next().decode(errors="replace")[:ltit].strip()

    lbas = _i8(r.next())
    basis_name = r.next().decode(errors="replace")[:lbas].strip()

    nsets = _i8(r.next())
    nbf = _i8(r.next())
    nmo = _i8(r.next())

    if nsets != 1:
        raise ValueError(
            f"{path}: nsets = {nsets}. This reader handles RHF (nsets = 1) only; "
            f"a UHF file carries separate alpha and beta sets."
        )

    occ = _f8(r.next())
    eps = _f8(r.next())
    if occ.size != nbf or eps.size != nbf:
        raise ValueError(f"{path}: occ/eps length != nbf ({nbf})")

    # One record per MO, each holding that MO's AO coefficients. Stacking as
    # columns gives the conventional C with rows = AO, columns = MO.
    C = np.column_stack([_f8(r.next()) for _ in range(nmo)])
    if C.shape != (nbf, nmo):
        raise ValueError(f"{path}: coefficient matrix is {C.shape}, expected {(nbf, nmo)}")

    tail = _f8(r.next())
    energy, enrep = float(tail[0]), float(tail[1])

    return MoVecs(scftype, title, basis_name, nsets, nbf, nmo,
                  occ, eps, C, energy, enrep)


def density_matrix(mv: MoVecs) -> np.ndarray:
    """AO density matrix P = 2 C_occ C_occ^T (RHF, closed shell).

    P is invariant under any unitary rotation within the occupied space, so the
    symmetry adaptation and 'symmetry fudging' of degenerate orbitals that
    NWChem reports for the C4v dimer-basis job cannot affect it.
    """
    Co = mv.C[:, :mv.n_occ]
    return 2.0 * (Co @ Co.T)


def blocks(P: np.ndarray, n_a: int = N_A) -> dict[str, np.ndarray]:
    """Split P into AA / AB / BB blocks by AO index.

    AO indices [0, n_a)  -> real monomer A
    AO indices [n_a, nbf) -> ghost centre B
    """
    return {
        "AA": P[:n_a, :n_a],
        "AB": P[:n_a, n_a:],
        "BB": P[n_a:, n_a:],
    }


def _cli(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__.split("Usage as a CLI")[-1].strip(), file=sys.stderr)
        return 2

    mv = read_movecs(argv[1])
    P = density_matrix(mv)
    b = blocks(P)

    nAB = np.linalg.norm(b["AB"])
    nBB = np.linalg.norm(b["BB"])

    print(f"file        : {argv[1]}")
    print(f"scftype     : {mv.scftype}    basis: {mv.basis_name}")
    print(f"nsets/nbf/nmo: {mv.nsets} / {mv.nbf} / {mv.nmo}")
    print(f"n_occ       : {mv.n_occ}   (electrons = {mv.occ.sum():.1f})")
    print(f"energy      : {mv.energy:.12f} Ha   enrep: {mv.enrep:.12f} Ha")
    print(f"eps[:6]     : {np.round(mv.eps[:6], 6)}")
    print(f"P symmetric : {np.allclose(P, P.T, atol=1e-12)}")
    print()
    print(f"||P_AA||_F  = {np.linalg.norm(b['AA']):.10e}")
    print(f"||P_AB||_F  = {nAB:.10e}     <- t(R)")
    print(f"||P_BB||_F  = {nBB:.10e}")
    if nAB > 0:
        # Idempotency of any converged single determinant gives
        #   P_BB = 1/2 P_BA S_AA P_AB + O(t^3),
        # so this ratio sits near 0.5 up to the S_AA != I factor. It is a
        # convergence diagnostic, NOT a test of the block argument.
        print(f"||P_BB||/||P_AB||^2 = {nBB / nAB**2:.6f}   (idempotency ~ 0.5)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli(sys.argv))
