#!/bin/bash
# submit_all_movecs.sh
# Orchestrator for the Ne/2_new density-matrix sub-study (movecs_study) on NOVA.
#
# Layout walked:
#   ~/BSSE/Ne/2_new/movecs_study/R_config/<NNN>_R_<label>/SCF/aug-cc-pvdz/A_AB.nw
#   ~/BSSE/Ne/2_new/movecs_study/monomer/SCF/aug-cc-pvdz/A_A.nw
#
# 68 jobs total: 67 A_AB (one per in-window R) + 1 A_A (R-independent).
# SCF-only on a 2-atom system, so the whole batch is a couple of minutes.
#
# Modelled directly on submit_all_jobs.sh: same sentinel-pair email pattern,
# same skip-existing logic, same log-folder convention. Differences are only
# those forced by the sub-study layout (one file key per R instead of four,
# SCF/ instead of CCSD_T/, plus the separate monomer/ leaf).
#
# Two modes (mutually exclusive, exactly one required):
#   --R <label>   submit the single A_AB job for one R (e.g. the benchmark).
#                 <label> is the bare 3-decimal label, e.g. 1p500.
#   --all         submit all 68 jobs under ONE sentinel pair.
#
# Usage:
#   ./submit_all_movecs.sh --R 1p500    # benchmark one R (1 job)
#   ./submit_all_movecs.sh --all        # full window (68 jobs)
#
# Skip-existing: a .nw with a matching .out is skipped, so a partial rerun
# after failures only submits the missing jobs.
#
# Logs: ~/BSSE/Ne/2_new/movecs_study/scripts/<batch_label>_logs/

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
EMAIL="frojas32@iastate.edu"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"                     # .../2_new/movecs_study
R_CONFIG_DIR="${BASE_DIR}/R_config"
MONOMER_NW="${BASE_DIR}/monomer/SCF/aug-cc-pvdz/A_A.nw"
SUBMIT_MOVECS="${SCRIPT_DIR}/submit_movecs.sh"

# ── Parse CLI ─────────────────────────────────────────────────────────────────
R_LABEL=""
ALL=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --R)   R_LABEL="$2"; shift 2 ;;
        --all) ALL=1;        shift 1 ;;
        -h|--help)
            echo "Usage: $0 (--R <label> | --all)"
            echo "  --R <label>   submit the A_AB job for one R, e.g. 1p500"
            echo "  --all         submit all 68 jobs (67 A_AB + 1 A_A monomer)"
            exit 0
            ;;
        *) echo "Error: unknown arg $1"; exit 1 ;;
    esac
done

if [[ -n "$R_LABEL" && "$ALL" -eq 1 ]]; then
    echo "Error: --R and --all are mutually exclusive."
    exit 1
fi
if [[ -z "$R_LABEL" && "$ALL" -eq 0 ]]; then
    echo "Error: one of --R <label> or --all is required."
    echo "Usage: $0 (--R <label> | --all)"
    exit 1
fi

if [[ ! -d "$R_CONFIG_DIR" ]]; then
    echo "Error: R_config folder not found: $R_CONFIG_DIR"
    echo "       Run generate_movecs_inputs.py first."
    exit 1
fi

# ── Determine which R folders to walk ─────────────────────────────────────────
if [[ "$ALL" -eq 1 ]]; then
    mapfile -t R_DIRS < <(find "$R_CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d | sort)
    if [[ ${#R_DIRS[@]} -eq 0 ]]; then
        echo "Error: no R folders found under $R_CONFIG_DIR"
        exit 1
    fi
    BATCH_LABEL="all_movecs"
else
    mapfile -t MATCHES < <(find "$R_CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d \
                           -name "*_R_${R_LABEL}" | sort)
    if [[ ${#MATCHES[@]} -eq 0 ]]; then
        echo "Error: no R folder matching *_R_${R_LABEL} under $R_CONFIG_DIR"
        exit 1
    fi
    if [[ ${#MATCHES[@]} -gt 1 ]]; then
        echo "Error: label ${R_LABEL} is ambiguous, matched ${#MATCHES[@]} folders:"
        printf '   %s\n' "${MATCHES[@]}"
        exit 1
    fi
    R_DIRS=("${MATCHES[0]}")
    BATCH_LABEL="R_${R_LABEL}_movecs"
fi

# ── Prepare log folder ────────────────────────────────────────────────────────
LOG_DIR="${SCRIPT_DIR}/${BATCH_LABEL}_logs"
mkdir -p "$LOG_DIR"

echo "═══════════════════════════════════════════════════════════════════"
echo "  Ne/2_new movecs_study batch submission"
echo "  Mode:       $([[ "$ALL" -eq 1 ]] && echo '--all' || echo "--R ${R_LABEL}")"
echo "  R folders:  ${#R_DIRS[@]}"
echo "  Log dir:    ${LOG_DIR}"
echo "═══════════════════════════════════════════════════════════════════"

# ── Submit sentinel #1: "submitted" ──────────────────────────────────────────
SENTINEL_START=$(sbatch --parsable \
    --job-name="job ${BATCH_LABEL} submitted" \
    --output="${LOG_DIR}/${BATCH_LABEL}_submitted.log" \
    --time=00:01:00 --mem=100M --ntasks=1 \
    --mail-type=END --mail-user="${EMAIL}" \
    --wrap="echo '${BATCH_LABEL} batch submitted at' \$(date)")

echo "Submitted 'batch-submitted' sentinel (jobid=${SENTINEL_START})"

# ── Submit the R-independent monomer job once, in --all mode ─────────────────
JOB_IDS=()
N_SUBMITTED=0
N_SKIPPED=0
N_TOTAL=0

if [[ "$ALL" -eq 1 ]]; then
    if [[ -f "$MONOMER_NW" ]]; then
        N_TOTAL=$((N_TOTAL + 1))
        if [[ -f "${MONOMER_NW%.nw}.out" ]]; then
            N_SKIPPED=$((N_SKIPPED + 1))
        else
            JID=$(sbatch --parsable --export=ALL \
                --job-name="monomer_A_A" \
                --output="${LOG_DIR}/monomer_A_A.log" \
                "${SUBMIT_MOVECS}" "${MONOMER_NW}")
            JOB_IDS+=("$JID")
            N_SUBMITTED=$((N_SUBMITTED + 1))
        fi
    else
        echo "Warning: monomer input not found, skipping: $MONOMER_NW"
    fi
fi

# ── Walk R folders and submit the A_AB jobs ──────────────────────────────────
for RDIR in "${R_DIRS[@]}"; do
    NW_DIR="${RDIR}/SCF/aug-cc-pvdz"
    if [[ ! -d "$NW_DIR" ]]; then
        echo "Warning: expected input dir missing, skipping: $NW_DIR"
        continue
    fi

    R_FOLDER=$(basename "$RDIR")          # e.g. 001_R_1p500

    for NW_FILE in "$NW_DIR"/*.nw; do
        [[ -e "$NW_FILE" ]] || continue
        N_TOTAL=$((N_TOTAL + 1))

        OUT_FILE="${NW_FILE%.nw}.out"
        if [[ -f "$OUT_FILE" ]]; then
            N_SKIPPED=$((N_SKIPPED + 1))
            continue
        fi

        NW_BASE=$(basename "$NW_FILE")
        JOB_NAME="${R_FOLDER}_${NW_BASE%.nw}"   # e.g. 001_R_1p500_A_AB

        JID=$(sbatch --parsable --export=ALL \
            --job-name="${JOB_NAME}" \
            --output="${LOG_DIR}/${JOB_NAME}.log" \
            "${SUBMIT_MOVECS}" "${NW_FILE}")

        JOB_IDS+=("$JID")
        N_SUBMITTED=$((N_SUBMITTED + 1))
    done
done

echo "───────────────────────────────────────────────────────────────────"
echo "  Total .nw files scanned : ${N_TOTAL}"
echo "  Skipped (out exists)    : ${N_SKIPPED}"
echo "  Submitted this run      : ${N_SUBMITTED}"
echo "───────────────────────────────────────────────────────────────────"

# ── Submit sentinel #2: "done" (depends on all jobs) ─────────────────────────
if [[ ${N_SUBMITTED} -gt 0 ]]; then
    DEP_LIST=$(IFS=,; echo "${JOB_IDS[*]}")
    SENTINEL_END=$(sbatch --parsable \
        --job-name="job ${BATCH_LABEL} finished" \
        --output="${LOG_DIR}/${BATCH_LABEL}_done.log" \
        --time=00:01:00 --mem=100M --ntasks=1 \
        --dependency=afterany:"${DEP_LIST}" \
        --mail-type=END --mail-user="${EMAIL}" \
        --wrap="echo '${BATCH_LABEL} batch done at' \$(date)")
    echo "Submitted 'batch-done' sentinel (jobid=${SENTINEL_END}), depends on ${N_SUBMITTED} jobs"
else
    echo "No jobs submitted (all outputs already exist). No 'done' sentinel needed."
fi

echo "═══════════════════════════════════════════════════════════════════"
echo "  Emails will be sent to: ${EMAIL}"
echo "  Monitor with: squeue -u \$USER"
echo "  Batch-complete signal: ${LOG_DIR}/${BATCH_LABEL}_done.log"
echo "═══════════════════════════════════════════════════════════════════"
