#!/bin/bash
# submit_movecs.sh
# Slurm batch script for a single NWChem SCF/aug-cc-pVDZ calculation for the
# Ne/2_new density-matrix sub-study (movecs_study).
#
# Layout of jobs on NOVA:
#   ~/BSSE/Ne/2_new/movecs_study/R_config/<NNN>_R_<label>/SCF/aug-cc-pvdz/A_AB.nw
#   ~/BSSE/Ne/2_new/movecs_study/monomer/SCF/aug-cc-pvdz/A_A.nw
#
# ─────────────────────────────────────────────────────────────────────────────
# THE ONE CRITICAL DIFFERENCE FROM submit_energy.sh
# ─────────────────────────────────────────────────────────────────────────────
# The parent script's cleanup loop keeps ONLY .nw and .out:
#
#     for f in "${BASE}".*; do
#         if [[ "$f" != "${BASE}.nw" && "$f" != "${BASE}.out" ]]; then
#             rm -f "$f"
#         fi
#     done
#
# NWChem wrote A_AB.movecs on every one of the 400 parent jobs and that loop
# deleted it. This script keeps .movecs as a third protected extension. That
# single change is the entire reason for the re-run.
#
# Everything else is preserved from submit_energy.sh: same module, same
# --ntasks=2 (2-atom system; the >=6-atom --ntasks=1 rule does not apply),
# same clean-leaf-directory guarantee via `cd "$NW_DIR"` so no stale .movecs
# is inherited and the SCF genuinely iterates.
#
# NOTE ON THE PARENT DATA: this sub-study writes into movecs_study/ and never
# touches Ne/2_new/R_config/. The parent .out files remain preserved for the
# 1e/2e study (handoff Sec. 9 / Sec. 11.6).
#
# Resources: SCF-only on a 2-atom system is seconds, not minutes. 10 min and
# 8G are already generous; the parent's 1hr/20G were sized for CCSD(T).
#
# Usage (direct):
#   sbatch submit_movecs.sh /full/path/to/A_AB.nw
# Usage (via submit_all_movecs.sh):
#   the orchestrator walks the tree and calls sbatch

#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --mem=8G
#SBATCH --time=00:10:00

# ── Load NWChem ───────────────────────────────────────────────────────────────
module load nwchem/7.2.0-py39-py310-openmpi4-oxtctbu

# ── Resolve paths ─────────────────────────────────────────────────────────────
NW_FILE=$1

if [[ -z "$NW_FILE" ]]; then
    echo "Error: no .nw file provided."
    echo "Usage: sbatch submit_movecs.sh /full/path/to/file.nw"
    exit 1
fi

if [[ ! -f "$NW_FILE" ]]; then
    echo "Error: file not found: $NW_FILE"
    exit 1
fi

NW_DIR=$(dirname  "$NW_FILE")
NW_BASE=$(basename "$NW_FILE")
OUT_BASE="${NW_BASE%.nw}.out"

# ── Run NWChem ────────────────────────────────────────────────────────────────
cd "$NW_DIR" || { echo "Error: cannot cd to $NW_DIR"; exit 1; }

mpirun -np "$SLURM_NTASKS" nwchem "$NW_BASE" > "$OUT_BASE" 2>&1

# ── Clean up NWChem scratch (keep .nw, .out AND .movecs) ─────────────────────
BASE="${NW_BASE%.nw}"
for f in "${BASE}".*; do
    if [[ "$f" != "${BASE}.nw" \
       && "$f" != "${BASE}.out" \
       && "$f" != "${BASE}.movecs" ]]; then
        rm -f "$f"
    fi
done

# ── Hard gate: the movecs is the entire point of this job ────────────────────
# Fail loudly rather than silently leaving a gap in the R scan. Without this,
# a missing movecs would only surface much later, in the reader.
if [[ ! -f "${BASE}.movecs" ]]; then
    echo "ERROR: ${BASE}.movecs was not produced in ${NW_DIR}" >&2
    echo "       Check that the .nw contains 'vectors output ${BASE}.movecs'" >&2
    exit 1
fi

echo "OK: kept ${BASE}.out and ${BASE}.movecs ($(stat -c%s "${BASE}.movecs") bytes)"
