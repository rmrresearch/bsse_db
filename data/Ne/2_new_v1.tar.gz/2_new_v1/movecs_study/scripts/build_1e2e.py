r"""
build_1e2e.py — One- vs two-electron decomposition of the SCF BSSE across R.

THE QUESTION THIS ANSWERS
-------------------------
Fitting guessed functional forms to 2b_bsse_SCF has failed twice. Both the pure
N-Gaussian ladder and the polynomial x Gaussian ladder leave SMOOTH, STRUCTURED
residuals that subdivide into more lobes as terms are added rather than
collapsing to scatter. That is the signature of a wrong functional family, and
it was shown not to be an overfitting artefact: fitting M2 on 10 points predicts
the other 57 with RMSE 0.0379 against 0.0377 for a fit using all 67, so the
error is pure bias.

The constructive alternative is to BUILD Delta E_SCF from the measured density
and the analytic integrals rather than fit it:

    Delta E_SCF = sum_ij P_ij(R) H_ij(R)   +   (1/2) sum P G(P)
                  \_______ 1-electron _______/    \___ 2-electron ___/

The one-electron part is cheap: S, T and V over contracted Gaussians on two
centres are closed form from the exponents already in the .out. The
two-electron part needs four-index integrals over 46 functions -- a
substantially larger job.

So before writing either, this script asks which half actually carries the
structure. Specifically the SHOULDER in 2b_bsse_SCF near R = 2.35-2.7 A, which
contains the reproducible turning point at R = 2.288-2.439 (|BSSE_SCF| increases
outward over five consecutive points; confirmed at two independent convergence
thresholds, and ~5 orders of magnitude above the gnorm ~ 1e-10 noise floor).

  - if Delta E_1e is smooth and Delta E_2e carries the shoulder
        -> coding S, T, V will not help; the effort belongs on the 2e term
  - if Delta E_1e carries the shoulder
        -> the one-electron integrals suffice and the path is bounded

Costs one grep. No new compute.

WHAT IS EXTRACTED
-----------------
NWChem prints, in every 'Final RHF results' block:

    Total SCF energy =   -128.496962546215
    One-electron energy =   -182.407692103369
    Two-electron energy =     53.910729557135

Per R, for monomer A in the union basis (A_AB) against monomer A in its own
basis (A_A, R-independent, read once):

    dE_1e(R) = E_1e(AB) - E_1e(A)
    dE_2e(R) = E_2e(AB) - E_2e(A)
    dE_scf(R) = E_scf(AB) - E_scf(A)          [= 2b_bsse_SCF / 2]

HARD GATE
---------
dE_1e + dE_2e must equal dE_scf to ~1e-10 Ha. Nuclear repulsion is identically
zero for A_A and for A_AB (the ghost carries no charge), so the three-way
identity is exact and any deviation means a parse error. The script aborts
rather than writing a CSV it cannot vouch for.

SIGN CONVENTION
---------------
Signed values in Hartree for the raw columns, signed kcal/mol for the BSSE-like
columns, absolute values applied at plot time only -- matching the parent study.
Note dE_1e and dE_2e are LARGE and OPPOSITE (order 0.1 Ha each) while their sum
is ~1e-4 Ha. This is a near-cancellation of four significant figures, so the
fractional metric |dE_1e|/(|dE_1e|+|dE_2e|) says almost nothing about which term
controls the SHAPE. The shape question is answered by the derivative structure,
not the magnitudes, which is why the script plots both terms against R rather
than reporting a single ratio.

Usage:
    python3 build_1e2e.py
    python3 build_1e2e.py --no-plot
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

R_VALUES = np.linspace(1.5, 4.5, 100)
METHOD_DIR, BASIS_DIR = "SCF", "aug-cc-pvdz"
HART2KCAL = 627.5094740631
CONSISTENCY_TOL = 1.0e-10          # Ha, on dE_1e + dE_2e - dE_scf

FIELDS = {
    "scf": "Total SCF energy =",
    "e1":  "One-electron energy =",
    "e2":  "Two-electron energy =",
}


def r_to_label(r: float) -> str:
    return f"{r:.3f}".replace(".", "p")


def grab(path: Path) -> dict:
    """Last numeric field of the last line carrying each label."""
    out = {k: None for k in FIELDS}
    text = path.read_text(errors="replace")
    for line in text.splitlines():
        for key, label in FIELDS.items():
            if label in line:
                try:
                    out[key] = float(line.split()[-1])
                except (ValueError, IndexError):
                    pass
    missing = [FIELDS[k] for k, v in out.items() if v is None]
    if missing:
        raise SystemExit(f"ERROR: {path} missing: {missing}")
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--no-plot", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent.parent
    mono = root / "monomer" / METHOD_DIR / BASIS_DIR / "A_A.out"
    if not mono.exists():
        raise SystemExit(f"ERROR: monomer output not found: {mono}")
    ref = grab(mono)
    print(f"monomer reference (R-independent):")
    print(f"  E_scf = {ref['scf']:.12f}   E_1e = {ref['e1']:.12f}   "
          f"E_2e = {ref['e2']:.12f}")

    rows = []
    for folder in sorted((root / "R_config").iterdir()):
        if not folder.is_dir():
            continue
        try:
            index0 = int(folder.name.split("_")[0]) - 1
        except ValueError:
            continue
        out = folder / METHOD_DIR / BASIS_DIR / "A_AB.out"
        if not out.exists():
            continue
        v = grab(out)
        d1 = v["e1"] - ref["e1"]
        d2 = v["e2"] - ref["e2"]
        ds = v["scf"] - ref["scf"]
        resid = ds - (d1 + d2)
        if abs(resid) > CONSISTENCY_TOL:
            raise SystemExit(
                f"ERROR: {out}\n"
                f"  dE_1e + dE_2e = {d1 + d2:.12f} but dE_scf = {ds:.12f}\n"
                f"  residual {resid:.3e} Ha exceeds {CONSISTENCY_TOL:.0e}."
            )
        r = float(R_VALUES[index0])
        rows.append({
            "R": r, "grid_index": index0 + 1, "R_label": r_to_label(r),
            "E_1e_AB": v["e1"], "E_2e_AB": v["e2"], "E_scf_AB": v["scf"],
            "dE_1e_Ha": d1, "dE_2e_Ha": d2, "dE_scf_Ha": ds,
            "dE_1e_kcal": d1 * HART2KCAL,
            "dE_2e_kcal": d2 * HART2KCAL,
            "dE_scf_kcal": ds * HART2KCAL,
            # 2b_bsse_SCF convention: both monomers, symmetric dimer
            "bsse_scf_kcal": 2.0 * ds * HART2KCAL,
            "frac_1e": abs(d1) / (abs(d1) + abs(d2)),
            "consistency_resid_Ha": resid,
        })

    if not rows:
        raise SystemExit("ERROR: no A_AB.out files found.")

    df = pd.DataFrame(rows).sort_values("grid_index").reset_index(drop=True)
    out_csv = root / "data_frames_plots" / "ne_dimer_1e2e_vs_R.csv"
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False, float_format="%.15g")

    print(f"\nrows written : {len(df)}")
    print(f"output       : {out_csv}")
    print(f"consistency  : max |dE_1e + dE_2e - dE_scf| = "
          f"{df['consistency_resid_Ha'].abs().max():.3e} Ha  (gate {CONSISTENCY_TOL:.0e})")

    print(f"\n{'R':>7}{'dE_1e':>14}{'dE_2e':>14}{'dE_scf':>14}{'frac_1e':>9}")
    print(f"{'(A)':>7}{'(kcal/mol)':>14}{'(kcal/mol)':>14}{'(kcal/mol)':>14}")
    for t in [1.5, 1.9, 2.2, 2.35, 2.5, 2.7, 3.0, 3.5]:
        i = (df["R"] - t).abs().idxmin()
        x = df.loc[i]
        print(f"{x['R']:>7.3f}{x['dE_1e_kcal']:>14.4f}{x['dE_2e_kcal']:>14.4f}"
              f"{x['dE_scf_kcal']:>14.6f}{x['frac_1e']:>9.4f}")

    # Which term carries the shoulder? Compare curvature in the shoulder window
    # against the smooth region, per term, after normalising each to its own
    # range so the comparison is about SHAPE and not magnitude.
    print("\nSHAPE TEST — second difference, normalised per term")
    print("  (large in the shoulder window relative to elsewhere = carries it)")
    win = (df["R"] >= 2.30) & (df["R"] <= 2.75)
    for col, name in [("dE_1e_kcal", "dE_1e"), ("dE_2e_kcal", "dE_2e"),
                      ("dE_scf_kcal", "dE_scf")]:
        y = df[col].to_numpy()
        rng = y.max() - y.min()
        if len(y) < 7 or rng <= 0 or win.sum() < 3 or (~win).sum() < 3:
            print(f"  {name:<8} skipped (need the full R grid for this test)")
            continue
        y = (y - y.min()) / rng
        d2y = np.gradient(np.gradient(y))
        inside = np.abs(d2y[win.to_numpy()]).mean()
        outside = np.abs(d2y[~win.to_numpy()]).mean()
        print(f"  {name:<8} |d2| shoulder = {inside:.3e}   elsewhere = "
              f"{outside:.3e}   ratio = {inside / outside:6.2f}")

    if args.no_plot:
        return

    import matplotlib
    import matplotlib.pyplot as plt
    plt.rcParams["text.usetex"] = True
    plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
    plt.rcParams["font.family"] = "serif"

    fig, axes = plt.subplots(3, 1, figsize=(8, 10), sharex=True)
    axes[0].scatter(df["R"], df["dE_1e_kcal"], s=16, color="tab:blue")
    axes[0].set_ylabel(r"$\Delta E_{1e}$ (kcal/mol)")
    axes[1].scatter(df["R"], df["dE_2e_kcal"], s=16, color="tab:orange")
    axes[1].set_ylabel(r"$\Delta E_{2e}$ (kcal/mol)")
    axes[2].scatter(df["R"], df["dE_scf_kcal"], s=16, color="black")
    axes[2].set_ylabel(r"$\Delta E_{\mathrm{SCF}}$ (kcal/mol)")
    axes[2].set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    for ax in axes:
        ax.axvspan(2.30, 2.75, color="red", alpha=0.10)
    fig.tight_layout()
    p1 = out_csv.parent / "ne_dimer_1e2e_vs_R.png"
    fig.savefig(p1, dpi=300)
    plt.close(fig)

    # Normalised overlay: shape comparison with magnitude removed
    fig, ax = plt.subplots(figsize=(8, 5))
    for col, lab, c in [("dE_1e_kcal", r"$\Delta E_{1e}$", "tab:blue"),
                        ("dE_2e_kcal", r"$\Delta E_{2e}$", "tab:orange"),
                        ("dE_scf_kcal", r"$\Delta E_{\mathrm{SCF}}$", "black")]:
        y = df[col].to_numpy()
        ax.plot(df["R"], (y - y.min()) / (y.max() - y.min()), "o-", ms=3,
                color=c, label=lab, lw=1)
    ax.axvspan(2.30, 2.75, color="red", alpha=0.10)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"normalised to own range")
    ax.legend(frameon=False)
    fig.tight_layout()
    p2 = out_csv.parent / "ne_dimer_1e2e_normalised.png"
    fig.savefig(p2, dpi=300)
    plt.close(fig)
    print(f"\n  saved: {p1.name}\n  saved: {p2.name}")


if __name__ == "__main__":
    main()
