#!/usr/bin/env python3
"""
check_movecs.py — Verify the Ne/2_new movecs_study runs before anything is deleted.

Location:  Ne/2_new/movecs_study/scripts/
Inputs:    Ne/2_new/movecs_study/R_config/<NNN>_R_<label>/SCF/aug-cc-pvdz/A_AB.{out,movecs}
           Ne/2_new/movecs_study/monomer/SCF/aug-cc-pvdz/A_A.{out,movecs}

WHY THIS IS DIFFERENT FROM check_convergence.py
------------------------------------------------
The parent study gates on five label lines in the .out, because its downstream
consumers are text parsers. This study's deliverable is the BINARY .movecs, so a
converged .out is necessary but not sufficient -- the vectors file must also
exist, parse, and demonstrably belong to that converged SCF.

FIVE GATES PER JOB
------------------
  1a. .out exists and carries 'Total SCF energy ='
  1b. the SCF CONVERGED: the last iteration's orbital-gradient norm (gnorm) is
      at or below the convergence threshold NWChem printed, and the
      'Final RHF results' block is present
  2. .movecs exists
  3. .movecs parses: every Fortran record marker matches its trailer
  4. nbf and n_occ are correct
         A_AB : nbf = 46 (23 real Ne + 23 ghost), n_occ = 5
         A_A  : nbf = 23,                          n_occ = 5
  5. the energy in the .movecs trailing record matches 'Total SCF energy ='
     in the .out to ENERGY_TOL

Gate 5 is the one that matters most and the one the parent pipeline could not
have. NWChem writes the total energy into the last record of the .movecs. If
that value agrees with the .out, the coefficient matrix provably came from the
SCF that produced that energy -- it is not a stale file inherited from an
earlier run. The stale-.movecs bug is exactly what corrupted the ORIGINAL Ne
study (handoff Sec. 5: A_A runs read a converged .movecs, skipped iterations,
and printed no 1e/2e breakdown). This gate makes the same class of failure
impossible to miss here.

Status buckets (per job):
    ok        : all five gates pass
    no_out      : .out missing, or present without a total SCF energy
    unconverged : SCF did not reach the printed threshold, or no Final RHF block
    no_movecs : .out fine, .movecs absent (the cleanup loop is the usual cause)
    corrupt   : .movecs present but fails to parse
    mismatch  : parses, but nbf/n_occ wrong or energy disagrees with the .out

RUN THIS TWICE
--------------
  1. On NOVA, after the batch  -> did the jobs succeed?
  2. Locally, after the rsync  -> did the transfer succeed?

Only after the LOCAL run is green should anything be deleted on NOVA. After the
delete, the laptop copy is the only copy.

Usage:
    python3 check_movecs.py                # all 67 R + the monomer
    python3 check_movecs.py --R 1p500      # one R
    python3 check_movecs.py --summary      # counts only
    python3 check_movecs.py --failed       # only non-ok jobs

Exit status: 0 if everything passes, 1 otherwise -- so it can gate a delete:
    python3 check_movecs.py --summary && rm -f ../R_config/*/SCF/aug-cc-pvdz/*.out
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import numpy as np

from read_movecs import read_movecs, N_A


# Grid (single source of truth, matches generate_movecs_inputs.py).
R_VALUES = np.linspace(1.5, 4.5, 100)
N_WINDOW = 67

METHOD_DIR = "SCF"
BASIS_DIR = "aug-cc-pvdz"

EXPECTED_N_OCC = 5          # Ne: 10 electrons, closed shell
FIELD_SCF = "Total SCF energy ="

# ── SCF convergence gate ─────────────────────────────────────────────────────
# Rather than grep for a failure string (whose exact wording varies by NWChem
# build and failure mode), this checks POSITIVELY, against two things NWChem
# always prints on a successful run:
#
#   Convergence threshold     :          1.000E-08
#                iter       energy          gnorm     gmax       time
#                   3     -128.4969625462  4.59D-08  2.80D-08      1.6
#         Final RHF  results
#
# Gate: the LAST iteration's gnorm must be <= the threshold NWChem itself
# printed, and the 'Final RHF results' block must be present. The orbital
# gradient norm IS the convergence criterion (NWChem manual, THRESH directive:
# "The convergence threshold is the norm of the orbital gradient"), so this
# tests the actual criterion rather than a proxy.
#
# The printed threshold is also reported, which independently confirms the
# `thresh 1e-8` in the .nw was honoured -- a run at the 1e-4 default would show
# 1.000E-04 here and be visible immediately.
RE_THRESHOLD = re.compile(r"Convergence threshold\s*:\s*([\d.]+[ED][+-]?\d+)",
                          re.IGNORECASE)
RE_ITER_ROW = re.compile(
    r"^\s+(\d+)\s+(-?\d+\.\d+)\s+([\d.]+[DE][+-]\d+)\s+([\d.]+[DE][+-]\d+)\s+[\d.]+\s*$"
)
FIELD_FINAL_BLOCK = "Final RHF"


def _fortran_float(s: str) -> float:
    """'4.59D-08' -> 4.59e-08. NWChem writes D exponents in the iteration table."""
    return float(s.upper().replace("D", "E"))

# Tolerance for gate 5. The .out prints 12 decimals; the .movecs stores the full
# double. 1e-9 Ha is far below anything this study resolves (the SCF BSSE at
# R = 4.5 A is ~3e-6 Ha) yet far above print-rounding, so the gate catches a
# genuinely stale file without firing on formatting.
ENERGY_TOL = 1.0e-9


def r_to_label(r: float) -> str:
    return f"{r:.3f}".replace(".", "p")


R_LABELS = [r_to_label(r) for r in R_VALUES[:N_WINDOW]]


def parse_out(path: Path) -> dict:
    """Extract energy and SCF convergence evidence from an .out file.

    Returns a dict with keys: energy, threshold, n_iter, gnorm, final_block.
    Any of energy/threshold/gnorm may be None if the run did not get that far.
    """
    info = {"energy": None, "threshold": None, "n_iter": None,
            "gnorm": None, "final_block": False}
    if not path.exists():
        return info

    text = path.read_text(errors="replace")
    info["final_block"] = FIELD_FINAL_BLOCK in text

    m = RE_THRESHOLD.search(text)
    if m:
        info["threshold"] = _fortran_float(m.group(1))

    last_iter = None
    for line in text.splitlines():
        if FIELD_SCF in line:
            try:
                info["energy"] = float(line.split()[-1])
            except (ValueError, IndexError):
                pass
        m = RE_ITER_ROW.match(line)
        if m:
            last_iter = m
    if last_iter:
        info["n_iter"] = int(last_iter.group(1))
        info["gnorm"] = _fortran_float(last_iter.group(3))

    return info


def check_job(out_path: Path, movecs_path: Path, expected_nbf: int):
    """Run the gates in order. Returns (status, message)."""
    out = parse_out(out_path)

    # Gate 1a: the .out exists and reports a total SCF energy.
    if out["energy"] is None:
        why = "no .out" if not out_path.exists() else "no 'Total SCF energy =' in .out"
        return "no_out", why

    # Gate 1b: the SCF actually converged. Checked positively against the
    # orbital-gradient norm, which is NWChem's own convergence criterion.
    if not out["final_block"]:
        return "unconverged", "no 'Final RHF results' block in .out"
    if out["gnorm"] is None or out["threshold"] is None:
        return "unconverged", ("could not read the SCF iteration table or the "
                               "printed convergence threshold")
    if out["gnorm"] > out["threshold"]:
        return "unconverged", (f"final gnorm {out['gnorm']:.2e} > threshold "
                               f"{out['threshold']:.2e} after {out['n_iter']} iterations")

    e_out = out["energy"]

    if not movecs_path.exists():
        return "no_movecs", ".movecs absent (cleanup loop? check submit_movecs.sh)"

    try:
        mv = read_movecs(movecs_path)
    except Exception as exc:                      # noqa: BLE001 - report anything
        return "corrupt", f"parse failed: {exc}"

    if mv.nbf != expected_nbf:
        return "mismatch", f"nbf = {mv.nbf}, expected {expected_nbf}"
    if mv.n_occ != EXPECTED_N_OCC:
        return "mismatch", f"n_occ = {mv.n_occ}, expected {EXPECTED_N_OCC}"

    de = abs(mv.energy - e_out)
    if de > ENERGY_TOL:
        return "mismatch", (f"energy .movecs {mv.energy:.12f} vs .out {e_out:.12f} "
                            f"(delta {de:.2e} > {ENERGY_TOL:.0e}) -- STALE .movecs?")

    return "ok", (f"E = {mv.energy:.12f}  nbf = {mv.nbf}  n_occ = {mv.n_occ}  "
                  f"gnorm = {out['gnorm']:.1e}/{out['threshold']:.0e} in {out['n_iter']} iter")


def jobs(root: Path, only_label: str | None):
    """Yield (job_name, out_path, movecs_path, expected_nbf)."""
    if only_label is None:
        mono = root / "monomer" / METHOD_DIR / BASIS_DIR
        yield "monomer/A_A", mono / "A_A.out", mono / "A_A.movecs", N_A

    r_config = root / "R_config"
    for folder in sorted(r_config.iterdir()) if r_config.is_dir() else []:
        if not folder.is_dir():
            continue
        label = folder.name.split("_R_")[-1]
        if only_label is not None and label != only_label:
            continue
        leaf = folder / METHOD_DIR / BASIS_DIR
        yield folder.name, leaf / "A_AB.out", leaf / "A_AB.movecs", 2 * N_A


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Verify .out + .movecs consistency for the movecs sub-study."
    )
    ap.add_argument("--R", dest="r_label", default=None, choices=R_LABELS,
                    metavar="LABEL", help="Check one R (e.g. 1p500).")
    ap.add_argument("--summary", action="store_true", help="Counts only.")
    ap.add_argument("--failed", action="store_true", help="Only non-ok jobs.")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent.parent
    if not (root / "R_config").is_dir():
        raise SystemExit(f"ERROR: expected 'R_config/' inside {root}, not found.")

    show_ok = not args.summary and not args.failed
    show_bad = not args.summary

    counts = {"ok": 0, "no_out": 0, "unconverged": 0, "no_movecs": 0,
              "corrupt": 0, "mismatch": 0}
    problems: list[tuple[str, str, str]] = []
    energies: list[float] = []

    if not args.summary:
        print(f"Checking {root}")
        print("─" * 78)

    for name, out_path, movecs_path, nbf in jobs(root, args.r_label):
        status, msg = check_job(out_path, movecs_path, nbf)
        counts[status] += 1

        if status == "ok":
            if show_ok:
                print(f"  ✅  {name:<22s}  {msg}")
            if movecs_path.exists():
                energies.append(read_movecs(movecs_path).energy)
        else:
            problems.append((name, status, msg))
            if show_bad:
                mark = {"no_out": "❌", "unconverged": "❌", "no_movecs": "⏳",
                        "corrupt": "❌", "mismatch": "✗"}[status]
                print(f"  {mark}  {name:<22s}  {status.upper()}: {msg}")

    total = sum(counts.values())
    expected = 1 + N_WINDOW if args.r_label is None else 1
    clean = counts["ok"] == total and total == expected

    print("\n" + "═" * 78)
    print(f"  {'ALL GATES PASSED ✅' if clean else 'ATTENTION NEEDED ✗'}")
    print(f"  ✅  ok        : {counts['ok']:>4}   (expected {expected})")
    print(f"  ❌  no_out    : {counts['no_out']:>4}")
    print(f"  ❌  unconverged: {counts['unconverged']:>3}")
    print(f"  ⏳  no_movecs : {counts['no_movecs']:>4}")
    print(f"  ❌  corrupt   : {counts['corrupt']:>4}")
    print(f"  ✗   mismatch  : {counts['mismatch']:>4}")
    print(f"      total     : {total:>4}")
    if energies:
        print(f"  E range   : [{min(energies):.9f}, {max(energies):.9f}] Ha")
    print("═" * 78)

    if problems and args.summary:
        print("\nProblems:")
        for name, status, msg in problems:
            print(f"  {name}  — {status}: {msg}")

    if clean:
        print("\nSafe to delete the NOVA copies — but only after this same check "
              "passes on the LOCAL tree.")
        sys.exit(0)
    else:
        print("\nDo NOT delete anything until this is green.")
        sys.exit(1)


if __name__ == "__main__":
    main()
