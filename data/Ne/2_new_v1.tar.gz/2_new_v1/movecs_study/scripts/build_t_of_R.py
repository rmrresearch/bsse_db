"""
build_t_of_R.py — Walk the movecs_study tree, extract the density-matrix blocks,
and write the t(R) CSV.

Pipeline position (mirrors the parent study's two-stage split):
    read_movecs.py     parsing layer      .movecs -> C, occ, eps
    build_t_of_R.py    builder layer      C -> P -> blocks -> CSV     <- this file

WHAT IS MEASURED
----------------
For monomer A computed in the union (dimer) basis, P = 2 C_occ C_occ^T splits by
AO index into

    P_AA  (23x23)  real Ne block
    P_AB  (23x23)  cross block
    P_BB  (23x23)  ghost block

The ghost-mixing amplitude is

    t(R) = ||P_AB(R)||_F

which is the one quantity the SCF block argument leaves undetermined. Everything
else in that argument (the GPT Gaussian factors, the Boys prefactors) is
closed-form; t(R) has to be measured.

Delta P_AA = P_AA(union basis) - P^A(own basis) is also recorded. P^A comes from
the single R-independent monomer job in monomer/. Its .movecs has nbf = 23, so it
drops straight into the AA block with no padding.

COLUMNS
-------
    R                full-precision grid value, recovered from the folder index
    grid_index       1-based index into the PARENT linspace(1.5, 4.5, 100)
    R_label          3-decimal 'p' tag, e.g. 1p500
    t_R              ||P_AB||_F                  <- the measurement
    norm_P_BB        ||P_BB||_F
    norm_P_AA        ||P_AA||_F
    norm_dP_AA       ||P_AA - P^A||_F
    idem_ratio       ||P_BB|| / ||P_AB||^2
    scf_energy       total SCF energy from the .movecs trailing record, Ha
    n_occ            occupied orbital count (5 for Ne; a gate, not a variable)

R IS RECOVERED FROM THE FOLDER INDEX, NOT THE LABEL
---------------------------------------------------
Same convention as the parent build_raw_data.py: the 3-decimal label is a rounded
human tag. Folder 002_R_1p530 is really R = 1.5303030303030303. Reading R from
the label would introduce a ~5e-4 A error, which is 1.6% of the grid step.

Because the folder indices are identical to the parent R_config, the R values in
this CSV match ne_dimer_bsse_vs_R.csv exactly, so the two join on R with no
interpolation and no tolerance matching.

IDEM_RATIO IS A CONVERGENCE DIAGNOSTIC, NOT A PHYSICS TEST
----------------------------------------------------------
For ANY converged single determinant, C^T S C = I gives P S P = 2P, whose BB
block reduces at leading order to

    P_BB = 1/2 P_BA S_AA P_AB + O(t^3)

so ||P_BB|| ~ ||P_AB||^2 holds regardless of whether the ghost-mixing picture is
correct. It is guaranteed by idempotency alone. This column is therefore a check
that the SCF converged and that the block split is right -- it is NOT evidence
for the block argument, and must not be reported as such. The ratio sits near
0.5, offset by the S_AA != I factor (0.578 at the R = 1.5 benchmark).

CSV PRECISION
-------------
float_format '%.15g', matching Ne/2_new (the parent study deviated from HF/H2O's
'%.10g' precisely so values reconcile bit-for-bit; see handoff Sec. 11 item 1).

Usage:
    python3 build_t_of_R.py                 # all available R -> CSV
    python3 build_t_of_R.py --R 1p500       # print one R, write nothing
    python3 build_t_of_R.py --out other.csv # alternate output path
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from read_movecs import read_movecs, density_matrix, blocks, N_A


# The PARENT grid. Do not redefine: t(R) must land on the parent's R values.
R_MIN, R_MAX, N_POINTS = 1.5, 4.5, 100
R_VALUES = np.linspace(R_MIN, R_MAX, N_POINTS)

METHOD_DIR = "SCF"
BASIS_DIR = "aug-cc-pvdz"

# Ne is a closed-shell 10-electron atom: exactly 5 doubly occupied orbitals.
# Anything else means the wrong file or a failed SCF, so it is a hard gate.
EXPECTED_N_OCC = 5


def r_to_label(r: float) -> str:
    """1.5303030303 -> '1p530' (3-decimal folder tag)."""
    return f"{r:.3f}".replace(".", "p")


def load_monomer_P(root: Path) -> np.ndarray:
    """P^A: monomer A in its own basis. R-independent, so read once.

    Returns a (23, 23) array. Raises if the monomer job is missing -- without it
    Delta P_AA cannot be formed.
    """
    path = root / "monomer" / METHOD_DIR / BASIS_DIR / "A_A.movecs"
    if not path.exists():
        raise SystemExit(
            f"ERROR: monomer reference not found: {path}\n"
            f"       Run the monomer job (submit_all_movecs.sh --all submits it)."
        )
    mv = read_movecs(path)
    if mv.nbf != N_A:
        raise SystemExit(
            f"ERROR: {path} has nbf = {mv.nbf}, expected {N_A}. "
            f"Is this really the monomer-in-own-basis job?"
        )
    if mv.n_occ != EXPECTED_N_OCC:
        raise SystemExit(f"ERROR: {path} has n_occ = {mv.n_occ}, expected {EXPECTED_N_OCC}")
    return density_matrix(mv)


def process_one(movecs: Path, P_A: np.ndarray, index0: int) -> dict:
    """Extract every recorded quantity for one R."""
    mv = read_movecs(movecs)

    if mv.nbf != 2 * N_A:
        raise SystemExit(
            f"ERROR: {movecs} has nbf = {mv.nbf}, expected {2 * N_A} "
            f"(monomer + ghost, aug-cc-pVDZ spherical)."
        )
    if mv.n_occ != EXPECTED_N_OCC:
        raise SystemExit(
            f"ERROR: {movecs} has n_occ = {mv.n_occ}, expected {EXPECTED_N_OCC}. "
            f"The SCF may have converged to the wrong state."
        )

    P = density_matrix(mv)
    b = blocks(P, N_A)

    n_AB = float(np.linalg.norm(b["AB"]))
    n_BB = float(np.linalg.norm(b["BB"]))
    r = float(R_VALUES[index0])

    return {
        "R": r,
        "grid_index": index0 + 1,
        "R_label": r_to_label(r),
        "t_R": n_AB,
        "norm_P_BB": n_BB,
        "norm_P_AA": float(np.linalg.norm(b["AA"])),
        "norm_dP_AA": float(np.linalg.norm(b["AA"] - P_A)),
        "idem_ratio": n_BB / n_AB**2 if n_AB > 0 else float("nan"),
        "scf_energy": mv.energy,
        "n_occ": mv.n_occ,
    }


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Extract t(R) = ||P_AB||_F from the movecs_study tree."
    )
    p.add_argument("--R", dest="r_label", default=None, metavar="LABEL",
                   help="Report a single R to stdout and write nothing.")
    p.add_argument("--out", default=None, metavar="PATH",
                   help="Output CSV path. Default: "
                        "movecs_study/data_frames_plots/ne_dimer_t_of_R.csv")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    # Anchoring: this script lives in movecs_study/scripts/.
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent
    r_config = root / "R_config"
    if not r_config.is_dir():
        raise SystemExit(f"ERROR: expected 'R_config/' inside {root}, not found.")

    P_A = load_monomer_P(root)

    rows = []
    missing = []
    for folder in sorted(r_config.iterdir()):
        if not folder.is_dir():
            continue
        try:
            index0 = int(folder.name.split("_")[0]) - 1
        except ValueError:
            print(f"Warning: skipping unrecognised folder {folder.name}", file=sys.stderr)
            continue

        movecs = folder / METHOD_DIR / BASIS_DIR / "A_AB.movecs"
        if not movecs.exists():
            missing.append(folder.name)
            continue

        row = process_one(movecs, P_A, index0)
        if args.r_label is not None and row["R_label"] != args.r_label:
            continue
        rows.append(row)

    if not rows:
        raise SystemExit("ERROR: no .movecs files found. Has the batch been pulled back?")

    df = pd.DataFrame(rows).sort_values("grid_index").reset_index(drop=True)

    if args.r_label is not None:
        with pd.option_context("display.float_format", "{:.10e}".format):
            print(df.to_string(index=False))
        return

    out = Path(args.out) if args.out else \
        root / "data_frames_plots" / "ne_dimer_t_of_R.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False, float_format="%.15g")

    print(f"rows written : {len(df)}")
    print(f"output       : {out}")
    print(f"R range      : [{df['R'].min():.6f}, {df['R'].max():.6f}] A")
    if missing:
        print(f"MISSING      : {len(missing)} folder(s) without A_AB.movecs")
        for name in missing[:10]:
            print(f"               {name}")
        if len(missing) > 10:
            print(f"               ... and {len(missing) - 10} more")
    print()
    print("t(R) summary")
    print(f"  t at R_min : {df['t_R'].iloc[0]:.6e}")
    print(f"  t at R_max : {df['t_R'].iloc[-1]:.6e}")
    print(f"  monotonic decreasing : {bool((df['t_R'].diff().dropna() < 0).all())}")
    print(f"  idem_ratio range     : "
          f"[{df['idem_ratio'].min():.4f}, {df['idem_ratio'].max():.4f}]  "
          f"(idempotency ~ 0.5; a convergence check, not a physics test)")


if __name__ == "__main__":
    main()
