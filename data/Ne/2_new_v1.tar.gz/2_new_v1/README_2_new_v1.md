# Ne dimer BSSE — study v1 (superseded)

Superseded by `2_new_v2/`. Retained: it is the only source of data beyond
3.5 Å, and it holds the fit-form survey and the density-matrix (`movecs`)
sub-study, neither of which is repeated in v2.

To be archived as `2_new_v1.tar.gz` once v2 is complete.

---

## 1. What is here

```
2_new_v1/
├── R_config/                  100 R-points, CCSD(T)/aug-cc-pVDZ
├── R_config_pickle_data/      raw_data.pickle
├── scripts/                   generation, parsing, BSSE assembly, plotting
├── data_frames_plots/         master CSV + fit-form survey
├── 2b_bsse_scf/               SCF-component ladder study (F0–F6, G1–G3)
├── movecs_study/              density-matrix / P_AB analysis
└── one_shot_study/            energy decomposition, SCF convergence
```

### 1.1 Main grid — `R_config/`

- 100 points, `R ∈ [1.5, 4.5] Å`, `ΔR = 0.0303 Å`
- CCSD(T)/aug-cc-pVDZ, single basis
- labels `001_R_1p500` … `100_R_4p500`
- four jobs per point: `A_A`, `A_AB`, `B_AB`, `AB_AB`

Parsed to `R_config_pickle_data/raw_data.pickle`, then to
`data_frames_plots/ne_dimer_bsse_vs_R.csv` (23 columns).

**Conventions.** `bsse = no_vmfc − vmfc`. Raw energy columns in Hartree,
signed; BSSE columns in kcal/mol, signed. Component columns are
**incremental** — `MP2c = E_MP2 − E_SCF`, `CCSD_Tc = E_CCSD(T) − E_MP2` — so
`SCF + MP2c + CCSD_Tc = total_bsse` identically.

<!-- TODO: record the SCF convergence threshold used, from any R_config
     .nw input or the corresponding .out header -->

### 1.2 Fit-form survey — `data_frames_plots/`

One sub-directory per candidate form fitted to the **total** `|BSSE|(R)`:

| directory | form |
|---|---|
| `gaussian_fit/` | `a·exp(−bR²)` |
| `erf_fit/` | `a[1 + erf(−bR)]` (Heindel–Xantheas 2020) |
| `gaussian_erf_fit/` | `a₁[1 + erf(−b₁R)] + a₂exp(−b₂R²)` |
| `2_gaussian_fit/` | two Gaussians |
| `n_gaussian_fit/` | n Gaussians, n scanned |
| `poly_gaussian_fit/` | `P(R)·exp(−bR²)` |

Most outputs carry the `Rmax3p5` suffix — fitted on `R ≤ 3.5 Å`, not the full
100-point range.

`gaussian_erf_fit/` additionally holds `*_b1pos*` variants, from a refit with
`b₁` constrained positive. See §3.2.

### 1.3 SCF ladder — `2b_bsse_scf/`

Systematic ladder of candidate forms for the **SCF component alone**, rungs
F0–F6 and G1–G3. See `2b_bsse_scf/README.md` for the rung definitions.

Outputs in `data_frames_plots/`:
`ne_scf_ladder_params_Rmax3p5.csv` (per-rung parameters, σ, RMSE in-window and
held-out, R², condition number, runs, acf, turning-point flag),
`ne_scf_ladder_curves_Rmax3p5.csv`, and the fit / residual / correlation plots.

### 1.4 Density-matrix study — `movecs_study/`

Independent 67-point grid, `R ∈ [1.5, 3.5] Å`, `ΔR = 0.0303 Å`, SCF only, with
`.movecs` retained. Produced `ne_dimer_P_AB_shells.csv`, `ne_dimer_t_of_R.csv`,
`ne_dimer_1e2e_vs_R.csv`.

Findings: `t(R) = ‖P_AB‖_F` is monotonically decreasing while `BSSE_SCF` is
not; SVD of the shell-pair-resolved `P_AB` channel matrix shows rank-2
structure capturing ≈90% of the variance.

### 1.5 One-shot SCF test — `one_shot_study/`

A test of whether `E_A(AB)` could be obtained from a single non-iterative SCF
step, using the converged monomer density or `E_A(A)` as the starting point,
rather than a full SCF in the dimer basis.

`energy_decomp.csv` — one-/two-electron energy decomposition.
`scf_convergence.csv` — SCF convergence behaviour from the tested guesses.

Exploratory; the outcome informed the v2 pipeline design.

---

## 2. Results that stand

**Component weights** over the 100-point grid: 40.2% SCF, 48.8% MP2
correlation, 11.0% CCSD(T) correlation. Exact-sum check
`|Σ components − total_bsse| = 4×10⁻¹⁵`.

**Non-monotonic structure in `|BSSE_SCF|(R)`** — a local minimum at
`R = 2.288 Å` (0.10611 kcal/mol) and a local maximum at `R = 2.439 Å`
(0.11325 kcal/mol); amplitude ≈ **0.0072 kcal/mol**. Verified to persist under
subsampling of the grid down to 20 points over `[1.5, 3.5]`.

**Structured residuals for every form tried.** F0 leaves 4 runs against ≈34
expected with acf = 0.908; no rung F0–G3 exceeds 7 runs. The residual lobes sit
at fixed positions in `R` across all rungs.

**Failure modes that closed specific rungs** — recorded so they are not
retried: sub-GPT-floor fitted exponents (F5, F6); variational-bound violations
(F3); parameter collinearity (G1, G2); catastrophic cancellation (G3).
Condition numbers reach 4×10¹⁸ (F3) and relative parameter uncertainties
reach 10⁴ (F3, F5).

**Held-out testing discriminates where RMSE does not.** F3 has the best
in-window RMSE (0.0191 kcal/mol) and the worst held-out ratio (3.08).

---

## 3. Why the study was superseded

### 3.1 The stopping criterion was unreachable

The ladder used residual randomisation as its acceptance test. That test
assumes the data is signal + random noise, so that a correct model leaves only
noise behind.

These data are deterministic. Repeating a job returns the same number; the only
numerical noise is at the SCF convergence threshold. The residuals are
therefore **model error**, not noise — a smooth difference between two smooth
curves — and smooth functions do not appear random. Residual randomisation is
unachievable for any closed-form fit here, and the search it drove had no
stopping point.

Consequence for v2: residual structure is retained as a **falsification** test
(structured residuals from a low-parameter model do show the form is wrong) but
is not used as a **validation** test. Validation moves to magnitude against a
stated tolerance, parameter constraint from theory, and transfer to systems not
fitted.

<!-- TODO: pending PI discussion -->

### 3.2 A defect in the combined Gaussian+erf fit

The reported combined fit has `b₁ = −0.223 Å⁻¹`, so the erf term reads
`erf(+0.223R)`, which **increases** with `R` and tends to `2a₁ = 0.136`
kcal/mol as `R → ∞`. BSSE must vanish at infinite separation.

The term is not a minor tail correction: at `R = 3.0 Å` the Gaussian
contributes ≈0.006 kcal/mol and the erf term ≈0.113. The 23% RMSE improvement
over the single-form fits is therefore produced by an additive near-constant,
not by an erf channel.

The `*_b1pos*` outputs in `gaussian_erf_fit/` are a refit with `b₁` constrained
positive. **Closed.** The defect belongs to a form that v2 does not use: v2
fits the SCF, MP2 and CCSD(T) components separately rather than fitting a
combined Gaussian+erf to the total, and checks the `R → ∞` limit of every
fitted form analytically, so this failure mode cannot recur.

### 3.3 The two-channel argument does not hold

The draft argued that the HF energy carries two structurally distinct
dependencies on inter-centre distance — Gaussian from overlap and kinetic
integrals, erf from nuclear-attraction and two-electron integrals.

Szabo & Ostlund eq. A.33 shows the nuclear-attraction integral carries the
**same** Gaussian prefactor `exp[−αβ/(α+β)R²]` as the overlap. The erf enters
as `F₀`, which is a modulation on top of that Gaussian, and its form is
`erf(κR)/R`, not `erf(κR)`. Confirmed against Boys 1950 and
Besalú & Carbó-Dorca 2011 (the latter also establishes that arbitrary angular
momentum multiplies by a polynomial in `R` and leaves the exponent unchanged).

The correct contrast is `exp(−γR²)` versus `exp(−γR²)·erf(κR)/R`, with
`γ = αβ/(α+β)` and `κ = β/√(α+β)` for a nucleus at A — both fixed by the basis
exponents.

<!-- TODO: pending PI discussion -->

### 3.4 Limitations of the grid

- `R ∈ [1.5, 4.5]` samples far into the tail, where `|BSSE| < 0.05` kcal/mol
  and nothing is resolved, while `R_e = 3.089–3.100 Å` sits at the edge of the
  region actually fitted (`Rmax3p5`).
- A single basis cannot test whether a fitted exponent lies inside the GPT
  window for **its own** basis — the check that distinguishes a derived form
  from a heuristic one.

The non-monotonic feature is *not* a limitation of v1. At 1.15×10⁻⁵ Ha it sits
roughly three orders of magnitude above the numerical floor implied by the
NWChem default `thresh 1.0e-4` (the manual states the energy converges to
approximately the square of the orbital-gradient norm). v2 tightens convergence
on the manual's general guidance for weakly interacting systems, not to rescue
this feature.

### 3.5 Scope of the fits

All forms in `data_frames_plots/` were fitted to the **total** `|BSSE|`. The
GPT/Boys argument governs the integrals entering `ΔE_SCF`; it says nothing
about correlation, which is ≈60% of the total here. Fitting the total with a
GPT-motivated form applies the argument outside its domain.

v2 fits the components separately, following Iwata *et al.* (J. Comput. Chem.
2026, Remark 6): HF and correlation BSSE originate in orbital basis
inconsistency (OBI) and configuration basis inconsistency (CBI) respectively
and must be examined separately. Note OBI is present in the correlation
energies as well, so the two are distinguishable but not independent.

---

## 4. Relationship to `results_ne_dimer.tex`

The draft's Figures 1–2 and the 44/46/10 component weights come from the
earlier `Ne/2` study — 268 randomly sampled orientations reduced to 50
separations — **not** from this directory. The draft describes them as 268
configurations, which overstates the number of distinct separations.

The draft's fit figures (3–5) come from `data_frames_plots/`.

The section requires rewriting for: the configuration count, the component
weights (40.2/48.8/11.0 on this grid), the `b₁ < 0` defect (§3.2), and the
two-channel argument (§3.3).

---

## 5. Carried into v2

- `scripts/` — extended for three bases and a tightened SCF threshold
- conventions — `bsse = no_vmfc − vmfc`, incremental components, signed storage
- the exact-sum check as a pipeline assertion
- the held-out test, moved from tail extrapolation to interior interpolation

**Not carried:** the residual-randomisation acceptance criterion (§3.1); rungs
F1–F6 and G1–G3 (§2, failure modes); fitting the total with a GPT-motivated
form (§3.5).
