load pymol_radial_xyz/0_0.0_0.0_1.5.xyz, 0_0.0_0.0_1.5
load pymol_radial_xyz/1_0.0_0.0_2.0.xyz, 1_0.0_0.0_2.0
load pymol_radial_xyz/2_0.0_0.0_2.5.xyz, 2_0.0_0.0_2.5
load pymol_radial_xyz/3_0.0_0.0_3.0.xyz, 3_0.0_0.0_3.0
load pymol_radial_xyz/4_0.0_0.0_3.5.xyz, 4_0.0_0.0_3.5
preset.ball_and_stick(selection='all', mode=1)
