"""
make_pymol_xyz.py

Purpose
-------
Extracts the Ne dimer geometry from each AB_AB.nw file in the translational
configurations and writes:

    1. pymol_xyz/n_x_y_z.xyz   — one XYZ file per configuration
    2. load_dimers.pml          — PyMOL script to load all configurations

XYZ format:
    2
    Ne dimer config n (x y z)
    Ne  0.0  0.0  0.0
    Ne  x    y    z

where (x, y, z) is the displacement vector of the second Ne atom.

Usage
-----
Run from Ne/2/:

    python3 scripts/make_pymol_xyz.py

Output:
    Ne/2/pymol_xyz/         <- one .xyz per configuration
    Ne/2/load_dimers.pml    <- PyMOL loader script
"""

from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

ROOT      = Path(__file__).parent.parent   # Ne/2/
TRNL_DIR  = ROOT / "translational"
PYMOL_DIR = ROOT / "pymol_xyz"
METHOD    = "CCSD_T"
BASIS     = "aug-cc-pvdz"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_geometry(nw_file: Path) -> list[tuple[str, str, str, str]]:
    """
    Parse atom lines from the geometry block of a NWChem input file.
    Returns list of (element, x, y, z) tuples.
    """
    atoms = []
    in_geometry = False
    for line in nw_file.read_text().splitlines():
        stripped = line.strip()
        if stripped.lower() == "geometry":
            in_geometry = True
            continue
        if stripped.lower() == "end" and in_geometry:
            break
        if in_geometry and stripped:
            parts = stripped.split()
            if len(parts) == 4:
                atoms.append((parts[0], parts[1], parts[2], parts[3]))
    return atoms


def write_xyz(path: Path, config_name: str, atoms: list[tuple[str, str, str, str]]) -> None:
    """Write a standard XYZ file."""
    # Parse index and coords from config name: n_x_y_z
    parts = config_name.split("_", 1)
    index = parts[0]
    coords = parts[1].replace("_", " ")
    lines = [
        str(len(atoms)),
        f"Ne dimer config {index} ({coords})",
    ]
    for elem, x, y, z in atoms:
        lines.append(f"{elem}  {x}  {y}  {z}")
    path.write_text("\n".join(lines) + "\n")


def write_pml(pml_path: Path, xyz_files: list[str]) -> None:
    """Write a PyMOL script that loads all XYZ files with ball-and-stick display."""
    lines = []
    for xyz_name in xyz_files:
        obj_name = Path(xyz_name).stem
        lines.append(f"load pymol_xyz/{xyz_name}, {obj_name}")
    lines.append("preset.ball_and_stick(selection='all', mode=1)")
    pml_path.write_text("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    # Collect configurations in sorted order
    config_dirs = sorted([
        d for d in TRNL_DIR.iterdir()
        if d.is_dir()
    ])

    if not config_dirs:
        print(f"No configuration folders found in {TRNL_DIR}")
        return

    PYMOL_DIR.mkdir(exist_ok=True)
    xyz_filenames = []
    ok = 0
    warn = 0

    for config_dir in config_dirs:
        config_name = config_dir.name
        nw_file = config_dir / METHOD / BASIS / "AB_AB.nw"

        if not nw_file.exists():
            print(f"  [WARN] Missing: {nw_file}")
            warn += 1
            continue

        atoms = parse_geometry(nw_file)
        if len(atoms) != 2:
            print(f"  [WARN] Expected 2 atoms, got {len(atoms)} in {nw_file}")
            warn += 1
            continue

        xyz_name = f"{config_name}.xyz"
        xyz_path = PYMOL_DIR / xyz_name
        write_xyz(xyz_path, config_name, atoms)
        xyz_filenames.append(xyz_name)
        ok += 1

    # Write PyMOL loader script
    pml_path = ROOT / "load_dimers.pml"
    write_pml(pml_path, sorted(xyz_filenames))

    print(f"\nDone.")
    print(f"  {ok} XYZ files written to {PYMOL_DIR}")
    if warn:
        print(f"  {warn} warnings — check output above")
    print(f"  PyMOL script written to {pml_path}")
    print(f"\nTo visualize in PyMOL, run from Ne/2/:")
    print(f"  pymol load_dimers.pml")


if __name__ == "__main__":
    main()