"""
copy_rename_files.py

Purpose
-------
Reorganize the Ne dimer NWChem input/output files from the original
Ne_Ne_distance_x_y_z/ flat structure into the standardized layout:

    translational/n_x_y_z/CCSD_T/aug-cc-pvdz/REAL_BASIS.nw
    translational/n_x_y_z/CCSD_T/aug-cc-pvdz/REAL_BASIS.out

where n is the configuration index (0-based, assigned by sorted order of
the original folder names) and x, y, z are the Ne-Ne displacement vector
components in Angstroms.

Original files are preserved in original_data/ as backup.

File renaming convention (BASIS_REAL -> REAL_BASIS):
    input_E_A_A.txt   -> A_A.nw
    input_E_AB_AB.txt -> AB_AB.nw
    input_E_AB_A.txt  -> A_AB.nw
    input_E_AB_B.txt  -> B_AB.nw
    (same pattern for output_E_*.txt -> *.out)

Usage
-----
Run from the Ne/2/ directory:

    python3 scripts/copy_rename_files.py

The script is safe to re-run: it skips destinations that already exist.
"""

import shutil
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

ROOT      = Path(__file__).parent.parent   # Ne/2/
ORIG_DATA = ROOT / "original_data"
TRNL_DIR  = ROOT / "translational"
METHOD    = "CCSD_T"
BASIS     = "aug-cc-pvdz"
PREFIX    = "Ne_Ne_distance_"


# ---------------------------------------------------------------------------
# File renaming map: original stem -> new stem
# (input_E_<key>.txt -> <value>.nw, output_E_<key>.txt -> <value>.out)
# ---------------------------------------------------------------------------

RENAME_MAP = {
    "A_A":   "A_A",
    "AB_AB": "AB_AB",
    "AB_A":  "A_AB",
    "AB_B":  "B_AB",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_coords(folder_name: str) -> tuple[str, str, str]:
    """Extract (x, y, z) strings from Ne_Ne_distance_x_y_z folder name."""
    stem = folder_name.removeprefix(PREFIX)
    parts = stem.split("_")
    if len(parts) != 3:
        raise ValueError(f"Unexpected folder name format: {folder_name}")
    return parts[0], parts[1], parts[2]


def new_config_name(index: int, x: str, y: str, z: str) -> str:
    return f"{index}_{x}_{y}_{z}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    # 1. Collect and sort original configuration folders
    orig_folders = sorted([
        f for f in ROOT.iterdir()
        if f.is_dir() and f.name.startswith(PREFIX)
    ])

    if not orig_folders:
        print("No original Ne_Ne_distance_* folders found in", ROOT)
        print("Have they already been moved to original_data/?")
        return

    print(f"Found {len(orig_folders)} configuration folders.")

    # 2. Create original_data/ and copy originals there as backup
    ORIG_DATA.mkdir(exist_ok=True)
    for folder in orig_folders:
        dest = ORIG_DATA / folder.name
        if dest.exists():
            print(f"  [SKIP backup] {folder.name} already in original_data/")
        else:
            shutil.copytree(folder, dest)
            print(f"  [backup] {folder.name} -> original_data/")

    # 3. Reorganize into translational/n_x_y_z/CCSD_T/aug-cc-pvdz/
    TRNL_DIR.mkdir(exist_ok=True)
    for index, folder in enumerate(orig_folders):
        x, y, z = parse_coords(folder.name)
        config_name = new_config_name(index, x, y, z)
        dest_dir = TRNL_DIR / config_name / METHOD / BASIS
        dest_dir.mkdir(parents=True, exist_ok=True)

        for orig_key, new_stem in RENAME_MAP.items():
            for ext, suffix in [("input", ".nw"), ("output", ".out")]:
                src = folder / f"{ext}_E_{orig_key}.txt"
                dst = dest_dir / f"{new_stem}{suffix}"

                if not src.exists():
                    print(f"  [WARN] Missing: {src}")
                    continue

                if dst.exists():
                    print(f"  [SKIP] {dst.name} already exists in {config_name}")
                    continue

                shutil.copy2(src, dst)

        print(f"  [{index:03d}] {folder.name} -> translational/{config_name}/")

    print(f"\nDone. {len(orig_folders)} configurations reorganized.")
    print(f"Originals preserved in {ORIG_DATA}")
    print(f"Reorganized files in   {TRNL_DIR}")


if __name__ == "__main__":
    main()