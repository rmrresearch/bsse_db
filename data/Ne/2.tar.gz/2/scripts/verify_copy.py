"""
verify_copy.py

Purpose
-------
Byte-by-byte verification that every file copied and renamed by
copy_rename_files.py matches its original in original_data/.

For each configuration, compares:
    original_data/Ne_Ne_distance_x_y_z/input_E_<key>.txt
    translational/n_x_y_z/CCSD_T/aug-cc-pvdz/<new_stem>.nw

    original_data/Ne_Ne_distance_x_y_z/output_E_<key>.txt
    translational/n_x_y_z/CCSD_T/aug-cc-pvdz/<new_stem>.out

Uses filecmp.cmp() with shallow=False for full content comparison.

Usage
-----
Run from anywhere inside Ne/2/:

    python3 scripts/verify_copy.py

Prints OK for each passing pair and MISMATCH for any failure.
Final line reports total verified / total expected.
"""

import filecmp
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration — must match copy_rename_files.py exactly
# ---------------------------------------------------------------------------

ROOT      = Path(__file__).parent.parent   # Ne/2/
ORIG_DATA = ROOT / "original_data"
TRNL_DIR  = ROOT / "translational"
METHOD    = "CCSD_T"
BASIS     = "aug-cc-pvdz"
PREFIX    = "Ne_Ne_distance_"

RENAME_MAP = {
    "A_A":   "A_A",
    "AB_AB": "AB_AB",
    "AB_A":  "A_AB",
    "AB_B":  "B_AB",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_coords(folder_name: str) -> tuple[str, str, str]:
    stem = folder_name.removeprefix(PREFIX)
    parts = stem.split("_")
    if len(parts) != 3:
        raise ValueError(f"Unexpected folder name format: {folder_name}")
    return parts[0], parts[1], parts[2]


def new_config_name(index: int, x: str, y: str, z: str) -> str:
    return f"{index}_{x}_{y}_{z}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    # Collect original folders in same sorted order as copy_rename_files.py
    orig_folders = sorted([
        f for f in ORIG_DATA.iterdir()
        if f.is_dir() and f.name.startswith(PREFIX)
    ])

    if not orig_folders:
        print(f"No original folders found in {ORIG_DATA}")
        return

    total    = 0
    verified = 0
    mismatches = []

    for index, orig_folder in enumerate(orig_folders):
        x, y, z = parse_coords(orig_folder.name)
        config_name = new_config_name(index, x, y, z)
        dest_dir = TRNL_DIR / config_name / METHOD / BASIS

        for orig_key, new_stem in RENAME_MAP.items():
            for ext, suffix in [("input", ".nw"), ("output", ".out")]:
                src = orig_folder / f"{ext}_E_{orig_key}.txt"
                dst = dest_dir / f"{new_stem}{suffix}"

                total += 1

                if not src.exists():
                    print(f"  [MISSING SRC] {src}")
                    mismatches.append(str(src))
                    continue

                if not dst.exists():
                    print(f"  [MISSING DST] {dst}")
                    mismatches.append(str(dst))
                    continue

                if filecmp.cmp(src, dst, shallow=False):
                    verified += 1
                else:
                    print(f"  [MISMATCH] {orig_folder.name}/{ext}_E_{orig_key}.txt"
                          f"  vs  {config_name}/{new_stem}{suffix}")
                    mismatches.append(str(dst))

    print(f"\n{'='*60}")
    print(f"Verification complete: {verified}/{total} files OK")
    if mismatches:
        print(f"{len(mismatches)} FAILURES:")
        for m in mismatches:
            print(f"  {m}")
    else:
        print("All files verified ✅")
    print('='*60)


if __name__ == "__main__":
    main()