"""
copy_rename_files_pvtz.py

Purpose
-------
Reorganize the Ne dimer aug-cc-pVTZ NWChem input/output files from the
Ne_pvtz_dimers.tar archive directly into the standardized layout:

    radial/n_x_y_z/CCSD_T/aug-cc-pvtz/REAL_BASIS.nw
    radial/n_x_y_z/CCSD_T/aug-cc-pvtz/REAL_BASIS.out

where n is the configuration index (0-based, assigned by sorted order of
the R values) and (x, y, z) = (0.0, 0.0, R) since this is a pure z-axis
radial scan.

Source archive: original_data/Ne_pvtz_dimers.tar

File renaming convention:
    input_monomer.txt  -> A_A.nw
    input_dimer.txt    -> AB_AB.nw
    input_A_AB.txt     -> A_AB.nw
    input_B_AB.txt     -> B_AB.nw
    (same pattern for output_*.txt -> *.out)

Usage
-----
Run from anywhere inside Ne/2/:

    python3 scripts/copy_rename_files_pvtz.py

The script is safe to re-run: it skips destinations that already exist.
"""

import tarfile
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

ROOT        = Path(__file__).parent.parent   # Ne/2/
ORIG_TAR    = ROOT / "original_data" / "Ne_pvtz_dimers.tar"
RADIAL_DIR  = ROOT / "radial"
METHOD      = "CCSD_T"
BASIS       = "aug-cc-pvtz"
PREFIX      = "Ne_dimer_"
SUFFIX      = "_pvtz"


# ---------------------------------------------------------------------------
# File renaming map: original stem -> (new stem, extension)
# ---------------------------------------------------------------------------

RENAME_MAP = {
    "input_monomer":  ("A_A",   ".nw"),
    "input_dimer":    ("AB_AB", ".nw"),
    "input_A_AB":     ("A_AB",  ".nw"),
    "input_B_AB":     ("B_AB",  ".nw"),
    "output_monomer": ("A_A",   ".out"),
    "output_dimer":   ("AB_AB", ".out"),
    "output_A_AB":    ("A_AB",  ".out"),
    "output_B_AB":    ("B_AB",  ".out"),
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_distance(folder_name: str) -> str:
    """Extract R (distance) string from Ne_dimer_R_pvtz folder name."""
    stem = folder_name.removeprefix(PREFIX).removesuffix(SUFFIX)
    return stem


def new_config_name(index: int, r: str) -> str:
    return f"{index}_0.0_0.0_{r}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    if not ORIG_TAR.exists():
        print(f"Archive not found: {ORIG_TAR}")
        return

    # 1. Collect and sort folder names from the tar
    with tarfile.open(ORIG_TAR, "r:") as tar:
        orig_folders = sorted([
            m.name.strip("./").rstrip("/")
            for m in tar.getmembers()
            if m.isdir()
            and m.name.strip("./").rstrip("/").startswith(PREFIX)
        ], key=lambda x: float(parse_distance(x)))

    if not orig_folders:
        print("No Ne_dimer_*_pvtz folders found in archive.")
        return

    print(f"Found {len(orig_folders)} configurations in {ORIG_TAR.name}.")

    # 2. Extract and rename into radial/n_x_y_z/CCSD_T/aug-cc-pvtz/
    RADIAL_DIR.mkdir(exist_ok=True)

    with tarfile.open(ORIG_TAR, "r:") as tar:
        for index, folder_name in enumerate(orig_folders):
            r = parse_distance(folder_name)
            config_name = new_config_name(index, r)
            dest_dir = RADIAL_DIR / config_name / METHOD / BASIS
            dest_dir.mkdir(parents=True, exist_ok=True)

            for orig_stem, (new_stem, ext) in RENAME_MAP.items():
                orig_internal = f"./{folder_name}/{orig_stem}.txt"
                dst = dest_dir / f"{new_stem}{ext}"

                if dst.exists():
                    print(f"  [SKIP] {dst.name} already exists in {config_name}")
                    continue

                try:
                    member = tar.getmember(orig_internal)
                    f = tar.extractfile(member)
                    if f is None:
                        print(f"  [WARN] Could not extract: {orig_internal}")
                        continue
                    dst.write_bytes(f.read())
                except KeyError:
                    print(f"  [WARN] Not found in archive: {orig_internal}")
                    continue

            print(f"  [{index:02d}] {folder_name} -> radial/{config_name}/")

    print(f"\nDone. {len(orig_folders)} configurations reorganized.")
    print(f"Reorganized files in {RADIAL_DIR}")


if __name__ == "__main__":
    main()