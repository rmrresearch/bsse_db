"""
plot_trnl_contours.py

Purpose
-------
Make x-z contour plots at fixed y for translational BSSE scans.
Works for any molecule (Ne, HF, H2O) via --mol argument.

Complete y slices are detected automatically from the CSV - no need
to specify them manually. Only slices with a full rectangular (x, z)
grid are plotted; incomplete slices are skipped with a warning.

Usage
-----
  # Ne dimer - auto-detects complete y slices, SCF only
  python3 plot_trnl_contours.py --mol Ne --method SCF

  # All three methods at once, save PNGs
  python3 plot_trnl_contours.py --mol Ne --method all --save

  # HF dimer, all methods
  python3 plot_trnl_contours.py --mol HF --method all --save

  # H2O dimer
  python3 plot_trnl_contours.py --mol H2O --method all

  # Plot vmfc or no_vmfc instead of bsse
  python3 plot_trnl_contours.py --mol Ne --method all --value vmfc

  # Check grid completeness separately:
  python3 analyze_trnl_grid_coverage.py
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Use TeX Live for all text rendering
plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "text.latex.preamble": r"\usepackage{amsmath} \usepackage{amssymb}",
})

# Mapping from CLI value key to LaTeX label for colorbar
VALUE_LABELS = {
    "bsse":    r"BSSE (Hartree)",
    "no_vmfc": r"$E_{\mathrm{int}}$ no VMFC (Hartree)",
    "vmfc":    r"$E_{\mathrm{int}}$ VMFC (Hartree)",
}

# Molecule display names for plot titles
MOL_LABELS = {
    "Ne":  r"Ne",
    "HF":  r"HF",
    "H2O": r"H$_2$O",
}


def find_complete_y_slices(df: pd.DataFrame) -> list:
    """
    Identify y values that have a complete rectangular (x, z) grid.

    A slice is complete when every (x, z) combination is present,
    i.e. n_points == n_x * n_z with no missing entries.

    Parameters
    ----------
    df : pd.DataFrame
        Translational dataframe with columns x, y, z.

    Returns
    -------
    list of float
        Sorted list of y values with complete grids, ready to plot.
    """
    complete = []
    for y0, grp in df.groupby("y"):
        n_x = grp["x"].nunique()
        n_z = grp["z"].nunique()
        if len(grp) == n_x * n_z:
            complete.append(y0)
    return sorted(complete)


def contour_fixed_y(
    df: pd.DataFrame,
    mol: str,
    y_values: list,
    value_col: str = "bsse",
    levels: int = 30,
    save: bool = False,
    prefix: str = "",
) -> None:
    """
    Make x-z contour plots at fixed y slices.

    Parameters
    ----------
    df : pd.DataFrame
        Translational BSSE dataframe with columns x, y, z and value_col.
    mol : str
        Molecule label for the plot title, e.g. 'Ne', 'HF', 'H2O'.
    y_values : list of float
        Complete y slices to plot (from find_complete_y_slices).
    value_col : str
        Column to contour ('bsse', 'no_vmfc', 'vmfc').
    levels : int
        Number of contour levels.
    save : bool
        If True, save each figure as a PNG file.
    prefix : str
        String appended to title and filename, e.g. 'SCF_aug-cc-pvdz'.
    """
    cbar_label = VALUE_LABELS.get(value_col, f"{value_col} (Hartree)")
    mol_label  = MOL_LABELS.get(mol, mol)

    for y0 in y_values:
        dfy = df[df["y"] == y0].copy()

        # Pivot to rectangular grid: rows = x, cols = z
        grid = dfy.pivot(index="x", columns="z", values=value_col)

        missing = int(grid.isna().sum().sum())
        if missing != 0:
            print(f"[WARN] y={y0}: grid has {missing} missing points; skipping.")
            continue

        X, Z = np.meshgrid(grid.columns.to_numpy(), grid.index.to_numpy())
        V = grid.to_numpy()

        plt.figure(figsize=(6, 5))
        cf = plt.contourf(X, Z, V, levels=levels)
        cbar = plt.colorbar(cf)
        cbar.set_label(cbar_label, fontsize=13)
        cbar.ax.tick_params(labelsize=11)
        plt.xlabel(r"{\large $z$} (\AA)", fontsize=13)
        plt.ylabel(r"{\large $x$} (\AA)", fontsize=13)
        plt.xticks(fontsize=11)
        plt.yticks(fontsize=11)
        plt.title(
            rf"{mol_label} dimer {cbar_label.split('(')[0].strip()} contour at "
            rf"$y = {y0}\,\mathrm{{\AA}}$ ({prefix})",
            fontsize=13
        )
        plt.tight_layout()

        if save:
            fname = f"contour_xz_y{y0:g}_{value_col}_{mol}_{prefix}.png"
            plt.savefig(fname, dpi=200, bbox_inches="tight")
            print(f"[SAVE] {fname}")

        plt.show()


def main():
    parser = argparse.ArgumentParser(
        description="Plot translational BSSE contours at complete y slices "
                    "(auto-detected from the CSV)."
    )
    parser.add_argument(
        "--mol",
        choices=["Ne", "HF", "H2O"],
        required=True,
        help="Molecule label used in plot titles (Ne, HF, H2O).",
    )
    parser.add_argument(
        "--method",
        choices=["SCF", "MP2", "CCSD_T", "all"],
        default="SCF",
        help="Method to plot, or 'all' for SCF, MP2, and CCSD_T (default: SCF).",
    )
    parser.add_argument(
        "--basis",
        default="aug-cc-pvdz",
    )
    parser.add_argument(
        "--value",
        choices=["bsse", "no_vmfc", "vmfc"],
        default="bsse",
    )
    parser.add_argument(
        "--levels",
        type=int,
        default=30,
    )
    parser.add_argument(
        "--save",
        action="store_true",
        help="Save PNGs to disk.",
    )
    args = parser.parse_args()

    methods = ["SCF", "MP2", "CCSD_T"] if args.method == "all" else [args.method]

    for method in methods:
        csv_name = f"trnl_{method}_{args.basis}.csv"
        df = pd.read_csv(csv_name)
        print(f"\n[INFO] Loaded {csv_name}  ({len(df)} rows)")

        complete_y = find_complete_y_slices(df)
        if not complete_y:
            print("[ERROR] No complete y slices found. Run analyze_trnl_grid_coverage.py for details.")
            continue

        print(f"[INFO] Complete y slices found: {complete_y}")
        print(f"[INFO] Plotting {len(complete_y)} contour(s) for {method}...")

        prefix = f"{method}_{args.basis}"
        contour_fixed_y(
            df,
            mol=args.mol,
            y_values=complete_y,
            value_col=args.value,
            levels=args.levels,
            save=args.save,
            prefix=prefix,
        )


if __name__ == "__main__":
    main()