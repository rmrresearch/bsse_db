"""
fit_erf.py
----------
Fit the total CCSD(T) Ne dimer BSSE to the Heindel-Xantheas (2020) form:
|BSSE(R)| = a * [1 + erf(-b R)].

Workflow:
  1. Fit stage: nonlinear least squares on |BSSE| = a * [1 + erf(-b R)]
     using all 268 points (no filtering). Initial guess from exploratory
     analysis (seed-insensitive within reasonable range): a0 = 2.5
     kcal/mol, b0 = 0.5 A^-1.

  2. Correlation stage: predicted vs measured |BSSE|, with OLS regression
     line for visual bias check and R^2_fit (linear space) as the
     comparison metric across functional forms.

Note on the fit parameter `a`:
  The Heindel form gives BSSE(R = 0) = a * [1 + erf(0)] = a. However, the
  data range here is R in [1.500, 3.031] A. The fitted value of `a` is
  therefore a *formal* R = 0 limit of the fit form, NOT a physically
  meaningful BSSE value (Ne atoms cannot overlap). The fit is valid only
  within the sampled R range. This caveat belongs in the Ne dimer
  write-up.

Reads:  ne_dimer_bsse_vs_R.csv  (uses |bsse_total| only)
Output: PNG files in the same directory as this script.

Usage:
    python3 fit_erf.py --stage fit
    python3 fit_erf.py --stage correlation
    python3 fit_erf.py --stage all
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.special import erf

# ---------------------------------------------------------------------------
# LaTeX rendering settings (consistent with build_bsse_vs_R.py / fit_gaussian.py)
# ---------------------------------------------------------------------------
plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
#   Script lives in:  .../data_frames_plots/erf_fit/
#   CSV (read-only):  .../data_frames_plots/ne_dimer_bsse_vs_R.csv
#   Plots (output):   .../data_frames_plots/erf_fit/
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent          # erf_fit/
PARENT_DIR = SCRIPT_DIR.parent                        # data_frames_plots/
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

# Initial guesses for nonlinear LS
# (Seed-insensitive in this regime — verified with multiple seeds; all
#  converged to identical (a, b). Picking modest, data-grounded values.)
A0_INIT = 2.5   # kcal/mol
B0_INIT = 0.5   # A^-1


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def erf_heindel(R: np.ndarray, a: float, b: float) -> np.ndarray:
    """|BSSE|(R) = a * [1 + erf(-b R)]  (Heindel-Xantheas 2020, eq. A.2)."""
    return a * (1.0 + erf(-b * R))


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_data() -> tuple[np.ndarray, np.ndarray]:
    """Return (R, |BSSE_total|) in (A, kcal/mol)."""
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    R = df["R"].to_numpy()
    bsse_total_abs = np.abs(df["bsse_total"].to_numpy())
    return R, bsse_total_abs


# ---------------------------------------------------------------------------
# Stage 1: nonlinear least squares
# ---------------------------------------------------------------------------
def run_fit(R: np.ndarray, bsse: np.ndarray,
            a0: float, b0: float) -> tuple[float, float, float, float, float]:
    """Nonlinear LS on |BSSE| = a * [1 + erf(-b R)].
    Returns (a, sigma_a, b, sigma_b, rmse)."""
    popt, pcov = curve_fit(erf_heindel, R, bsse, p0=[a0, b0])
    a, b = popt
    sigma_a, sigma_b = np.sqrt(np.diag(pcov))
    pred = erf_heindel(R, a, b)
    residuals = bsse - pred
    rmse = float(np.sqrt(np.mean(residuals**2)))

    print("=" * 60)
    print("STAGE 1 — NONLINEAR LS FIT: |BSSE| = a * [1 + erf(-b R)]")
    print("=" * 60)
    print(f"  Initial guess: a0 = {a0:.6f}, b0 = {b0:.6f}")
    print(f"  Points used:   {len(R)} (no filter)")
    print(f"  a            = {a: .6f} +/- {sigma_a: .6f}  kcal/mol")
    print(f"  b            = {b: .6f} +/- {sigma_b: .6f}  A^-1")
    print(f"  RMSE         = {rmse: .6f}  kcal/mol")
    print()
    print(f"  Note: fit is valid over R in [{R.min():.3f}, {R.max():.3f}] A.")
    print(f"        Parameter `a` is the formal R = 0 limit of the fit form,")
    print(f"        not a physically meaningful BSSE value. See write-up.")
    print()

    # Overlay plot: data + fitted curve, drawn over data range only
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, alpha=0.6, color="black",
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    ax.plot(R_line, erf_heindel(R_line, a, b), "r-", lw=2,
            label=(fr"fit: $|\mathrm{{BSSE}}| = {a:.3f}\,[1 + \mathrm{{erf}}(-{b:.3f}\,R)]$"
                   "\n"
                   fr"($a = {a:.3f}$ kcal/mol, $b = {b:.3f}\,$\AA$^{{-1}}$)"
                   "\n"
                   fr"RMSE $= {rmse:.4f}$ kcal/mol"))
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.5,
               label=r"1 kcal/mol threshold")
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / "ne_dimer_erf_fit.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()

    return a, sigma_a, b, sigma_b, rmse


# ---------------------------------------------------------------------------
# Stage 2: correlation plot
# ---------------------------------------------------------------------------
def run_correlation(R: np.ndarray, bsse: np.ndarray,
                    a: float, b: float) -> float:
    """Predicted vs measured |BSSE|. Returns R^2_fit (linear-space)."""
    pred = erf_heindel(R, a, b)
    ss_res = np.sum((bsse - pred) ** 2)
    ss_tot = np.sum((bsse - bsse.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    # OLS regression line: measured = m * predicted + c
    # Shown for visual bias check only; its R^2 is NOT reported (R^2_fit is).
    m, c = np.polyfit(pred, bsse, 1)

    print("=" * 60)
    print("STAGE 2 — CORRELATION: measured vs predicted |BSSE|")
    print("=" * 60)
    print(f"  R^2_fit (linear space) = {r2: .6f}")
    print(f"  OLS regression line (visual only):"
          f"  measured = {m:.4f} * predicted + {c:.4f}")
    print()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(pred, bsse, s=25, alpha=0.6, color="black")
    lo = 0.0
    hi = max(bsse.max(), pred.max()) * 1.05

    # OLS regression line through the points (red dashed)
    x_line = np.linspace(lo, hi, 200)
    ax.plot(x_line, m * x_line + c, "r--", lw=1.5,
            label=fr"$y = {m:.3f}\,x + {c:.3f}$")

    # R^2_fit as a non-line legend entry
    ax.plot([], [], " ", label=fr"$R^2_\mathrm{{fit}} = {r2:.4f}$")

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(r"predicted $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_ylabel(r"measured $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_aspect("equal", "box")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / "ne_dimer_erf_correlation.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return r2


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",
                        choices=["fit", "correlation", "all"],
                        default="all",
                        help="Which stage to run")
    args = parser.parse_args()

    R, bsse = load_data()
    print(f"Loaded {len(R)} points from {CSV_PATH.name}")
    print(f"  R range:      [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print()

    a = b = None

    if args.stage in ("fit", "all"):
        a, _, b, _, _ = run_fit(R, bsse, A0_INIT, B0_INIT)

    if args.stage in ("correlation", "all"):
        if a is None:
            # Running 'correlation' alone — generate fit silently first
            a, _, b, _, _ = run_fit(R, bsse, A0_INIT, B0_INIT)
        run_correlation(R, bsse, a, b)


if __name__ == "__main__":
    main()
