"""
build_radial_dataframe.py  (Ne/2/data_frames_plots/)

Purpose
-------
Build per-method CSV files for the Ne dimer radial dataset
(aug-cc-pVTZ, 5 configurations) from the two-body BSSE pickle.

For each method (SCF, MP2, CCSD_T) one CSV is written:

    radial_{method}_aug-cc-pvtz.csv

Each CSV has one row per configuration with columns:
    config   — integer config index
    x, y, z  — displacement vector components (Angstrom);
                for radial configs x=0, y=0, z=R (separation distance)
    method   — level of theory
    basis    — basis set name
    no_vmfc  — standard two-body interaction energy ΔE_IJ(I,J,IJ) (Hartree)
    vmfc     — VMFC-corrected interaction energy ΔE_IJ(IJ) (Hartree)
    bsse     — BSSE = no_vmfc - vmfc (Hartree)

Input pickles (read from bsse_db/data/)
---------------------------------------
    raw_data_Ne.pickle               — provides config parameters (x, y, z)
    many_body_interactions_Ne.pickle — provides interaction energies

Output
------
    radial_SCF_aug-cc-pvtz.csv
    radial_MP2_aug-cc-pvtz.csv
    radial_CCSD_T_aug-cc-pvtz.csv

Usage
-----
    cd bsse_db/data/Ne/2/data_frames_plots/
    python3 build_radial_dataframe.py
"""

# ---- path setup ----
import sys
from pathlib import Path

here     = Path(__file__).resolve()
data_dir = here.parent.parent.parent.parent   # bsse_db/data
sys.path.insert(0, str(data_dir))

# ---- imports that depend on that path ----
from open_pickle_data import open_pickle
from two_body_bsse import twobody_bsse

# ---- standard imports ----
import pandas as pd


def main():
    """
    Load Ne radial BSSE data and write one CSV per method.

    Reads interaction energies from many_body_interactions_Ne.pickle
    and spatial parameters (x, y, z) from raw_data_Ne.pickle.
    For radial configs x=y=0 and z=R (the Ne-Ne separation distance).
    Iterates over SCF, MP2, and CCSD_T and writes a sorted CSV
    (by config index) for each method to the current directory.
    """
    raw_pickle       = data_dir / "raw_data_Ne.pickle"
    many_body_pickle = data_dir / "many_body_interactions_Ne.pickle"

    two_body_bsse = twobody_bsse(many_body_pickle, "Ne")
    parameters    = open_pickle(raw_pickle)["parameters"]

    radial_bsse = two_body_bsse["Ne"]["2"]["radial"]
    radial_pars = parameters["Ne"]["2"]["radial"]

    methods = ["SCF", "MP2", "CCSD_T"]
    basis   = "aug-cc-pvtz"

    for method in methods:
        rows = []

        for cfg in sorted(radial_bsse.keys(), key=int):
            p = radial_pars[cfg]["params"]
            e = radial_bsse[cfg][method][basis]

            rows.append({
                "config":  cfg,
                "x":       p["x"],
                "y":       p["y"],
                "z":       p["z"],   # z = R (separation distance)
                "method":  method,
                "basis":   basis,
                "no_vmfc": e["no_vmfc"],
                "vmfc":    e["vmfc"],
                "bsse":    e["bsse"],
            })

        df = pd.DataFrame(rows)

        out_file = here.parent / f"radial_{method}_{basis}.csv"
        df.to_csv(out_file, index=False)
        print(method, df.shape, "saved to:", out_file)


if __name__ == "__main__":
    main()