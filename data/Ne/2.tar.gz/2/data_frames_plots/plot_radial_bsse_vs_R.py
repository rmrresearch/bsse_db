"""
plot_radial_bsse_vs_R.py

Purpose
-------
Plot BSSE vs R for the radial dataset of a given molecule.
All three methods (SCF, MP2, CCSD_T) are shown on a single figure,
each as a line with markers. R is taken from the z column of the
radial CSV (x=y=0 for all radial configs).

Works for any molecule with a radial dataset (Ne, HF) via --mol argument.

Usage
-----
  # Ne dimer - preview
  python3 plot_radial_bsse_vs_R.py --mol Ne

  # Ne dimer - save PNG
  python3 plot_radial_bsse_vs_R.py --mol Ne --save

  # Plot vmfc or no_vmfc instead of bsse
  python3 plot_radial_bsse_vs_R.py --mol Ne --value vmfc

  # HF dimer
  python3 plot_radial_bsse_vs_R.py --mol HF --save
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "text.latex.preamble": r"\usepackage{amsmath} \usepackage{amssymb}",
})

VALUE_LABELS = {
    "bsse":    r"BSSE (Hartree)",
    "no_vmfc": r"$E_{\mathrm{int}}$ no VMFC (Hartree)",
    "vmfc":    r"$E_{\mathrm{int}}$ VMFC (Hartree)",
}

MOL_LABELS = {
    "Ne":  r"Ne",
    "HF":  r"HF",
    "H2O": r"H$_2$O",
}

METHOD_STYLES = {
    "SCF":    {"color": "C0", "marker": "o",  "label": "SCF"},
    "MP2":    {"color": "C1", "marker": "s",  "label": "MP2"},
    "CCSD_T": {"color": "C2", "marker": "^",  "label": r"CCSD(T)"},
}


def plot_radial(mol, basis, value_col, use_abs, save):
    """
    Plot BSSE vs R for all three methods on a single figure.

    Reads radial_{method}_{basis}.csv for each method. The separation
    distance R is taken from the z column (x=y=0 for all radial configs).

    Parameters
    ----------
    mol : str
        Molecule label, e.g. 'Ne', 'HF'.
    basis : str
        Basis set suffix used in CSV filenames, e.g. 'aug-cc-pvtz'.
    value_col : str
        Column to plot ('bsse', 'no_vmfc', 'vmfc').
    use_abs : bool
        If True, plot absolute values.
    save : bool
        If True, save the figure as a PNG file.
    """
    mol_label   = MOL_LABELS.get(mol, mol)
    base_ylabel = VALUE_LABELS.get(value_col, f"{value_col} (Hartree)")
    ylabel      = rf"$|${base_ylabel}$|$" if use_abs else base_ylabel

    fig, ax = plt.subplots(figsize=(8, 5))
    any_plotted = False

    for method in ["SCF", "MP2", "CCSD_T"]:
        csv_name = f"radial_{method}_{basis}.csv"
        if not Path(csv_name).exists():
            print(f"[SKIP] {csv_name} not found.")
            continue

        df   = pd.read_csv(csv_name).sort_values("z")
        R    = df["z"].to_numpy()
        yval = df[value_col].to_numpy()

        if use_abs:
            yval = np.abs(yval)

        style = METHOD_STYLES[method]
        ax.plot(R, yval,
                color=style["color"], marker=style["marker"],
                label=style["label"], linewidth=2, markersize=7)
        any_plotted = True

    if not any_plotted:
        print("[ERROR] No radial CSV files found. Run build_radial_dataframe.py first.")
        return

    ax.set_xlabel(r"$R$ (\AA)", fontsize=13)
    ax.set_ylabel(ylabel, fontsize=13)
    ax.set_title(
        rf"{mol_label} dimer {base_ylabel.split('(')[0].strip()} vs $R$ ({basis})",
        fontsize=13,
    )
    ax.legend(fontsize=11)
    ax.tick_params(labelsize=11)
    plt.tight_layout()

    if save:
        suffix = "abs" if use_abs else "signed"
        fname  = f"radial_{value_col}_vs_R_{mol}_{basis}_{suffix}.png"
        plt.savefig(fname, dpi=200, bbox_inches="tight")
        print(f"[SAVE] {fname}")

    plt.show()


def main():
    parser = argparse.ArgumentParser(
        description="Plot BSSE vs R for the radial dataset (all methods on one figure)."
    )
    parser.add_argument("--mol", choices=["Ne", "HF"], required=True,
                        help="Molecule label (Ne or HF).")
    parser.add_argument("--basis", default="aug-cc-pvtz",
                        help="Basis set suffix (default: aug-cc-pvtz).")
    parser.add_argument("--value", choices=["bsse", "no_vmfc", "vmfc"],
                        default="bsse", help="Quantity to plot (default: bsse).")
    parser.add_argument("--abs", action="store_true", help="Plot absolute values.")
    parser.add_argument("--save", action="store_true", help="Save figure as PNG.")
    args = parser.parse_args()

    plot_radial(
        mol=args.mol,
        basis=args.basis,
        value_col=args.value,
        use_abs=args.abs,
        save=args.save,
    )


if __name__ == "__main__":
    main()