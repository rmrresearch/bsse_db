"""
build_bsse_vs_R.py  (Ne/2/data_frames_plots/)

Purpose
-------
Build a consolidated CSV of BSSE vs R for the Ne dimer (aug-cc-pVDZ),
combining the SCF, MP2-correlation, and CCSD(T)-correlation components
into a single dataset indexed by the inter-monomer distance

    R = sqrt(x^2 + y^2 + z^2)

This script also produces two figures:

  1. ne_dimer_bsse_vs_R.png
     Scatter plot of |BSSE| vs R for the three components and the total
     (full CCSD(T)) BSSE on a log y-axis.

  2. ne_dimer_component_breakdown.png
     Bar plot of mean fractional contribution per component, averaged
     over all R values. Component i contribution =
         mean(|bsse_i|) / sum_j mean(|bsse_j|).

Sign convention
---------------
The 'bsse' column in the input CSVs is no_vmfc - vmfc (signed), which is
typically negative since BSSE artificially stabilises the interaction.
For plotting and statistics we use the magnitude |bsse|, matching the
literature convention where BSSE is reported as a positive correction.

Energy components (incremental, stored in kcal/mol)
----------------------------------------------------
  bsse_scf      : SCF (Hartree-Fock) contribution to BSSE
  bsse_mp2c     : MP2 correlation increment of BSSE (E_MP2  - E_SCF  basis)
  bsse_ccsdtc   : CCSD(T) correlation increment of BSSE (E_CCSDT - E_MP2)
  bsse_total    : sum of the three (= full CCSD(T) BSSE)

Input CSVs are in Hartree; values are converted to kcal/mol on load
using 1 Hartree = 627.5094740631 kcal/mol. The PI's stated accuracy
target is ~1 kcal/mol, so kcal/mol is the working unit throughout.

Input (read from current directory)
-----------------------------------
  trnl_SCF_aug-cc-pvdz.csv
  trnl_MP2_aug-cc-pvdz.csv
  trnl_CCSD_T_aug-cc-pvdz.csv

Output (written to current directory)
-------------------------------------
  ne_dimer_bsse_vs_R.csv
  ne_dimer_bsse_vs_R.png
  ne_dimer_component_breakdown.png

Usage
-----
  # Build everything (CSV + both plots) -- default behaviour
  python3 build_bsse_vs_R.py
  python3 build_bsse_vs_R.py --plot all

  # Regenerate only one plot (loads existing CSV, rebuilds if missing)
  python3 build_bsse_vs_R.py --plot bsse_vs_R
  python3 build_bsse_vs_R.py --plot component_break_down
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Use LaTeX for all text rendering.
plt.rcParams.update({
    "text.usetex":   True,
    "font.family":   "serif",
    "font.serif":    ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})


BASIS = "aug-cc-pvdz"

# Unit conversion: input CSVs are in Hartree; we store and plot kcal/mol.
HARTREE_TO_KCALMOL = 627.5094740631


# ---------------------------------------------------------------------------
# Data loading and merging
# ---------------------------------------------------------------------------

def load_method_csv(method: str, basis: str) -> pd.DataFrame:
    """
    Load a single per-method translational CSV produced by
    build_trnl_dataframe.py.

    Parameters
    ----------
    method : str
        Level of theory, one of "SCF", "MP2", "CCSD_T".
    basis : str
        Basis set tag used in the filename, e.g. "aug-cc-pvdz".

    Returns
    -------
    pandas.DataFrame
        Raw contents of trnl_{method}_{basis}.csv. Columns are
        config, x, y, z, method, basis, no_vmfc, vmfc, bsse — with
        energies still in Hartree at this stage.

    Raises
    ------
    FileNotFoundError
        If the expected CSV does not exist in the current directory.
    """
    path = Path(f"trnl_{method}_{basis}.csv")
    if not path.exists():
        raise FileNotFoundError(f"Missing input file: {path}")
    return pd.read_csv(path)


def merge_components(basis: str) -> pd.DataFrame:
    """
    Load the three per-method CSVs (SCF, MP2, CCSD_T) and merge them on
    (config, x, y, z) into a single wide-format dataframe.

    The three input files must share the same configuration grid;
    rows that do not match across all three are dropped (inner merge).

    Parameters
    ----------
    basis : str
        Basis set tag used in the filenames.

    Returns
    -------
    pandas.DataFrame
        One row per configuration with columns
        config, x, y, z, bsse_scf, bsse_mp2c, bsse_ccsdtc — still in Hartree.
    """
    df_scf   = load_method_csv("SCF",    basis)
    df_mp2   = load_method_csv("MP2",    basis)
    df_ccsdt = load_method_csv("CCSD_T", basis)

    keep = ["config", "x", "y", "z", "bsse"]
    df_scf   = df_scf[keep].rename(columns={"bsse": "bsse_scf"})
    df_mp2   = df_mp2[keep].rename(columns={"bsse": "bsse_mp2c"})
    df_ccsdt = df_ccsdt[keep].rename(columns={"bsse": "bsse_ccsdtc"})

    df = df_scf.merge(df_mp2,   on=["config", "x", "y", "z"], how="inner")
    df = df.merge(df_ccsdt,     on=["config", "x", "y", "z"], how="inner")
    return df


def add_R_and_total(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the inter-monomer distance R and the total BSSE to the dataframe,
    and convert the three component BSSE columns from Hartree to kcal/mol.

    R is computed as R = sqrt(x^2 + y^2 + z^2). The total BSSE is the
    sum of the three (now kcal/mol) component columns, equivalent to the
    full CCSD(T) BSSE.

    Parameters
    ----------
    df : pandas.DataFrame
        Output of merge_components, with energies in Hartree.

    Returns
    -------
    pandas.DataFrame
        Same dataframe with columns added (R, bsse_total) and the three
        bsse_* component columns converted in place to kcal/mol.
    """
    df["R"] = np.sqrt(df["x"]**2 + df["y"]**2 + df["z"]**2)

    # Convert per-component BSSE from Hartree to kcal/mol
    df["bsse_scf"]    = df["bsse_scf"]    * HARTREE_TO_KCALMOL
    df["bsse_mp2c"]   = df["bsse_mp2c"]   * HARTREE_TO_KCALMOL
    df["bsse_ccsdtc"] = df["bsse_ccsdtc"] * HARTREE_TO_KCALMOL

    df["bsse_total"] = df["bsse_scf"] + df["bsse_mp2c"] + df["bsse_ccsdtc"]
    return df


def _ytick_fmt(x: float, pos) -> str:
    """
    Custom y-axis tick formatter for the log-scaled |BSSE| axis.

    Returns "1.0", "10.0", "100.0", ... for values >= 1, and the compact
    %g format ("0.1", "0.01", ...) for values < 1. Used with
    matplotlib.ticker.FuncFormatter on the y-axis of plot_bsse_vs_R.

    Parameters
    ----------
    x : float
        Tick value supplied by matplotlib.
    pos : int
        Tick position index (required by FuncFormatter, unused here).

    Returns
    -------
    str
        Formatted tick label.
    """
    return f"{x:.1f}" if x >= 1 else f"{x:g}"


def build_dataframe(here: Path) -> pd.DataFrame:
    """
    Run the full data pipeline (load, merge, add R, convert units) and
    save the consolidated CSV to disk.

    Parameters
    ----------
    here : pathlib.Path
        Directory in which to write ne_dimer_bsse_vs_R.csv. The input
        per-method CSVs are also read from this directory.

    Returns
    -------
    pandas.DataFrame
        The consolidated dataframe (also written to disk), sorted by R
        and reindexed.

    Side effects
    ------------
    Writes ne_dimer_bsse_vs_R.csv into `here` and prints a one-line
    summary (row count + R range) to stdout.
    """
    df = merge_components(BASIS)
    df = add_R_and_total(df)
    df = df.sort_values("R").reset_index(drop=True)

    out_csv = here / "ne_dimer_bsse_vs_R.csv"
    df.to_csv(out_csv, index=False)
    print(f"Saved CSV: {out_csv}")
    print(f"  Rows: {len(df)}")
    print(f"  R range: [{df['R'].min():.3f}, {df['R'].max():.3f}] Å")
    return df


def load_or_build(here: Path) -> pd.DataFrame:
    """
    Return the consolidated dataframe, reusing an existing CSV when
    possible so that single-plot reruns are fast.

    If ne_dimer_bsse_vs_R.csv already exists in `here`, it is read and
    returned without touching the raw per-method CSVs. Otherwise the
    pipeline is run via build_dataframe.

    Parameters
    ----------
    here : pathlib.Path
        Directory in which to look for / write the consolidated CSV.

    Returns
    -------
    pandas.DataFrame
        The consolidated dataframe (loaded or freshly built).
    """
    out_csv = here / "ne_dimer_bsse_vs_R.csv"
    if out_csv.exists():
        print(f"Loaded existing CSV: {out_csv}")
        return pd.read_csv(out_csv)
    print(f"CSV not found at {out_csv}; rebuilding.")
    return build_dataframe(here)


# ---------------------------------------------------------------------------
# Plots
# ---------------------------------------------------------------------------

def plot_bsse_vs_R(df: pd.DataFrame, output_path: Path) -> None:
    """
    Save a scatter plot of |BSSE| (kcal/mol) vs R (Å) for
    the four traces: SCF, MP2 correlation, CCSD(T) correlation, and the
    total (full CCSD(T)) BSSE.

    A horizontal red dashed line at y = 1 kcal/mol marks the PI's
    target accuracy threshold; intersections with this line indicate
    the R at which each component drops below 1 kcal/mol.

    Parameters
    ----------
    df : pandas.DataFrame
        Dataframe with columns R, bsse_scf, bsse_mp2c, bsse_ccsdtc,
        bsse_total (kcal/mol). Rows do not need to be pre-sorted.
    output_path : pathlib.Path
        Destination PNG path.

    Side effects
    ------------
    Writes the figure to `output_path` (300 dpi) and prints a one-line
    confirmation to stdout.
    """
    df_sorted = df.sort_values("R")

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(df_sorted["R"], np.abs(df_sorted["bsse_scf"]),
               s=22, alpha=0.65, label="SCF",            color="tab:blue")
    ax.scatter(df_sorted["R"], np.abs(df_sorted["bsse_mp2c"]),
               s=22, alpha=0.65, label="MP2 corr.",      color="tab:orange")
    ax.scatter(df_sorted["R"], np.abs(df_sorted["bsse_ccsdtc"]),
               s=22, alpha=0.65, label="CCSD(T) corr.",  color="tab:green")
    ax.scatter(df_sorted["R"], np.abs(df_sorted["bsse_total"]),
               s=22, alpha=0.85, label="Total (full CCSD(T))",
               color="black")

    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (Å)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    # ax.set_yscale("log")
    ax.yaxis.set_major_formatter(FuncFormatter(_ytick_fmt))

    # PI's 1 kcal/mol accuracy reference
    ax.axhline(y=1.0, color="red", linestyle="--", linewidth=1.0,
               alpha=0.7, label="1 kcal/mol threshold")
    ax.axhline(y=0.5, color="grey", linestyle="--", linewidth=1.0,
               alpha=0.7)

    ax.set_title("Ne dimer: BSSE vs inter-monomer distance (aug-cc-pVDZ)")
    ax.legend(frameon=False)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"Saved plot: {output_path}")


def plot_component_breakdown(df: pd.DataFrame, output_path: Path) -> None:
    """
    Save a bar plot of the mean fractional contribution of each BSSE
    component to the total, averaged over all configurations.

    For each component i, the metric is
        fraction_i = mean(|bsse_i|) / sum_j mean(|bsse_j|),
    converted to percent. Working with magnitudes avoids sign issues
    when components have different signs at some R values.

    Parameters
    ----------
    df : pandas.DataFrame
        Dataframe with columns bsse_scf, bsse_mp2c, bsse_ccsdtc
        (kcal/mol).
    output_path : pathlib.Path
        Destination PNG path.

    Side effects
    ------------
    Writes the figure to `output_path` (300 dpi) and prints a four-line
    breakdown summary (mean magnitudes and percentages) to stdout.
    """
    mean_scf    = float(np.mean(np.abs(df["bsse_scf"])))
    mean_mp2c   = float(np.mean(np.abs(df["bsse_mp2c"])))
    mean_ccsdtc = float(np.mean(np.abs(df["bsse_ccsdtc"])))
    total       = mean_scf + mean_mp2c + mean_ccsdtc

    components  = ["SCF", "MP2 corr.", "CCSD(T) corr."]
    percentages = [100 * mean_scf / total,
                   100 * mean_mp2c / total,
                   100 * mean_ccsdtc / total]
    colors      = ["tab:blue", "tab:orange", "tab:green"]

    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(components, percentages, color=colors, alpha=0.8)
    for bar, pct in zip(bars, percentages):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.8,
                f"{pct:.1f}\\%", ha="center", va="bottom", fontsize=11)

    ax.set_ylabel(r"Mean fractional contribution to $|\mathrm{BSSE}|$ (\%)")
    ax.set_title("Ne dimer: BSSE component breakdown (aug-cc-pVDZ)")
    ax.set_ylim(0, max(percentages) * 1.18)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"Saved plot: {output_path}")

    print("\n[Component breakdown — mean |BSSE| over all configs]")
    print(f"  SCF           : {mean_scf:.4f} kcal/mol   ({percentages[0]:.2f}%)")
    print(f"  MP2 corr.     : {mean_mp2c:.4f} kcal/mol   ({percentages[1]:.2f}%)")
    print(f"  CCSD(T) corr. : {mean_ccsdtc:.4f} kcal/mol   ({percentages[2]:.2f}%)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Entry point. Parses the --plot CLI flag and dispatches.

    --plot all (default):
        Rebuild the consolidated CSV from the raw per-method CSVs and
        regenerate both plots.

    --plot bsse_vs_R:
        Regenerate only the |BSSE| vs R figure. Loads the consolidated
        CSV if present; rebuilds it from raw inputs if not.

    --plot component_break_down:
        Regenerate only the component breakdown figure. Same CSV
        load-or-rebuild behaviour as above.
    """
    parser = argparse.ArgumentParser(
        description="Build Ne dimer BSSE vs R analysis (CSV + plots)."
    )
    parser.add_argument(
        "--plot",
        choices=["bsse_vs_R", "component_break_down", "all"],
        default="all",
        help="Which plot(s) to generate. Default 'all' also rebuilds the CSV. "
             "Individual plot options load the existing CSV (rebuild if missing).",
    )
    args = parser.parse_args()

    here = Path(__file__).resolve().parent

    if args.plot == "all":
        df = build_dataframe(here)
        plot_bsse_vs_R(df,          here / "ne_dimer_bsse_vs_R.png")
        plot_component_breakdown(df, here / "ne_dimer_component_breakdown.png")
    else:
        df = load_or_build(here)
        if args.plot == "bsse_vs_R":
            plot_bsse_vs_R(df, here / "ne_dimer_bsse_vs_R.png")
        elif args.plot == "component_break_down":
            plot_component_breakdown(df, here / "ne_dimer_component_breakdown.png")


if __name__ == "__main__":
    main()
