"""
compute_rho_R.py  (Ne/2/data_frames_plots/)

Purpose
-------
Compute the ratio

    rho(R) = |BSSE(CCSD(T))| / |BSSE(MP2)|

for the Ne dimer (aug-cc-pVDZ) as a function of the inter-monomer
distance R.  rho quantifies how well the MP2 BSSE approximates the full
CCSD(T) BSSE; a flat rho(R) indicates that MP2 gives a reliable proxy
for CCSD(T) across the sampled geometry space.

Quantity definitions
--------------------
  bsse_mp2_abs(R)   = |bsse_scf + bsse_mp2c|   (full MP2 BSSE magnitude)
  bsse_ccsdt_abs(R) = |bsse_total|              (full CCSD(T) BSSE magnitude)
  rho(R)            = bsse_ccsdt_abs / bsse_mp2_abs

Noise-regime flag
-----------------
Points where bsse_mp2_abs < 0.05 kcal/mol are flagged as noise-prone
because the small denominator amplifies numerical noise.  Statistics
are reported separately for the signal regime (unflagged) and all points.
Flagged points are shown with open grey markers in the figure so they
remain visible but are visually distinct.

Input (read from current directory)
-----------------------------------
  ne_dimer_bsse_vs_R.csv
    Columns: config, x, y, z, bsse_scf, bsse_mp2c, bsse_ccsdtc, R,
             bsse_total — all energies in kcal/mol, signed.

Output (written to current directory)
-------------------------------------
  ne_dimer_rho_R.csv
    Columns: R, bsse_mp2_abs, bsse_ccsdt_abs, rho — sorted by R.
  ne_dimer_rho_R.png
    Scatter plot of rho(R) vs R with mean and ±5% band annotations.

Usage
-----
  # Build everything (CSV + plot + stats) -- default behaviour
  python3 compute_rho_R.py
  python3 compute_rho_R.py --plot all

  # Regenerate only the figure (loads existing CSV, rebuilds if missing)
  python3 compute_rho_R.py --plot rho_vs_R
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Use LaTeX for all text rendering.
plt.rcParams.update({
    "text.usetex":        True,
    "font.family":        "serif",
    "font.serif":         ["Computer Modern Roman"],
    "text.latex.preamble": r"\usepackage[version=4]{mhchem}",
})

NOISE_THRESHOLD = 0.05  # kcal/mol — denominator below this → noise-prone


# ---------------------------------------------------------------------------
# Data loading and computation
# ---------------------------------------------------------------------------

def compute_rho(df_input: pd.DataFrame) -> pd.DataFrame:
    """
    Compute bsse_mp2_abs, bsse_ccsdt_abs, rho, and noise_flag from the
    consolidated BSSE dataframe.

    Parameters
    ----------
    df_input : pandas.DataFrame
        Output of ne_dimer_bsse_vs_R.csv with columns bsse_scf, bsse_mp2c,
        bsse_total, R (energies in kcal/mol).

    Returns
    -------
    pandas.DataFrame
        Copy of df_input with four new columns appended:
        bsse_mp2_abs, bsse_ccsdt_abs, rho, noise_flag.
        rho is NaN where bsse_mp2_abs == 0.
    """
    df = df_input.copy()
    df["bsse_mp2_abs"]   = np.abs(df["bsse_scf"] + df["bsse_mp2c"])
    df["bsse_ccsdt_abs"] = np.abs(df["bsse_total"])
    df["rho"] = np.where(
        df["bsse_mp2_abs"] > 0,
        df["bsse_ccsdt_abs"] / df["bsse_mp2_abs"],
        np.nan,
    )
    df["noise_flag"] = df["bsse_mp2_abs"] < NOISE_THRESHOLD
    return df


def build_dataframe(here: Path) -> pd.DataFrame:
    """
    Load ne_dimer_bsse_vs_R.csv, compute rho, and write ne_dimer_rho_R.csv.

    Parameters
    ----------
    here : pathlib.Path
        Directory containing ne_dimer_bsse_vs_R.csv and destination for
        ne_dimer_rho_R.csv.

    Returns
    -------
    pandas.DataFrame
        Full dataframe with columns R, bsse_mp2_abs, bsse_ccsdt_abs, rho,
        noise_flag — sorted by R.  (noise_flag is not written to disk.)

    Raises
    ------
    FileNotFoundError
        If ne_dimer_bsse_vs_R.csv does not exist in `here`.

    Side effects
    ------------
    Writes ne_dimer_rho_R.csv (columns R, bsse_mp2_abs, bsse_ccsdt_abs,
    rho) into `here` and prints a two-line summary to stdout.
    """
    src = here / "ne_dimer_bsse_vs_R.csv"
    if not src.exists():
        raise FileNotFoundError(f"Missing input file: {src}")

    df_input = pd.read_csv(src)
    df = compute_rho(df_input)
    df = df.sort_values("R").reset_index(drop=True)

    out_csv = here / "ne_dimer_rho_R.csv"
    df[["R", "bsse_mp2_abs", "bsse_ccsdt_abs", "rho"]].to_csv(out_csv, index=False)
    print(f"Saved CSV: {out_csv}")
    print(f"  Rows: {len(df)}")
    print(f"  R range: [{df['R'].min():.3f}, {df['R'].max():.3f}] Å")
    return df


def load_or_build(here: Path) -> pd.DataFrame:
    """
    Return the rho dataframe, reusing an existing CSV when possible.

    If ne_dimer_rho_R.csv already exists in `here`, it is loaded and the
    noise_flag column is recomputed from bsse_mp2_abs.  Otherwise the
    pipeline is run via build_dataframe.

    Parameters
    ----------
    here : pathlib.Path
        Directory in which to look for / write ne_dimer_rho_R.csv.

    Returns
    -------
    pandas.DataFrame
        Dataframe with columns R, bsse_mp2_abs, bsse_ccsdt_abs, rho,
        noise_flag.
    """
    out_csv = here / "ne_dimer_rho_R.csv"
    if out_csv.exists():
        print(f"Loaded existing CSV: {out_csv}")
        df = pd.read_csv(out_csv)
        df["noise_flag"] = df["bsse_mp2_abs"] < NOISE_THRESHOLD
        return df
    print(f"CSV not found at {out_csv}; rebuilding.")
    return build_dataframe(here)


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------

def print_stats(df: pd.DataFrame) -> None:
    """
    Print summary statistics for rho to stdout.

    Reports mean, std, min, max over the signal regime and over all
    points; the R-range of signal-regime points within ±5% of the signal
    mean; and a one-line constancy summary.

    Parameters
    ----------
    df : pandas.DataFrame
        Dataframe with columns R, rho, noise_flag.
    """
    n_total  = len(df)
    df_signal = df[~df["noise_flag"]]
    df_noise  = df[ df["noise_flag"]]
    n_signal  = len(df_signal)

    rho_sig = df_signal["rho"].dropna()
    rho_all = df["rho"].dropna()

    mean_sig = float(rho_sig.mean())
    lo       = mean_sig * 0.95
    hi       = mean_sig * 1.05

    within   = df_signal[df_signal["rho"].between(lo, hi)]
    n_within = len(within)

    if n_within > 0:
        r_lo = float(within["R"].min())
        r_hi = float(within["R"].max())
    else:
        r_lo = r_hi = float("nan")

    print(f"\n[rho(R) statistics -- {n_total} total configurations]")
    print(f"  Noise-flagged (|BSSE(MP2)| < {NOISE_THRESHOLD} kcal/mol): "
          f"{len(df_noise)} configs")

    print(f"\n  Signal regime ({n_signal} points):")
    print(f"    mean(rho) = {mean_sig:.4f}")
    print(f"    std(rho)  = {float(rho_sig.std()):.4f}")
    print(f"    min(rho)  = {float(rho_sig.min()):.4f}")
    print(f"    max(rho)  = {float(rho_sig.max()):.4f}")

    print(f"\n  All points ({n_total}):")
    print(f"    mean(rho) = {float(rho_all.mean()):.4f}")
    print(f"    std(rho)  = {float(rho_all.std()):.4f}")
    print(f"    min(rho)  = {float(rho_all.min()):.4f}")
    print(f"    max(rho)  = {float(rho_all.max()):.4f}")

    print(f"\n  R-range within +/-5% of mean (signal): "
          f"[{r_lo:.3f}, {r_hi:.3f}] A")
    print(f"  rho constancy: {n_within} of {n_signal} signal-regime points "
          f"within +/-5% of mean")


# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------

def plot_rho_vs_R(df: pd.DataFrame, output_path: Path) -> None:
    """
    Save a scatter plot of rho(R) vs R (Å) with signal/noise-regime points
    coloured separately and horizontal lines at the signal-regime mean
    and its ±5% band.

    Parameters
    ----------
    df : pandas.DataFrame
        Dataframe with columns R, rho, noise_flag.
    output_path : pathlib.Path
        Destination PNG path.

    Side effects
    ------------
    Writes the figure to `output_path` (300 dpi, bbox_inches='tight') and
    prints a one-line confirmation to stdout.
    """
    df_signal = df[~df["noise_flag"]]
    df_noise  = df[ df["noise_flag"]]

    mean_sig = float(df_signal["rho"].dropna().mean())
    lo       = mean_sig * 0.95
    hi       = mean_sig * 1.05

    fig, ax = plt.subplots(figsize=(8, 6))

    ax.scatter(
        df_signal["R"], df_signal["rho"],
        s=22, alpha=0.75, color="tab:blue",
        label=(r"Signal "
               r"($|\mathrm{BSSE}(\mathrm{MP2})| \geq "
               + str(NOISE_THRESHOLD)
               + r"$ kcal/mol)"),
    )
    if len(df_noise) > 0:
        ax.scatter(
            df_noise["R"], df_noise["rho"],
            s=22, alpha=0.65,
            facecolors="none", edgecolors="grey",
            label=(r"Noise-prone "
                   r"($|\mathrm{BSSE}(\mathrm{MP2})| < "
                   + str(NOISE_THRESHOLD)
                   + r"$ kcal/mol)"),
        )

    ax.axhline(mean_sig, color="black", linestyle="-",  linewidth=1.2,
               label=r"$\langle\rho\rangle$ (signal)")
    ax.axhline(lo,       color="black", linestyle="--", linewidth=0.9,
               label=r"$\langle\rho\rangle \pm 5\%$")
    ax.axhline(hi,       color="black", linestyle="--", linewidth=0.9)

    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(
        r"$\rho(R) = |\mathrm{BSSE}(\mathrm{CCSD(T)})| "
        r"/ |\mathrm{BSSE}(\mathrm{MP2})|$"
    )
    ax.legend(frameon=False)

    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Saved plot: {output_path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Entry point.  Parses the --plot CLI flag and dispatches.

    --plot all (default):
        Load ne_dimer_bsse_vs_R.csv, compute rho, rebuild ne_dimer_rho_R.csv,
        print statistics, and regenerate the figure.

    --plot rho_vs_R:
        Load ne_dimer_rho_R.csv (rebuild from source if missing), print
        statistics, and regenerate the figure.
    """
    parser = argparse.ArgumentParser(
        description="Compute rho(R) = |BSSE(CCSD(T))| / |BSSE(MP2)| for "
                    "the Ne dimer (aug-cc-pVDZ) and produce CSV + figure."
    )
    parser.add_argument(
        "--plot",
        choices=["rho_vs_R", "all"],
        default="all",
        help="Which outputs to generate.  Default 'all' rebuilds the CSV "
             "and the figure.  'rho_vs_R' loads the existing CSV (rebuilds "
             "if missing) and regenerates only the figure.",
    )
    args = parser.parse_args()

    here = Path(__file__).resolve().parent

    if args.plot == "all":
        df = build_dataframe(here)
    else:
        df = load_or_build(here)

    print_stats(df)
    plot_rho_vs_R(df, here / "ne_dimer_rho_R.png")


if __name__ == "__main__":
    main()
