"""
fit_poly_gaussian.py
--------------------
Fit the total CCSD(T) Ne dimer BSSE to a polynomial-corrected Gaussian:
|BSSE(R)| = a * (1 + c1*R + c2*R^2) * exp(-b R^2).

Theory motivation (handoff context, write-up will expand):
  - Products of Gaussian primitives at different centers are exactly
    polynomial(R) * Gaussian(R^2) (Besalu & Carbo-Dorca 2011, GGPT).
  - For two 1s primitives the polynomial reduces to specific even
    forms (e.g. kinetic integral: (3 - 2*mu*R^2), Szabo-Ostlund A.11).
  - For higher angular momentum (p, d) primitives — present in
    aug-cc-pVDZ for Ne — the polynomial structure is more general and
    can contain both even and odd powers of R depending on the
    Cartesian indices. We therefore fit a *general* quadratic
    polynomial in R and let the data determine its coefficients.
  - Note the constant term is fixed at 1 to avoid the (a, c0)
    degeneracy: a * (c0 + c1 R + c2 R^2) is identical to
    (a*c0) * (1 + (c1/c0) R + (c2/c0) R^2) — only the product and
    ratios are determined by the data. Fixing c0 = 1 places the
    overall amplitude in `a` without loss of generality.

Initial guesses (seed-insensitive; verified by exploratory runs):
  a0  = 12.31 kcal/mol  (pure Gaussian best fit)
  b0  = 0.753 A^-2      (pure Gaussian best fit)
  c10 = 0.01            (small perturbation to break Jacobian degeneracy)
  c20 = 0.01            (same)

Workflow:
  1. Fit stage: nonlinear least squares on all 268 points (no filter).
     Reports (a, b, c1, c2) +/- uncertainties, RMSE.
     Flags any ill-conditioning explicitly.

  2. Correlation stage: predicted vs measured |BSSE| with OLS line and
     R^2_fit as the comparison metric.

Note on the fit parameters:
  At R = 0 the form gives BSSE(0) = a (constant term of polynomial = 1).
  However the data range is R in [1.500, 3.031] A, so any R = 0
  extrapolation is formal only and has no physical meaning. The fit is
  valid only within the sampled R range. See Ne dimer write-up.

Reads:  ne_dimer_bsse_vs_R.csv  (uses |bsse_total| only)
Output: PNG files in the same directory as this script.

Usage:
    python3 fit_poly_gaussian.py --stage fit
    python3 fit_poly_gaussian.py --stage correlation
    python3 fit_poly_gaussian.py --stage all
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

# ---------------------------------------------------------------------------
# LaTeX rendering (consistent with the other fit scripts)
# ---------------------------------------------------------------------------
plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent          # poly_gaussian_fit/
PARENT_DIR = SCRIPT_DIR.parent                        # data_frames_plots/
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

# Initial guesses (seed-insensitive — verified)
A_INIT  = 12.31   # kcal/mol  (pure Gaussian best fit)
B_INIT  = 0.753   # A^-2      (pure Gaussian best fit)
C1_INIT = 0.01    # A^-1
C2_INIT = 0.01    # A^-2


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def poly_gaussian(R: np.ndarray, a: float, b: float,
                  c1: float, c2: float) -> np.ndarray:
    """|BSSE|(R) = a * (1 + c1*R + c2*R^2) * exp(-b R^2).

    General-quadratic polynomial pre-factor times a Gaussian envelope.
    """
    return a * (1.0 + c1 * R + c2 * R**2) * np.exp(-b * R**2)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_data() -> tuple[np.ndarray, np.ndarray]:
    """Return (R, |BSSE_total|) in (A, kcal/mol)."""
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    R = df["R"].to_numpy()
    bsse_total_abs = np.abs(df["bsse_total"].to_numpy())
    return R, bsse_total_abs


# ---------------------------------------------------------------------------
# Conditioning check
# ---------------------------------------------------------------------------
def check_conditioning(params: dict[str, tuple[float, float]]) -> list[str]:
    """Flag parameters where sigma >= |p| (data does not constrain them)."""
    warnings = []
    for name, (p, sigma) in params.items():
        if abs(p) < 1e-12:
            ratio = float("inf") if sigma > 0 else 0.0
        else:
            ratio = sigma / abs(p)
        if ratio >= 1.0:
            warnings.append(
                f"    {name}: sigma/|p| = {ratio:.2f}  "
                f"(p = {p:.4f}, sigma = {sigma:.4f}) — UNCONSTRAINED"
            )
    return warnings


# ---------------------------------------------------------------------------
# Stage 1: nonlinear least squares
# ---------------------------------------------------------------------------
def run_fit(R: np.ndarray, bsse: np.ndarray,
            a0: float, b0: float, c10: float, c20: float
            ) -> tuple[float, float, float, float,
                       float, float, float, float, float]:
    """Nonlinear LS on |BSSE| = a * (1 + c1*R + c2*R^2) * exp(-b R^2).

    Returns (a, sigma_a, b, sigma_b, c1, sigma_c1, c2, sigma_c2, rmse).
    """
    popt, pcov = curve_fit(poly_gaussian, R, bsse,
                           p0=[a0, b0, c10, c20],
                           maxfev=10000)
    a, b, c1, c2 = popt
    sigma_a, sigma_b, sigma_c1, sigma_c2 = np.sqrt(np.diag(pcov))

    pred = poly_gaussian(R, a, b, c1, c2)
    residuals = bsse - pred
    rmse = float(np.sqrt(np.mean(residuals**2)))

    print("=" * 60)
    print("STAGE 1 — NONLINEAR LS FIT (polynomial-corrected Gaussian):")
    print("  |BSSE| = a * (1 + c1*R + c2*R^2) * exp(-b R^2)")
    print("=" * 60)
    print(f"  Initial guess:")
    print(f"    a0  = {a0:.4f} kcal/mol,  b0  = {b0:.4f} A^-2")
    print(f"    c10 = {c10:.4f} A^-1,     c20 = {c20:.4f} A^-2")
    print(f"  Points used: {len(R)} (no filter)")
    print()
    print(f"  a            = {a: .6f} +/- {sigma_a: .6f}  kcal/mol")
    print(f"  b            = {b: .6f} +/- {sigma_b: .6f}  A^-2")
    print(f"  c1           = {c1: .6f} +/- {sigma_c1: .6f}  A^-1")
    print(f"  c2           = {c2: .6f} +/- {sigma_c2: .6f}  A^-2")
    print(f"  RMSE         = {rmse: .6f}  kcal/mol")
    print()

    cond = check_conditioning({
        "a":  (a,  sigma_a),
        "b":  (b,  sigma_b),
        "c1": (c1, sigma_c1),
        "c2": (c2, sigma_c2),
    })
    if cond:
        print("  CONDITIONING WARNING — parameter(s) not constrained by data:")
        for w in cond:
            print(w)
    else:
        print("  All parameters well-conditioned (sigma/|p| < 1).")
    print()
    print(f"  Note: fit is valid over R in [{R.min():.3f}, {R.max():.3f}] A.")
    print(f"        At R = 0 the form gives BSSE = a, but R = 0 is outside")
    print(f"        the data range and physically inaccessible. See write-up.")
    print()

    # Sign-aware substitution of c1 and c2 into the equation legend, so
    # that negative coefficients render as "- 0.787" not "+ -0.787".
    c1_sign = "-" if c1 < 0 else "+"
    c2_sign = "-" if c2 < 0 else "+"

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, alpha=0.6, color="black",
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    ax.plot(R_line, poly_gaussian(R_line, a, b, c1, c2), "r-", lw=2,
            label=(fr"fit: $|\mathrm{{BSSE}}| = {a:.3f}\,"
                   fr"(1 {c1_sign} {abs(c1):.3f}\,R {c2_sign} {abs(c2):.3f}\,R^2)\,"
                   fr"\exp(-{b:.3f}\,R^2)$"
                   "\n"
                   fr"($a = {a:.3f}$ kcal/mol, $b = {b:.3f}\,$\AA$^{{-2}}$,"
                   "\n"
                   fr"\ \ $c_1 = {c1:.3f}\,$\AA$^{{-1}}$, "
                   fr"$c_2 = {c2:.3f}\,$\AA$^{{-2}}$)"
                   "\n"
                   fr"RMSE $= {rmse:.4f}$ kcal/mol"))
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.5,
               label=r"1 kcal/mol threshold")
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_title(r"Polynomial-corrected Gaussian fit "
                 r"to total CCSD(T) Ne dimer BSSE")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / "ne_dimer_poly_gaussian_fit.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()

    return (a, sigma_a, b, sigma_b,
            c1, sigma_c1, c2, sigma_c2, rmse)


# ---------------------------------------------------------------------------
# Stage 2: correlation plot
# ---------------------------------------------------------------------------
def run_correlation(R: np.ndarray, bsse: np.ndarray,
                    a: float, b: float, c1: float, c2: float) -> float:
    """Predicted vs measured |BSSE|. Returns R^2_fit (linear-space)."""
    pred = poly_gaussian(R, a, b, c1, c2)
    ss_res = np.sum((bsse - pred) ** 2)
    ss_tot = np.sum((bsse - bsse.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    m, c = np.polyfit(pred, bsse, 1)
    c_sign = "-" if c < 0 else "+"
    c_abs = abs(c)

    print("=" * 60)
    print("STAGE 2 — CORRELATION: measured vs predicted |BSSE|")
    print("=" * 60)
    print(f"  R^2_fit (linear space) = {r2: .6f}")
    print(f"  OLS regression line (visual only):"
          f"  measured = {m:.4f} * predicted + {c:.4f}")
    print()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(pred, bsse, s=25, alpha=0.6, color="black")
    lo = 0.0
    hi = max(bsse.max(), pred.max()) * 1.05

    x_line = np.linspace(lo, hi, 200)
    ax.plot(x_line, m * x_line + c, "r--", lw=1.5,
            label=fr"$y = {m:.4f}\,x {c_sign} {c_abs:.4f}$")
    ax.plot([], [], " ", label=fr"$R^2_\mathrm{{fit}} = {r2:.4f}$")

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(r"predicted $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_ylabel(r"measured $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_title(r"Measured vs predicted $|\mathrm{BSSE}|$ "
                 r"— polynomial-corrected Gaussian fit, Ne dimer")
    ax.set_aspect("equal", "box")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / "ne_dimer_poly_gaussian_correlation.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return r2


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",
                        choices=["fit", "correlation", "all"],
                        default="all",
                        help="Which stage to run")
    args = parser.parse_args()

    R, bsse = load_data()
    print(f"Loaded {len(R)} points from {CSV_PATH.name}")
    print(f"  R range:      [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print()

    a = b = c1 = c2 = None

    if args.stage in ("fit", "all"):
        a, _, b, _, c1, _, c2, _, _ = run_fit(
            R, bsse, A_INIT, B_INIT, C1_INIT, C2_INIT
        )

    if args.stage in ("correlation", "all"):
        if a is None:
            a, _, b, _, c1, _, c2, _, _ = run_fit(
                R, bsse, A_INIT, B_INIT, C1_INIT, C2_INIT
            )
        run_correlation(R, bsse, a, b, c1, c2)


if __name__ == "__main__":
    main()
