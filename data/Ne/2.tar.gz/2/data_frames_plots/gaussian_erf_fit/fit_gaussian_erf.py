"""
fit_gaussian_erf.py
-------------------
Fit the total CCSD(T) Ne dimer BSSE to a two-channel combined form:
|BSSE(R)| = a1 * [1 + erf(-b1 R)] + a2 * exp(-b2 R^2).

Physical motivation (handoff 011):
  - erf channel  -> Coulomb-type integrals via Boys function F_0(t)
    (V_ne, J, K)
  - Gaussian channel -> kinetic/overlap integrals (S_AB, T_AB)
  This is the "channel-mixing" empirical form; it is heuristic, not a
  first-principles derivation of BSSE.

Initial guess (Strategy B — physical channels):
  a1 = 1.0 kcal/mol, b1 = 0.3 A^-1    (erf handles long-R tail)
  a2 = 12.0 kcal/mol, b2 = 0.75 A^-2  (Gaussian handles steep bulk)

Workflow:
  1. Fit stage: nonlinear least squares on all 268 points (no filter).
     Reports (a1, b1, a2, b2) +/- uncertainties, RMSE.
     Flags any ill-conditioning explicitly: if sigma(p) > |p| for any
     parameter, the data does not constrain it and the result must be
     interpreted with care.

  2. Correlation stage: predicted vs measured |BSSE| with OLS line for
     visual bias check and R^2_fit (linear space) as the comparison
     metric across forms.

Note on the fit parameters:
  At R = 0 the form gives BSSE(0) = a1 + a2 (since erf(0) = 0 and
  exp(0) = 1). However the data range is R in [1.500, 3.031] A, so any
  R = 0 extrapolation has no physical meaning. The fit is valid only
  within the sampled R range. See Ne dimer write-up.

Reads:  ne_dimer_bsse_vs_R.csv  (uses |bsse_total| only)
Output: PNG files in the same directory as this script.

Usage:
    python3 fit_gaussian_erf.py --stage fit
    python3 fit_gaussian_erf.py --stage correlation
    python3 fit_gaussian_erf.py --stage all
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.special import erf

# ---------------------------------------------------------------------------
# LaTeX rendering settings (consistent with build_bsse_vs_R.py / fit_erf.py)
# ---------------------------------------------------------------------------
plt.rcParams["text.usetex"] = True
plt.rcParams["text.latex.preamble"] = r"\usepackage{mhchem}"
plt.rcParams["font.family"] = "serif"

# ---------------------------------------------------------------------------
# Paths
#   Script lives in:  .../data_frames_plots/gaussian_erf_fit/
#   CSV (read-only):  .../data_frames_plots/ne_dimer_bsse_vs_R.csv
#   Plots (output):   .../data_frames_plots/gaussian_erf_fit/
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent          # gaussian_erf_fit/
PARENT_DIR = SCRIPT_DIR.parent                        # data_frames_plots/
CSV_PATH = PARENT_DIR / "ne_dimer_bsse_vs_R.csv"

# Initial guesses (Strategy B — physical channels)
# erf handles long-R Coulomb-like tail; Gaussian handles short-R bulk.
# Verified seed-insensitive: multiple seeds converged to the same minimum.
A1_INIT = 1.0    # kcal/mol  (erf amplitude)
B1_INIT = 0.3    # A^-1      (erf decay)
A2_INIT = 12.0   # kcal/mol  (Gaussian amplitude)
B2_INIT = 0.75   # A^-2      (Gaussian decay)


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
def gaussian_erf(R: np.ndarray, a1: float, b1: float,
                 a2: float, b2: float) -> np.ndarray:
    """|BSSE|(R) = a1 * [1 + erf(-b1 R)] + a2 * exp(-b2 R^2).

    Two-channel combined form (Heindel erf + Gaussian).
    """
    return a1 * (1.0 + erf(-b1 * R)) + a2 * np.exp(-b2 * R**2)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_data() -> tuple[np.ndarray, np.ndarray]:
    """Return (R, |BSSE_total|) in (A, kcal/mol)."""
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH)
    R = df["R"].to_numpy()
    bsse_total_abs = np.abs(df["bsse_total"].to_numpy())
    return R, bsse_total_abs


# ---------------------------------------------------------------------------
# Conditioning check
# ---------------------------------------------------------------------------
def check_conditioning(params: dict[str, tuple[float, float]]) -> list[str]:
    """Flag parameters where sigma >= |p| (data does not constrain them).

    Returns list of warning strings; empty list if all parameters are
    well-conditioned.
    """
    warnings = []
    for name, (p, sigma) in params.items():
        if abs(p) < 1e-12:
            ratio = float("inf") if sigma > 0 else 0.0
        else:
            ratio = sigma / abs(p)
        if ratio >= 1.0:
            warnings.append(
                f"    {name}: sigma/|p| = {ratio:.2f}  "
                f"(p = {p:.4f}, sigma = {sigma:.4f}) — UNCONSTRAINED"
            )
    return warnings


# ---------------------------------------------------------------------------
# Stage 1: nonlinear least squares
# ---------------------------------------------------------------------------
def run_fit(R: np.ndarray, bsse: np.ndarray,
            a1_0: float, b1_0: float,
            a2_0: float, b2_0: float
            ) -> tuple[float, float, float, float,
                       float, float, float, float, float]:
    """Nonlinear LS on |BSSE| = a1*[1+erf(-b1 R)] + a2*exp(-b2 R^2).

    Returns (a1, sigma_a1, b1, sigma_b1, a2, sigma_a2, b2, sigma_b2, rmse).
    """
    popt, pcov = curve_fit(gaussian_erf, R, bsse,
                           p0=[a1_0, b1_0, a2_0, b2_0],
                           maxfev=5000)
    a1, b1, a2, b2 = popt
    sigma_a1, sigma_b1, sigma_a2, sigma_b2 = np.sqrt(np.diag(pcov))

    pred = gaussian_erf(R, a1, b1, a2, b2)
    residuals = bsse - pred
    rmse = float(np.sqrt(np.mean(residuals**2)))

    print("=" * 60)
    print("STAGE 1 — NONLINEAR LS FIT (combined Gaussian + erf):")
    print("  |BSSE| = a1 * [1 + erf(-b1 R)] + a2 * exp(-b2 R^2)")
    print("=" * 60)
    print(f"  Initial guess (Strategy B):")
    print(f"    a1_0 = {a1_0:.4f} kcal/mol,  b1_0 = {b1_0:.4f} A^-1")
    print(f"    a2_0 = {a2_0:.4f} kcal/mol,  b2_0 = {b2_0:.4f} A^-2")
    print(f"  Points used: {len(R)} (no filter)")
    print()
    print(f"  a1           = {a1: .6f} +/- {sigma_a1: .6f}  kcal/mol")
    print(f"  b1           = {b1: .6f} +/- {sigma_b1: .6f}  A^-1")
    print(f"  a2           = {a2: .6f} +/- {sigma_a2: .6f}  kcal/mol")
    print(f"  b2           = {b2: .6f} +/- {sigma_b2: .6f}  A^-2")
    print(f"  RMSE         = {rmse: .6f}  kcal/mol")
    print()

    # Conditioning check
    cond = check_conditioning({
        "a1": (a1, sigma_a1),
        "b1": (b1, sigma_b1),
        "a2": (a2, sigma_a2),
        "b2": (b2, sigma_b2),
    })
    if cond:
        print("  CONDITIONING WARNING — parameter(s) not constrained by data:")
        for w in cond:
            print(w)
        print("    Interpretation: the data may not contain enough")
        print("    independent information to distinguish both channels.")
        print("    See Ne dimer write-up; consider polynomial-corrected")
        print("    Gaussian as alternative refinement.")
    else:
        print("  All parameters well-conditioned (sigma/|p| < 1).")
    print()
    print(f"  Note: fit is valid over R in [{R.min():.3f}, {R.max():.3f}] A.")
    print(f"        At R = 0 the form gives a1 + a2, but R = 0 is outside")
    print(f"        the data range and physically inaccessible. See write-up.")
    print()

    # Overlay plot
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(R, bsse, s=20, alpha=0.6, color="black",
               label=r"data ($|\mathrm{BSSE}_\mathrm{total}|$)")
    R_line = np.linspace(R.min(), R.max(), 400)
    ax.plot(R_line, gaussian_erf(R_line, a1, b1, a2, b2), "r-", lw=2,
            label=(fr"fit: $|\mathrm{{BSSE}}| = {a1:.3f}\,[1 + \mathrm{{erf}}({-b1:.3f}\,R)]"
                   fr" + {a2:.3f}\,\exp(-{b2:.3f}\,R^2)$"
                   "\n"
                   fr"($a_1 = {a1:.3f}$ kcal/mol, $b_1 = {b1:.3f}\,$\AA$^{{-1}}$,"
                   "\n"
                   fr"\ \ $a_2 = {a2:.3f}$ kcal/mol, $b_2 = {b2:.3f}\,$\AA$^{{-2}}$)"
                   "\n"
                   fr"RMSE $= {rmse:.4f}$ kcal/mol"))
    ax.axhline(1.0, color="red", linestyle="--", alpha=0.5,
               label=r"1 kcal/mol threshold")
    ax.axhline(0.5, color="grey", linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$R_{\ce{Ne-Ne}}$ (\AA)")
    ax.set_ylabel(r"$|\mathrm{BSSE}|$ (kcal/mol)")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / "ne_dimer_gaussian_erf_fit.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()

    return a1, sigma_a1, b1, sigma_b1, a2, sigma_a2, b2, sigma_b2, rmse


# ---------------------------------------------------------------------------
# Stage 2: correlation plot
# ---------------------------------------------------------------------------
def run_correlation(R: np.ndarray, bsse: np.ndarray,
                    a1: float, b1: float,
                    a2: float, b2: float) -> float:
    """Predicted vs measured |BSSE|. Returns R^2_fit (linear-space)."""
    pred = gaussian_erf(R, a1, b1, a2, b2)
    ss_res = np.sum((bsse - pred) ** 2)
    ss_tot = np.sum((bsse - bsse.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot

    # OLS regression line for visual bias check
    m, c = np.polyfit(pred, bsse, 1)
    c_sign = "-" if c < 0 else "+"
    c_abs = abs(c)

    print("=" * 60)
    print("STAGE 2 — CORRELATION: measured vs predicted |BSSE|")
    print("=" * 60)
    print(f"  R^2_fit (linear space) = {r2: .6f}")
    print(f"  OLS regression line (visual only):"
          f"  measured = {m:.4f} * predicted + {c:.4f}")
    print()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(pred, bsse, s=25, alpha=0.6, color="black")
    lo = 0.0
    hi = max(bsse.max(), pred.max()) * 1.05

    x_line = np.linspace(lo, hi, 200)
    ax.plot(x_line, m * x_line + c, "r--", lw=1.5,
            label=fr"$y = {m:.4f}\,x {c_sign} {c_abs:.4f}$")
    ax.plot([], [], " ", label=fr"$R^2_\mathrm{{fit}} = {r2:.4f}$")

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(r"predicted $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_ylabel(r"measured $|\mathrm{BSSE}|$ (kcal/mol)")
    ax.set_aspect("equal", "box")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    out = SCRIPT_DIR / "ne_dimer_gaussian_erf_correlation.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"  saved: {out.name}")
    print()
    return r2


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",
                        choices=["fit", "correlation", "all"],
                        default="all",
                        help="Which stage to run")
    args = parser.parse_args()

    R, bsse = load_data()
    print(f"Loaded {len(R)} points from {CSV_PATH.name}")
    print(f"  R range:      [{R.min():.3f}, {R.max():.3f}] A")
    print(f"  |BSSE| range: [{bsse.min():.6f}, {bsse.max():.6f}] kcal/mol")
    print()

    a1 = b1 = a2 = b2 = None

    if args.stage in ("fit", "all"):
        a1, _, b1, _, a2, _, b2, _, _ = run_fit(
            R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT
        )

    if args.stage in ("correlation", "all"):
        if a1 is None:
            a1, _, b1, _, a2, _, b2, _, _ = run_fit(
                R, bsse, A1_INIT, B1_INIT, A2_INIT, B2_INIT
            )
        run_correlation(R, bsse, a1, b1, a2, b2)


if __name__ == "__main__":
    main()
