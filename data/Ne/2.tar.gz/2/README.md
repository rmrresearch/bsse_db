# Ne Dimer — `bsse_db/data/Ne/2/`

## Overview

This folder contains all NWChem input and output files for the Ne dimer
system, along with the complete reorganization and analysis pipeline.
Calculations are performed at the CCSD(T) level of theory. Both Ne atoms
are treated as **rigid** (single atoms) throughout.

Two datasets are present, differing in geometry sampling strategy and
basis set:

| Dataset | Folder | Basis | Configurations | Sampling |
|---|---|---|---|---|
| Translational grid | `translational/` | aug-cc-pVDZ | 268 | 3D displacement vector scan |
| Radial scan | `radial/` | aug-cc-pVTZ | 5 | z-axis distance scan |

The translational dataset is the one used for the BSSE fit study
documented at the end of this README; the radial dataset is used for
sanity checks and cross-basis reference.

---

## Geometry

Each configuration is defined by the displacement vector between the two
Ne atoms:

```
Ne  0.0  0.0  0.0
Ne  x    y    z
```

where `(x, y, z)` are the Cartesian components in Ångströms. The first Ne
atom is fixed at the origin; the second is placed at `(x, y, z)`.

### Translational dataset

Each of `x`, `y`, `z` takes values from {0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75} Å
in steps of 0.25 Å. Not all combinations are present — the dataset covers
268 configurations out of the full 7×7×7 = 343 possible grid points. Grid
coverage per slice can be analyzed with
`data_frames_plots/analyze_trnl_grid_coverage.py` once the data frames
are built.

### Radial dataset

Pure z-axis scan: x=0.0, y=0.0, z=R for R ∈ {1.5, 2.0, 2.5, 3.0, 3.5} Å.
5 configurations total.

---

## File Naming Convention

All NWChem files follow the `<real>_<basis>` convention defined in GitHub
Issue #46:

- `<real>` — the atom(s) with real electrons
- `<basis>` — the atom(s) contributing basis functions
- `.nw` — NWChem input file
- `.out` — NWChem output file

For the dimer (A = first Ne, B = second Ne), the 4 unique calculations per
configuration are:

| File | Description |
|---|---|
| `A_A.nw` / `A_A.out` | Monomer A in its own basis |
| `AB_AB.nw` / `AB_AB.out` | Full dimer in dimer basis |
| `A_AB.nw` / `A_AB.out` | Monomer A in dimer basis (ghost B) |
| `B_AB.nw` / `B_AB.out` | Monomer B in dimer basis (ghost A) |

Note: since both atoms are identical Ne, `A_A` covers both monomers —
no separate `B_B` calculation is needed.

---

## Configuration Labels

Each configuration is labeled `n_x_y_z` where:

- `n` is the configuration index (0-based, assigned by sorted order)
- `(x, y, z)` are the displacement vector components in Ångströms

**Translational example:** `0_0.25_0.25_1.5` → index 0, displacement (0.25, 0.25, 1.5) Å

**Radial example:** `3_0.0_0.0_3.0` → index 3, displacement (0.0, 0.0, 3.0) Å

---

## Folder Structure

```
2/
├── original_data/              ← original tarballs (backup)
│   ├── Ne_dimers.tar           ← translational dataset (aug-cc-pVDZ)
│   └── Ne_pvtz_dimers.tar      ← radial dataset (aug-cc-pVTZ)
├── translational/              ← aug-cc-pVDZ reorganized configurations
│   ├── 0_0.25_0.25_1.5/
│   │   └── CCSD_T/
│   │       └── aug-cc-pvdz/
│   │           ├── A_A.nw / A_A.out
│   │           ├── AB_AB.nw / AB_AB.out
│   │           ├── A_AB.nw / A_AB.out
│   │           └── B_AB.nw / B_AB.out
│   └── ... (268 configurations total)
├── radial/                     ← aug-cc-pVTZ reorganized configurations
│   ├── 0_0.0_0.0_1.5/
│   │   └── CCSD_T/
│   │       └── aug-cc-pvtz/
│   │           ├── A_A.nw / A_A.out
│   │           ├── AB_AB.nw / AB_AB.out
│   │           ├── A_AB.nw / A_AB.out
│   │           └── B_AB.nw / B_AB.out
│   └── ... (5 configurations total)
├── pymol_xyz/                  ← 268 .xyz files (translational)
├── pymol_radial_xyz/           ← 5 .xyz files (radial)
├── data_frames_plots/          ← parsed CSVs, analysis scripts, plots (see below)
├── load_dimers.pml             ← PyMOL loader for translational configs
├── load_radial.pml             ← PyMOL loader for radial configs
└── scripts/
    ├── copy_rename_files.py
    ├── copy_rename_files_pvtz.py
    ├── verify_copy.py
    ├── make_pymol_xyz.py
    └── make_pymol_radial_xyz.py
```

**Note on `original_data/`:** Contains the original tarballs in their
pre-reorganization form. `Ne_dimers.tar` is a plain tar (not gzip);
`Ne_pvtz_dimers.tar` is also a plain tar. Both are preserved as backup;
the canonical files for the pipeline are in `translational/` and `radial/`.

---

## Scripts (`scripts/`)

### `scripts/copy_rename_files.py`
Reorganizes the translational `Ne_Ne_distance_x_y_z/` folders into
`translational/n_x_y_z/CCSD_T/aug-cc-pvdz/`. Assigns indices by sorted
order of the original folder names. Originals are copied to `original_data/`
as backup.

### `scripts/copy_rename_files_pvtz.py`
Extracts the radial pvtz dataset directly from `original_data/Ne_pvtz_dimers.tar`
into `radial/n_0.0_0.0_R/CCSD_T/aug-cc-pvtz/`. Configurations are sorted
by R value numerically.

### `scripts/verify_copy.py`
Byte-by-byte verification of all translational copied files using
`filecmp.cmp()`. Result: **2144/2144 files verified OK ✅**

### `scripts/make_pymol_xyz.py`
Extracts geometries from each translational `AB_AB.nw` and writes
`pymol_xyz/n_x_y_z.xyz`. Also generates `load_dimers.pml`.

### `scripts/make_pymol_radial_xyz.py`
Extracts geometries from each radial `AB_AB.nw` and writes
`pymol_radial_xyz/n_x_y_z.xyz`. Also generates `load_radial.pml`.

---

## Visualization

To load translational configurations in PyMOL, run from `Ne/2/`:

```bash
pymol load_dimers.pml
```

To load radial configurations in PyMOL, run from `Ne/2/`:

```bash
pymol load_radial.pml
```

---

## Downstream Pipeline

Two shared upstream modules at `bsse_db/data/` (parent of the species
folders) provide the pickle-level BSSE data used by the Ne translational
CSV builder:

| Script | Input | Output | Description |
|---|---|---|---|
| `open_pickle_data.py` | `raw_data_Ne.pickle` | dict | Utility loader for the raw NWChem-parsed pickle |
| `two_body_bsse.py` | `many_body_interactions_Ne.pickle` | dict | Computes 2-body BSSE (VMFC-corrected difference `no_vmfc − vmfc`) |

These modules are shared across the Ne studies (2, 3, 4-body). The
`raw_data_Ne.pickle` and `many_body_interactions_Ne.pickle` pickles at
`bsse_db/data/` are the parsed and BSSE-computed versions of the raw
NWChem outputs for the whole Ne family.

The `data_frames_plots/` folder inside `Ne/2/` then chains the
translational and radial datasets from those pickles into the CSV and
figure products used by the fit study:

| Script | Input | Output | Description |
|---|---|---|---|
| `build_trnl_dataframe.py` | `raw_data_Ne.pickle`, `many_body_interactions_Ne.pickle` | `trnl_{SCF,MP2,CCSD_T}_aug-cc-pvdz.csv` | Per-method CSVs for the 268 translational configs (Hartree) |
| `build_radial_dataframe.py` | `raw_data_Ne.pickle`, `many_body_interactions_Ne.pickle` | `radial_{SCF,MP2,CCSD_T}_aug-cc-pvtz.csv` | Per-method CSVs for the 5 radial configs (Hartree) |
| `build_bsse_vs_R.py` | `trnl_{SCF,MP2,CCSD_T}_aug-cc-pvdz.csv` | `ne_dimer_bsse_vs_R.csv`, `ne_dimer_bsse_vs_R.png`, `ne_dimer_component_breakdown.png` | Consolidated per-config dataset (adds R = √(x² + y² + z²)), unit conversion Hartree → kcal/mol, component decomposition figures |
| `analyze_trnl_grid_coverage.py` | `trnl_*.csv` | grid coverage report | Reports which of the 343 possible (x, y, z) grid points are present in the 268-config sample |
| `plot_trnl_contours.py` | `trnl_*.csv` | `contour_xz_y*.png` | 2D BSSE contour slices at fixed y values |
| `plot_radial_bsse_vs_R.py` | `radial_*.csv` | `radial_bsse_vs_R_Ne_aug-cc-pvtz_signed.png` | 5-point aug-cc-pVTZ radial reference |

All scripts anchor their paths via `Path(__file__).resolve().parent` and
run from their own directory, so no path editing is required.

---

## BSSE Fit Study

The scientific contribution of this folder is the empirical
characterization of `|BSSE|(R)` for the Ne dimer via three least-squares
fits, applied to the total CCSD(T) BSSE at aug-cc-pVDZ. All three fits
are run from within `data_frames_plots/`, each in its own subfolder,
consuming `ne_dimer_bsse_vs_R.csv` (268 rows, kcal/mol).

### Fit forms

Three candidate functional forms are examined:

1. **Pure Gaussian** — `|BSSE|(R) = a · exp(−b R²)`
2. **Heindel–Xantheas erf** — `|BSSE|(R) = a · [1 + erf(−b R)]`
3. **Combined Gaussian + erf** —
   `|BSSE|(R) = a₁ · [1 + erf(−b₁ R)] + a₂ · exp(−b₂ R²)`

The combined form is the main finding.

### Physical motivation (brief)

The Hartree–Fock energy is built from kinetic-energy, overlap,
nuclear-attraction, and two-electron Coulomb integrals over the atomic
basis. Under the Gaussian product theorem, primitive 1s Gaussians
centered at Rₐ and R_b produce a two-center distance dependence that
splits into two structurally distinct classes:

- **Gaussian decay** — from the kinetic-energy and overlap integrals
- **Error-function decay** — from the nuclear-attraction and two-electron
  Coulomb integrals (via the Boys function F₀, which is proportional to
  an erf of a scaled inter-center distance)

A fit form that includes both classes therefore captures the two
qualitatively distinct integral-level dependencies expected in the HF
Hamiltonian, and (since MP2 and CCSD(T) are built on the same SCF
wavefunction) these signatures are expected to persist through the
correlated components. This is the empirical motivation for the combined
form, not a first-principles derivation.

Full argument, references (Szabo & Ostlund; Boys 1950; Besalú &
Carbó-Dorca 2011; Heindel & Xantheas 2020; Iwata et al. 2026), and
figures live in the paper's `sections/dimer/results_ne_dimer.tex`.

### Fit scripts

Each fit form lives in its own subfolder under `data_frames_plots/`:

| Subfolder | Script | Stages | Outputs |
|---|---|---|---|
| `gaussian_fit/` | `fit_gaussian.py` | `diagnostic`, `fit`, `correlation`, `all` | `ne_dimer_gaussian_diagnostic.png`, `ne_dimer_gaussian_fit.png`, `ne_dimer_gaussian_correlation.png` |
| `erf_fit/` | `fit_erf.py` | `fit`, `correlation`, `all` | `ne_dimer_erf_fit.png`, `ne_dimer_erf_correlation.png` |
| `gaussian_erf_fit/` | `fit_gaussian_erf.py` | `fit`, `correlation`, `all` | `ne_dimer_gaussian_erf_fit.png`, `ne_dimer_gaussian_erf_correlation.png` |

Each script takes `--stage {…}` to run one or all stages independently.

**Stage semantics:**

- **`diagnostic`** (Gaussian only) — OLS fit of `ln|BSSE|` vs `R²` for a
  log-space linearity check. Points with `|BSSE| ≤ 0.01 kcal/mol` are
  dropped for log safety. The OLS slope and intercept seed the nonlinear
  fit stage. Verdict thresholds: `R² ≥ 0.9` = strong support,
  `0.8 ≤ R² < 0.9` = acceptable, `< 0.8` = stop and reassess. The erf and
  combined forms don't admit a log-linear diagnostic and skip this stage.
- **`fit`** — nonlinear least squares on `|BSSE_total|` over all 268
  points (no filter). Reports parameters ± σ and RMSE.
- **`correlation`** — predicted vs measured `|BSSE|` scatter, with an
  OLS regression line for visual bias check and `R²_fit` (linear-space).

### Initial guesses

| Fit | Parameter guesses | Rationale |
|---|---|---|
| Gaussian | derived from diagnostic OLS slope/intercept | Data-driven seed |
| Erf | `a₀ = 2.5 kcal/mol`, `b₀ = 0.5 Å⁻¹` | Seed-insensitive in this regime (verified across multiple seeds) |
| Combined | `a₁ = 1.0 kcal/mol`, `b₁ = 0.3 Å⁻¹`, `a₂ = 12.0 kcal/mol`, `b₂ = 0.75 Å⁻²` | Strategy B: erf handles the long-R Coulomb-like tail; Gaussian handles the short-R bulk |

### Results

| Fit | RMSE (kcal/mol) | Notes |
|---|---:|---|
| Gaussian, `a exp(−b R²)` | 0.0633 | `a = 12.313 kcal/mol`, `b = 0.753 Å⁻²`. Systematic underprediction at `R ≳ 2.2 Å`. |
| Erf, `a [1 + erf(−b R)]` | 0.0622 | `a = 25.228 kcal/mol`, `b = 0.798 Å⁻¹`. Same underprediction pattern in the tail. |
| Combined | **0.0484** | `a₁ = 0.068`, `b₁ = −0.223`, `a₂ = 15.685`, `b₂ = 0.866`. ~23% RMSE improvement over the individual fits; reproduces the tail. |

The combined form reduces RMSE by approximately 23% relative to each
single-form fit and reproduces the data across the full sampled range,
including the tail region where the single-form fits systematically
underpredict `|BSSE|(R)`. This is the main finding.

### Interpretation caveats (baked into the fit scripts)

- **Erf `a` is a formal R = 0 limit.** The Heindel form evaluates to `a`
  at R = 0 (since erf(0) = 0). The sampled R range is
  `R ∈ [1.500, 3.031] Å`; the fitted `a` is a mathematical extrapolation,
  not a physically meaningful BSSE (Ne atoms cannot overlap).
- **Combined-fit parameters are not independently physical.** At R = 0
  the combined form gives `a₁ + a₂`, again outside the data range. The
  fitted `a₁ = 0.068` and `b₁ = −0.223` in the combined fit are
  substantially smaller (and `b₁` has a different sign) than those of
  the isolated erf fit — the optimizer distributes most of the amplitude
  onto the Gaussian channel and uses the erf contribution as a small
  correction that extends the reach of the fit into the tail. Individual
  parameter values in the combined fit should not be compared
  quantitatively to those of the isolated fits.
- **Conditioning check.** `fit_gaussian_erf.py` runs a conditioning check
  and flags any parameter with `σ/|p| ≥ 1` as unconstrained by the data.
  For the current 268-point Ne dataset, all four parameters are
  well-conditioned.
- **Scope.** The fits are empirical characterizations of `|BSSE|(R)` on
  the sampled range `R ∈ [1.5, 3.0] Å`, which lies inside the Ne–Ne
  equilibrium distance (`Rₑ ≈ 2.9–3.1 Å` per Wüest & Merkt 2003, so the
  sampled configurations sit on the repulsive wall). The fits are not
  predictive outside this range, and individual parameter values are
  not physical constants.

---

## Exploratory analyses not in the paper

The `data_frames_plots/` folder also contains exploratory analyses that
were investigated but are not part of the current paper. They are
preserved for repository completeness but should not be treated as
scientific results of this study:

- **`poly_gaussian_fit/`** — a polynomial-corrected Gaussian fit form
  explored as an alternative refinement. Not featured in the paper.
- **`compute_rho_R.py`, `ne_dimer_rho_R.csv`, `ne_dimer_rho_R.png`** — a
  study of the ratio ρ(R) = `|BSSE(CCSD(T))| / |BSSE(MP2)|` as a
  function of R. The hypothesis that ρ(R) is approximately constant was
  tested and found not to hold; the study was removed from the Ne
  section of the paper.
- **Contour plots** (`contour_xz_y1.5_*`, `contour_xz_y1.75_*`) — 2D
  BSSE slices at fixed y values for each of the three methods (SCF,
  MP2, CCSD(T)), produced by `plot_trnl_contours.py`. Diagnostic
  visualizations, not paper figures.

These files are kept in the repository for reproducibility of prior
exploratory work but should be treated as inactive.

---

## Tarball

The tarball `bsse_db/data/Ne/2.tar.gz` is created from `bsse_db/data/Ne/`
with:

```bash
tar -czf 2.tar.gz 2
```

Internal paths are of the form:
- `2/translational/n_x_y_z/CCSD_T/aug-cc-pvdz/REAL_BASIS.out`
- `2/radial/n_x_y_z/CCSD_T/aug-cc-pvtz/REAL_BASIS.out`

The tarball preserves everything in the folder, including the fit-study
outputs and the exploratory analyses documented above.

---

## References

- Valiron & Mayer (1997) *Chem. Phys. Lett.* **275**, 46–55 — VMFC method
- Richard, Bakr & Sherrill (2018) *J. Chem. Theory Comput.* **14**, 2386 — PI's unified framework
- Boys (1950) *Proc. R. Soc. A* **200**, 542–554 — Gaussian product theorem
- Szabo & Ostlund (1996) *Modern Quantum Chemistry* — HF integral evaluation (Appendix A)
- Besalú & Carbó-Dorca (2011) *J. Math. Chem.* **49**, 1769–1784 — Generalized Gaussian product theorem
- Heindel & Xantheas (2020) *J. Chem. Theory Comput.* **16**, 6843–6855 — Empirical erf fit for 2-body BSSE in water clusters
- Wüest & Merkt (2003) *J. Chem. Phys.* **118**, 8807–8812 — Ne–Ne equilibrium distance
- van Mourik, Wilson & Dunning (1999) *Mol. Phys.* **96**, 529–547 — aug-cc-pVxZ BSSE benchmark for Ne
- Ema et al. (2023) *ChemPhysChem* **24**, e202300485 — BSSE at small Dunning bases
- Iwata, Kano & Matsuzawa (2026) *J. Comput. Chem.* **47**, e70292 — CP correction on Ne₂ binding-energy curves
- GitHub Issue #46 — PI's revised task list and file naming conventions
