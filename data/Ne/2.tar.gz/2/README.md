# Ne Dimer — `bsse_db/data/Ne/2/`

## Overview

This folder contains all NWChem input and output files for the Ne dimer
system, along with the complete reorganization and analysis pipeline.
Calculations are performed at the CCSD(T) level of theory. Both Ne atoms
are treated as **rigid** (single atoms) throughout.

Two datasets are present, differing in geometry sampling strategy and
basis set:

| Dataset | Folder | Basis | Configurations | Sampling |
|---|---|---|---|---|
| Translational grid | `translational/` | aug-cc-pVDZ | 268 | 3D displacement vector scan |
| Radial scan | `radial/` | aug-cc-pVTZ | 5 | z-axis distance scan |

---

## Geometry

Each configuration is defined by the displacement vector between the two
Ne atoms:

```
Ne  0.0  0.0  0.0
Ne  x    y    z
```

where `(x, y, z)` are the Cartesian components in Ångströms. The first Ne
atom is fixed at the origin; the second is placed at `(x, y, z)`.

### Translational dataset

Each of `x`, `y`, `z` takes values from {0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75} Å
in steps of 0.25 Å. Not all combinations are present — the dataset covers
268 configurations out of the full 7×7×7 = 343 possible grid points. Grid
coverage per slice can be analyzed with
`data_frames_plots/analyze_trnl_grid_coverage.py` once the data frames
are built.

### Radial dataset

Pure z-axis scan: x=0.0, y=0.0, z=R for R ∈ {1.5, 2.0, 2.5, 3.0, 3.5} Å.
5 configurations total.

---

## File Naming Convention

All NWChem files follow the `<real>_<basis>` convention defined in GitHub
Issue #46:

- `<real>` — the atom(s) with real electrons
- `<basis>` — the atom(s) contributing basis functions
- `.nw` — NWChem input file
- `.out` — NWChem output file

For the dimer (A = first Ne, B = second Ne), the 4 unique calculations per
configuration are:

| File | Description |
|---|---|
| `A_A.nw` / `A_A.out` | Monomer A in its own basis |
| `AB_AB.nw` / `AB_AB.out` | Full dimer in dimer basis |
| `A_AB.nw` / `A_AB.out` | Monomer A in dimer basis (ghost B) |
| `B_AB.nw` / `B_AB.out` | Monomer B in dimer basis (ghost A) |

Note: since both atoms are identical Ne, `A_A` covers both monomers —
no separate `B_B` calculation is needed.

---

## Configuration Labels

Each configuration is labeled `n_x_y_z` where:

- `n` is the configuration index (0-based, assigned by sorted order)
- `(x, y, z)` are the displacement vector components in Ångströms

**Translational example:** `0_0.25_0.25_1.5` → index 0, displacement (0.25, 0.25, 1.5) Å

**Radial example:** `3_0.0_0.0_3.0` → index 3, displacement (0.0, 0.0, 3.0) Å

---

## Folder Structure

```
2/
├── original_data/              ← original tarballs (backup)
│   ├── Ne_dimers.tar           ← translational dataset (aug-cc-pVDZ)
│   └── Ne_pvtz_dimers.tar      ← radial dataset (aug-cc-pVTZ)
├── translational/              ← aug-cc-pVDZ reorganized configurations
│   ├── 0_0.25_0.25_1.5/
│   │   └── CCSD_T/
│   │       └── aug-cc-pvdz/
│   │           ├── A_A.nw / A_A.out
│   │           ├── AB_AB.nw / AB_AB.out
│   │           ├── A_AB.nw / A_AB.out
│   │           └── B_AB.nw / B_AB.out
│   └── ... (268 configurations total)
├── radial/                     ← aug-cc-pVTZ reorganized configurations
│   ├── 0_0.0_0.0_1.5/
│   │   └── CCSD_T/
│   │       └── aug-cc-pvtz/
│   │           ├── A_A.nw / A_A.out
│   │           ├── AB_AB.nw / AB_AB.out
│   │           ├── A_AB.nw / A_AB.out
│   │           └── B_AB.nw / B_AB.out
│   └── ... (5 configurations total)
├── pymol_xyz/                  ← 268 .xyz files (translational)
├── pymol_radial_xyz/           ← 5 .xyz files (radial)
├── data_frames_plots/          ← parsed CSVs, analysis scripts, plots
├── load_dimers.pml             ← PyMOL loader for translational configs
├── load_radial.pml             ← PyMOL loader for radial configs
└── scripts/
    ├── copy_rename_files.py
    ├── copy_rename_files_pvtz.py
    ├── verify_copy.py
    ├── make_pymol_xyz.py
    └── make_pymol_radial_xyz.py
```

**Note on `original_data/`:** Contains the original tarballs in their
pre-reorganization form. `Ne_dimers.tar` is a plain tar (not gzip); 
`Ne_pvtz_dimers.tar` is also a plain tar. Both are preserved as backup;
the canonical files for the pipeline are in `translational/` and `radial/`.

---

## Scripts (`scripts/`)

### `scripts/copy_rename_files.py`
Reorganizes the translational `Ne_Ne_distance_x_y_z/` folders into
`translational/n_x_y_z/CCSD_T/aug-cc-pvdz/`. Assigns indices by sorted
order of the original folder names. Originals are copied to `original_data/`
as backup.

### `scripts/copy_rename_files_pvtz.py`
Extracts the radial pvtz dataset directly from `original_data/Ne_pvtz_dimers.tar`
into `radial/n_0.0_0.0_R/CCSD_T/aug-cc-pvtz/`. Configurations are sorted
by R value numerically.

### `scripts/verify_copy.py`
Byte-by-byte verification of all translational copied files using
`filecmp.cmp()`. Result: **2144/2144 files verified OK ✅**

### `scripts/make_pymol_xyz.py`
Extracts geometries from each translational `AB_AB.nw` and writes
`pymol_xyz/n_x_y_z.xyz`. Also generates `load_dimers.pml`.

### `scripts/make_pymol_radial_xyz.py`
Extracts geometries from each radial `AB_AB.nw` and writes
`pymol_radial_xyz/n_x_y_z.xyz`. Also generates `load_radial.pml`.

---

## Visualization

To load translational configurations in PyMOL, run from `Ne/2/`:

```bash
pymol load_dimers.pml
```

To load radial configurations in PyMOL, run from `Ne/2/`:

```bash
pymol load_radial.pml
```

---

## Downstream Pipeline

The following scripts in `bsse_db/data/` process this folder (to be added):

| Script | Input | Output | Description |
|---|---|---|---|
| `build_raw_data_Ne_2.py` | `2.tar.gz` | `raw_data_Ne_2.pickle` | Extracts SCF, MP2, CCSD(T) energies for both datasets |
| `two_body_bsse_Ne_2.py` | `raw_data_Ne_2.pickle` | `two_body_bsse_Ne_2.pickle` | Computes 2-body BSSE (FORM I and FORM II) |
| `build_dimer_dataframe_Ne_2.py` | `two_body_bsse_Ne_2.pickle` | CSVs in `data_frames_plots/` | Builds analysis dataframes |

---

## Tarball

The tarball `bsse_db/data/Ne/2.tar.gz` is created from `bsse_db/data/Ne/`
with:

```bash
tar -czf 2.tar.gz 2
```

Internal paths are of the form:
- `2/translational/n_x_y_z/CCSD_T/aug-cc-pvdz/REAL_BASIS.out`
- `2/radial/n_x_y_z/CCSD_T/aug-cc-pvtz/REAL_BASIS.out`

---

## References

- Valiron & Mayer (1997) *Chem. Phys. Lett.* **275**, 46–55 — VMFC method
- Richard, Bakr & Sherrill (2018) *J. Chem. Theory Comput.* **14**, 2386 — PI's unified framework
- GitHub Issue #46 — PI's revised task list and file naming conventions